/* Emacs: this is -*- C -*- code, */
/* generated 2014-05-17T03:04:33-07 by Liar version 4.118. */

#include "liarc.h"

#define LABEL_1_4 3
#define ENVIRONMENT_LABEL_1_3 6
#define DEBUGGING_LABEL_1_2 5
#define OBJECT_1_0 4
#define FREE_REFERENCES_LABEL_1_0 4
#define NUMBER_OF_LINKER_SECTIONS_1_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_1 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_1_4);
      goto lambda_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (lambda_3)
DEFLABEL (lambda_0)
  INTERRUPT_CHECK (26, LABEL_1_4);
  Rvl = (current_block [OBJECT_1_0]);
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_2_4 3
#define ENVIRONMENT_LABEL_2_3 6
#define DEBUGGING_LABEL_2_2 5
#define OBJECT_2_0 4
#define FREE_REFERENCES_LABEL_2_0 4
#define NUMBER_OF_LINKER_SECTIONS_2_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_2 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_2_4);
      goto lambda_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (lambda_3)
DEFLABEL (lambda_0)
  INTERRUPT_CHECK (26, LABEL_2_4);
  Rvl = (current_block [OBJECT_2_0]);
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_3_4 3
#define ENVIRONMENT_LABEL_3_3 6
#define DEBUGGING_LABEL_3_2 5
#define OBJECT_3_0 4
#define FREE_REFERENCES_LABEL_3_0 4
#define NUMBER_OF_LINKER_SECTIONS_3_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_3 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_3_4);
      goto lambda_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (lambda_3)
DEFLABEL (lambda_0)
  INTERRUPT_CHECK (26, LABEL_3_4);
  Rvl = (current_block [OBJECT_3_0]);
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_4_4 3
#define ENVIRONMENT_LABEL_4_3 6
#define DEBUGGING_LABEL_4_2 5
#define OBJECT_4_0 4
#define FREE_REFERENCES_LABEL_4_0 4
#define NUMBER_OF_LINKER_SECTIONS_4_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_4 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_4_4);
      goto lambda_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (lambda_3)
DEFLABEL (lambda_0)
  INTERRUPT_CHECK (26, LABEL_4_4);
  Rvl = (current_block [OBJECT_4_0]);
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_5_4 3
#define ENVIRONMENT_LABEL_5_3 6
#define DEBUGGING_LABEL_5_2 5
#define OBJECT_5_0 4
#define FREE_REFERENCES_LABEL_5_0 4
#define NUMBER_OF_LINKER_SECTIONS_5_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_5 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_5_4);
      goto lambda_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (lambda_3)
DEFLABEL (lambda_0)
  INTERRUPT_CHECK (26, LABEL_5_4);
  Rvl = (current_block [OBJECT_5_0]);
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_6_4 3
#define ENVIRONMENT_LABEL_6_3 6
#define DEBUGGING_LABEL_6_2 5
#define OBJECT_6_0 4
#define FREE_REFERENCES_LABEL_6_0 4
#define NUMBER_OF_LINKER_SECTIONS_6_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_6 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_6_4);
      goto lambda_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (lambda_3)
DEFLABEL (lambda_0)
  INTERRUPT_CHECK (26, LABEL_6_4);
  Rvl = (current_block [OBJECT_6_0]);
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_7_4 3
#define ENVIRONMENT_LABEL_7_3 6
#define DEBUGGING_LABEL_7_2 5
#define OBJECT_7_0 4
#define FREE_REFERENCES_LABEL_7_0 4
#define NUMBER_OF_LINKER_SECTIONS_7_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_7 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_7_4);
      goto lambda_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (lambda_3)
DEFLABEL (lambda_0)
  INTERRUPT_CHECK (26, LABEL_7_4);
  Rvl = (current_block [OBJECT_7_0]);
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_8_4 3
#define ENVIRONMENT_LABEL_8_3 7
#define DEBUGGING_LABEL_8_2 6
#define OBJECT_8_1 5
#define OBJECT_8_0 4
#define FREE_REFERENCES_LABEL_8_0 4
#define NUMBER_OF_LINKER_SECTIONS_8_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_8 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_8_4);
      goto cache_tag_index_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_tag_index_3)
DEFLABEL (cache_tag_index_0)
  INTERRUPT_CHECK (26, LABEL_8_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_8_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd18.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_8_1]), 2);

DEFLABEL (label_5)
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd16.Lng))))
    goto label_4;
  Rvl = ((Wrd14.pObj) [2]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_9_4 3
#define ENVIRONMENT_LABEL_9_3 7
#define DEBUGGING_LABEL_9_2 6
#define OBJECT_9_1 5
#define OBJECT_9_0 4
#define FREE_REFERENCES_LABEL_9_0 4
#define NUMBER_OF_LINKER_SECTIONS_9_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_9 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_9_4);
      goto cache_mask_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_mask_3)
DEFLABEL (cache_mask_0)
  INTERRUPT_CHECK (26, LABEL_9_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_9_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd18.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_9_1]), 2);

DEFLABEL (label_5)
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd16.Lng))))
    goto label_4;
  Rvl = ((Wrd14.pObj) [3]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_10_4 3
#define ENVIRONMENT_LABEL_10_3 7
#define DEBUGGING_LABEL_10_2 6
#define OBJECT_10_1 5
#define OBJECT_10_0 4
#define FREE_REFERENCES_LABEL_10_0 4
#define NUMBER_OF_LINKER_SECTIONS_10_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_10 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_10_4);
      goto cache_limit_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_limit_3)
DEFLABEL (cache_limit_0)
  INTERRUPT_CHECK (26, LABEL_10_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_10_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd18.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_10_1]), 2);

DEFLABEL (label_5)
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 3L) < ((unsigned long) (Wrd16.Lng))))
    goto label_4;
  Rvl = ((Wrd14.pObj) [4]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_11_4 3
#define ENVIRONMENT_LABEL_11_3 7
#define DEBUGGING_LABEL_11_2 6
#define OBJECT_11_1 5
#define OBJECT_11_0 4
#define FREE_REFERENCES_LABEL_11_0 4
#define NUMBER_OF_LINKER_SECTIONS_11_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_11 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_11_4);
      goto cache_n_tags_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_n_tags_3)
DEFLABEL (cache_n_tags_0)
  INTERRUPT_CHECK (26, LABEL_11_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_11_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd18.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_11_1]), 2);

DEFLABEL (label_5)
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 4L) < ((unsigned long) (Wrd16.Lng))))
    goto label_4;
  Rvl = ((Wrd14.pObj) [5]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_12_4 3
#define ENVIRONMENT_LABEL_12_3 7
#define DEBUGGING_LABEL_12_2 6
#define OBJECT_12_1 5
#define OBJECT_12_0 4
#define FREE_REFERENCES_LABEL_12_0 4
#define NUMBER_OF_LINKER_SECTIONS_12_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_12 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_12_4);
      goto cache_tags_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_tags_3)
DEFLABEL (cache_tags_0)
  INTERRUPT_CHECK (26, LABEL_12_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_12_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd18.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_12_1]), 2);

DEFLABEL (label_5)
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd16.Lng))))
    goto label_4;
  Rvl = ((Wrd14.pObj) [6]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_13_4 3
#define ENVIRONMENT_LABEL_13_3 7
#define DEBUGGING_LABEL_13_2 6
#define OBJECT_13_1 5
#define OBJECT_13_0 4
#define FREE_REFERENCES_LABEL_13_0 4
#define NUMBER_OF_LINKER_SECTIONS_13_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_13 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_13_4);
      goto cache_values_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_values_3)
DEFLABEL (cache_values_0)
  INTERRUPT_CHECK (26, LABEL_13_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_13_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd18.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_13_1]), 2);

DEFLABEL (label_5)
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd16.Lng))))
    goto label_4;
  Rvl = ((Wrd14.pObj) [7]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_14_4 3
#define ENVIRONMENT_LABEL_14_3 7
#define DEBUGGING_LABEL_14_2 6
#define OBJECT_14_1 5
#define OBJECT_14_0 4
#define FREE_REFERENCES_LABEL_14_0 4
#define NUMBER_OF_LINKER_SECTIONS_14_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_14 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_14_4);
      goto cache_overflow_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_overflow_3)
DEFLABEL (cache_overflow_0)
  INTERRUPT_CHECK (26, LABEL_14_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_14_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd18.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_14_1]), 2);

DEFLABEL (label_5)
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd16.Lng))))
    goto label_4;
  Rvl = ((Wrd14.pObj) [8]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_15_4 3
#define ENVIRONMENT_LABEL_15_3 8
#define DEBUGGING_LABEL_15_2 7
#define OBJECT_15_2 6
#define OBJECT_15_1 5
#define OBJECT_15_0 4
#define FREE_REFERENCES_LABEL_15_0 4
#define NUMBER_OF_LINKER_SECTIONS_15_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_15 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd10;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd19;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_15_4);
      goto set_cache_tag_indexB_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (set_cache_tag_indexB_3)
DEFLABEL (set_cache_tag_indexB_0)
  INTERRUPT_CHECK (26, LABEL_15_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_15_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd19.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd19.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_15_2]), 3);

DEFLABEL (label_5)
  (Wrd15.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd16.Obj) = ((Wrd15.pObj) [0]);
  (Wrd17.Lng) = (FIXNUM_TO_LONG (Wrd16.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd17.Lng))))
    goto label_4;
  (Wrd10.Obj) = (Rsp [2]);
  ((Wrd15.pObj) [2]) = (Wrd10.Obj);
  Rvl = (current_block [OBJECT_15_1]);
  Rsp = (& (Rsp [3]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_16_4 3
#define ENVIRONMENT_LABEL_16_3 8
#define DEBUGGING_LABEL_16_2 7
#define OBJECT_16_2 6
#define OBJECT_16_1 5
#define OBJECT_16_0 4
#define FREE_REFERENCES_LABEL_16_0 4
#define NUMBER_OF_LINKER_SECTIONS_16_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_16 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd10;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd19;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_16_4);
      goto set_cache_overflowB_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (set_cache_overflowB_3)
DEFLABEL (set_cache_overflowB_0)
  INTERRUPT_CHECK (26, LABEL_16_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_16_0]);
  (Rsp [1]) = (Wrd6.Obj);
  (Wrd19.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd19.uLng) == 62)
    goto label_5;

DEFLABEL (label_4)
  INVOKE_PRIMITIVE ((current_block [OBJECT_16_2]), 3);

DEFLABEL (label_5)
  (Wrd15.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd16.Obj) = ((Wrd15.pObj) [0]);
  (Wrd17.Lng) = (FIXNUM_TO_LONG (Wrd16.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd17.Lng))))
    goto label_4;
  (Wrd10.Obj) = (Rsp [2]);
  ((Wrd15.pObj) [8]) = (Wrd10.Obj);
  Rvl = (current_block [OBJECT_16_1]);
  Rsp = (& (Rsp [3]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_17_4 3
#define LABEL_17_5 5
#define LABEL_17_6 7
#define LABEL_17_7 9
#define ENVIRONMENT_LABEL_17_3 17
#define DEBUGGING_LABEL_17_2 16
#define OBJECT_17_3 15
#define OBJECT_17_2 14
#define OBJECT_17_1 13
#define OBJECT_17_0 12
#define FREE_REFERENCE_17_0 11
#define FREE_REFERENCES_LABEL_17_0 10
#define NUMBER_OF_LINKER_SECTIONS_17_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_17 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd42;
  machine_word Wrd41;
  machine_word Wrd30;
  machine_word Wrd38;
  machine_word Wrd37;
  machine_word Wrd36;
  machine_word Wrd40;
  machine_word Wrd39;
  machine_word Wrd29;
  machine_word Wrd27;
  machine_word Wrd25;
  machine_word Wrd50;
  machine_word Wrd21;
  machine_word Wrd20;
  machine_word Wrd9;
  machine_word Wrd14;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_17_4);
      goto cacheP_4;

    case 1:
      current_block = (Rpc - LABEL_17_5);
      goto label_6;

    case 2:
      current_block = (Rpc - LABEL_17_6);
      goto label_7;

    case 3:
      current_block = (Rpc - LABEL_17_7);
      goto label_8;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cacheP_10)
DEFLABEL (cacheP_4)
  INTERRUPT_CHECK (26, LABEL_17_4);
  (Wrd5.Obj) = (Rsp [0]);
  (Wrd6.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd6.uLng) == 62)
    goto label_13;

DEFLABEL (label_12)
  Rvl = ((SCHEME_OBJECT) 0);

DEFLABEL (label_11)
  Rsp = (& (Rsp [1]));
  goto pop_return;

DEFLABEL (label_13)
  if (! ((Wrd6.uLng) == 62))
    goto label_19;
  (Wrd12.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd13.Obj) = ((Wrd12.pObj) [0]);
  (Wrd14.uLng) = (OBJECT_DATUM (Wrd13.Obj));
  (Wrd9.Obj) = (MAKE_OBJECT (26, (Wrd14.uLng)));

DEFLABEL (label_18)
  (Wrd21.uLng) = (OBJECT_TYPE (Wrd9.Obj));
  if (! ((Wrd21.uLng) == 26))
    goto label_17;
  (Wrd50.Lng) = (FIXNUM_TO_LONG (Wrd9.Obj));
  if ((Wrd50.Lng) == 0)
    goto label_12;

DEFLABEL (label_16)
  (Wrd27.pObj) = ((SCHEME_OBJECT *) (current_block [FREE_REFERENCE_17_0]));
  (Wrd29.Obj) = ((Wrd27.pObj) [0]);
  (* (--Rsp)) = (Wrd29.Obj);
  (Wrd39.Obj) = (Rsp [1]);
  (Wrd40.uLng) = (OBJECT_TYPE (Wrd39.Obj));
  if (! ((Wrd40.uLng) == 62))
    goto label_15;
  (Wrd36.pObj) = (OBJECT_ADDRESS (Wrd39.Obj));
  (Wrd37.Obj) = ((Wrd36.pObj) [0]);
  (Wrd38.Lng) = (FIXNUM_TO_LONG (Wrd37.Obj));
  if (! (((unsigned long) 0L) < ((unsigned long) (Wrd38.Lng))))
    goto label_15;
  (Wrd30.Obj) = ((Wrd36.pObj) [1]);

DEFLABEL (label_14)
  (Wrd46.Obj) = (* (Rsp++));
  if (! ((Wrd30.Obj) == (Wrd46.Obj)))
    goto label_12;
  Rvl = (current_block [OBJECT_17_3]);
  goto label_11;

DEFLABEL (label_15)
  (Wrd41.Obj) = (Rsp [1]);
  (Wrd42.Obj) = (current_block [OBJECT_17_1]);
  (Wrd45.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_17_7]))));
  (* (--Rsp)) = (Wrd45.Obj);
  (* (--Rsp)) = (Wrd42.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_17_2]), 2);

DEFLABEL (label_8)
  (Wrd30.Obj) = Rvl;
  goto label_14;

DEFLABEL (label_17)
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_17_6]))));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd9.Obj);
  INVOKE_INTERFACE_0 (45);

DEFLABEL (label_7)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_16;
  goto label_12;

DEFLABEL (label_19)
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_17_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_17_0]), 1);

DEFLABEL (label_6)
  (Wrd9.Obj) = Rvl;
  goto label_18;

INVOKE_INTERFACE_TARGET_0
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_18_4 3
#define ENVIRONMENT_LABEL_18_3 10
#define DEBUGGING_LABEL_18_2 9
#define OBJECT_18_1 8
#define OBJECT_18_0 7
#define EXECUTE_CACHE_18_5 5
#define FREE_REFERENCES_LABEL_18_0 4
#define NUMBER_OF_LINKER_SECTIONS_18_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_18 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd7;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_18_4);
      goto new_cache_0;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (new_cache_3)
DEFLABEL (new_cache_0)
  INTERRUPT_CHECK (26, LABEL_18_4);
  (Wrd5.Obj) = (Rsp [0]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (current_block [OBJECT_18_0]);
  (* (--Rsp)) = (Wrd6.Obj);
  (Wrd7.Obj) = (current_block [OBJECT_18_1]);
  (Rsp [2]) = (Wrd7.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_18_5]));

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_19_4 3
#define LABEL_19_5 5
#define LABEL_19_6 7
#define LABEL_19_8 9
#define ENVIRONMENT_LABEL_19_3 22
#define DEBUGGING_LABEL_19_2 21
#define OBJECT_19_3 20
#define OBJECT_19_2 19
#define OBJECT_19_1 18
#define OBJECT_19_0 17
#define EXECUTE_CACHE_19_10 11
#define EXECUTE_CACHE_19_9 13
#define EXECUTE_CACHE_19_7 15
#define FREE_REFERENCES_LABEL_19_0 10
#define NUMBER_OF_LINKER_SECTIONS_19_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_19 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd23;
  machine_word Wrd21;
  machine_word Wrd18;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd10;
  machine_word Wrd29;
  machine_word Wrd8;
  machine_word Wrd7;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_19_4);
      goto make_cache_7;

    case 1:
      current_block = (Rpc - LABEL_19_5);
      goto continuation_5;

    case 2:
      current_block = (Rpc - LABEL_19_6);
      goto continuation_4;

    case 3:
      current_block = (Rpc - LABEL_19_8);
      goto continuation_6;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (make_cache_10)
DEFLABEL (make_cache_7)
  INTERRUPT_CHECK (26, LABEL_19_4);
  (Wrd5.Obj) = (Rsp [1]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (Rsp [3]);
  (Wrd7.Lng) = (FIXNUM_TO_LONG (Wrd6.Obj));
  (Wrd8.Obj) = (current_block [OBJECT_19_0]);
  if ((Wrd7.Lng) > 4L)
    goto label_12;
  (Wrd10.Obj) = (current_block [OBJECT_19_2]);
  (* (--Rsp)) = (Wrd10.Obj);

DEFLABEL (label_11)
  (Wrd11.Obj) = (Rsp [4]);
  (Wrd12.Lng) = (FIXNUM_TO_LONG (Wrd11.Obj));
  (Wrd13.Lng) = ((Wrd12.Lng) - 1L);
  (Wrd14.Obj) = (LONG_TO_FIXNUM (Wrd13.Lng));
  (* (--Rsp)) = (Wrd14.Obj);
  (Wrd15.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd15.Obj);
  (Wrd18.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_19_5]))));
  (* (--Rsp)) = (Wrd18.Obj);
  (Wrd21.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_19_6]))));
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  (Wrd23.Obj) = (Rsp [8]);
  (* (--Rsp)) = (Wrd23.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_19_7]));

DEFLABEL (continuation_4)
  INTERRUPT_CHECK (27, LABEL_19_6);
  (* (--Rsp)) = Rvl;
  (Wrd5.Obj) = (Rsp [8]);
  (* (--Rsp)) = (Wrd5.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_19_9]));

DEFLABEL (continuation_5)
  INTERRUPT_CHECK (27, LABEL_19_5);
  (Rsp [4]) = Rvl;
  (Wrd8.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_19_8]))));
  (* (--Rsp)) = (Wrd8.Obj);
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  (Wrd10.Obj) = (Rsp [8]);
  (* (--Rsp)) = (Wrd10.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_19_9]));

DEFLABEL (continuation_6)
  INTERRUPT_CHECK (27, LABEL_19_8);
  (Rsp [5]) = Rvl;
  (Wrd6.Obj) = (current_block [OBJECT_19_3]);
  (Rsp [6]) = (Wrd6.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_19_10]));

DEFLABEL (label_12)
  if ((Wrd7.Lng) > 16L)
    goto label_14;
  (* (--Rsp)) = (Wrd8.Obj);
  goto label_13;

DEFLABEL (label_14)
  (Wrd29.Obj) = (current_block [OBJECT_19_1]);
  (* (--Rsp)) = (Wrd29.Obj);

DEFLABEL (label_13)
  goto label_11;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_20_4 3
#define LABEL_20_5 5
#define ENVIRONMENT_LABEL_20_3 10
#define DEBUGGING_LABEL_20_2 9
#define OBJECT_20_2 8
#define OBJECT_20_1 7
#define OBJECT_20_0 6
#define FREE_REFERENCES_LABEL_20_0 6
#define NUMBER_OF_LINKER_SECTIONS_20_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_20 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd25;
  machine_word Wrd24;
  machine_word Wrd28;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_20_4);
      goto cache_length_1;

    case 1:
      current_block = (Rpc - LABEL_20_5);
      goto label_3;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_length_5)
DEFLABEL (cache_length_1)
  INTERRUPT_CHECK (26, LABEL_20_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_8;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_8;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_7)
  (Rsp [0]) = (Wrd5.Obj);
  (Wrd28.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd28.uLng) == 10))
    goto label_6;
  (Wrd24.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd25.Obj) = ((Wrd24.pObj) [0]);
  Rvl = (MAKE_OBJECT (26, (Wrd25.uLng)));
  Rsp = (& (Rsp [1]));
  goto pop_return;

DEFLABEL (label_6)
  INVOKE_PRIMITIVE ((current_block [OBJECT_20_2]), 1);

DEFLABEL (label_8)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_20_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_20_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_20_1]), 2);

DEFLABEL (label_3)
  (Wrd5.Obj) = Rvl;
  goto label_7;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_21_4 3
#define LABEL_21_5 5
#define ENVIRONMENT_LABEL_21_3 10
#define DEBUGGING_LABEL_21_2 9
#define OBJECT_21_2 8
#define OBJECT_21_1 7
#define OBJECT_21_0 6
#define FREE_REFERENCES_LABEL_21_0 6
#define NUMBER_OF_LINKER_SECTIONS_21_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_21 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd26;
  machine_word Wrd23;
  machine_word Wrd35;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd31;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd37;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_21_4);
      goto cache_line_tags_1;

    case 1:
      current_block = (Rpc - LABEL_21_5);
      goto label_3;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_line_tags_5)
DEFLABEL (cache_line_tags_1)
  INTERRUPT_CHECK (26, LABEL_21_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_9;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_9;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_8)
  (Rsp [0]) = (Wrd5.Obj);
  (Wrd37.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd37.uLng) == 10)
    goto label_7;

DEFLABEL (label_6)
  INVOKE_PRIMITIVE ((current_block [OBJECT_21_2]), 2);

DEFLABEL (label_7)
  (Wrd28.Obj) = (Rsp [1]);
  (Wrd29.uLng) = (OBJECT_TYPE (Wrd28.Obj));
  if (! ((Wrd29.uLng) == 26))
    goto label_6;
  (Wrd31.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  (Wrd33.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd34.Obj) = ((Wrd33.pObj) [0]);
  (Wrd35.Lng) = (FIXNUM_TO_LONG (Wrd34.Obj));
  if (! (((unsigned long) (Wrd31.Lng)) < ((unsigned long) (Wrd35.Lng))))
    goto label_6;
  (Wrd23.uLng) = (OBJECT_DATUM (Wrd28.Obj));
  (Wrd26.pObj) = (& ((Wrd33.pObj) [(Wrd23.Lng)]));
  Rvl = ((Wrd26.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_9)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_21_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_21_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_21_1]), 2);

DEFLABEL (label_3)
  (Wrd5.Obj) = Rvl;
  goto label_8;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_22_4 3
#define LABEL_22_5 5
#define ENVIRONMENT_LABEL_22_3 11
#define DEBUGGING_LABEL_22_2 10
#define OBJECT_22_3 9
#define OBJECT_22_2 8
#define OBJECT_22_1 7
#define OBJECT_22_0 6
#define FREE_REFERENCES_LABEL_22_0 6
#define NUMBER_OF_LINKER_SECTIONS_22_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_22 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd23;
  machine_word Wrd36;
  machine_word Wrd35;
  machine_word Wrd34;
  machine_word Wrd32;
  machine_word Wrd30;
  machine_word Wrd29;
  machine_word Wrd38;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_22_4);
      goto set_cache_line_tagsB_1;

    case 1:
      current_block = (Rpc - LABEL_22_5);
      goto label_3;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (set_cache_line_tagsB_5)
DEFLABEL (set_cache_line_tagsB_1)
  INTERRUPT_CHECK (26, LABEL_22_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_9;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_9;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_8)
  (Rsp [0]) = (Wrd5.Obj);
  (Wrd38.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd38.uLng) == 10)
    goto label_7;

DEFLABEL (label_6)
  INVOKE_PRIMITIVE ((current_block [OBJECT_22_3]), 3);

DEFLABEL (label_7)
  (Wrd29.Obj) = (Rsp [1]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 26))
    goto label_6;
  (Wrd32.Lng) = (FIXNUM_TO_LONG (Wrd29.Obj));
  (Wrd34.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd35.Obj) = ((Wrd34.pObj) [0]);
  (Wrd36.Lng) = (FIXNUM_TO_LONG (Wrd35.Obj));
  if (! (((unsigned long) (Wrd32.Lng)) < ((unsigned long) (Wrd36.Lng))))
    goto label_6;
  (Wrd23.uLng) = (OBJECT_DATUM (Wrd29.Obj));
  (Wrd26.pObj) = (& ((Wrd34.pObj) [(Wrd23.Lng)]));
  (Wrd27.Obj) = (Rsp [2]);
  ((Wrd26.pObj) [1]) = (Wrd27.Obj);
  Rvl = (current_block [OBJECT_22_2]);
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_9)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_22_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_22_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_22_1]), 2);

DEFLABEL (label_3)
  (Wrd5.Obj) = Rvl;
  goto label_8;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_23_4 3
#define LABEL_23_5 5
#define ENVIRONMENT_LABEL_23_3 10
#define DEBUGGING_LABEL_23_2 9
#define OBJECT_23_2 8
#define OBJECT_23_1 7
#define OBJECT_23_0 6
#define FREE_REFERENCES_LABEL_23_0 6
#define NUMBER_OF_LINKER_SECTIONS_23_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_23 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd26;
  machine_word Wrd23;
  machine_word Wrd35;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd31;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd37;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_23_4);
      goto cache_line_value_1;

    case 1:
      current_block = (Rpc - LABEL_23_5);
      goto label_3;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_line_value_5)
DEFLABEL (cache_line_value_1)
  INTERRUPT_CHECK (26, LABEL_23_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_9;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd13.Lng))))
    goto label_9;
  (Wrd5.Obj) = ((Wrd11.pObj) [7]);

DEFLABEL (label_8)
  (Rsp [0]) = (Wrd5.Obj);
  (Wrd37.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd37.uLng) == 10)
    goto label_7;

DEFLABEL (label_6)
  INVOKE_PRIMITIVE ((current_block [OBJECT_23_2]), 2);

DEFLABEL (label_7)
  (Wrd28.Obj) = (Rsp [1]);
  (Wrd29.uLng) = (OBJECT_TYPE (Wrd28.Obj));
  if (! ((Wrd29.uLng) == 26))
    goto label_6;
  (Wrd31.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  (Wrd33.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd34.Obj) = ((Wrd33.pObj) [0]);
  (Wrd35.Lng) = (FIXNUM_TO_LONG (Wrd34.Obj));
  if (! (((unsigned long) (Wrd31.Lng)) < ((unsigned long) (Wrd35.Lng))))
    goto label_6;
  (Wrd23.uLng) = (OBJECT_DATUM (Wrd28.Obj));
  (Wrd26.pObj) = (& ((Wrd33.pObj) [(Wrd23.Lng)]));
  Rvl = ((Wrd26.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_9)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_23_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_23_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_23_1]), 2);

DEFLABEL (label_3)
  (Wrd5.Obj) = Rvl;
  goto label_8;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_24_4 3
#define LABEL_24_5 5
#define ENVIRONMENT_LABEL_24_3 11
#define DEBUGGING_LABEL_24_2 10
#define OBJECT_24_3 9
#define OBJECT_24_2 8
#define OBJECT_24_1 7
#define OBJECT_24_0 6
#define FREE_REFERENCES_LABEL_24_0 6
#define NUMBER_OF_LINKER_SECTIONS_24_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_24 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd23;
  machine_word Wrd36;
  machine_word Wrd35;
  machine_word Wrd34;
  machine_word Wrd32;
  machine_word Wrd30;
  machine_word Wrd29;
  machine_word Wrd38;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_24_4);
      goto set_cache_line_valueB_1;

    case 1:
      current_block = (Rpc - LABEL_24_5);
      goto label_3;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (set_cache_line_valueB_5)
DEFLABEL (set_cache_line_valueB_1)
  INTERRUPT_CHECK (26, LABEL_24_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_9;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd13.Lng))))
    goto label_9;
  (Wrd5.Obj) = ((Wrd11.pObj) [7]);

DEFLABEL (label_8)
  (Rsp [0]) = (Wrd5.Obj);
  (Wrd38.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if ((Wrd38.uLng) == 10)
    goto label_7;

DEFLABEL (label_6)
  INVOKE_PRIMITIVE ((current_block [OBJECT_24_3]), 3);

DEFLABEL (label_7)
  (Wrd29.Obj) = (Rsp [1]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 26))
    goto label_6;
  (Wrd32.Lng) = (FIXNUM_TO_LONG (Wrd29.Obj));
  (Wrd34.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd35.Obj) = ((Wrd34.pObj) [0]);
  (Wrd36.Lng) = (FIXNUM_TO_LONG (Wrd35.Obj));
  if (! (((unsigned long) (Wrd32.Lng)) < ((unsigned long) (Wrd36.Lng))))
    goto label_6;
  (Wrd23.uLng) = (OBJECT_DATUM (Wrd29.Obj));
  (Wrd26.pObj) = (& ((Wrd34.pObj) [(Wrd23.Lng)]));
  (Wrd27.Obj) = (Rsp [2]);
  ((Wrd26.pObj) [1]) = (Wrd27.Obj);
  Rvl = (current_block [OBJECT_24_2]);
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_9)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_24_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_24_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_24_1]), 2);

DEFLABEL (label_3)
  (Wrd5.Obj) = Rvl;
  goto label_8;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_25_4 3
#define LABEL_25_5 5
#define LABEL_25_6 7
#define ENVIRONMENT_LABEL_25_3 13
#define DEBUGGING_LABEL_25_2 12
#define OBJECT_25_3 11
#define OBJECT_25_2 10
#define OBJECT_25_1 9
#define OBJECT_25_0 8
#define FREE_REFERENCES_LABEL_25_0 8
#define NUMBER_OF_LINKER_SECTIONS_25_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_25 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd30;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd31;
  machine_word Wrd29;
  machine_word Wrd21;
  machine_word Wrd24;
  machine_word Wrd23;
  machine_word Wrd25;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_25_4);
      goto cache_next_line_4;

    case 1:
      current_block = (Rpc - LABEL_25_5);
      goto label_6;

    case 2:
      current_block = (Rpc - LABEL_25_6);
      goto label_7;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_next_line_9)
DEFLABEL (cache_next_line_4)
  INTERRUPT_CHECK (26, LABEL_25_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_16;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_16;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_15)
  (Wrd25.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd25.uLng) == 10))
    goto label_14;
  (Wrd23.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd24.Obj) = ((Wrd23.pObj) [0]);
  (Wrd21.Obj) = (MAKE_OBJECT (26, (Wrd24.uLng)));

DEFLABEL (label_13)
  (Wrd31.Obj) = (Rsp [1]);
  (Wrd32.Lng) = (FIXNUM_TO_LONG (Wrd31.Obj));
  (Wrd33.Lng) = ((Wrd32.Lng) + 1L);
  (Wrd30.Obj) = (LONG_TO_FIXNUM (Wrd33.Lng));
  if ((Wrd30.Obj) == (Wrd21.Obj))
    goto label_11;
  Rvl = (Wrd30.Obj);
  goto label_10;

DEFLABEL (label_11)
  Rvl = (current_block [OBJECT_25_3]);

DEFLABEL (label_10)
DEFLABEL (label_12)
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_14)
  (Wrd29.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_25_6]))));
  (* (--Rsp)) = (Wrd29.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_25_2]), 1);

DEFLABEL (label_7)
  (Wrd21.Obj) = Rvl;
  goto label_13;

DEFLABEL (label_16)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_25_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_25_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_25_1]), 2);

DEFLABEL (label_6)
  (Wrd5.Obj) = Rvl;
  goto label_15;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_26_4 3
#define LABEL_26_5 5
#define LABEL_26_6 7
#define ENVIRONMENT_LABEL_26_3 12
#define DEBUGGING_LABEL_26_2 11
#define OBJECT_26_2 10
#define OBJECT_26_1 9
#define OBJECT_26_0 8
#define FREE_REFERENCES_LABEL_26_0 8
#define NUMBER_OF_LINKER_SECTIONS_26_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_26 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd44;
  machine_word Wrd43;
  machine_word Wrd42;
  machine_word Wrd41;
  machine_word Wrd39;
  machine_word Wrd31;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd35;
  machine_word Wrd30;
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd15;
  machine_word Wrd23;
  machine_word Wrd22;
  machine_word Wrd21;
  machine_word Wrd25;
  machine_word Wrd24;
  machine_word Wrd10;
  machine_word Wrd9;
  machine_word Wrd8;
  machine_word Wrd7;
  machine_word Wrd6;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_26_4);
      goto cache_line_separation_5;

    case 1:
      current_block = (Rpc - LABEL_26_5);
      goto label_7;

    case 2:
      current_block = (Rpc - LABEL_26_6);
      goto label_8;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_line_separation_10)
DEFLABEL (cache_line_separation_5)
  INTERRUPT_CHECK (26, LABEL_26_4);
  (Wrd5.Obj) = (Rsp [2]);
  (Wrd6.Lng) = (FIXNUM_TO_LONG (Wrd5.Obj));
  (Wrd7.Obj) = (Rsp [1]);
  (Wrd8.Lng) = (FIXNUM_TO_LONG (Wrd7.Obj));
  (Wrd9.Lng) = ((Wrd6.Lng) - (Wrd8.Lng));
  (Wrd10.Obj) = (LONG_TO_FIXNUM (Wrd9.Lng));
  (* (--Rsp)) = (Wrd10.Obj);
  if ((Wrd9.Lng) < 0)
    goto label_12;
  Rvl = (Wrd10.Obj);

DEFLABEL (label_11)
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_12)
  (Wrd24.Obj) = (Rsp [1]);
  (Wrd25.uLng) = (OBJECT_TYPE (Wrd24.Obj));
  if (! ((Wrd25.uLng) == 62))
    goto label_16;
  (Wrd21.pObj) = (OBJECT_ADDRESS (Wrd24.Obj));
  (Wrd22.Obj) = ((Wrd21.pObj) [0]);
  (Wrd23.Lng) = (FIXNUM_TO_LONG (Wrd22.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd23.Lng))))
    goto label_16;
  (Wrd15.Obj) = ((Wrd21.pObj) [6]);

DEFLABEL (label_15)
  (Wrd35.uLng) = (OBJECT_TYPE (Wrd15.Obj));
  if (! ((Wrd35.uLng) == 10))
    goto label_14;
  (Wrd33.pObj) = (OBJECT_ADDRESS (Wrd15.Obj));
  (Wrd34.Obj) = ((Wrd33.pObj) [0]);
  (Wrd31.Obj) = (MAKE_OBJECT (26, (Wrd34.uLng)));

DEFLABEL (label_13)
  (Wrd41.Obj) = (Rsp [0]);
  (Wrd42.Lng) = (FIXNUM_TO_LONG (Wrd41.Obj));
  (Wrd43.Lng) = (FIXNUM_TO_LONG (Wrd31.Obj));
  (Wrd44.Lng) = ((Wrd42.Lng) + (Wrd43.Lng));
  Rvl = (LONG_TO_FIXNUM (Wrd44.Lng));
  goto label_11;

DEFLABEL (label_14)
  (Wrd39.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_26_6]))));
  (* (--Rsp)) = (Wrd39.Obj);
  (* (--Rsp)) = (Wrd15.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_26_2]), 1);

DEFLABEL (label_8)
  (Wrd31.Obj) = Rvl;
  goto label_13;

DEFLABEL (label_16)
  (Wrd26.Obj) = (Rsp [1]);
  (Wrd27.Obj) = (current_block [OBJECT_26_0]);
  (Wrd30.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_26_5]))));
  (* (--Rsp)) = (Wrd30.Obj);
  (* (--Rsp)) = (Wrd27.Obj);
  (* (--Rsp)) = (Wrd26.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_26_1]), 2);

DEFLABEL (label_7)
  (Wrd15.Obj) = Rvl;
  goto label_15;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_27_4 3
#define LABEL_27_5 5
#define LABEL_27_7 7
#define LABEL_27_8 9
#define TAG_27_9 3
#define LABEL_27_10 11
#define TAG_27_11 4
#define LABEL_27_15 13
#define LABEL_27_16 15
#define LABEL_27_12 17
#define TAG_27_13 7
#define LABEL_27_18 19
#define LABEL_27_19 21
#define LABEL_27_20 23
#define LABEL_27_14 25
#define LABEL_27_21 27
#define LABEL_27_22 29
#define LABEL_27_17 31
#define LABEL_27_23 33
#define LABEL_27_24 35
#define LABEL_27_25 37
#define LABEL_27_26 39
#define ENVIRONMENT_LABEL_27_3 56
#define DEBUGGING_LABEL_27_2 55
#define OBJECT_27_11 54
#define OBJECT_27_10 53
#define OBJECT_27_9 52
#define OBJECT_27_8 51
#define OBJECT_27_7 50
#define OBJECT_27_6 49
#define OBJECT_27_5 48
#define OBJECT_27_4 47
#define OBJECT_27_3 46
#define OBJECT_27_2 45
#define OBJECT_27_1 44
#define OBJECT_27_0 43
#define EXECUTE_CACHE_27_6 41
#define FREE_REFERENCES_LABEL_27_0 40
#define NUMBER_OF_LINKER_SECTIONS_27_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_27 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd34;
  machine_word Wrd39;
  machine_word Wrd48;
  machine_word Wrd47;
  machine_word Wrd99;
  machine_word Wrd103;
  machine_word Wrd102;
  machine_word Wrd101;
  machine_word Wrd100;
  machine_word Wrd95;
  machine_word Wrd98;
  machine_word Wrd97;
  machine_word Wrd96;
  machine_word Wrd91;
  machine_word Wrd87;
  machine_word Wrd90;
  machine_word Wrd89;
  machine_word Wrd88;
  machine_word Wrd86;
  machine_word Wrd78;
  machine_word Wrd81;
  machine_word Wrd80;
  machine_word Wrd82;
  machine_word Wrd71;
  machine_word Wrd72;
  machine_word Wrd66;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd70;
  machine_word Wrd69;
  machine_word Wrd132;
  machine_word Wrd129;
  machine_word Wrd126;
  machine_word Wrd128;
  machine_word Wrd127;
  machine_word Wrd109;
  machine_word Wrd121;
  machine_word Wrd120;
  machine_word Wrd119;
  machine_word Wrd125;
  machine_word Wrd124;
  machine_word Wrd104;
  machine_word Wrd108;
  machine_word Wrd107;
  machine_word Wrd11;
  machine_word Wrd32;
  machine_word Wrd54;
  machine_word Wrd53;
  machine_word Wrd50;
  machine_word Wrd35;
  machine_word Wrd33;
  machine_word Wrd40;
  machine_word Wrd38;
  machine_word Wrd23;
  machine_word Wrd29;
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd20;
  machine_word Wrd21;
  machine_word Wrd10;
  machine_word Wrd12;
  machine_word Wrd5;
  machine_word Wrd6;
  machine_word Wrd75;
  machine_word Wrd77;
  machine_word Wrd76;
  machine_word Wrd74;
  machine_word Wrd73;
  machine_word Wrd60;
  machine_word Wrd62;
  machine_word Wrd61;
  machine_word Wrd51;
  machine_word Wrd52;
  machine_word Wrd49;
  machine_word Wrd45;
  machine_word Wrd46;
  machine_word Wrd44;
  machine_word Wrd43;
  machine_word Wrd41;
  machine_word Wrd42;
  machine_word Wrd37;
  machine_word Wrd36;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd25;
  machine_word Wrd24;
  machine_word Wrd28;
  machine_word Wrd22;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd13;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd9;
  machine_word Wrd8;
  machine_word Wrd7;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_27_4);
      goto probe_cache_38;

    case 1:
      current_block = (Rpc - LABEL_27_5);
      goto continuation_0;

    case 2:
      current_block = (Rpc - LABEL_27_7);
      goto label_40;

    case 3:
      current_block = (Rpc - LABEL_27_8);
      goto lambda_53;

    case 4:
      current_block = (Rpc - LABEL_27_10);
      goto lambda_54;

    case 5:
      current_block = (Rpc - LABEL_27_15);
      goto label_41;

    case 6:
      current_block = (Rpc - LABEL_27_16);
      goto label_42;

    case 7:
      current_block = (Rpc - LABEL_27_12);
      goto lambda_55;

    case 8:
      current_block = (Rpc - LABEL_27_18);
      goto label_43;

    case 9:
      current_block = (Rpc - LABEL_27_19);
      goto label_44;

    case 10:
      current_block = (Rpc - LABEL_27_20);
      goto loop_30;

    case 11:
      current_block = (Rpc - LABEL_27_14);
      goto continuation_18;

    case 12:
      current_block = (Rpc - LABEL_27_21);
      goto label_46;

    case 13:
      current_block = (Rpc - LABEL_27_22);
      goto label_45;

    case 14:
      current_block = (Rpc - LABEL_27_17);
      goto continuation_4;

    case 15:
      current_block = (Rpc - LABEL_27_23);
      goto label_50;

    case 16:
      current_block = (Rpc - LABEL_27_24);
      goto label_48;

    case 17:
      current_block = (Rpc - LABEL_27_25);
      goto label_49;

    case 18:
      current_block = (Rpc - LABEL_27_26);
      goto label_47;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (probe_cache_52)
DEFLABEL (probe_cache_38)
  INTERRUPT_CHECK (26, LABEL_27_4);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_5]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd8.Obj);
  (Wrd9.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd9.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_27_6]));

DEFLABEL (continuation_0)
  INTERRUPT_CHECK (27, LABEL_27_5);
  (* (--Rsp)) = Rvl;
  if (! (Rvl == ((SCHEME_OBJECT) 0)))
    goto label_57;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_57)
  (Wrd16.Obj) = (Rsp [1]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_59;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 3L) < ((unsigned long) (Wrd15.Lng))))
    goto label_59;
  (Wrd9.Obj) = ((Wrd13.pObj) [4]);
  (* (--Rsp)) = (Wrd9.Obj);

DEFLABEL (label_58)
  (Wrd28.Obj) = (MAKE_OBJECT (50, 0));
  (* (Rhp++)) = (Wrd28.Obj);
  (Wrd24.pObj) = (& (Rhp [-1]));
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd24.pObj)));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (Rhp++)) = (Wrd28.Obj);
  (Wrd30.pObj) = (& (Rhp [-1]));
  (Wrd31.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd30.pObj)));
  (* (--Rsp)) = (Wrd31.Obj);
  (* (Rhp++)) = (Wrd28.Obj);
  (Wrd36.pObj) = (& (Rhp [-1]));
  (Wrd37.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd36.pObj)));
  (* (--Rsp)) = (Wrd37.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 4));
  (Wrd42.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x202, 2);
  (* (Rhp++)) = (dispatch_base + TAG_27_9);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_27_8])));
  Rhp += 1;
  (Wrd41.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd42.pObj)));
  Wrd43 = Wrd42;
  (Wrd44.Obj) = (Rsp [6]);
  ((Wrd43.pObj) [2]) = (Wrd44.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 5));
  (Wrd46.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x202, 2);
  (* (Rhp++)) = (dispatch_base + TAG_27_11);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_27_10])));
  Rhp += 2;
  (Wrd45.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd46.pObj)));
  Wrd49 = Wrd46;
  ((Wrd49.pObj) [2]) = (Wrd25.Obj);
  ((Wrd49.pObj) [3]) = (Wrd31.Obj);
  (* (--Rsp)) = (Wrd45.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 8));
  (Wrd52.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x303, 2);
  (* (Rhp++)) = (dispatch_base + TAG_27_13);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_27_12])));
  Rhp += 5;
  (Wrd51.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd52.pObj)));
  Wrd61 = Wrd52;
  (Wrd62.Obj) = (Rsp [7]);
  ((Wrd61.pObj) [2]) = (Wrd62.Obj);
  (Wrd60.Obj) = (Rsp [5]);
  ((Wrd61.pObj) [3]) = (Wrd60.Obj);
  ((Wrd61.pObj) [4]) = (Wrd25.Obj);
  ((Wrd61.pObj) [5]) = (Wrd31.Obj);
  ((Wrd61.pObj) [6]) = (Wrd37.Obj);
  (* (--Rsp)) = (Wrd51.Obj);
  ((Wrd36.pObj) [0]) = (Wrd51.Obj);
  ((Wrd30.pObj) [0]) = (Wrd45.Obj);
  ((Wrd24.pObj) [0]) = (Wrd41.Obj);
  Rsp = (& (Rsp [3]));
  (Wrd73.Obj) = (Rsp [4]);
  (Rsp [5]) = (Wrd73.Obj);
  (Wrd74.Obj) = (current_block [OBJECT_27_2]);
  (Rsp [6]) = (Wrd74.Obj);
  (Wrd76.Obj) = (Rsp [0]);
  (Wrd77.pObj) = (OBJECT_ADDRESS (Wrd76.Obj));
  (Wrd75.Obj) = ((Wrd77.pObj) [0]);
  (Rsp [4]) = (Wrd75.Obj);
  Rsp = (& (Rsp [4]));
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (label_59)
  (Wrd18.Obj) = (Rsp [1]);
  (Wrd19.Obj) = (current_block [OBJECT_27_0]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_7]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_1]), 2);

DEFLABEL (label_40)
  (* (--Rsp)) = Rvl;
  goto label_58;

DEFLABEL (lambda_53)
  CLOSURE_HEADER (LABEL_27_8);

DEFLABEL (lambda_32)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd6.Obj) = (Rsp [0]);
  (Wrd7.pObj) = (OBJECT_ADDRESS (Wrd6.Obj));
  (Wrd5.Obj) = ((Wrd7.pObj) [2]);
  (Wrd8.Obj) = (Rsp [1]);
  (Rsp [0]) = (Wrd8.Obj);
  (Rsp [1]) = (Wrd5.Obj);
  goto loop_30;

DEFLABEL (lambda_54)
  CLOSURE_HEADER (LABEL_27_10);

DEFLABEL (lambda_21)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd5.Obj) = (Rsp [1]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_27_3])))
    goto label_60;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_60)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_14]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd14.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd14.uLng) == 1))
    goto label_70;
  (Wrd12.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd10.Obj) = ((Wrd12.pObj) [0]);

DEFLABEL (label_69)
  (Wrd21.uLng) = (OBJECT_TYPE (Wrd10.Obj));
  if (! ((Wrd21.uLng) == 1))
    goto label_68;
  (Wrd19.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd20.Obj) = ((Wrd19.pObj) [0]);
  (* (--Rsp)) = (Wrd20.Obj);

DEFLABEL (label_67)
  (Wrd26.Obj) = (Rsp [2]);
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd26.Obj));
  (Wrd28.Obj) = ((Wrd27.pObj) [2]);
  (Wrd29.pObj) = (OBJECT_ADDRESS (Wrd28.Obj));
  (Wrd30.Obj) = ((Wrd29.pObj) [0]);
  (* (--Rsp)) = (Wrd30.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (continuation_18)
  INTERRUPT_CHECK (27, LABEL_27_14);
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_64;
  (Wrd10.Obj) = (Rsp [1]);
  (Wrd11.uLng) = (OBJECT_TYPE (Wrd10.Obj));
  if (! ((Wrd11.uLng) == 1))
    goto label_63;
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd7.Obj) = ((Wrd9.pObj) [0]);

DEFLABEL (label_62)
  (Rsp [1]) = (Wrd7.Obj);
  Rsp = (& (Rsp [1]));
  (Wrd20.Obj) = (Rsp [0]);
  (Wrd21.uLng) = (OBJECT_TYPE (Wrd20.Obj));
  if (! ((Wrd21.uLng) == 1))
    goto label_61;
  (Wrd18.pObj) = (OBJECT_ADDRESS (Wrd20.Obj));
  Rvl = ((Wrd18.pObj) [1]);
  Rsp = (& (Rsp [1]));
  goto pop_return;

DEFLABEL (label_61)
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_8]), 1);

DEFLABEL (label_63)
  (Wrd15.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_22]))));
  (* (--Rsp)) = (Wrd15.Obj);
  (* (--Rsp)) = (Wrd10.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_4]), 1);

DEFLABEL (label_45)
  (Wrd7.Obj) = Rvl;
  goto label_62;

DEFLABEL (label_64)
  (Wrd24.Obj) = (Rsp [0]);
  (Wrd25.pObj) = (OBJECT_ADDRESS (Wrd24.Obj));
  (Wrd26.Obj) = ((Wrd25.pObj) [3]);
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd26.Obj));
  (Wrd23.Obj) = ((Wrd27.pObj) [0]);
  (Rsp [0]) = (Wrd23.Obj);
  (Wrd31.Obj) = (Rsp [1]);
  (Wrd32.uLng) = (OBJECT_TYPE (Wrd31.Obj));
  if (! ((Wrd32.uLng) == 1))
    goto label_66;
  (Wrd30.pObj) = (OBJECT_ADDRESS (Wrd31.Obj));
  (Wrd28.Obj) = ((Wrd30.pObj) [1]);

DEFLABEL (label_65)
  (Rsp [1]) = (Wrd28.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (label_66)
  (Wrd36.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_21]))));
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd31.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_8]), 1);

DEFLABEL (label_46)
  (Wrd28.Obj) = Rvl;
  goto label_65;

DEFLABEL (label_68)
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_16]))));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd10.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_4]), 1);

DEFLABEL (label_42)
  (* (--Rsp)) = Rvl;
  goto label_67;

DEFLABEL (label_70)
  (Wrd18.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_15]))));
  (* (--Rsp)) = (Wrd18.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_4]), 1);

DEFLABEL (label_41)
  (Wrd10.Obj) = Rvl;
  goto label_69;

DEFLABEL (lambda_55)
  CLOSURE_HEADER (LABEL_27_12);

DEFLABEL (lambda_14)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_17]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd21.Obj) = (Rsp [1]);
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd21.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [2]);
  (Wrd24.uLng) = (OBJECT_TYPE (Wrd23.Obj));
  if (! ((Wrd24.uLng) == 62))
    goto label_89;
  (Wrd18.pObj) = (OBJECT_ADDRESS (Wrd23.Obj));
  (Wrd19.Obj) = ((Wrd18.pObj) [0]);
  (Wrd20.Lng) = (FIXNUM_TO_LONG (Wrd19.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd20.Lng))))
    goto label_89;
  (Wrd8.Obj) = ((Wrd18.pObj) [6]);

DEFLABEL (label_88)
  (Wrd44.uLng) = (OBJECT_TYPE (Wrd8.Obj));
  if (! ((Wrd44.uLng) == 10))
    goto label_87;
  (Wrd37.Obj) = (Rsp [2]);
  (Wrd38.uLng) = (OBJECT_TYPE (Wrd37.Obj));
  if (! ((Wrd38.uLng) == 26))
    goto label_87;
  (Wrd40.Lng) = (FIXNUM_TO_LONG (Wrd37.Obj));
  (Wrd41.pObj) = (OBJECT_ADDRESS (Wrd8.Obj));
  (Wrd42.Obj) = ((Wrd41.pObj) [0]);
  (Wrd43.Lng) = (FIXNUM_TO_LONG (Wrd42.Obj));
  if (! (((unsigned long) (Wrd40.Lng)) < ((unsigned long) (Wrd43.Lng))))
    goto label_87;
  (Wrd33.uLng) = (OBJECT_DATUM (Wrd37.Obj));
  (Wrd35.pObj) = (& ((Wrd41.pObj) [(Wrd33.Lng)]));
  (Wrd36.Obj) = ((Wrd35.pObj) [1]);
  (* (--Rsp)) = (Wrd36.Obj);

DEFLABEL (label_86)
  (Wrd50.Obj) = (Rsp [2]);
  (Wrd51.pObj) = (OBJECT_ADDRESS (Wrd50.Obj));
  (Wrd52.Obj) = ((Wrd51.pObj) [4]);
  (Wrd53.pObj) = (OBJECT_ADDRESS (Wrd52.Obj));
  (Wrd54.Obj) = ((Wrd53.pObj) [0]);
  (* (--Rsp)) = (Wrd54.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (continuation_4)
  INTERRUPT_CHECK (27, LABEL_27_17);
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_75;
  (Wrd7.Obj) = (Rsp [1]);
  (Rsp [2]) = (Wrd7.Obj);
  (Wrd21.Obj) = (Rsp [0]);
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd21.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [2]);
  (Wrd24.uLng) = (OBJECT_TYPE (Wrd23.Obj));
  if (! ((Wrd24.uLng) == 62))
    goto label_74;
  (Wrd18.pObj) = (OBJECT_ADDRESS (Wrd23.Obj));
  (Wrd19.Obj) = ((Wrd18.pObj) [0]);
  (Wrd20.Lng) = (FIXNUM_TO_LONG (Wrd19.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd20.Lng))))
    goto label_74;
  (Wrd8.Obj) = ((Wrd18.pObj) [7]);

DEFLABEL (label_73)
  (Rsp [1]) = (Wrd8.Obj);
  Rsp = (& (Rsp [1]));
  (Wrd47.Obj) = (Rsp [0]);
  (Wrd48.uLng) = (OBJECT_TYPE (Wrd47.Obj));
  if ((Wrd48.uLng) == 10)
    goto label_72;

DEFLABEL (label_71)
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_6]), 2);

DEFLABEL (label_72)
  (Wrd39.Obj) = (Rsp [1]);
  (Wrd40.uLng) = (OBJECT_TYPE (Wrd39.Obj));
  if (! ((Wrd40.uLng) == 26))
    goto label_71;
  (Wrd42.Lng) = (FIXNUM_TO_LONG (Wrd39.Obj));
  (Wrd44.pObj) = (OBJECT_ADDRESS (Wrd47.Obj));
  (Wrd45.Obj) = ((Wrd44.pObj) [0]);
  (Wrd46.Lng) = (FIXNUM_TO_LONG (Wrd45.Obj));
  if (! (((unsigned long) (Wrd42.Lng)) < ((unsigned long) (Wrd46.Lng))))
    goto label_71;
  (Wrd34.uLng) = (OBJECT_DATUM (Wrd39.Obj));
  (Wrd37.pObj) = (& ((Wrd44.pObj) [(Wrd34.Lng)]));
  Rvl = ((Wrd37.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_74)
  (Wrd26.Obj) = (Rsp [0]);
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd26.Obj));
  (Wrd25.Obj) = ((Wrd27.pObj) [2]);
  (Wrd28.Obj) = (current_block [OBJECT_27_11]);
  (Wrd31.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_26]))));
  (* (--Rsp)) = (Wrd31.Obj);
  (* (--Rsp)) = (Wrd28.Obj);
  (* (--Rsp)) = (Wrd25.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_1]), 2);

DEFLABEL (label_47)
  (Wrd8.Obj) = Rvl;
  goto label_73;

DEFLABEL (label_75)
  (Wrd50.Obj) = (Rsp [2]);
  (Wrd51.Obj) = (Rsp [0]);
  (Wrd52.pObj) = (OBJECT_ADDRESS (Wrd51.Obj));
  (Wrd53.Obj) = ((Wrd52.pObj) [3]);
  if ((Wrd50.Obj) == (Wrd53.Obj))
    goto label_83;
  (Wrd69.Obj) = ((Wrd52.pObj) [2]);
  (Wrd70.uLng) = (OBJECT_TYPE (Wrd69.Obj));
  if (! ((Wrd70.uLng) == 62))
    goto label_82;
  (Wrd64.pObj) = (OBJECT_ADDRESS (Wrd69.Obj));
  (Wrd65.Obj) = ((Wrd64.pObj) [0]);
  (Wrd66.Lng) = (FIXNUM_TO_LONG (Wrd65.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd66.Lng))))
    goto label_82;
  (Wrd54.Obj) = ((Wrd64.pObj) [6]);

DEFLABEL (label_81)
  (Wrd82.uLng) = (OBJECT_TYPE (Wrd54.Obj));
  if (! ((Wrd82.uLng) == 10))
    goto label_80;
  (Wrd80.pObj) = (OBJECT_ADDRESS (Wrd54.Obj));
  (Wrd81.Obj) = ((Wrd80.pObj) [0]);
  (Wrd78.Obj) = (MAKE_OBJECT (26, (Wrd81.uLng)));

DEFLABEL (label_79)
  (Wrd88.Obj) = (Rsp [1]);
  (Wrd89.Lng) = (FIXNUM_TO_LONG (Wrd88.Obj));
  (Wrd90.Lng) = ((Wrd89.Lng) + 1L);
  (Wrd87.Obj) = (LONG_TO_FIXNUM (Wrd90.Lng));
  if ((Wrd87.Obj) == (Wrd78.Obj))
    goto label_77;
  Wrd91 = Wrd87;
  goto label_76;

DEFLABEL (label_77)
  (Wrd91.Obj) = (current_block [OBJECT_27_2]);

DEFLABEL (label_76)
DEFLABEL (label_78)
  (Rsp [1]) = (Wrd91.Obj);
  (Wrd96.Obj) = (Rsp [2]);
  (Wrd97.Lng) = (FIXNUM_TO_LONG (Wrd96.Obj));
  (Wrd98.Lng) = ((Wrd97.Lng) + 1L);
  (Wrd95.Obj) = (LONG_TO_FIXNUM (Wrd98.Lng));
  (Rsp [2]) = (Wrd95.Obj);
  (Wrd100.Obj) = (Rsp [0]);
  (Wrd101.pObj) = (OBJECT_ADDRESS (Wrd100.Obj));
  (Wrd102.Obj) = ((Wrd101.pObj) [6]);
  (Wrd103.pObj) = (OBJECT_ADDRESS (Wrd102.Obj));
  (Wrd99.Obj) = ((Wrd103.pObj) [0]);
  (Rsp [0]) = (Wrd99.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (label_80)
  (Wrd86.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_25]))));
  (* (--Rsp)) = (Wrd86.Obj);
  (* (--Rsp)) = (Wrd54.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_10]), 1);

DEFLABEL (label_49)
  (Wrd78.Obj) = Rvl;
  goto label_79;

DEFLABEL (label_82)
  (Wrd72.Obj) = (Rsp [0]);
  (Wrd73.pObj) = (OBJECT_ADDRESS (Wrd72.Obj));
  (Wrd71.Obj) = ((Wrd73.pObj) [2]);
  (Wrd74.Obj) = (current_block [OBJECT_27_5]);
  (Wrd77.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_24]))));
  (* (--Rsp)) = (Wrd77.Obj);
  (* (--Rsp)) = (Wrd74.Obj);
  (* (--Rsp)) = (Wrd71.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_1]), 2);

DEFLABEL (label_48)
  (Wrd54.Obj) = Rvl;
  goto label_81;

DEFLABEL (label_83)
  (Wrd107.Obj) = ((Wrd52.pObj) [5]);
  (Wrd108.pObj) = (OBJECT_ADDRESS (Wrd107.Obj));
  (Wrd104.Obj) = ((Wrd108.pObj) [0]);
  (Rsp [1]) = (Wrd104.Obj);
  (Wrd124.Obj) = ((Wrd52.pObj) [2]);
  (Wrd125.uLng) = (OBJECT_TYPE (Wrd124.Obj));
  if (! ((Wrd125.uLng) == 62))
    goto label_85;
  (Wrd119.pObj) = (OBJECT_ADDRESS (Wrd124.Obj));
  (Wrd120.Obj) = ((Wrd119.pObj) [0]);
  (Wrd121.Lng) = (FIXNUM_TO_LONG (Wrd120.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd121.Lng))))
    goto label_85;
  (Wrd109.Obj) = ((Wrd119.pObj) [8]);

DEFLABEL (label_84)
  (Rsp [2]) = (Wrd109.Obj);
  Rsp = (& (Rsp [1]));
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (label_85)
  (Wrd127.Obj) = (Rsp [0]);
  (Wrd128.pObj) = (OBJECT_ADDRESS (Wrd127.Obj));
  (Wrd126.Obj) = ((Wrd128.pObj) [2]);
  (Wrd129.Obj) = (current_block [OBJECT_27_9]);
  (Wrd132.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_23]))));
  (* (--Rsp)) = (Wrd132.Obj);
  (* (--Rsp)) = (Wrd129.Obj);
  (* (--Rsp)) = (Wrd126.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_1]), 2);

DEFLABEL (label_50)
  (Wrd109.Obj) = Rvl;
  goto label_84;

DEFLABEL (label_87)
  (Wrd46.Obj) = (Rsp [2]);
  (Wrd49.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_19]))));
  (* (--Rsp)) = (Wrd49.Obj);
  (* (--Rsp)) = (Wrd46.Obj);
  (* (--Rsp)) = (Wrd8.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_6]), 2);

DEFLABEL (label_44)
  (* (--Rsp)) = Rvl;
  goto label_86;

DEFLABEL (label_89)
  (Wrd26.Obj) = (Rsp [1]);
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd26.Obj));
  (Wrd25.Obj) = ((Wrd27.pObj) [2]);
  (Wrd28.Obj) = (current_block [OBJECT_27_5]);
  (Wrd31.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_27_18]))));
  (* (--Rsp)) = (Wrd31.Obj);
  (* (--Rsp)) = (Wrd28.Obj);
  (* (--Rsp)) = (Wrd25.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_27_1]), 2);

DEFLABEL (label_43)
  (Wrd8.Obj) = Rvl;
  goto label_88;

DEFLABEL (loop_56)
DEFLABEL (loop_30)
  INTERRUPT_CHECK (26, LABEL_27_20);
  (Wrd6.Obj) = (Rsp [0]);
  (Wrd7.pObj) = (OBJECT_ADDRESS (Wrd6.Obj));
  (Wrd5.Obj) = ((Wrd7.pObj) [0]);
  (Wrd9.Obj) = (Rsp [1]);
  (Wrd10.pObj) = (OBJECT_ADDRESS (Wrd9.Obj));
  (Wrd8.Obj) = ((Wrd10.pObj) [0]);
  if ((Wrd5.Obj) == (Wrd8.Obj))
    goto label_91;
  Rvl = ((SCHEME_OBJECT) 0);

DEFLABEL (label_90)
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_91)
  (Wrd13.Obj) = ((Wrd7.pObj) [1]);
  if ((Wrd13.Obj) == (current_block [OBJECT_27_3]))
    goto label_92;
  (Rsp [0]) = (Wrd13.Obj);
  (Wrd20.Obj) = ((Wrd10.pObj) [1]);
  (Rsp [1]) = (Wrd20.Obj);
  goto loop_30;

DEFLABEL (label_92)
  Rvl = (current_block [OBJECT_27_7]);
  goto label_90;

INVOKE_INTERFACE_TARGET_0
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_28_4 3
#define LABEL_28_5 5
#define LABEL_28_6 7
#define LABEL_28_7 9
#define LABEL_28_8 11
#define ENVIRONMENT_LABEL_28_3 18
#define DEBUGGING_LABEL_28_2 17
#define OBJECT_28_4 16
#define OBJECT_28_3 15
#define OBJECT_28_2 14
#define OBJECT_28_1 13
#define OBJECT_28_0 12
#define FREE_REFERENCES_LABEL_28_0 12
#define NUMBER_OF_LINKER_SECTIONS_28_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_28 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd44;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd39;
  machine_word Wrd43;
  machine_word Wrd42;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd35;
  machine_word Wrd18;
  machine_word Wrd26;
  machine_word Wrd25;
  machine_word Wrd24;
  machine_word Wrd22;
  machine_word Wrd21;
  machine_word Wrd9;
  machine_word Wrd8;
  machine_word Wrd5;
  machine_word Wrd38;
  machine_word Wrd37;
  machine_word Wrd36;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd23;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd27;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd7;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_28_4);
      goto compute_primary_cache_line_13;

    case 1:
      current_block = (Rpc - LABEL_28_5);
      goto label_15;

    case 2:
      current_block = (Rpc - LABEL_28_6);
      goto label_16;

    case 3:
      current_block = (Rpc - LABEL_28_7);
      goto loop_10;

    case 4:
      current_block = (Rpc - LABEL_28_8);
      goto label_17;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (compute_primary_cache_line_19)
DEFLABEL (compute_primary_cache_line_13)
  INTERRUPT_CHECK (26, LABEL_28_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_24;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd13.Lng))))
    goto label_24;
  (Wrd7.Obj) = ((Wrd11.pObj) [3]);
  (* (--Rsp)) = (Wrd7.Obj);

DEFLABEL (label_23)
  (Wrd30.Obj) = (Rsp [1]);
  (Wrd31.uLng) = (OBJECT_TYPE (Wrd30.Obj));
  if (! ((Wrd31.uLng) == 62))
    goto label_22;
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd30.Obj));
  (Wrd28.Obj) = ((Wrd27.pObj) [0]);
  (Wrd29.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd29.Lng))))
    goto label_22;
  (Wrd23.Obj) = ((Wrd27.pObj) [2]);
  (* (--Rsp)) = (Wrd23.Obj);

DEFLABEL (label_21)
  (Wrd37.Obj) = (current_block [OBJECT_28_3]);
  (* (--Rsp)) = (Wrd37.Obj);
  (Wrd38.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd38.Obj);
  goto loop_10;

DEFLABEL (label_22)
  (Wrd32.Obj) = (Rsp [1]);
  (Wrd33.Obj) = (current_block [OBJECT_28_2]);
  (Wrd36.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_28_6]))));
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd33.Obj);
  (* (--Rsp)) = (Wrd32.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_28_1]), 2);

DEFLABEL (label_16)
  (* (--Rsp)) = Rvl;
  goto label_21;

DEFLABEL (label_24)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_28_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_28_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_28_1]), 2);

DEFLABEL (label_15)
  (* (--Rsp)) = Rvl;
  goto label_23;

DEFLABEL (loop_20)
DEFLABEL (loop_10)
  INTERRUPT_CHECK (26, LABEL_28_7);
  (Wrd5.Obj) = (Rsp [0]);
  if ((Wrd5.Obj) == (current_block [OBJECT_28_4]))
    goto label_29;
  (Wrd8.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd9.Obj) = ((Wrd8.pObj) [0]);
  if ((Wrd9.Obj) == ((SCHEME_OBJECT) 0))
    goto label_27;
  Wrd13 = Wrd9;
  (Wrd28.uLng) = (OBJECT_TYPE (Wrd9.Obj));
  if (! ((Wrd28.uLng) == 62))
    goto label_26;
  (Wrd21.Obj) = (Rsp [2]);
  (Wrd22.uLng) = (OBJECT_TYPE (Wrd21.Obj));
  if (! ((Wrd22.uLng) == 26))
    goto label_26;
  (Wrd24.Lng) = (FIXNUM_TO_LONG (Wrd21.Obj));
  (Wrd25.pObj) = (OBJECT_ADDRESS (Wrd9.Obj));
  (Wrd26.Obj) = ((Wrd25.pObj) [0]);
  (Wrd27.Lng) = (FIXNUM_TO_LONG (Wrd26.Obj));
  if (! (((unsigned long) (Wrd24.Lng)) < ((unsigned long) (Wrd27.Lng))))
    goto label_26;
  (Wrd18.uLng) = (OBJECT_DATUM (Wrd21.Obj));
  (Wrd20.pObj) = (& ((Wrd25.pObj) [(Wrd18.Lng)]));
  (Wrd16.Obj) = ((Wrd20.pObj) [1]);

DEFLABEL (label_25)
  (Wrd35.Obj) = (Rsp [1]);
  (Wrd36.Lng) = (FIXNUM_TO_LONG (Wrd35.Obj));
  (Wrd37.Lng) = (FIXNUM_TO_LONG (Wrd16.Obj));
  (Wrd40.Lng) = ((Wrd36.Lng) + (Wrd37.Lng));
  (Wrd41.Obj) = (Rsp [3]);
  (Wrd42.Lng) = (FIXNUM_TO_LONG (Wrd41.Obj));
  (Wrd43.Lng) = ((Wrd40.Lng) & (Wrd42.Lng));
  (Wrd39.Obj) = (LONG_TO_FIXNUM (Wrd43.Lng));
  (Rsp [1]) = (Wrd39.Obj);
  (Wrd45.Obj) = (Rsp [0]);
  (Wrd46.pObj) = (OBJECT_ADDRESS (Wrd45.Obj));
  (Wrd44.Obj) = ((Wrd46.pObj) [1]);
  (Rsp [0]) = (Wrd44.Obj);
  goto loop_10;

DEFLABEL (label_26)
  (Wrd30.Obj) = (Rsp [2]);
  (Wrd33.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_28_8]))));
  (* (--Rsp)) = (Wrd33.Obj);
  (* (--Rsp)) = (Wrd30.Obj);
  (* (--Rsp)) = (Wrd13.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_28_1]), 2);

DEFLABEL (label_17)
  (Wrd16.Obj) = Rvl;
  goto label_25;

DEFLABEL (label_27)
  Rvl = ((SCHEME_OBJECT) 0);

DEFLABEL (label_28)
  Rsp = (& (Rsp [6]));
  goto pop_return;

DEFLABEL (label_29)
  Rvl = (Rsp [1]);
  goto label_28;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_29_4 3
#define LABEL_29_5 5
#define ENVIRONMENT_LABEL_29_3 9
#define DEBUGGING_LABEL_29_2 8
#define OBJECT_29_1 7
#define OBJECT_29_0 6
#define FREE_REFERENCES_LABEL_29_0 6
#define NUMBER_OF_LINKER_SECTIONS_29_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_29 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd27;
  machine_word Wrd24;
  machine_word Wrd19;
  machine_word Wrd21;
  machine_word Wrd20;
  machine_word Wrd16;
  machine_word Wrd18;
  machine_word Wrd17;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd9;
  machine_word Wrd8;
  machine_word Wrd13;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_29_4);
      goto cache_entry_reusableP_14;

    case 1:
      current_block = (Rpc - LABEL_29_5);
      goto loop_11;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_entry_reusableP_17)
DEFLABEL (cache_entry_reusableP_14)
  INTERRUPT_CHECK (26, LABEL_29_4);
  (Wrd5.Obj) = (Rsp [0]);
  if ((Wrd5.Obj) == ((SCHEME_OBJECT) 0))
    goto label_20;
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  goto label_19;

DEFLABEL (label_20)
  (Wrd13.Obj) = (current_block [OBJECT_29_0]);
  (* (--Rsp)) = (Wrd13.Obj);

DEFLABEL (label_19)
DEFLABEL (label_22)
  (Wrd8.Obj) = (Rsp [0]);
  if ((Wrd8.Obj) == ((SCHEME_OBJECT) 0))
    goto label_21;
  Rvl = (Wrd8.Obj);
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_21)
  Rsp = (& (Rsp [1]));
  goto loop_11;

DEFLABEL (loop_18)
DEFLABEL (loop_11)
  INTERRUPT_CHECK (26, LABEL_29_5);
  (Wrd5.Obj) = (Rsp [0]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_29_1])))
    goto label_23;
  Rvl = (current_block [OBJECT_29_0]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_23)
  (Wrd8.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd9.Obj) = ((Wrd8.pObj) [0]);
  if ((Wrd9.Obj) == ((SCHEME_OBJECT) 0))
    goto label_25;
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  goto label_24;

DEFLABEL (label_25)
  (Wrd11.Obj) = (current_block [OBJECT_29_0]);
  (* (--Rsp)) = (Wrd11.Obj);

DEFLABEL (label_24)
DEFLABEL (label_29)
  (Wrd12.Obj) = (Rsp [0]);
  if ((Wrd12.Obj) == ((SCHEME_OBJECT) 0))
    goto label_27;
  Rvl = (Wrd12.Obj);

DEFLABEL (label_26)
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_27)
  (Wrd17.Obj) = (Rsp [1]);
  (Wrd18.pObj) = (OBJECT_ADDRESS (Wrd17.Obj));
  (Wrd16.Obj) = ((Wrd18.pObj) [0]);
  (Wrd20.Obj) = (Rsp [2]);
  (Wrd21.pObj) = (OBJECT_ADDRESS (Wrd20.Obj));
  (Wrd19.Obj) = ((Wrd21.pObj) [0]);
  if (! ((Wrd16.Obj) == (Wrd19.Obj)))
    goto label_28;
  (Wrd24.Obj) = ((Wrd18.pObj) [1]);
  (Rsp [1]) = (Wrd24.Obj);
  (Wrd27.Obj) = ((Wrd21.pObj) [1]);
  (Rsp [2]) = (Wrd27.Obj);
  Rsp = (& (Rsp [1]));
  goto loop_11;

DEFLABEL (label_28)
  Rvl = ((SCHEME_OBJECT) 0);
  goto label_26;

INVOKE_INTERFACE_TARGET_1
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_30_4 3
#define LABEL_30_5 5
#define LABEL_30_6 7
#define LABEL_30_7 9
#define LABEL_30_8 11
#define LABEL_30_9 13
#define LABEL_30_10 15
#define ENVIRONMENT_LABEL_30_3 23
#define DEBUGGING_LABEL_30_2 22
#define OBJECT_30_5 21
#define OBJECT_30_4 20
#define OBJECT_30_3 19
#define OBJECT_30_2 18
#define OBJECT_30_1 17
#define OBJECT_30_0 16
#define FREE_REFERENCES_LABEL_30_0 16
#define NUMBER_OF_LINKER_SECTIONS_30_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_30 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd45;
  machine_word Wrd48;
  machine_word Wrd47;
  machine_word Wrd46;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd37;
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd31;
  machine_word Wrd28;
  machine_word Wrd35;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd7;
  machine_word Wrd6;
  machine_word Wrd58;
  machine_word Wrd55;
  machine_word Wrd54;
  machine_word Wrd44;
  machine_word Wrd64;
  machine_word Wrd63;
  machine_word Wrd62;
  machine_word Wrd51;
  machine_word Wrd30;
  machine_word Wrd29;
  machine_word Wrd24;
  machine_word Wrd23;
  machine_word Wrd22;
  machine_word Wrd25;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_30_4);
      goto cache_count_19;

    case 1:
      current_block = (Rpc - LABEL_30_5);
      goto label_21;

    case 2:
      current_block = (Rpc - LABEL_30_6);
      goto label_22;

    case 3:
      current_block = (Rpc - LABEL_30_7);
      goto loop_12;

    case 4:
      current_block = (Rpc - LABEL_30_8);
      goto do_loop_16;

    case 5:
      current_block = (Rpc - LABEL_30_9);
      goto label_23;

    case 6:
      current_block = (Rpc - LABEL_30_10);
      goto label_24;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache_count_26)
DEFLABEL (cache_count_19)
  INTERRUPT_CHECK (26, LABEL_30_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_32;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_32;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_31)
  (Wrd25.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd25.uLng) == 10))
    goto label_30;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Obj) = (MAKE_OBJECT (26, (Wrd23.uLng)));
  (* (--Rsp)) = (Wrd24.Obj);

DEFLABEL (label_29)
  (Wrd30.Obj) = (current_block [OBJECT_30_3]);
  (* (--Rsp)) = (Wrd30.Obj);
  (* (--Rsp)) = (Wrd30.Obj);
  goto do_loop_16;

DEFLABEL (label_30)
  (Wrd29.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_30_6]))));
  (* (--Rsp)) = (Wrd29.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_30_2]), 1);

DEFLABEL (label_22)
  (* (--Rsp)) = Rvl;
  goto label_29;

DEFLABEL (label_32)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_30_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_30_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_30_1]), 2);

DEFLABEL (label_21)
  (Wrd5.Obj) = Rvl;
  goto label_31;

DEFLABEL (do_loop_28)
DEFLABEL (do_loop_16)
  INTERRUPT_CHECK (26, LABEL_30_8);
  (Wrd5.Obj) = (Rsp [0]);
  (Wrd6.Obj) = (Rsp [2]);
  if (! ((Wrd5.Obj) == (Wrd6.Obj)))
    goto label_33;
  Rvl = (Rsp [1]);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_33)
  (Wrd16.Obj) = (Rsp [3]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_40;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_40;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_39)
  (Wrd35.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd35.uLng) == 10))
    goto label_38;
  (Wrd28.Obj) = (Rsp [0]);
  (Wrd29.uLng) = (OBJECT_TYPE (Wrd28.Obj));
  if (! ((Wrd29.uLng) == 26))
    goto label_38;
  (Wrd31.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  (Wrd32.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd33.Obj) = ((Wrd32.pObj) [0]);
  (Wrd34.Lng) = (FIXNUM_TO_LONG (Wrd33.Obj));
  if (! (((unsigned long) (Wrd31.Lng)) < ((unsigned long) (Wrd34.Lng))))
    goto label_38;
  (Wrd24.uLng) = (OBJECT_DATUM (Wrd28.Obj));
  (Wrd26.pObj) = (& ((Wrd32.pObj) [(Wrd24.Lng)]));
  (Wrd27.Obj) = ((Wrd26.pObj) [1]);
  (* (--Rsp)) = (Wrd27.Obj);

DEFLABEL (label_37)
  (Wrd41.Obj) = (Rsp [0]);
  if ((Wrd41.Obj) == ((SCHEME_OBJECT) 0))
    goto label_35;

DEFLABEL (label_34)
  goto loop_12;

DEFLABEL (label_35)
  Rsp = (& (Rsp [1]));
  (Wrd44.Obj) = (Rsp [1]);

DEFLABEL (label_36)
  (Rsp [1]) = (Wrd44.Obj);
  (Wrd46.Obj) = (Rsp [0]);
  (Wrd47.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  (Wrd48.Lng) = ((Wrd47.Lng) + 1L);
  (Wrd45.Obj) = (LONG_TO_FIXNUM (Wrd48.Lng));
  (Rsp [0]) = (Wrd45.Obj);
  goto do_loop_16;

DEFLABEL (label_38)
  (Wrd37.Obj) = (Rsp [0]);
  (Wrd40.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_30_10]))));
  (* (--Rsp)) = (Wrd40.Obj);
  (* (--Rsp)) = (Wrd37.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_30_5]), 2);

DEFLABEL (label_24)
  (* (--Rsp)) = Rvl;
  goto label_37;

DEFLABEL (label_40)
  (Wrd18.Obj) = (Rsp [3]);
  (Wrd19.Obj) = (current_block [OBJECT_30_0]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_30_9]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_30_1]), 2);

DEFLABEL (label_23)
  (Wrd7.Obj) = Rvl;
  goto label_39;

DEFLABEL (loop_27)
DEFLABEL (loop_12)
  INTERRUPT_CHECK (26, LABEL_30_7);
  (Wrd51.Obj) = (Rsp [0]);
  if ((Wrd51.Obj) == (current_block [OBJECT_30_4]))
    goto label_41;
  (Wrd54.pObj) = (OBJECT_ADDRESS (Wrd51.Obj));
  (Wrd55.Obj) = ((Wrd54.pObj) [0]);
  if ((Wrd55.Obj) == ((SCHEME_OBJECT) 0))
    goto label_35;
  (Wrd58.Obj) = ((Wrd54.pObj) [1]);
  (Rsp [0]) = (Wrd58.Obj);
  goto label_34;

DEFLABEL (label_41)
  Rsp = (& (Rsp [1]));
  (Wrd62.Obj) = (Rsp [1]);
  (Wrd63.Lng) = (FIXNUM_TO_LONG (Wrd62.Obj));
  (Wrd64.Lng) = ((Wrd63.Lng) + 1L);
  (Wrd44.Obj) = (LONG_TO_FIXNUM (Wrd64.Lng));
  goto label_36;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_31_4 3
#define LABEL_31_5 5
#define LABEL_31_6 7
#define LABEL_31_7 9
#define LABEL_31_8 11
#define LABEL_31_9 13
#define LABEL_31_10 15
#define LABEL_31_11 17
#define LABEL_31_12 19
#define LABEL_31_13 21
#define LABEL_31_14 23
#define LABEL_31_15 25
#define LABEL_31_16 27
#define LABEL_31_17 29
#define LABEL_31_18 31
#define LABEL_31_19 33
#define LABEL_31_20 35
#define LABEL_31_21 37
#define LABEL_31_22 39
#define LABEL_31_23 41
#define LABEL_31_24 43
#define LABEL_31_25 45
#define LABEL_31_26 47
#define LABEL_31_27 49
#define LABEL_31_28 51
#define LABEL_31_29 53
#define LABEL_31_30 55
#define LABEL_31_31 57
#define LABEL_31_32 59
#define LABEL_31_33 61
#define LABEL_31_34 63
#define LABEL_31_35 65
#define LABEL_31_36 67
#define ENVIRONMENT_LABEL_31_3 82
#define DEBUGGING_LABEL_31_2 81
#define OBJECT_31_12 80
#define OBJECT_31_11 79
#define OBJECT_31_10 78
#define OBJECT_31_9 77
#define OBJECT_31_8 76
#define OBJECT_31_7 75
#define OBJECT_31_6 74
#define OBJECT_31_5 73
#define OBJECT_31_4 72
#define OBJECT_31_3 71
#define OBJECT_31_2 70
#define OBJECT_31_1 69
#define OBJECT_31_0 68
#define FREE_REFERENCES_LABEL_31_0 68
#define NUMBER_OF_LINKER_SECTIONS_31_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_31 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd34;
  machine_word Wrd25;
  machine_word Wrd23;
  machine_word Wrd9;
  machine_word Wrd62;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd63;
  machine_word Wrd53;
  machine_word Wrd44;
  machine_word Wrd40;
  machine_word Wrd35;
  machine_word Wrd39;
  machine_word Wrd125;
  machine_word Wrd134;
  machine_word Wrd133;
  machine_word Wrd128;
  machine_word Wrd135;
  machine_word Wrd115;
  machine_word Wrd114;
  machine_word Wrd109;
  machine_word Wrd113;
  machine_word Wrd100;
  machine_word Wrd99;
  machine_word Wrd96;
  machine_word Wrd90;
  machine_word Wrd88;
  machine_word Wrd87;
  machine_word Wrd74;
  machine_word Wrd73;
  machine_word Wrd150;
  machine_word Wrd26;
  machine_word Wrd24;
  machine_word Wrd142;
  machine_word Wrd141;
  machine_word Wrd138;
  machine_word Wrd22;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd167;
  machine_word Wrd158;
  machine_word Wrd6;
  machine_word Wrd5;
  machine_word Wrd253;
  machine_word Wrd252;
  machine_word Wrd251;
  machine_word Wrd249;
  machine_word Wrd248;
  machine_word Wrd246;
  machine_word Wrd245;
  machine_word Wrd241;
  machine_word Wrd228;
  machine_word Wrd232;
  machine_word Wrd229;
  machine_word Wrd238;
  machine_word Wrd237;
  machine_word Wrd236;
  machine_word Wrd234;
  machine_word Wrd233;
  machine_word Wrd240;
  machine_word Wrd239;
  machine_word Wrd227;
  machine_word Wrd224;
  machine_word Wrd223;
  machine_word Wrd212;
  machine_word Wrd220;
  machine_word Wrd219;
  machine_word Wrd218;
  machine_word Wrd222;
  machine_word Wrd221;
  machine_word Wrd211;
  machine_word Wrd208;
  machine_word Wrd207;
  machine_word Wrd198;
  machine_word Wrd204;
  machine_word Wrd203;
  machine_word Wrd202;
  machine_word Wrd206;
  machine_word Wrd205;
  machine_word Wrd254;
  machine_word Wrd195;
  machine_word Wrd192;
  machine_word Wrd194;
  machine_word Wrd193;
  machine_word Wrd190;
  machine_word Wrd189;
  machine_word Wrd187;
  machine_word Wrd186;
  machine_word Wrd182;
  machine_word Wrd169;
  machine_word Wrd173;
  machine_word Wrd170;
  machine_word Wrd179;
  machine_word Wrd178;
  machine_word Wrd177;
  machine_word Wrd175;
  machine_word Wrd174;
  machine_word Wrd181;
  machine_word Wrd180;
  machine_word Wrd168;
  machine_word Wrd165;
  machine_word Wrd164;
  machine_word Wrd153;
  machine_word Wrd161;
  machine_word Wrd160;
  machine_word Wrd159;
  machine_word Wrd163;
  machine_word Wrd162;
  machine_word Wrd152;
  machine_word Wrd149;
  machine_word Wrd148;
  machine_word Wrd139;
  machine_word Wrd145;
  machine_word Wrd144;
  machine_word Wrd143;
  machine_word Wrd147;
  machine_word Wrd146;
  machine_word Wrd136;
  machine_word Wrd131;
  machine_word Wrd130;
  machine_word Wrd129;
  machine_word Wrd132;
  machine_word Wrd127;
  machine_word Wrd124;
  machine_word Wrd123;
  machine_word Wrd112;
  machine_word Wrd120;
  machine_word Wrd119;
  machine_word Wrd118;
  machine_word Wrd122;
  machine_word Wrd121;
  machine_word Wrd111;
  machine_word Wrd110;
  machine_word Wrd107;
  machine_word Wrd106;
  machine_word Wrd97;
  machine_word Wrd103;
  machine_word Wrd102;
  machine_word Wrd101;
  machine_word Wrd105;
  machine_word Wrd104;
  machine_word Wrd331;
  machine_word Wrd328;
  machine_word Wrd340;
  machine_word Wrd339;
  machine_word Wrd338;
  machine_word Wrd336;
  machine_word Wrd334;
  machine_word Wrd333;
  machine_word Wrd342;
  machine_word Wrd325;
  machine_word Wrd322;
  machine_word Wrd321;
  machine_word Wrd310;
  machine_word Wrd318;
  machine_word Wrd317;
  machine_word Wrd316;
  machine_word Wrd320;
  machine_word Wrd319;
  machine_word Wrd306;
  machine_word Wrd309;
  machine_word Wrd308;
  machine_word Wrd307;
  machine_word Wrd305;
  machine_word Wrd304;
  machine_word Wrd300;
  machine_word Wrd287;
  machine_word Wrd291;
  machine_word Wrd288;
  machine_word Wrd297;
  machine_word Wrd296;
  machine_word Wrd295;
  machine_word Wrd293;
  machine_word Wrd292;
  machine_word Wrd299;
  machine_word Wrd298;
  machine_word Wrd286;
  machine_word Wrd283;
  machine_word Wrd282;
  machine_word Wrd271;
  machine_word Wrd279;
  machine_word Wrd278;
  machine_word Wrd277;
  machine_word Wrd281;
  machine_word Wrd280;
  machine_word Wrd270;
  machine_word Wrd267;
  machine_word Wrd266;
  machine_word Wrd257;
  machine_word Wrd263;
  machine_word Wrd262;
  machine_word Wrd261;
  machine_word Wrd265;
  machine_word Wrd264;
  machine_word Wrd94;
  machine_word Wrd92;
  machine_word Wrd93;
  machine_word Wrd91;
  machine_word Wrd77;
  machine_word Wrd80;
  machine_word Wrd78;
  machine_word Wrd85;
  machine_word Wrd84;
  machine_word Wrd83;
  machine_word Wrd82;
  machine_word Wrd81;
  machine_word Wrd86;
  machine_word Wrd76;
  machine_word Wrd75;
  machine_word Wrd72;
  machine_word Wrd71;
  machine_word Wrd60;
  machine_word Wrd68;
  machine_word Wrd67;
  machine_word Wrd66;
  machine_word Wrd70;
  machine_word Wrd69;
  machine_word Wrd59;
  machine_word Wrd58;
  machine_word Wrd57;
  machine_word Wrd56;
  machine_word Wrd55;
  machine_word Wrd54;
  machine_word Wrd50;
  machine_word Wrd37;
  machine_word Wrd41;
  machine_word Wrd38;
  machine_word Wrd47;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd43;
  machine_word Wrd42;
  machine_word Wrd49;
  machine_word Wrd48;
  machine_word Wrd36;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd21;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd27;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd7;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_31_4);
      goto probe_cache_1_56;

    case 1:
      current_block = (Rpc - LABEL_31_5);
      goto label_58;

    case 2:
      current_block = (Rpc - LABEL_31_6);
      goto label_59;

    case 3:
      current_block = (Rpc - LABEL_31_7);
      goto label_60;

    case 4:
      current_block = (Rpc - LABEL_31_8);
      goto label_61;

    case 5:
      current_block = (Rpc - LABEL_31_9);
      goto label_62;

    case 6:
      current_block = (Rpc - LABEL_31_10);
      goto label_72;

    case 7:
      current_block = (Rpc - LABEL_31_11);
      goto label_73;

    case 8:
      current_block = (Rpc - LABEL_31_12);
      goto label_74;

    case 9:
      current_block = (Rpc - LABEL_31_13);
      goto label_75;

    case 10:
      current_block = (Rpc - LABEL_31_14);
      goto label_63;

    case 11:
      current_block = (Rpc - LABEL_31_15);
      goto label_64;

    case 12:
      current_block = (Rpc - LABEL_31_16);
      goto label_65;

    case 13:
      current_block = (Rpc - LABEL_31_17);
      goto label_66;

    case 14:
      current_block = (Rpc - LABEL_31_18);
      goto label_67;

    case 15:
      current_block = (Rpc - LABEL_31_19);
      goto label_68;

    case 16:
      current_block = (Rpc - LABEL_31_20);
      goto label_69;

    case 17:
      current_block = (Rpc - LABEL_31_21);
      goto label_70;

    case 18:
      current_block = (Rpc - LABEL_31_22);
      goto label_71;

    case 19:
      current_block = (Rpc - LABEL_31_23);
      goto search_lines_48;

    case 20:
      current_block = (Rpc - LABEL_31_24);
      goto label_83;

    case 21:
      current_block = (Rpc - LABEL_31_25);
      goto label_76;

    case 22:
      current_block = (Rpc - LABEL_31_26);
      goto label_82;

    case 23:
      current_block = (Rpc - LABEL_31_27);
      goto label_79;

    case 24:
      current_block = (Rpc - LABEL_31_28);
      goto label_80;

    case 25:
      current_block = (Rpc - LABEL_31_29);
      goto label_81;

    case 26:
      current_block = (Rpc - LABEL_31_30);
      goto label_77;

    case 27:
      current_block = (Rpc - LABEL_31_31);
      goto label_78;

    case 28:
      current_block = (Rpc - LABEL_31_32);
      goto search_overflow_46;

    case 29:
      current_block = (Rpc - LABEL_31_33);
      goto label_84;

    case 30:
      current_block = (Rpc - LABEL_31_34);
      goto label_85;

    case 31:
      current_block = (Rpc - LABEL_31_35);
      goto label_87;

    case 32:
      current_block = (Rpc - LABEL_31_36);
      goto label_86;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (probe_cache_1_89)
DEFLABEL (probe_cache_1_56)
  INTERRUPT_CHECK (26, LABEL_31_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_132;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd13.Lng))))
    goto label_132;
  (Wrd7.Obj) = ((Wrd11.pObj) [3]);
  (* (--Rsp)) = (Wrd7.Obj);

DEFLABEL (label_131)
  (Wrd30.Obj) = (Rsp [1]);
  (Wrd31.uLng) = (OBJECT_TYPE (Wrd30.Obj));
  if (! ((Wrd31.uLng) == 62))
    goto label_130;
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd30.Obj));
  (Wrd28.Obj) = ((Wrd27.pObj) [0]);
  (Wrd29.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd29.Lng))))
    goto label_130;
  (Wrd21.Obj) = ((Wrd27.pObj) [2]);

DEFLABEL (label_129)
  (Wrd48.Obj) = (Rsp [2]);
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd48.Obj));
  if (! ((Wrd49.uLng) == 62))
    goto label_128;
  (Wrd42.uLng) = (OBJECT_TYPE (Wrd21.Obj));
  if (! ((Wrd42.uLng) == 26))
    goto label_128;
  (Wrd43.Lng) = (FIXNUM_TO_LONG (Wrd21.Obj));
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd48.Obj));
  (Wrd46.Obj) = ((Wrd45.pObj) [0]);
  (Wrd47.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  if (! (((unsigned long) (Wrd43.Lng)) < ((unsigned long) (Wrd47.Lng))))
    goto label_128;
  (Wrd38.uLng) = (OBJECT_DATUM (Wrd21.Obj));
  (Wrd41.pObj) = (& ((Wrd45.pObj) [(Wrd38.Lng)]));
  (Wrd37.Obj) = ((Wrd41.pObj) [1]);

DEFLABEL (label_127)
  (Wrd55.Obj) = (* (Rsp++));
  (Wrd56.Lng) = (FIXNUM_TO_LONG (Wrd37.Obj));
  (Wrd57.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd58.Lng) = ((Wrd56.Lng) & (Wrd57.Lng));
  (Wrd59.Obj) = (LONG_TO_FIXNUM (Wrd58.Lng));
  (* (--Rsp)) = (Wrd59.Obj);
  (Wrd69.Obj) = (Rsp [1]);
  (Wrd70.uLng) = (OBJECT_TYPE (Wrd69.Obj));
  if (! ((Wrd70.uLng) == 62))
    goto label_126;
  (Wrd66.pObj) = (OBJECT_ADDRESS (Wrd69.Obj));
  (Wrd67.Obj) = ((Wrd66.pObj) [0]);
  (Wrd68.Lng) = (FIXNUM_TO_LONG (Wrd67.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd68.Lng))))
    goto label_126;
  (Wrd60.Obj) = ((Wrd66.pObj) [6]);

DEFLABEL (label_125)
  (Wrd76.Obj) = (* (Rsp++));
  (Wrd86.uLng) = (OBJECT_TYPE (Wrd60.Obj));
  if (! ((Wrd86.uLng) == 10))
    goto label_124;
  (Wrd81.uLng) = (OBJECT_TYPE (Wrd76.Obj));
  if (! ((Wrd81.uLng) == 26))
    goto label_124;
  (Wrd82.Lng) = (FIXNUM_TO_LONG (Wrd76.Obj));
  (Wrd83.pObj) = (OBJECT_ADDRESS (Wrd60.Obj));
  (Wrd84.Obj) = ((Wrd83.pObj) [0]);
  (Wrd85.Lng) = (FIXNUM_TO_LONG (Wrd84.Obj));
  if (! (((unsigned long) (Wrd82.Lng)) < ((unsigned long) (Wrd85.Lng))))
    goto label_124;
  (Wrd78.uLng) = (OBJECT_DATUM (Wrd76.Obj));
  (Wrd80.pObj) = (& ((Wrd83.pObj) [(Wrd78.Lng)]));
  (Wrd77.Obj) = ((Wrd80.pObj) [1]);

DEFLABEL (label_123)
  (Wrd93.pObj) = (OBJECT_ADDRESS (Wrd77.Obj));
  (Wrd92.Obj) = ((Wrd93.pObj) [0]);
  (Wrd94.Obj) = (Rsp [1]);
  if ((Wrd94.Obj) == (Wrd92.Obj))
    goto label_112;
  (Wrd104.Obj) = (Rsp [0]);
  (Wrd105.uLng) = (OBJECT_TYPE (Wrd104.Obj));
  if (! ((Wrd105.uLng) == 62))
    goto label_111;
  (Wrd101.pObj) = (OBJECT_ADDRESS (Wrd104.Obj));
  (Wrd102.Obj) = ((Wrd101.pObj) [0]);
  (Wrd103.Lng) = (FIXNUM_TO_LONG (Wrd102.Obj));
  if (! (((unsigned long) 3L) < ((unsigned long) (Wrd103.Lng))))
    goto label_111;
  (Wrd97.Obj) = ((Wrd101.pObj) [4]);
  (* (--Rsp)) = (Wrd97.Obj);

DEFLABEL (label_110)
  (Wrd111.Obj) = (current_block [OBJECT_31_7]);
  (* (--Rsp)) = (Wrd111.Obj);
  (Wrd121.Obj) = (Rsp [2]);
  (Wrd122.uLng) = (OBJECT_TYPE (Wrd121.Obj));
  if (! ((Wrd122.uLng) == 62))
    goto label_109;
  (Wrd118.pObj) = (OBJECT_ADDRESS (Wrd121.Obj));
  (Wrd119.Obj) = ((Wrd118.pObj) [0]);
  (Wrd120.Lng) = (FIXNUM_TO_LONG (Wrd119.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd120.Lng))))
    goto label_109;
  (Wrd112.Obj) = ((Wrd118.pObj) [6]);

DEFLABEL (label_108)
  (Wrd132.uLng) = (OBJECT_TYPE (Wrd112.Obj));
  if (! ((Wrd132.uLng) == 10))
    goto label_107;
  (Wrd129.pObj) = (OBJECT_ADDRESS (Wrd112.Obj));
  (Wrd130.Obj) = ((Wrd129.pObj) [0]);
  (Wrd131.Obj) = (MAKE_OBJECT (26, (Wrd130.uLng)));
  (* (--Rsp)) = (Wrd131.Obj);

DEFLABEL (label_106)
  (Wrd146.Obj) = (Rsp [3]);
  (Wrd147.uLng) = (OBJECT_TYPE (Wrd146.Obj));
  if (! ((Wrd147.uLng) == 62))
    goto label_105;
  (Wrd143.pObj) = (OBJECT_ADDRESS (Wrd146.Obj));
  (Wrd144.Obj) = ((Wrd143.pObj) [0]);
  (Wrd145.Lng) = (FIXNUM_TO_LONG (Wrd144.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd145.Lng))))
    goto label_105;
  (Wrd139.Obj) = ((Wrd143.pObj) [3]);
  (* (--Rsp)) = (Wrd139.Obj);

DEFLABEL (label_104)
  (Wrd162.Obj) = (Rsp [4]);
  (Wrd163.uLng) = (OBJECT_TYPE (Wrd162.Obj));
  if (! ((Wrd163.uLng) == 62))
    goto label_103;
  (Wrd159.pObj) = (OBJECT_ADDRESS (Wrd162.Obj));
  (Wrd160.Obj) = ((Wrd159.pObj) [0]);
  (Wrd161.Lng) = (FIXNUM_TO_LONG (Wrd160.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd161.Lng))))
    goto label_103;
  (Wrd153.Obj) = ((Wrd159.pObj) [2]);

DEFLABEL (label_102)
  (Wrd180.Obj) = (Rsp [5]);
  (Wrd181.uLng) = (OBJECT_TYPE (Wrd180.Obj));
  if (! ((Wrd181.uLng) == 62))
    goto label_101;
  (Wrd174.uLng) = (OBJECT_TYPE (Wrd153.Obj));
  if (! ((Wrd174.uLng) == 26))
    goto label_101;
  (Wrd175.Lng) = (FIXNUM_TO_LONG (Wrd153.Obj));
  (Wrd177.pObj) = (OBJECT_ADDRESS (Wrd180.Obj));
  (Wrd178.Obj) = ((Wrd177.pObj) [0]);
  (Wrd179.Lng) = (FIXNUM_TO_LONG (Wrd178.Obj));
  if (! (((unsigned long) (Wrd175.Lng)) < ((unsigned long) (Wrd179.Lng))))
    goto label_101;
  (Wrd170.uLng) = (OBJECT_DATUM (Wrd153.Obj));
  (Wrd173.pObj) = (& ((Wrd177.pObj) [(Wrd170.Lng)]));
  (Wrd169.Obj) = ((Wrd173.pObj) [1]);

DEFLABEL (label_100)
  (Wrd187.Obj) = (* (Rsp++));
  (Wrd189.Lng) = (FIXNUM_TO_LONG (Wrd169.Obj));
  (Wrd190.Lng) = (FIXNUM_TO_LONG (Wrd187.Obj));
  (Wrd193.Lng) = ((Wrd189.Lng) & (Wrd190.Lng));
  (Wrd194.Lng) = ((Wrd193.Lng) + 1L);
  (Wrd192.Obj) = (LONG_TO_FIXNUM (Wrd194.Lng));
  (Wrd195.Obj) = (* (Rsp++));
  if ((Wrd192.Obj) == (Wrd195.Obj))
    goto label_99;
  (Wrd205.Obj) = (Rsp [2]);
  (Wrd206.uLng) = (OBJECT_TYPE (Wrd205.Obj));
  if (! ((Wrd206.uLng) == 62))
    goto label_98;
  (Wrd202.pObj) = (OBJECT_ADDRESS (Wrd205.Obj));
  (Wrd203.Obj) = ((Wrd202.pObj) [0]);
  (Wrd204.Lng) = (FIXNUM_TO_LONG (Wrd203.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd204.Lng))))
    goto label_98;
  (Wrd198.Obj) = ((Wrd202.pObj) [3]);
  (* (--Rsp)) = (Wrd198.Obj);

DEFLABEL (label_97)
  (Wrd221.Obj) = (Rsp [3]);
  (Wrd222.uLng) = (OBJECT_TYPE (Wrd221.Obj));
  if (! ((Wrd222.uLng) == 62))
    goto label_96;
  (Wrd218.pObj) = (OBJECT_ADDRESS (Wrd221.Obj));
  (Wrd219.Obj) = ((Wrd218.pObj) [0]);
  (Wrd220.Lng) = (FIXNUM_TO_LONG (Wrd219.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd220.Lng))))
    goto label_96;
  (Wrd212.Obj) = ((Wrd218.pObj) [2]);

DEFLABEL (label_95)
  (Wrd239.Obj) = (Rsp [4]);
  (Wrd240.uLng) = (OBJECT_TYPE (Wrd239.Obj));
  if (! ((Wrd240.uLng) == 62))
    goto label_94;
  (Wrd233.uLng) = (OBJECT_TYPE (Wrd212.Obj));
  if (! ((Wrd233.uLng) == 26))
    goto label_94;
  (Wrd234.Lng) = (FIXNUM_TO_LONG (Wrd212.Obj));
  (Wrd236.pObj) = (OBJECT_ADDRESS (Wrd239.Obj));
  (Wrd237.Obj) = ((Wrd236.pObj) [0]);
  (Wrd238.Lng) = (FIXNUM_TO_LONG (Wrd237.Obj));
  if (! (((unsigned long) (Wrd234.Lng)) < ((unsigned long) (Wrd238.Lng))))
    goto label_94;
  (Wrd229.uLng) = (OBJECT_DATUM (Wrd212.Obj));
  (Wrd232.pObj) = (& ((Wrd236.pObj) [(Wrd229.Lng)]));
  (Wrd228.Obj) = ((Wrd232.pObj) [1]);

DEFLABEL (label_93)
  (Wrd246.Obj) = (* (Rsp++));
  (Wrd248.Lng) = (FIXNUM_TO_LONG (Wrd228.Obj));
  (Wrd249.Lng) = (FIXNUM_TO_LONG (Wrd246.Obj));
  (Wrd251.Lng) = ((Wrd248.Lng) & (Wrd249.Lng));
  (Wrd252.Lng) = ((Wrd251.Lng) + 1L);
  (Wrd253.Obj) = (LONG_TO_FIXNUM (Wrd252.Lng));
  (* (--Rsp)) = (Wrd253.Obj);

DEFLABEL (label_92)
  goto search_lines_48;

DEFLABEL (label_94)
  (Wrd241.Obj) = (Rsp [4]);
  (Wrd245.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_22]))));
  (* (--Rsp)) = (Wrd245.Obj);
  (* (--Rsp)) = (Wrd212.Obj);
  (* (--Rsp)) = (Wrd241.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_71)
  (Wrd228.Obj) = Rvl;
  goto label_93;

DEFLABEL (label_96)
  (Wrd223.Obj) = (Rsp [3]);
  (Wrd224.Obj) = (current_block [OBJECT_31_2]);
  (Wrd227.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_21]))));
  (* (--Rsp)) = (Wrd227.Obj);
  (* (--Rsp)) = (Wrd224.Obj);
  (* (--Rsp)) = (Wrd223.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_70)
  (Wrd212.Obj) = Rvl;
  goto label_95;

DEFLABEL (label_98)
  (Wrd207.Obj) = (Rsp [2]);
  (Wrd208.Obj) = (current_block [OBJECT_31_0]);
  (Wrd211.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_20]))));
  (* (--Rsp)) = (Wrd211.Obj);
  (* (--Rsp)) = (Wrd208.Obj);
  (* (--Rsp)) = (Wrd207.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_69)
  (* (--Rsp)) = Rvl;
  goto label_97;

DEFLABEL (label_99)
  (Wrd254.Obj) = (current_block [OBJECT_31_7]);
  (* (--Rsp)) = (Wrd254.Obj);
  goto label_92;

DEFLABEL (label_101)
  (Wrd182.Obj) = (Rsp [5]);
  (Wrd186.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_19]))));
  (* (--Rsp)) = (Wrd186.Obj);
  (* (--Rsp)) = (Wrd153.Obj);
  (* (--Rsp)) = (Wrd182.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_68)
  (Wrd169.Obj) = Rvl;
  goto label_100;

DEFLABEL (label_103)
  (Wrd164.Obj) = (Rsp [4]);
  (Wrd165.Obj) = (current_block [OBJECT_31_2]);
  (Wrd168.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_18]))));
  (* (--Rsp)) = (Wrd168.Obj);
  (* (--Rsp)) = (Wrd165.Obj);
  (* (--Rsp)) = (Wrd164.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_67)
  (Wrd153.Obj) = Rvl;
  goto label_102;

DEFLABEL (label_105)
  (Wrd148.Obj) = (Rsp [3]);
  (Wrd149.Obj) = (current_block [OBJECT_31_0]);
  (Wrd152.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_17]))));
  (* (--Rsp)) = (Wrd152.Obj);
  (* (--Rsp)) = (Wrd149.Obj);
  (* (--Rsp)) = (Wrd148.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_66)
  (* (--Rsp)) = Rvl;
  goto label_104;

DEFLABEL (label_107)
  (Wrd136.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_16]))));
  (* (--Rsp)) = (Wrd136.Obj);
  (* (--Rsp)) = (Wrd112.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_8]), 1);

DEFLABEL (label_65)
  (* (--Rsp)) = Rvl;
  goto label_106;

DEFLABEL (label_109)
  (Wrd123.Obj) = (Rsp [2]);
  (Wrd124.Obj) = (current_block [OBJECT_31_3]);
  (Wrd127.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_15]))));
  (* (--Rsp)) = (Wrd127.Obj);
  (* (--Rsp)) = (Wrd124.Obj);
  (* (--Rsp)) = (Wrd123.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_64)
  (Wrd112.Obj) = Rvl;
  goto label_108;

DEFLABEL (label_111)
  (Wrd106.Obj) = (Rsp [0]);
  (Wrd107.Obj) = (current_block [OBJECT_31_6]);
  (Wrd110.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_14]))));
  (* (--Rsp)) = (Wrd110.Obj);
  (* (--Rsp)) = (Wrd107.Obj);
  (* (--Rsp)) = (Wrd106.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_63)
  (* (--Rsp)) = Rvl;
  goto label_110;

DEFLABEL (label_112)
  (Wrd264.Obj) = (Rsp [0]);
  (Wrd265.uLng) = (OBJECT_TYPE (Wrd264.Obj));
  if (! ((Wrd265.uLng) == 62))
    goto label_122;
  (Wrd261.pObj) = (OBJECT_ADDRESS (Wrd264.Obj));
  (Wrd262.Obj) = ((Wrd261.pObj) [0]);
  (Wrd263.Lng) = (FIXNUM_TO_LONG (Wrd262.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd263.Lng))))
    goto label_122;
  (Wrd257.Obj) = ((Wrd261.pObj) [3]);
  (* (--Rsp)) = (Wrd257.Obj);

DEFLABEL (label_121)
  (Wrd280.Obj) = (Rsp [1]);
  (Wrd281.uLng) = (OBJECT_TYPE (Wrd280.Obj));
  if (! ((Wrd281.uLng) == 62))
    goto label_120;
  (Wrd277.pObj) = (OBJECT_ADDRESS (Wrd280.Obj));
  (Wrd278.Obj) = ((Wrd277.pObj) [0]);
  (Wrd279.Lng) = (FIXNUM_TO_LONG (Wrd278.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd279.Lng))))
    goto label_120;
  (Wrd271.Obj) = ((Wrd277.pObj) [2]);

DEFLABEL (label_119)
  (Wrd298.Obj) = (Rsp [2]);
  (Wrd299.uLng) = (OBJECT_TYPE (Wrd298.Obj));
  if (! ((Wrd299.uLng) == 62))
    goto label_118;
  (Wrd292.uLng) = (OBJECT_TYPE (Wrd271.Obj));
  if (! ((Wrd292.uLng) == 26))
    goto label_118;
  (Wrd293.Lng) = (FIXNUM_TO_LONG (Wrd271.Obj));
  (Wrd295.pObj) = (OBJECT_ADDRESS (Wrd298.Obj));
  (Wrd296.Obj) = ((Wrd295.pObj) [0]);
  (Wrd297.Lng) = (FIXNUM_TO_LONG (Wrd296.Obj));
  if (! (((unsigned long) (Wrd293.Lng)) < ((unsigned long) (Wrd297.Lng))))
    goto label_118;
  (Wrd288.uLng) = (OBJECT_DATUM (Wrd271.Obj));
  (Wrd291.pObj) = (& ((Wrd295.pObj) [(Wrd288.Lng)]));
  (Wrd287.Obj) = ((Wrd291.pObj) [1]);

DEFLABEL (label_117)
  (Wrd305.Obj) = (* (Rsp++));
  (Wrd307.Lng) = (FIXNUM_TO_LONG (Wrd287.Obj));
  (Wrd308.Lng) = (FIXNUM_TO_LONG (Wrd305.Obj));
  (Wrd309.Lng) = ((Wrd307.Lng) & (Wrd308.Lng));
  (Wrd306.Obj) = (LONG_TO_FIXNUM (Wrd309.Lng));
  (Rsp [1]) = (Wrd306.Obj);
  (Wrd319.Obj) = (Rsp [0]);
  (Wrd320.uLng) = (OBJECT_TYPE (Wrd319.Obj));
  if (! ((Wrd320.uLng) == 62))
    goto label_116;
  (Wrd316.pObj) = (OBJECT_ADDRESS (Wrd319.Obj));
  (Wrd317.Obj) = ((Wrd316.pObj) [0]);
  (Wrd318.Lng) = (FIXNUM_TO_LONG (Wrd317.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd318.Lng))))
    goto label_116;
  (Wrd310.Obj) = ((Wrd316.pObj) [7]);

DEFLABEL (label_115)
  (Rsp [0]) = (Wrd310.Obj);
  (Wrd342.uLng) = (OBJECT_TYPE (Wrd310.Obj));
  if ((Wrd342.uLng) == 10)
    goto label_114;

DEFLABEL (label_113)
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_4]), 2);

DEFLABEL (label_114)
  (Wrd333.Obj) = (Rsp [1]);
  (Wrd334.uLng) = (OBJECT_TYPE (Wrd333.Obj));
  if (! ((Wrd334.uLng) == 26))
    goto label_113;
  (Wrd336.Lng) = (FIXNUM_TO_LONG (Wrd333.Obj));
  (Wrd338.pObj) = (OBJECT_ADDRESS (Wrd310.Obj));
  (Wrd339.Obj) = ((Wrd338.pObj) [0]);
  (Wrd340.Lng) = (FIXNUM_TO_LONG (Wrd339.Obj));
  if (! (((unsigned long) (Wrd336.Lng)) < ((unsigned long) (Wrd340.Lng))))
    goto label_113;
  (Wrd328.uLng) = (OBJECT_DATUM (Wrd333.Obj));
  (Wrd331.pObj) = (& ((Wrd338.pObj) [(Wrd328.Lng)]));
  Rvl = ((Wrd331.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_116)
  (Wrd321.Obj) = (Rsp [0]);
  (Wrd322.Obj) = (current_block [OBJECT_31_5]);
  (Wrd325.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_13]))));
  (* (--Rsp)) = (Wrd325.Obj);
  (* (--Rsp)) = (Wrd322.Obj);
  (* (--Rsp)) = (Wrd321.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_75)
  (Wrd310.Obj) = Rvl;
  goto label_115;

DEFLABEL (label_118)
  (Wrd300.Obj) = (Rsp [2]);
  (Wrd304.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_12]))));
  (* (--Rsp)) = (Wrd304.Obj);
  (* (--Rsp)) = (Wrd271.Obj);
  (* (--Rsp)) = (Wrd300.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_74)
  (Wrd287.Obj) = Rvl;
  goto label_117;

DEFLABEL (label_120)
  (Wrd282.Obj) = (Rsp [1]);
  (Wrd283.Obj) = (current_block [OBJECT_31_2]);
  (Wrd286.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_11]))));
  (* (--Rsp)) = (Wrd286.Obj);
  (* (--Rsp)) = (Wrd283.Obj);
  (* (--Rsp)) = (Wrd282.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_73)
  (Wrd271.Obj) = Rvl;
  goto label_119;

DEFLABEL (label_122)
  (Wrd266.Obj) = (Rsp [0]);
  (Wrd267.Obj) = (current_block [OBJECT_31_0]);
  (Wrd270.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_10]))));
  (* (--Rsp)) = (Wrd270.Obj);
  (* (--Rsp)) = (Wrd267.Obj);
  (* (--Rsp)) = (Wrd266.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_72)
  (* (--Rsp)) = Rvl;
  goto label_121;

DEFLABEL (label_124)
  (Wrd91.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_9]))));
  (* (--Rsp)) = (Wrd91.Obj);
  (* (--Rsp)) = (Wrd76.Obj);
  (* (--Rsp)) = (Wrd60.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_4]), 2);

DEFLABEL (label_62)
  (Wrd77.Obj) = Rvl;
  goto label_123;

DEFLABEL (label_126)
  (Wrd71.Obj) = (Rsp [1]);
  (Wrd72.Obj) = (current_block [OBJECT_31_3]);
  (Wrd75.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_8]))));
  (* (--Rsp)) = (Wrd75.Obj);
  (* (--Rsp)) = (Wrd72.Obj);
  (* (--Rsp)) = (Wrd71.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_61)
  (Wrd60.Obj) = Rvl;
  goto label_125;

DEFLABEL (label_128)
  (Wrd50.Obj) = (Rsp [2]);
  (Wrd54.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_7]))));
  (* (--Rsp)) = (Wrd54.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = (Wrd50.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_60)
  (Wrd37.Obj) = Rvl;
  goto label_127;

DEFLABEL (label_130)
  (Wrd32.Obj) = (Rsp [1]);
  (Wrd33.Obj) = (current_block [OBJECT_31_2]);
  (Wrd36.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_6]))));
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd33.Obj);
  (* (--Rsp)) = (Wrd32.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_59)
  (Wrd21.Obj) = Rvl;
  goto label_129;

DEFLABEL (label_132)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_31_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_58)
  (* (--Rsp)) = Rvl;
  goto label_131;

DEFLABEL (search_lines_90)
DEFLABEL (search_lines_48)
  INTERRUPT_CHECK (26, LABEL_31_23);
  (Wrd5.Obj) = (Rsp [1]);
  (Wrd6.Obj) = (Rsp [2]);
  if ((Wrd5.Obj) == (Wrd6.Obj))
    goto label_154;
  (Wrd16.Obj) = (Rsp [3]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_153;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_153;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_152)
  (Wrd145.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd145.uLng) == 10))
    goto label_151;
  (Wrd138.Obj) = (Rsp [0]);
  (Wrd139.uLng) = (OBJECT_TYPE (Wrd138.Obj));
  if (! ((Wrd139.uLng) == 26))
    goto label_151;
  (Wrd141.Lng) = (FIXNUM_TO_LONG (Wrd138.Obj));
  (Wrd142.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd143.Obj) = ((Wrd142.pObj) [0]);
  (Wrd144.Lng) = (FIXNUM_TO_LONG (Wrd143.Obj));
  if (! (((unsigned long) (Wrd141.Lng)) < ((unsigned long) (Wrd144.Lng))))
    goto label_151;
  (Wrd24.uLng) = (OBJECT_DATUM (Wrd138.Obj));
  (Wrd26.pObj) = (& ((Wrd142.pObj) [(Wrd24.Lng)]));
  (Wrd27.Obj) = ((Wrd26.pObj) [1]);
  if ((Wrd27.Obj) == ((SCHEME_OBJECT) 0))
    goto label_140;

DEFLABEL (label_150)
  (Wrd75.Obj) = (Rsp [3]);
  (Wrd76.uLng) = (OBJECT_TYPE (Wrd75.Obj));
  if (! ((Wrd76.uLng) == 62))
    goto label_149;
  (Wrd72.pObj) = (OBJECT_ADDRESS (Wrd75.Obj));
  (Wrd73.Obj) = ((Wrd72.pObj) [0]);
  (Wrd74.Lng) = (FIXNUM_TO_LONG (Wrd73.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd74.Lng))))
    goto label_149;
  (Wrd66.Obj) = ((Wrd72.pObj) [6]);

DEFLABEL (label_148)
  (Wrd94.uLng) = (OBJECT_TYPE (Wrd66.Obj));
  if (! ((Wrd94.uLng) == 10))
    goto label_147;
  (Wrd87.Obj) = (Rsp [0]);
  (Wrd88.uLng) = (OBJECT_TYPE (Wrd87.Obj));
  if (! ((Wrd88.uLng) == 26))
    goto label_147;
  (Wrd90.Lng) = (FIXNUM_TO_LONG (Wrd87.Obj));
  (Wrd91.pObj) = (OBJECT_ADDRESS (Wrd66.Obj));
  (Wrd92.Obj) = ((Wrd91.pObj) [0]);
  (Wrd93.Lng) = (FIXNUM_TO_LONG (Wrd92.Obj));
  if (! (((unsigned long) (Wrd90.Lng)) < ((unsigned long) (Wrd93.Lng))))
    goto label_147;
  (Wrd84.uLng) = (OBJECT_DATUM (Wrd87.Obj));
  (Wrd86.pObj) = (& ((Wrd91.pObj) [(Wrd84.Lng)]));
  (Wrd82.Obj) = ((Wrd86.pObj) [1]);

DEFLABEL (label_146)
  (Wrd101.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd100.Obj) = ((Wrd101.pObj) [0]);
  (Wrd102.Obj) = (Rsp [4]);
  if ((Wrd102.Obj) == (Wrd100.Obj))
    goto label_141;

DEFLABEL (label_140)
  (Wrd38.Obj) = (Rsp [3]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 62))
    goto label_139;
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (Wrd37.Lng) = (FIXNUM_TO_LONG (Wrd36.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd37.Lng))))
    goto label_139;
  (Wrd29.Obj) = ((Wrd35.pObj) [6]);

DEFLABEL (label_138)
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd49.uLng) == 10))
    goto label_137;
  (Wrd47.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd48.Obj) = ((Wrd47.pObj) [0]);
  (Wrd45.Obj) = (MAKE_OBJECT (26, (Wrd48.uLng)));

DEFLABEL (label_136)
  (Wrd55.Obj) = (Rsp [0]);
  (Wrd56.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd57.Lng) = ((Wrd56.Lng) + 1L);
  (Wrd54.Obj) = (LONG_TO_FIXNUM (Wrd57.Lng));
  if ((Wrd54.Obj) == (Wrd45.Obj))
    goto label_134;
  Wrd58 = Wrd54;
  goto label_133;

DEFLABEL (label_134)
  (Wrd58.Obj) = (current_block [OBJECT_31_7]);

DEFLABEL (label_133)
DEFLABEL (label_135)
  (Rsp [0]) = (Wrd58.Obj);
  (Wrd63.Obj) = (Rsp [1]);
  (Wrd64.Lng) = (FIXNUM_TO_LONG (Wrd63.Obj));
  (Wrd65.Lng) = ((Wrd64.Lng) + 1L);
  (Wrd62.Obj) = (LONG_TO_FIXNUM (Wrd65.Lng));
  (Rsp [1]) = (Wrd62.Obj);
  goto search_lines_48;

DEFLABEL (label_137)
  (Wrd53.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_31]))));
  (* (--Rsp)) = (Wrd53.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_8]), 1);

DEFLABEL (label_78)
  (Wrd45.Obj) = Rvl;
  goto label_136;

DEFLABEL (label_139)
  (Wrd40.Obj) = (Rsp [3]);
  (Wrd41.Obj) = (current_block [OBJECT_31_3]);
  (Wrd44.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_30]))));
  (* (--Rsp)) = (Wrd44.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd40.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_77)
  (Wrd29.Obj) = Rvl;
  goto label_138;

DEFLABEL (label_141)
  (Wrd112.Obj) = (Rsp [3]);
  (Wrd113.uLng) = (OBJECT_TYPE (Wrd112.Obj));
  if (! ((Wrd113.uLng) == 62))
    goto label_145;
  (Wrd109.pObj) = (OBJECT_ADDRESS (Wrd112.Obj));
  (Wrd110.Obj) = ((Wrd109.pObj) [0]);
  (Wrd111.Lng) = (FIXNUM_TO_LONG (Wrd110.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd111.Lng))))
    goto label_145;
  (Wrd103.Obj) = ((Wrd109.pObj) [7]);

DEFLABEL (label_144)
  (Rsp [3]) = (Wrd103.Obj);
  (Wrd119.Obj) = (Rsp [0]);
  (Rsp [4]) = (Wrd119.Obj);
  Rsp = (& (Rsp [3]));
  (Wrd135.Obj) = (Rsp [0]);
  (Wrd136.uLng) = (OBJECT_TYPE (Wrd135.Obj));
  if ((Wrd136.uLng) == 10)
    goto label_143;

DEFLABEL (label_142)
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_4]), 2);

DEFLABEL (label_143)
  (Wrd127.Obj) = (Rsp [1]);
  (Wrd128.uLng) = (OBJECT_TYPE (Wrd127.Obj));
  if (! ((Wrd128.uLng) == 26))
    goto label_142;
  (Wrd130.Lng) = (FIXNUM_TO_LONG (Wrd127.Obj));
  (Wrd132.pObj) = (OBJECT_ADDRESS (Wrd135.Obj));
  (Wrd133.Obj) = ((Wrd132.pObj) [0]);
  (Wrd134.Lng) = (FIXNUM_TO_LONG (Wrd133.Obj));
  if (! (((unsigned long) (Wrd130.Lng)) < ((unsigned long) (Wrd134.Lng))))
    goto label_142;
  (Wrd122.uLng) = (OBJECT_DATUM (Wrd127.Obj));
  (Wrd125.pObj) = (& ((Wrd132.pObj) [(Wrd122.Lng)]));
  Rvl = ((Wrd125.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_145)
  (Wrd114.Obj) = (Rsp [3]);
  (Wrd115.Obj) = (current_block [OBJECT_31_5]);
  (Wrd118.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_29]))));
  (* (--Rsp)) = (Wrd118.Obj);
  (* (--Rsp)) = (Wrd115.Obj);
  (* (--Rsp)) = (Wrd114.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_81)
  (Wrd103.Obj) = Rvl;
  goto label_144;

DEFLABEL (label_147)
  (Wrd96.Obj) = (Rsp [0]);
  (Wrd99.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_28]))));
  (* (--Rsp)) = (Wrd99.Obj);
  (* (--Rsp)) = (Wrd96.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_4]), 2);

DEFLABEL (label_80)
  (Wrd82.Obj) = Rvl;
  goto label_146;

DEFLABEL (label_149)
  (Wrd77.Obj) = (Rsp [3]);
  (Wrd78.Obj) = (current_block [OBJECT_31_3]);
  (Wrd81.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_27]))));
  (* (--Rsp)) = (Wrd81.Obj);
  (* (--Rsp)) = (Wrd78.Obj);
  (* (--Rsp)) = (Wrd77.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_79)
  (Wrd66.Obj) = Rvl;
  goto label_148;

DEFLABEL (label_151)
  (Wrd147.Obj) = (Rsp [0]);
  (Wrd150.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_26]))));
  (* (--Rsp)) = (Wrd150.Obj);
  (* (--Rsp)) = (Wrd147.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_4]), 2);

DEFLABEL (label_82)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_140;
  goto label_150;

DEFLABEL (label_153)
  (Wrd18.Obj) = (Rsp [3]);
  (Wrd19.Obj) = (current_block [OBJECT_31_3]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_25]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_76)
  (Wrd7.Obj) = Rvl;
  goto label_152;

DEFLABEL (label_154)
  (Wrd161.Obj) = (Rsp [3]);
  (Wrd162.uLng) = (OBJECT_TYPE (Wrd161.Obj));
  if (! ((Wrd162.uLng) == 62))
    goto label_156;
  (Wrd158.pObj) = (OBJECT_ADDRESS (Wrd161.Obj));
  (Wrd159.Obj) = ((Wrd158.pObj) [0]);
  (Wrd160.Lng) = (FIXNUM_TO_LONG (Wrd159.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd160.Lng))))
    goto label_156;
  (Wrd152.Obj) = ((Wrd158.pObj) [8]);

DEFLABEL (label_155)
  (Rsp [2]) = (Wrd152.Obj);
  Rsp = (& (Rsp [2]));
  goto search_overflow_46;

DEFLABEL (label_156)
  (Wrd163.Obj) = (Rsp [3]);
  (Wrd164.Obj) = (current_block [OBJECT_31_9]);
  (Wrd167.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_24]))));
  (* (--Rsp)) = (Wrd167.Obj);
  (* (--Rsp)) = (Wrd164.Obj);
  (* (--Rsp)) = (Wrd163.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_1]), 2);

DEFLABEL (label_83)
  (Wrd152.Obj) = Rvl;
  goto label_155;

DEFLABEL (search_overflow_91)
DEFLABEL (search_overflow_46)
  INTERRUPT_CHECK (26, LABEL_31_32);
  (Wrd5.Obj) = (Rsp [0]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_31_10])))
    goto label_157;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_157)
  (Wrd11.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd11.uLng) == 1))
    goto label_167;
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd7.Obj) = ((Wrd9.pObj) [0]);

DEFLABEL (label_166)
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd18.uLng) == 1))
    goto label_165;
  (Wrd17.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd16.Obj) = ((Wrd17.pObj) [0]);

DEFLABEL (label_164)
  (Wrd24.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd23.Obj) = ((Wrd24.pObj) [0]);
  (Wrd25.Obj) = (Rsp [2]);
  if ((Wrd25.Obj) == (Wrd23.Obj))
    goto label_160;
  (Wrd29.Obj) = (Rsp [0]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 1))
    goto label_159;
  (Wrd28.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd26.Obj) = ((Wrd28.pObj) [1]);

DEFLABEL (label_158)
  (Rsp [0]) = (Wrd26.Obj);
  goto search_overflow_46;

DEFLABEL (label_159)
  (Wrd34.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_36]))));
  (* (--Rsp)) = (Wrd34.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_12]), 1);

DEFLABEL (label_86)
  (Wrd26.Obj) = Rvl;
  goto label_158;

DEFLABEL (label_160)
  (Wrd38.Obj) = (Rsp [0]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 1))
    goto label_163;
  (Wrd37.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd35.Obj) = ((Wrd37.pObj) [0]);

DEFLABEL (label_162)
  (Rsp [2]) = (Wrd35.Obj);
  Rsp = (& (Rsp [2]));
  (Wrd48.Obj) = (Rsp [0]);
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd48.Obj));
  if (! ((Wrd49.uLng) == 1))
    goto label_161;
  (Wrd46.pObj) = (OBJECT_ADDRESS (Wrd48.Obj));
  Rvl = ((Wrd46.pObj) [1]);
  Rsp = (& (Rsp [1]));
  goto pop_return;

DEFLABEL (label_161)
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_12]), 1);

DEFLABEL (label_163)
  (Wrd43.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_35]))));
  (* (--Rsp)) = (Wrd43.Obj);
  (* (--Rsp)) = (Wrd38.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_11]), 1);

DEFLABEL (label_87)
  (Wrd35.Obj) = Rvl;
  goto label_162;

DEFLABEL (label_165)
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_34]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_11]), 1);

DEFLABEL (label_85)
  (Wrd16.Obj) = Rvl;
  goto label_164;

DEFLABEL (label_167)
  (Wrd15.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_31_33]))));
  (* (--Rsp)) = (Wrd15.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_31_11]), 1);

DEFLABEL (label_84)
  (Wrd7.Obj) = Rvl;
  goto label_166;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_32_4 3
#define LABEL_32_5 5
#define LABEL_32_6 7
#define LABEL_32_7 9
#define LABEL_32_8 11
#define LABEL_32_9 13
#define LABEL_32_10 15
#define LABEL_32_11 17
#define LABEL_32_12 19
#define LABEL_32_13 21
#define LABEL_32_14 23
#define LABEL_32_15 25
#define LABEL_32_16 27
#define LABEL_32_17 29
#define LABEL_32_18 31
#define LABEL_32_19 33
#define LABEL_32_20 35
#define LABEL_32_21 37
#define LABEL_32_22 39
#define LABEL_32_23 41
#define LABEL_32_24 43
#define LABEL_32_25 45
#define LABEL_32_26 47
#define LABEL_32_27 49
#define LABEL_32_28 51
#define LABEL_32_29 53
#define LABEL_32_30 55
#define LABEL_32_31 57
#define LABEL_32_32 59
#define LABEL_32_33 61
#define LABEL_32_34 63
#define LABEL_32_35 65
#define LABEL_32_36 67
#define LABEL_32_37 69
#define LABEL_32_38 71
#define LABEL_32_39 73
#define LABEL_32_40 75
#define LABEL_32_41 77
#define LABEL_32_42 79
#define LABEL_32_43 81
#define LABEL_32_44 83
#define LABEL_32_45 85
#define LABEL_32_46 87
#define LABEL_32_47 89
#define LABEL_32_48 91
#define LABEL_32_49 93
#define LABEL_32_50 95
#define LABEL_32_51 97
#define LABEL_32_52 99
#define LABEL_32_53 101
#define LABEL_32_54 103
#define LABEL_32_55 105
#define LABEL_32_56 107
#define LABEL_32_57 109
#define LABEL_32_58 111
#define LABEL_32_59 113
#define LABEL_32_60 115
#define LABEL_32_61 117
#define LABEL_32_62 119
#define ENVIRONMENT_LABEL_32_3 134
#define DEBUGGING_LABEL_32_2 133
#define OBJECT_32_12 132
#define OBJECT_32_11 131
#define OBJECT_32_10 130
#define OBJECT_32_9 129
#define OBJECT_32_8 128
#define OBJECT_32_7 127
#define OBJECT_32_6 126
#define OBJECT_32_5 125
#define OBJECT_32_4 124
#define OBJECT_32_3 123
#define OBJECT_32_2 122
#define OBJECT_32_1 121
#define OBJECT_32_0 120
#define FREE_REFERENCES_LABEL_32_0 120
#define NUMBER_OF_LINKER_SECTIONS_32_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_32 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd34;
  machine_word Wrd69;
  machine_word Wrd60;
  machine_word Wrd59;
  machine_word Wrd51;
  machine_word Wrd52;
  machine_word Wrd25;
  machine_word Wrd23;
  machine_word Wrd9;
  machine_word Wrd58;
  machine_word Wrd57;
  machine_word Wrd56;
  machine_word Wrd53;
  machine_word Wrd44;
  machine_word Wrd35;
  machine_word Wrd39;
  machine_word Wrd38;
  machine_word Wrd164;
  machine_word Wrd161;
  machine_word Wrd167;
  machine_word Wrd166;
  machine_word Wrd154;
  machine_word Wrd142;
  machine_word Wrd152;
  machine_word Wrd151;
  machine_word Wrd141;
  machine_word Wrd139;
  machine_word Wrd140;
  machine_word Wrd121;
  machine_word Wrd125;
  machine_word Wrd124;
  machine_word Wrd103;
  machine_word Wrd113;
  machine_word Wrd112;
  machine_word Wrd102;
  machine_word Wrd100;
  machine_word Wrd101;
  machine_word Wrd86;
  machine_word Wrd90;
  machine_word Wrd87;
  machine_word Wrd78;
  machine_word Wrd74;
  machine_word Wrd73;
  machine_word Wrd26;
  machine_word Wrd24;
  machine_word Wrd183;
  machine_word Wrd182;
  machine_word Wrd181;
  machine_word Wrd180;
  machine_word Wrd177;
  machine_word Wrd184;
  machine_word Wrd22;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd202;
  machine_word Wrd197;
  machine_word Wrd6;
  machine_word Wrd5;
  machine_word Wrd357;
  machine_word Wrd356;
  machine_word Wrd355;
  machine_word Wrd353;
  machine_word Wrd352;
  machine_word Wrd350;
  machine_word Wrd349;
  machine_word Wrd348;
  machine_word Wrd347;
  machine_word Wrd345;
  machine_word Wrd344;
  machine_word Wrd340;
  machine_word Wrd327;
  machine_word Wrd331;
  machine_word Wrd328;
  machine_word Wrd337;
  machine_word Wrd336;
  machine_word Wrd335;
  machine_word Wrd333;
  machine_word Wrd332;
  machine_word Wrd339;
  machine_word Wrd338;
  machine_word Wrd326;
  machine_word Wrd323;
  machine_word Wrd322;
  machine_word Wrd311;
  machine_word Wrd319;
  machine_word Wrd318;
  machine_word Wrd317;
  machine_word Wrd321;
  machine_word Wrd320;
  machine_word Wrd310;
  machine_word Wrd306;
  machine_word Wrd297;
  machine_word Wrd296;
  machine_word Wrd293;
  machine_word Wrd303;
  machine_word Wrd302;
  machine_word Wrd301;
  machine_word Wrd299;
  machine_word Wrd298;
  machine_word Wrd305;
  machine_word Wrd304;
  machine_word Wrd292;
  machine_word Wrd289;
  machine_word Wrd288;
  machine_word Wrd277;
  machine_word Wrd285;
  machine_word Wrd284;
  machine_word Wrd283;
  machine_word Wrd287;
  machine_word Wrd286;
  machine_word Wrd276;
  machine_word Wrd273;
  machine_word Wrd272;
  machine_word Wrd263;
  machine_word Wrd269;
  machine_word Wrd268;
  machine_word Wrd267;
  machine_word Wrd271;
  machine_word Wrd270;
  machine_word Wrd358;
  machine_word Wrd260;
  machine_word Wrd257;
  machine_word Wrd259;
  machine_word Wrd258;
  machine_word Wrd255;
  machine_word Wrd254;
  machine_word Wrd252;
  machine_word Wrd251;
  machine_word Wrd250;
  machine_word Wrd249;
  machine_word Wrd247;
  machine_word Wrd246;
  machine_word Wrd242;
  machine_word Wrd229;
  machine_word Wrd233;
  machine_word Wrd230;
  machine_word Wrd239;
  machine_word Wrd238;
  machine_word Wrd237;
  machine_word Wrd235;
  machine_word Wrd234;
  machine_word Wrd241;
  machine_word Wrd240;
  machine_word Wrd228;
  machine_word Wrd225;
  machine_word Wrd224;
  machine_word Wrd213;
  machine_word Wrd221;
  machine_word Wrd220;
  machine_word Wrd219;
  machine_word Wrd223;
  machine_word Wrd222;
  machine_word Wrd212;
  machine_word Wrd208;
  machine_word Wrd199;
  machine_word Wrd198;
  machine_word Wrd195;
  machine_word Wrd205;
  machine_word Wrd204;
  machine_word Wrd203;
  machine_word Wrd201;
  machine_word Wrd200;
  machine_word Wrd207;
  machine_word Wrd206;
  machine_word Wrd194;
  machine_word Wrd191;
  machine_word Wrd190;
  machine_word Wrd179;
  machine_word Wrd187;
  machine_word Wrd186;
  machine_word Wrd185;
  machine_word Wrd189;
  machine_word Wrd188;
  machine_word Wrd178;
  machine_word Wrd175;
  machine_word Wrd174;
  machine_word Wrd165;
  machine_word Wrd171;
  machine_word Wrd170;
  machine_word Wrd169;
  machine_word Wrd173;
  machine_word Wrd172;
  machine_word Wrd162;
  machine_word Wrd157;
  machine_word Wrd156;
  machine_word Wrd155;
  machine_word Wrd158;
  machine_word Wrd153;
  machine_word Wrd150;
  machine_word Wrd149;
  machine_word Wrd138;
  machine_word Wrd146;
  machine_word Wrd145;
  machine_word Wrd144;
  machine_word Wrd148;
  machine_word Wrd147;
  machine_word Wrd137;
  machine_word Wrd136;
  machine_word Wrd133;
  machine_word Wrd132;
  machine_word Wrd123;
  machine_word Wrd129;
  machine_word Wrd128;
  machine_word Wrd127;
  machine_word Wrd131;
  machine_word Wrd130;
  machine_word Wrd734;
  machine_word Wrd731;
  machine_word Wrd743;
  machine_word Wrd742;
  machine_word Wrd741;
  machine_word Wrd739;
  machine_word Wrd737;
  machine_word Wrd736;
  machine_word Wrd745;
  machine_word Wrd744;
  machine_word Wrd728;
  machine_word Wrd725;
  machine_word Wrd724;
  machine_word Wrd713;
  machine_word Wrd721;
  machine_word Wrd720;
  machine_word Wrd719;
  machine_word Wrd723;
  machine_word Wrd722;
  machine_word Wrd709;
  machine_word Wrd712;
  machine_word Wrd711;
  machine_word Wrd710;
  machine_word Wrd708;
  machine_word Wrd707;
  machine_word Wrd706;
  machine_word Wrd705;
  machine_word Wrd703;
  machine_word Wrd702;
  machine_word Wrd698;
  machine_word Wrd685;
  machine_word Wrd689;
  machine_word Wrd686;
  machine_word Wrd695;
  machine_word Wrd694;
  machine_word Wrd693;
  machine_word Wrd691;
  machine_word Wrd690;
  machine_word Wrd697;
  machine_word Wrd696;
  machine_word Wrd684;
  machine_word Wrd681;
  machine_word Wrd680;
  machine_word Wrd669;
  machine_word Wrd677;
  machine_word Wrd676;
  machine_word Wrd675;
  machine_word Wrd679;
  machine_word Wrd678;
  machine_word Wrd668;
  machine_word Wrd664;
  machine_word Wrd655;
  machine_word Wrd654;
  machine_word Wrd651;
  machine_word Wrd661;
  machine_word Wrd660;
  machine_word Wrd659;
  machine_word Wrd657;
  machine_word Wrd656;
  machine_word Wrd663;
  machine_word Wrd662;
  machine_word Wrd650;
  machine_word Wrd647;
  machine_word Wrd646;
  machine_word Wrd635;
  machine_word Wrd643;
  machine_word Wrd642;
  machine_word Wrd641;
  machine_word Wrd645;
  machine_word Wrd644;
  machine_word Wrd634;
  machine_word Wrd631;
  machine_word Wrd630;
  machine_word Wrd621;
  machine_word Wrd627;
  machine_word Wrd626;
  machine_word Wrd625;
  machine_word Wrd629;
  machine_word Wrd628;
  machine_word Wrd618;
  machine_word Wrd616;
  machine_word Wrd617;
  machine_word Wrd614;
  machine_word Wrd615;
  machine_word Wrd613;
  machine_word Wrd599;
  machine_word Wrd602;
  machine_word Wrd600;
  machine_word Wrd607;
  machine_word Wrd606;
  machine_word Wrd605;
  machine_word Wrd604;
  machine_word Wrd603;
  machine_word Wrd608;
  machine_word Wrd598;
  machine_word Wrd597;
  machine_word Wrd594;
  machine_word Wrd593;
  machine_word Wrd582;
  machine_word Wrd590;
  machine_word Wrd589;
  machine_word Wrd588;
  machine_word Wrd592;
  machine_word Wrd591;
  machine_word Wrd581;
  machine_word Wrd580;
  machine_word Wrd579;
  machine_word Wrd578;
  machine_word Wrd577;
  machine_word Wrd576;
  machine_word Wrd575;
  machine_word Wrd574;
  machine_word Wrd572;
  machine_word Wrd571;
  machine_word Wrd567;
  machine_word Wrd554;
  machine_word Wrd558;
  machine_word Wrd555;
  machine_word Wrd564;
  machine_word Wrd563;
  machine_word Wrd562;
  machine_word Wrd560;
  machine_word Wrd559;
  machine_word Wrd566;
  machine_word Wrd565;
  machine_word Wrd553;
  machine_word Wrd550;
  machine_word Wrd549;
  machine_word Wrd538;
  machine_word Wrd546;
  machine_word Wrd545;
  machine_word Wrd544;
  machine_word Wrd548;
  machine_word Wrd547;
  machine_word Wrd537;
  machine_word Wrd533;
  machine_word Wrd524;
  machine_word Wrd523;
  machine_word Wrd520;
  machine_word Wrd530;
  machine_word Wrd529;
  machine_word Wrd528;
  machine_word Wrd526;
  machine_word Wrd525;
  machine_word Wrd532;
  machine_word Wrd531;
  machine_word Wrd519;
  machine_word Wrd516;
  machine_word Wrd515;
  machine_word Wrd504;
  machine_word Wrd512;
  machine_word Wrd511;
  machine_word Wrd510;
  machine_word Wrd514;
  machine_word Wrd513;
  machine_word Wrd503;
  machine_word Wrd500;
  machine_word Wrd499;
  machine_word Wrd490;
  machine_word Wrd496;
  machine_word Wrd495;
  machine_word Wrd494;
  machine_word Wrd498;
  machine_word Wrd497;
  machine_word Wrd487;
  machine_word Wrd485;
  machine_word Wrd486;
  machine_word Wrd484;
  machine_word Wrd470;
  machine_word Wrd473;
  machine_word Wrd471;
  machine_word Wrd478;
  machine_word Wrd477;
  machine_word Wrd476;
  machine_word Wrd475;
  machine_word Wrd474;
  machine_word Wrd479;
  machine_word Wrd469;
  machine_word Wrd468;
  machine_word Wrd465;
  machine_word Wrd464;
  machine_word Wrd453;
  machine_word Wrd461;
  machine_word Wrd460;
  machine_word Wrd459;
  machine_word Wrd463;
  machine_word Wrd462;
  machine_word Wrd452;
  machine_word Wrd451;
  machine_word Wrd450;
  machine_word Wrd449;
  machine_word Wrd448;
  machine_word Wrd447;
  machine_word Wrd446;
  machine_word Wrd445;
  machine_word Wrd443;
  machine_word Wrd442;
  machine_word Wrd438;
  machine_word Wrd425;
  machine_word Wrd429;
  machine_word Wrd426;
  machine_word Wrd435;
  machine_word Wrd434;
  machine_word Wrd433;
  machine_word Wrd431;
  machine_word Wrd430;
  machine_word Wrd437;
  machine_word Wrd436;
  machine_word Wrd424;
  machine_word Wrd421;
  machine_word Wrd420;
  machine_word Wrd409;
  machine_word Wrd417;
  machine_word Wrd416;
  machine_word Wrd415;
  machine_word Wrd419;
  machine_word Wrd418;
  machine_word Wrd408;
  machine_word Wrd404;
  machine_word Wrd395;
  machine_word Wrd394;
  machine_word Wrd391;
  machine_word Wrd401;
  machine_word Wrd400;
  machine_word Wrd399;
  machine_word Wrd397;
  machine_word Wrd396;
  machine_word Wrd403;
  machine_word Wrd402;
  machine_word Wrd390;
  machine_word Wrd387;
  machine_word Wrd386;
  machine_word Wrd375;
  machine_word Wrd383;
  machine_word Wrd382;
  machine_word Wrd381;
  machine_word Wrd385;
  machine_word Wrd384;
  machine_word Wrd374;
  machine_word Wrd371;
  machine_word Wrd370;
  machine_word Wrd361;
  machine_word Wrd367;
  machine_word Wrd366;
  machine_word Wrd365;
  machine_word Wrd369;
  machine_word Wrd368;
  machine_word Wrd757;
  machine_word Wrd119;
  machine_word Wrd118;
  machine_word Wrd116;
  machine_word Wrd751;
  machine_word Wrd750;
  machine_word Wrd749;
  machine_word Wrd748;
  machine_word Wrd747;
  machine_word Wrd752;
  machine_word Wrd115;
  machine_word Wrd114;
  machine_word Wrd111;
  machine_word Wrd110;
  machine_word Wrd99;
  machine_word Wrd107;
  machine_word Wrd106;
  machine_word Wrd105;
  machine_word Wrd109;
  machine_word Wrd108;
  machine_word Wrd98;
  machine_word Wrd97;
  machine_word Wrd96;
  machine_word Wrd95;
  machine_word Wrd94;
  machine_word Wrd93;
  machine_word Wrd92;
  machine_word Wrd91;
  machine_word Wrd89;
  machine_word Wrd88;
  machine_word Wrd84;
  machine_word Wrd71;
  machine_word Wrd75;
  machine_word Wrd72;
  machine_word Wrd81;
  machine_word Wrd80;
  machine_word Wrd79;
  machine_word Wrd77;
  machine_word Wrd76;
  machine_word Wrd83;
  machine_word Wrd82;
  machine_word Wrd70;
  machine_word Wrd67;
  machine_word Wrd66;
  machine_word Wrd55;
  machine_word Wrd63;
  machine_word Wrd62;
  machine_word Wrd61;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd54;
  machine_word Wrd50;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd37;
  machine_word Wrd47;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd43;
  machine_word Wrd42;
  machine_word Wrd49;
  machine_word Wrd48;
  machine_word Wrd36;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd21;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd27;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd7;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_32_4);
      goto probe_cache_2_99;

    case 1:
      current_block = (Rpc - LABEL_32_5);
      goto label_101;

    case 2:
      current_block = (Rpc - LABEL_32_6);
      goto label_102;

    case 3:
      current_block = (Rpc - LABEL_32_7);
      goto label_103;

    case 4:
      current_block = (Rpc - LABEL_32_8);
      goto label_104;

    case 5:
      current_block = (Rpc - LABEL_32_9);
      goto label_105;

    case 6:
      current_block = (Rpc - LABEL_32_10);
      goto label_106;

    case 7:
      current_block = (Rpc - LABEL_32_11);
      goto label_140;

    case 8:
      current_block = (Rpc - LABEL_32_12);
      goto label_120;

    case 9:
      current_block = (Rpc - LABEL_32_13);
      goto label_121;

    case 10:
      current_block = (Rpc - LABEL_32_14);
      goto label_122;

    case 11:
      current_block = (Rpc - LABEL_32_15);
      goto label_123;

    case 12:
      current_block = (Rpc - LABEL_32_16);
      goto label_124;

    case 13:
      current_block = (Rpc - LABEL_32_17);
      goto label_125;

    case 14:
      current_block = (Rpc - LABEL_32_18);
      goto label_126;

    case 15:
      current_block = (Rpc - LABEL_32_19);
      goto label_127;

    case 16:
      current_block = (Rpc - LABEL_32_20);
      goto label_128;

    case 17:
      current_block = (Rpc - LABEL_32_21);
      goto label_129;

    case 18:
      current_block = (Rpc - LABEL_32_22);
      goto label_130;

    case 19:
      current_block = (Rpc - LABEL_32_23);
      goto label_131;

    case 20:
      current_block = (Rpc - LABEL_32_24);
      goto label_132;

    case 21:
      current_block = (Rpc - LABEL_32_25);
      goto label_133;

    case 22:
      current_block = (Rpc - LABEL_32_26);
      goto label_134;

    case 23:
      current_block = (Rpc - LABEL_32_27);
      goto label_135;

    case 24:
      current_block = (Rpc - LABEL_32_28);
      goto label_136;

    case 25:
      current_block = (Rpc - LABEL_32_29);
      goto label_137;

    case 26:
      current_block = (Rpc - LABEL_32_30);
      goto label_138;

    case 27:
      current_block = (Rpc - LABEL_32_31);
      goto label_139;

    case 28:
      current_block = (Rpc - LABEL_32_32);
      goto label_107;

    case 29:
      current_block = (Rpc - LABEL_32_33);
      goto label_108;

    case 30:
      current_block = (Rpc - LABEL_32_34);
      goto label_109;

    case 31:
      current_block = (Rpc - LABEL_32_35);
      goto label_110;

    case 32:
      current_block = (Rpc - LABEL_32_36);
      goto label_111;

    case 33:
      current_block = (Rpc - LABEL_32_37);
      goto label_112;

    case 34:
      current_block = (Rpc - LABEL_32_38);
      goto label_113;

    case 35:
      current_block = (Rpc - LABEL_32_39);
      goto label_114;

    case 36:
      current_block = (Rpc - LABEL_32_40);
      goto label_115;

    case 37:
      current_block = (Rpc - LABEL_32_41);
      goto label_116;

    case 38:
      current_block = (Rpc - LABEL_32_42);
      goto label_117;

    case 39:
      current_block = (Rpc - LABEL_32_43);
      goto label_118;

    case 40:
      current_block = (Rpc - LABEL_32_44);
      goto label_119;

    case 41:
      current_block = (Rpc - LABEL_32_45);
      goto search_lines_88;

    case 42:
      current_block = (Rpc - LABEL_32_46);
      goto label_150;

    case 43:
      current_block = (Rpc - LABEL_32_47);
      goto label_141;

    case 44:
      current_block = (Rpc - LABEL_32_48);
      goto label_149;

    case 45:
      current_block = (Rpc - LABEL_32_49);
      goto label_144;

    case 46:
      current_block = (Rpc - LABEL_32_50);
      goto label_145;

    case 47:
      current_block = (Rpc - LABEL_32_51);
      goto label_146;

    case 48:
      current_block = (Rpc - LABEL_32_52);
      goto label_147;

    case 49:
      current_block = (Rpc - LABEL_32_53);
      goto label_148;

    case 50:
      current_block = (Rpc - LABEL_32_54);
      goto label_142;

    case 51:
      current_block = (Rpc - LABEL_32_55);
      goto label_143;

    case 52:
      current_block = (Rpc - LABEL_32_56);
      goto search_overflow_86;

    case 53:
      current_block = (Rpc - LABEL_32_57);
      goto label_151;

    case 54:
      current_block = (Rpc - LABEL_32_58);
      goto label_152;

    case 55:
      current_block = (Rpc - LABEL_32_59);
      goto label_154;

    case 56:
      current_block = (Rpc - LABEL_32_60);
      goto label_155;

    case 57:
      current_block = (Rpc - LABEL_32_61);
      goto label_156;

    case 58:
      current_block = (Rpc - LABEL_32_62);
      goto label_153;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (probe_cache_2_158)
DEFLABEL (probe_cache_2_99)
  INTERRUPT_CHECK (26, LABEL_32_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_246;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd13.Lng))))
    goto label_246;
  (Wrd7.Obj) = ((Wrd11.pObj) [3]);
  (* (--Rsp)) = (Wrd7.Obj);

DEFLABEL (label_245)
  (Wrd30.Obj) = (Rsp [1]);
  (Wrd31.uLng) = (OBJECT_TYPE (Wrd30.Obj));
  if (! ((Wrd31.uLng) == 62))
    goto label_244;
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd30.Obj));
  (Wrd28.Obj) = ((Wrd27.pObj) [0]);
  (Wrd29.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd29.Lng))))
    goto label_244;
  (Wrd21.Obj) = ((Wrd27.pObj) [2]);

DEFLABEL (label_243)
  (Wrd48.Obj) = (Rsp [3]);
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd48.Obj));
  if (! ((Wrd49.uLng) == 62))
    goto label_242;
  (Wrd42.uLng) = (OBJECT_TYPE (Wrd21.Obj));
  if (! ((Wrd42.uLng) == 26))
    goto label_242;
  (Wrd43.Lng) = (FIXNUM_TO_LONG (Wrd21.Obj));
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd48.Obj));
  (Wrd46.Obj) = ((Wrd45.pObj) [0]);
  (Wrd47.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  if (! (((unsigned long) (Wrd43.Lng)) < ((unsigned long) (Wrd47.Lng))))
    goto label_242;
  (Wrd37.uLng) = (OBJECT_DATUM (Wrd21.Obj));
  (Wrd40.pObj) = (& ((Wrd45.pObj) [(Wrd37.Lng)]));
  (Wrd41.Obj) = ((Wrd40.pObj) [1]);
  (* (--Rsp)) = (Wrd41.Obj);

DEFLABEL (label_241)
  (Wrd64.Obj) = (Rsp [2]);
  (Wrd65.uLng) = (OBJECT_TYPE (Wrd64.Obj));
  if (! ((Wrd65.uLng) == 62))
    goto label_240;
  (Wrd61.pObj) = (OBJECT_ADDRESS (Wrd64.Obj));
  (Wrd62.Obj) = ((Wrd61.pObj) [0]);
  (Wrd63.Lng) = (FIXNUM_TO_LONG (Wrd62.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd63.Lng))))
    goto label_240;
  (Wrd55.Obj) = ((Wrd61.pObj) [2]);

DEFLABEL (label_239)
  (Wrd82.Obj) = (Rsp [3]);
  (Wrd83.uLng) = (OBJECT_TYPE (Wrd82.Obj));
  if (! ((Wrd83.uLng) == 62))
    goto label_238;
  (Wrd76.uLng) = (OBJECT_TYPE (Wrd55.Obj));
  if (! ((Wrd76.uLng) == 26))
    goto label_238;
  (Wrd77.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd79.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd80.Obj) = ((Wrd79.pObj) [0]);
  (Wrd81.Lng) = (FIXNUM_TO_LONG (Wrd80.Obj));
  if (! (((unsigned long) (Wrd77.Lng)) < ((unsigned long) (Wrd81.Lng))))
    goto label_238;
  (Wrd72.uLng) = (OBJECT_DATUM (Wrd55.Obj));
  (Wrd75.pObj) = (& ((Wrd79.pObj) [(Wrd72.Lng)]));
  (Wrd71.Obj) = ((Wrd75.pObj) [1]);

DEFLABEL (label_237)
  (Wrd89.Obj) = (* (Rsp++));
  (Wrd91.Lng) = (FIXNUM_TO_LONG (Wrd71.Obj));
  (Wrd92.Lng) = (FIXNUM_TO_LONG (Wrd89.Obj));
  (Wrd93.Lng) = ((Wrd91.Lng) + (Wrd92.Lng));
  (Wrd94.Obj) = (* (Rsp++));
  Wrd95 = Wrd93;
  (Wrd96.Lng) = (FIXNUM_TO_LONG (Wrd94.Obj));
  (Wrd97.Lng) = ((Wrd95.Lng) & (Wrd96.Lng));
  (Wrd98.Obj) = (LONG_TO_FIXNUM (Wrd97.Lng));
  (* (--Rsp)) = (Wrd98.Obj);
  (Wrd108.Obj) = (Rsp [1]);
  (Wrd109.uLng) = (OBJECT_TYPE (Wrd108.Obj));
  if (! ((Wrd109.uLng) == 62))
    goto label_236;
  (Wrd105.pObj) = (OBJECT_ADDRESS (Wrd108.Obj));
  (Wrd106.Obj) = ((Wrd105.pObj) [0]);
  (Wrd107.Lng) = (FIXNUM_TO_LONG (Wrd106.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd107.Lng))))
    goto label_236;
  (Wrd99.Obj) = ((Wrd105.pObj) [6]);

DEFLABEL (label_235)
  (Wrd115.Obj) = (* (Rsp++));
  (Wrd752.uLng) = (OBJECT_TYPE (Wrd99.Obj));
  if (! ((Wrd752.uLng) == 10))
    goto label_234;
  (Wrd747.uLng) = (OBJECT_TYPE (Wrd115.Obj));
  if (! ((Wrd747.uLng) == 26))
    goto label_234;
  (Wrd748.Lng) = (FIXNUM_TO_LONG (Wrd115.Obj));
  (Wrd749.pObj) = (OBJECT_ADDRESS (Wrd99.Obj));
  (Wrd750.Obj) = ((Wrd749.pObj) [0]);
  (Wrd751.Lng) = (FIXNUM_TO_LONG (Wrd750.Obj));
  if (! (((unsigned long) (Wrd748.Lng)) < ((unsigned long) (Wrd751.Lng))))
    goto label_234;
  (Wrd116.uLng) = (OBJECT_DATUM (Wrd115.Obj));
  (Wrd118.pObj) = (& ((Wrd749.pObj) [(Wrd116.Lng)]));
  (Wrd119.Obj) = ((Wrd118.pObj) [1]);
  if ((Wrd119.Obj) == ((SCHEME_OBJECT) 0))
    goto label_189;

DEFLABEL (label_233)
  (Wrd368.Obj) = (Rsp [0]);
  (Wrd369.uLng) = (OBJECT_TYPE (Wrd368.Obj));
  if (! ((Wrd369.uLng) == 62))
    goto label_232;
  (Wrd365.pObj) = (OBJECT_ADDRESS (Wrd368.Obj));
  (Wrd366.Obj) = ((Wrd365.pObj) [0]);
  (Wrd367.Lng) = (FIXNUM_TO_LONG (Wrd366.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd367.Lng))))
    goto label_232;
  (Wrd361.Obj) = ((Wrd365.pObj) [3]);
  (* (--Rsp)) = (Wrd361.Obj);

DEFLABEL (label_231)
  (Wrd384.Obj) = (Rsp [1]);
  (Wrd385.uLng) = (OBJECT_TYPE (Wrd384.Obj));
  if (! ((Wrd385.uLng) == 62))
    goto label_230;
  (Wrd381.pObj) = (OBJECT_ADDRESS (Wrd384.Obj));
  (Wrd382.Obj) = ((Wrd381.pObj) [0]);
  (Wrd383.Lng) = (FIXNUM_TO_LONG (Wrd382.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd383.Lng))))
    goto label_230;
  (Wrd375.Obj) = ((Wrd381.pObj) [2]);

DEFLABEL (label_229)
  (Wrd402.Obj) = (Rsp [3]);
  (Wrd403.uLng) = (OBJECT_TYPE (Wrd402.Obj));
  if (! ((Wrd403.uLng) == 62))
    goto label_228;
  (Wrd396.uLng) = (OBJECT_TYPE (Wrd375.Obj));
  if (! ((Wrd396.uLng) == 26))
    goto label_228;
  (Wrd397.Lng) = (FIXNUM_TO_LONG (Wrd375.Obj));
  (Wrd399.pObj) = (OBJECT_ADDRESS (Wrd402.Obj));
  (Wrd400.Obj) = ((Wrd399.pObj) [0]);
  (Wrd401.Lng) = (FIXNUM_TO_LONG (Wrd400.Obj));
  if (! (((unsigned long) (Wrd397.Lng)) < ((unsigned long) (Wrd401.Lng))))
    goto label_228;
  (Wrd391.uLng) = (OBJECT_DATUM (Wrd375.Obj));
  (Wrd394.pObj) = (& ((Wrd399.pObj) [(Wrd391.Lng)]));
  (Wrd395.Obj) = ((Wrd394.pObj) [1]);
  (* (--Rsp)) = (Wrd395.Obj);

DEFLABEL (label_227)
  (Wrd418.Obj) = (Rsp [2]);
  (Wrd419.uLng) = (OBJECT_TYPE (Wrd418.Obj));
  if (! ((Wrd419.uLng) == 62))
    goto label_226;
  (Wrd415.pObj) = (OBJECT_ADDRESS (Wrd418.Obj));
  (Wrd416.Obj) = ((Wrd415.pObj) [0]);
  (Wrd417.Lng) = (FIXNUM_TO_LONG (Wrd416.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd417.Lng))))
    goto label_226;
  (Wrd409.Obj) = ((Wrd415.pObj) [2]);

DEFLABEL (label_225)
  (Wrd436.Obj) = (Rsp [3]);
  (Wrd437.uLng) = (OBJECT_TYPE (Wrd436.Obj));
  if (! ((Wrd437.uLng) == 62))
    goto label_224;
  (Wrd430.uLng) = (OBJECT_TYPE (Wrd409.Obj));
  if (! ((Wrd430.uLng) == 26))
    goto label_224;
  (Wrd431.Lng) = (FIXNUM_TO_LONG (Wrd409.Obj));
  (Wrd433.pObj) = (OBJECT_ADDRESS (Wrd436.Obj));
  (Wrd434.Obj) = ((Wrd433.pObj) [0]);
  (Wrd435.Lng) = (FIXNUM_TO_LONG (Wrd434.Obj));
  if (! (((unsigned long) (Wrd431.Lng)) < ((unsigned long) (Wrd435.Lng))))
    goto label_224;
  (Wrd426.uLng) = (OBJECT_DATUM (Wrd409.Obj));
  (Wrd429.pObj) = (& ((Wrd433.pObj) [(Wrd426.Lng)]));
  (Wrd425.Obj) = ((Wrd429.pObj) [1]);

DEFLABEL (label_223)
  (Wrd443.Obj) = (* (Rsp++));
  (Wrd445.Lng) = (FIXNUM_TO_LONG (Wrd425.Obj));
  (Wrd446.Lng) = (FIXNUM_TO_LONG (Wrd443.Obj));
  (Wrd447.Lng) = ((Wrd445.Lng) + (Wrd446.Lng));
  (Wrd448.Obj) = (* (Rsp++));
  Wrd449 = Wrd447;
  (Wrd450.Lng) = (FIXNUM_TO_LONG (Wrd448.Obj));
  (Wrd451.Lng) = ((Wrd449.Lng) & (Wrd450.Lng));
  (Wrd452.Obj) = (LONG_TO_FIXNUM (Wrd451.Lng));
  (* (--Rsp)) = (Wrd452.Obj);
  (Wrd462.Obj) = (Rsp [1]);
  (Wrd463.uLng) = (OBJECT_TYPE (Wrd462.Obj));
  if (! ((Wrd463.uLng) == 62))
    goto label_222;
  (Wrd459.pObj) = (OBJECT_ADDRESS (Wrd462.Obj));
  (Wrd460.Obj) = ((Wrd459.pObj) [0]);
  (Wrd461.Lng) = (FIXNUM_TO_LONG (Wrd460.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd461.Lng))))
    goto label_222;
  (Wrd453.Obj) = ((Wrd459.pObj) [6]);

DEFLABEL (label_221)
  (Wrd469.Obj) = (* (Rsp++));
  (Wrd479.uLng) = (OBJECT_TYPE (Wrd453.Obj));
  if (! ((Wrd479.uLng) == 10))
    goto label_220;
  (Wrd474.uLng) = (OBJECT_TYPE (Wrd469.Obj));
  if (! ((Wrd474.uLng) == 26))
    goto label_220;
  (Wrd475.Lng) = (FIXNUM_TO_LONG (Wrd469.Obj));
  (Wrd476.pObj) = (OBJECT_ADDRESS (Wrd453.Obj));
  (Wrd477.Obj) = ((Wrd476.pObj) [0]);
  (Wrd478.Lng) = (FIXNUM_TO_LONG (Wrd477.Obj));
  if (! (((unsigned long) (Wrd475.Lng)) < ((unsigned long) (Wrd478.Lng))))
    goto label_220;
  (Wrd471.uLng) = (OBJECT_DATUM (Wrd469.Obj));
  (Wrd473.pObj) = (& ((Wrd476.pObj) [(Wrd471.Lng)]));
  (Wrd470.Obj) = ((Wrd473.pObj) [1]);

DEFLABEL (label_219)
  (Wrd486.pObj) = (OBJECT_ADDRESS (Wrd470.Obj));
  (Wrd485.Obj) = ((Wrd486.pObj) [0]);
  (Wrd487.Obj) = (Rsp [1]);
  if ((Wrd487.Obj) == (Wrd485.Obj))
    goto label_190;

DEFLABEL (label_189)
  (Wrd130.Obj) = (Rsp [0]);
  (Wrd131.uLng) = (OBJECT_TYPE (Wrd130.Obj));
  if (! ((Wrd131.uLng) == 62))
    goto label_188;
  (Wrd127.pObj) = (OBJECT_ADDRESS (Wrd130.Obj));
  (Wrd128.Obj) = ((Wrd127.pObj) [0]);
  (Wrd129.Lng) = (FIXNUM_TO_LONG (Wrd128.Obj));
  if (! (((unsigned long) 3L) < ((unsigned long) (Wrd129.Lng))))
    goto label_188;
  (Wrd123.Obj) = ((Wrd127.pObj) [4]);
  (* (--Rsp)) = (Wrd123.Obj);

DEFLABEL (label_187)
  (Wrd137.Obj) = (current_block [OBJECT_32_7]);
  (* (--Rsp)) = (Wrd137.Obj);
  (Wrd147.Obj) = (Rsp [2]);
  (Wrd148.uLng) = (OBJECT_TYPE (Wrd147.Obj));
  if (! ((Wrd148.uLng) == 62))
    goto label_186;
  (Wrd144.pObj) = (OBJECT_ADDRESS (Wrd147.Obj));
  (Wrd145.Obj) = ((Wrd144.pObj) [0]);
  (Wrd146.Lng) = (FIXNUM_TO_LONG (Wrd145.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd146.Lng))))
    goto label_186;
  (Wrd138.Obj) = ((Wrd144.pObj) [6]);

DEFLABEL (label_185)
  (Wrd158.uLng) = (OBJECT_TYPE (Wrd138.Obj));
  if (! ((Wrd158.uLng) == 10))
    goto label_184;
  (Wrd155.pObj) = (OBJECT_ADDRESS (Wrd138.Obj));
  (Wrd156.Obj) = ((Wrd155.pObj) [0]);
  (Wrd157.Obj) = (MAKE_OBJECT (26, (Wrd156.uLng)));
  (* (--Rsp)) = (Wrd157.Obj);

DEFLABEL (label_183)
  (Wrd172.Obj) = (Rsp [3]);
  (Wrd173.uLng) = (OBJECT_TYPE (Wrd172.Obj));
  if (! ((Wrd173.uLng) == 62))
    goto label_182;
  (Wrd169.pObj) = (OBJECT_ADDRESS (Wrd172.Obj));
  (Wrd170.Obj) = ((Wrd169.pObj) [0]);
  (Wrd171.Lng) = (FIXNUM_TO_LONG (Wrd170.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd171.Lng))))
    goto label_182;
  (Wrd165.Obj) = ((Wrd169.pObj) [3]);
  (* (--Rsp)) = (Wrd165.Obj);

DEFLABEL (label_181)
  (Wrd188.Obj) = (Rsp [4]);
  (Wrd189.uLng) = (OBJECT_TYPE (Wrd188.Obj));
  if (! ((Wrd189.uLng) == 62))
    goto label_180;
  (Wrd185.pObj) = (OBJECT_ADDRESS (Wrd188.Obj));
  (Wrd186.Obj) = ((Wrd185.pObj) [0]);
  (Wrd187.Lng) = (FIXNUM_TO_LONG (Wrd186.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd187.Lng))))
    goto label_180;
  (Wrd179.Obj) = ((Wrd185.pObj) [2]);

DEFLABEL (label_179)
  (Wrd206.Obj) = (Rsp [6]);
  (Wrd207.uLng) = (OBJECT_TYPE (Wrd206.Obj));
  if (! ((Wrd207.uLng) == 62))
    goto label_178;
  (Wrd200.uLng) = (OBJECT_TYPE (Wrd179.Obj));
  if (! ((Wrd200.uLng) == 26))
    goto label_178;
  (Wrd201.Lng) = (FIXNUM_TO_LONG (Wrd179.Obj));
  (Wrd203.pObj) = (OBJECT_ADDRESS (Wrd206.Obj));
  (Wrd204.Obj) = ((Wrd203.pObj) [0]);
  (Wrd205.Lng) = (FIXNUM_TO_LONG (Wrd204.Obj));
  if (! (((unsigned long) (Wrd201.Lng)) < ((unsigned long) (Wrd205.Lng))))
    goto label_178;
  (Wrd195.uLng) = (OBJECT_DATUM (Wrd179.Obj));
  (Wrd198.pObj) = (& ((Wrd203.pObj) [(Wrd195.Lng)]));
  (Wrd199.Obj) = ((Wrd198.pObj) [1]);
  (* (--Rsp)) = (Wrd199.Obj);

DEFLABEL (label_177)
  (Wrd222.Obj) = (Rsp [5]);
  (Wrd223.uLng) = (OBJECT_TYPE (Wrd222.Obj));
  if (! ((Wrd223.uLng) == 62))
    goto label_176;
  (Wrd219.pObj) = (OBJECT_ADDRESS (Wrd222.Obj));
  (Wrd220.Obj) = ((Wrd219.pObj) [0]);
  (Wrd221.Lng) = (FIXNUM_TO_LONG (Wrd220.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd221.Lng))))
    goto label_176;
  (Wrd213.Obj) = ((Wrd219.pObj) [2]);

DEFLABEL (label_175)
  (Wrd240.Obj) = (Rsp [6]);
  (Wrd241.uLng) = (OBJECT_TYPE (Wrd240.Obj));
  if (! ((Wrd241.uLng) == 62))
    goto label_174;
  (Wrd234.uLng) = (OBJECT_TYPE (Wrd213.Obj));
  if (! ((Wrd234.uLng) == 26))
    goto label_174;
  (Wrd235.Lng) = (FIXNUM_TO_LONG (Wrd213.Obj));
  (Wrd237.pObj) = (OBJECT_ADDRESS (Wrd240.Obj));
  (Wrd238.Obj) = ((Wrd237.pObj) [0]);
  (Wrd239.Lng) = (FIXNUM_TO_LONG (Wrd238.Obj));
  if (! (((unsigned long) (Wrd235.Lng)) < ((unsigned long) (Wrd239.Lng))))
    goto label_174;
  (Wrd230.uLng) = (OBJECT_DATUM (Wrd213.Obj));
  (Wrd233.pObj) = (& ((Wrd237.pObj) [(Wrd230.Lng)]));
  (Wrd229.Obj) = ((Wrd233.pObj) [1]);

DEFLABEL (label_173)
  (Wrd247.Obj) = (* (Rsp++));
  (Wrd249.Lng) = (FIXNUM_TO_LONG (Wrd229.Obj));
  (Wrd250.Lng) = (FIXNUM_TO_LONG (Wrd247.Obj));
  (Wrd251.Lng) = ((Wrd249.Lng) + (Wrd250.Lng));
  (Wrd252.Obj) = (* (Rsp++));
  Wrd254 = Wrd251;
  (Wrd255.Lng) = (FIXNUM_TO_LONG (Wrd252.Obj));
  (Wrd258.Lng) = ((Wrd254.Lng) & (Wrd255.Lng));
  (Wrd259.Lng) = ((Wrd258.Lng) + 1L);
  (Wrd257.Obj) = (LONG_TO_FIXNUM (Wrd259.Lng));
  (Wrd260.Obj) = (* (Rsp++));
  if ((Wrd257.Obj) == (Wrd260.Obj))
    goto label_172;
  (Wrd270.Obj) = (Rsp [2]);
  (Wrd271.uLng) = (OBJECT_TYPE (Wrd270.Obj));
  if (! ((Wrd271.uLng) == 62))
    goto label_171;
  (Wrd267.pObj) = (OBJECT_ADDRESS (Wrd270.Obj));
  (Wrd268.Obj) = ((Wrd267.pObj) [0]);
  (Wrd269.Lng) = (FIXNUM_TO_LONG (Wrd268.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd269.Lng))))
    goto label_171;
  (Wrd263.Obj) = ((Wrd267.pObj) [3]);
  (* (--Rsp)) = (Wrd263.Obj);

DEFLABEL (label_170)
  (Wrd286.Obj) = (Rsp [3]);
  (Wrd287.uLng) = (OBJECT_TYPE (Wrd286.Obj));
  if (! ((Wrd287.uLng) == 62))
    goto label_169;
  (Wrd283.pObj) = (OBJECT_ADDRESS (Wrd286.Obj));
  (Wrd284.Obj) = ((Wrd283.pObj) [0]);
  (Wrd285.Lng) = (FIXNUM_TO_LONG (Wrd284.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd285.Lng))))
    goto label_169;
  (Wrd277.Obj) = ((Wrd283.pObj) [2]);

DEFLABEL (label_168)
  (Wrd304.Obj) = (Rsp [5]);
  (Wrd305.uLng) = (OBJECT_TYPE (Wrd304.Obj));
  if (! ((Wrd305.uLng) == 62))
    goto label_167;
  (Wrd298.uLng) = (OBJECT_TYPE (Wrd277.Obj));
  if (! ((Wrd298.uLng) == 26))
    goto label_167;
  (Wrd299.Lng) = (FIXNUM_TO_LONG (Wrd277.Obj));
  (Wrd301.pObj) = (OBJECT_ADDRESS (Wrd304.Obj));
  (Wrd302.Obj) = ((Wrd301.pObj) [0]);
  (Wrd303.Lng) = (FIXNUM_TO_LONG (Wrd302.Obj));
  if (! (((unsigned long) (Wrd299.Lng)) < ((unsigned long) (Wrd303.Lng))))
    goto label_167;
  (Wrd293.uLng) = (OBJECT_DATUM (Wrd277.Obj));
  (Wrd296.pObj) = (& ((Wrd301.pObj) [(Wrd293.Lng)]));
  (Wrd297.Obj) = ((Wrd296.pObj) [1]);
  (* (--Rsp)) = (Wrd297.Obj);

DEFLABEL (label_166)
  (Wrd320.Obj) = (Rsp [4]);
  (Wrd321.uLng) = (OBJECT_TYPE (Wrd320.Obj));
  if (! ((Wrd321.uLng) == 62))
    goto label_165;
  (Wrd317.pObj) = (OBJECT_ADDRESS (Wrd320.Obj));
  (Wrd318.Obj) = ((Wrd317.pObj) [0]);
  (Wrd319.Lng) = (FIXNUM_TO_LONG (Wrd318.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd319.Lng))))
    goto label_165;
  (Wrd311.Obj) = ((Wrd317.pObj) [2]);

DEFLABEL (label_164)
  (Wrd338.Obj) = (Rsp [5]);
  (Wrd339.uLng) = (OBJECT_TYPE (Wrd338.Obj));
  if (! ((Wrd339.uLng) == 62))
    goto label_163;
  (Wrd332.uLng) = (OBJECT_TYPE (Wrd311.Obj));
  if (! ((Wrd332.uLng) == 26))
    goto label_163;
  (Wrd333.Lng) = (FIXNUM_TO_LONG (Wrd311.Obj));
  (Wrd335.pObj) = (OBJECT_ADDRESS (Wrd338.Obj));
  (Wrd336.Obj) = ((Wrd335.pObj) [0]);
  (Wrd337.Lng) = (FIXNUM_TO_LONG (Wrd336.Obj));
  if (! (((unsigned long) (Wrd333.Lng)) < ((unsigned long) (Wrd337.Lng))))
    goto label_163;
  (Wrd328.uLng) = (OBJECT_DATUM (Wrd311.Obj));
  (Wrd331.pObj) = (& ((Wrd335.pObj) [(Wrd328.Lng)]));
  (Wrd327.Obj) = ((Wrd331.pObj) [1]);

DEFLABEL (label_162)
  (Wrd345.Obj) = (* (Rsp++));
  (Wrd347.Lng) = (FIXNUM_TO_LONG (Wrd327.Obj));
  (Wrd348.Lng) = (FIXNUM_TO_LONG (Wrd345.Obj));
  (Wrd349.Lng) = ((Wrd347.Lng) + (Wrd348.Lng));
  (Wrd350.Obj) = (* (Rsp++));
  Wrd352 = Wrd349;
  (Wrd353.Lng) = (FIXNUM_TO_LONG (Wrd350.Obj));
  (Wrd355.Lng) = ((Wrd352.Lng) & (Wrd353.Lng));
  (Wrd356.Lng) = ((Wrd355.Lng) + 1L);
  (Wrd357.Obj) = (LONG_TO_FIXNUM (Wrd356.Lng));
  (* (--Rsp)) = (Wrd357.Obj);

DEFLABEL (label_161)
  goto search_lines_88;

DEFLABEL (label_163)
  (Wrd340.Obj) = (Rsp [5]);
  (Wrd344.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_44]))));
  (* (--Rsp)) = (Wrd344.Obj);
  (* (--Rsp)) = (Wrd311.Obj);
  (* (--Rsp)) = (Wrd340.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_119)
  (Wrd327.Obj) = Rvl;
  goto label_162;

DEFLABEL (label_165)
  (Wrd322.Obj) = (Rsp [4]);
  (Wrd323.Obj) = (current_block [OBJECT_32_2]);
  (Wrd326.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_43]))));
  (* (--Rsp)) = (Wrd326.Obj);
  (* (--Rsp)) = (Wrd323.Obj);
  (* (--Rsp)) = (Wrd322.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_118)
  (Wrd311.Obj) = Rvl;
  goto label_164;

DEFLABEL (label_167)
  (Wrd306.Obj) = (Rsp [5]);
  (Wrd310.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_42]))));
  (* (--Rsp)) = (Wrd310.Obj);
  (* (--Rsp)) = (Wrd277.Obj);
  (* (--Rsp)) = (Wrd306.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_117)
  (* (--Rsp)) = Rvl;
  goto label_166;

DEFLABEL (label_169)
  (Wrd288.Obj) = (Rsp [3]);
  (Wrd289.Obj) = (current_block [OBJECT_32_2]);
  (Wrd292.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_41]))));
  (* (--Rsp)) = (Wrd292.Obj);
  (* (--Rsp)) = (Wrd289.Obj);
  (* (--Rsp)) = (Wrd288.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_116)
  (Wrd277.Obj) = Rvl;
  goto label_168;

DEFLABEL (label_171)
  (Wrd272.Obj) = (Rsp [2]);
  (Wrd273.Obj) = (current_block [OBJECT_32_0]);
  (Wrd276.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_40]))));
  (* (--Rsp)) = (Wrd276.Obj);
  (* (--Rsp)) = (Wrd273.Obj);
  (* (--Rsp)) = (Wrd272.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_115)
  (* (--Rsp)) = Rvl;
  goto label_170;

DEFLABEL (label_172)
  (Wrd358.Obj) = (current_block [OBJECT_32_7]);
  (* (--Rsp)) = (Wrd358.Obj);
  goto label_161;

DEFLABEL (label_174)
  (Wrd242.Obj) = (Rsp [6]);
  (Wrd246.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_39]))));
  (* (--Rsp)) = (Wrd246.Obj);
  (* (--Rsp)) = (Wrd213.Obj);
  (* (--Rsp)) = (Wrd242.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_114)
  (Wrd229.Obj) = Rvl;
  goto label_173;

DEFLABEL (label_176)
  (Wrd224.Obj) = (Rsp [5]);
  (Wrd225.Obj) = (current_block [OBJECT_32_2]);
  (Wrd228.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_38]))));
  (* (--Rsp)) = (Wrd228.Obj);
  (* (--Rsp)) = (Wrd225.Obj);
  (* (--Rsp)) = (Wrd224.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_113)
  (Wrd213.Obj) = Rvl;
  goto label_175;

DEFLABEL (label_178)
  (Wrd208.Obj) = (Rsp [6]);
  (Wrd212.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_37]))));
  (* (--Rsp)) = (Wrd212.Obj);
  (* (--Rsp)) = (Wrd179.Obj);
  (* (--Rsp)) = (Wrd208.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_112)
  (* (--Rsp)) = Rvl;
  goto label_177;

DEFLABEL (label_180)
  (Wrd190.Obj) = (Rsp [4]);
  (Wrd191.Obj) = (current_block [OBJECT_32_2]);
  (Wrd194.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_36]))));
  (* (--Rsp)) = (Wrd194.Obj);
  (* (--Rsp)) = (Wrd191.Obj);
  (* (--Rsp)) = (Wrd190.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_111)
  (Wrd179.Obj) = Rvl;
  goto label_179;

DEFLABEL (label_182)
  (Wrd174.Obj) = (Rsp [3]);
  (Wrd175.Obj) = (current_block [OBJECT_32_0]);
  (Wrd178.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_35]))));
  (* (--Rsp)) = (Wrd178.Obj);
  (* (--Rsp)) = (Wrd175.Obj);
  (* (--Rsp)) = (Wrd174.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_110)
  (* (--Rsp)) = Rvl;
  goto label_181;

DEFLABEL (label_184)
  (Wrd162.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_34]))));
  (* (--Rsp)) = (Wrd162.Obj);
  (* (--Rsp)) = (Wrd138.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_8]), 1);

DEFLABEL (label_109)
  (* (--Rsp)) = Rvl;
  goto label_183;

DEFLABEL (label_186)
  (Wrd149.Obj) = (Rsp [2]);
  (Wrd150.Obj) = (current_block [OBJECT_32_3]);
  (Wrd153.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_33]))));
  (* (--Rsp)) = (Wrd153.Obj);
  (* (--Rsp)) = (Wrd150.Obj);
  (* (--Rsp)) = (Wrd149.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_108)
  (Wrd138.Obj) = Rvl;
  goto label_185;

DEFLABEL (label_188)
  (Wrd132.Obj) = (Rsp [0]);
  (Wrd133.Obj) = (current_block [OBJECT_32_6]);
  (Wrd136.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_32]))));
  (* (--Rsp)) = (Wrd136.Obj);
  (* (--Rsp)) = (Wrd133.Obj);
  (* (--Rsp)) = (Wrd132.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_107)
  (* (--Rsp)) = Rvl;
  goto label_187;

DEFLABEL (label_190)
  (Wrd497.Obj) = (Rsp [0]);
  (Wrd498.uLng) = (OBJECT_TYPE (Wrd497.Obj));
  if (! ((Wrd498.uLng) == 62))
    goto label_218;
  (Wrd494.pObj) = (OBJECT_ADDRESS (Wrd497.Obj));
  (Wrd495.Obj) = ((Wrd494.pObj) [0]);
  (Wrd496.Lng) = (FIXNUM_TO_LONG (Wrd495.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd496.Lng))))
    goto label_218;
  (Wrd490.Obj) = ((Wrd494.pObj) [3]);
  (* (--Rsp)) = (Wrd490.Obj);

DEFLABEL (label_217)
  (Wrd513.Obj) = (Rsp [1]);
  (Wrd514.uLng) = (OBJECT_TYPE (Wrd513.Obj));
  if (! ((Wrd514.uLng) == 62))
    goto label_216;
  (Wrd510.pObj) = (OBJECT_ADDRESS (Wrd513.Obj));
  (Wrd511.Obj) = ((Wrd510.pObj) [0]);
  (Wrd512.Lng) = (FIXNUM_TO_LONG (Wrd511.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd512.Lng))))
    goto label_216;
  (Wrd504.Obj) = ((Wrd510.pObj) [2]);

DEFLABEL (label_215)
  (Wrd531.Obj) = (Rsp [3]);
  (Wrd532.uLng) = (OBJECT_TYPE (Wrd531.Obj));
  if (! ((Wrd532.uLng) == 62))
    goto label_214;
  (Wrd525.uLng) = (OBJECT_TYPE (Wrd504.Obj));
  if (! ((Wrd525.uLng) == 26))
    goto label_214;
  (Wrd526.Lng) = (FIXNUM_TO_LONG (Wrd504.Obj));
  (Wrd528.pObj) = (OBJECT_ADDRESS (Wrd531.Obj));
  (Wrd529.Obj) = ((Wrd528.pObj) [0]);
  (Wrd530.Lng) = (FIXNUM_TO_LONG (Wrd529.Obj));
  if (! (((unsigned long) (Wrd526.Lng)) < ((unsigned long) (Wrd530.Lng))))
    goto label_214;
  (Wrd520.uLng) = (OBJECT_DATUM (Wrd504.Obj));
  (Wrd523.pObj) = (& ((Wrd528.pObj) [(Wrd520.Lng)]));
  (Wrd524.Obj) = ((Wrd523.pObj) [1]);
  (* (--Rsp)) = (Wrd524.Obj);

DEFLABEL (label_213)
  (Wrd547.Obj) = (Rsp [2]);
  (Wrd548.uLng) = (OBJECT_TYPE (Wrd547.Obj));
  if (! ((Wrd548.uLng) == 62))
    goto label_212;
  (Wrd544.pObj) = (OBJECT_ADDRESS (Wrd547.Obj));
  (Wrd545.Obj) = ((Wrd544.pObj) [0]);
  (Wrd546.Lng) = (FIXNUM_TO_LONG (Wrd545.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd546.Lng))))
    goto label_212;
  (Wrd538.Obj) = ((Wrd544.pObj) [2]);

DEFLABEL (label_211)
  (Wrd565.Obj) = (Rsp [3]);
  (Wrd566.uLng) = (OBJECT_TYPE (Wrd565.Obj));
  if (! ((Wrd566.uLng) == 62))
    goto label_210;
  (Wrd559.uLng) = (OBJECT_TYPE (Wrd538.Obj));
  if (! ((Wrd559.uLng) == 26))
    goto label_210;
  (Wrd560.Lng) = (FIXNUM_TO_LONG (Wrd538.Obj));
  (Wrd562.pObj) = (OBJECT_ADDRESS (Wrd565.Obj));
  (Wrd563.Obj) = ((Wrd562.pObj) [0]);
  (Wrd564.Lng) = (FIXNUM_TO_LONG (Wrd563.Obj));
  if (! (((unsigned long) (Wrd560.Lng)) < ((unsigned long) (Wrd564.Lng))))
    goto label_210;
  (Wrd555.uLng) = (OBJECT_DATUM (Wrd538.Obj));
  (Wrd558.pObj) = (& ((Wrd562.pObj) [(Wrd555.Lng)]));
  (Wrd554.Obj) = ((Wrd558.pObj) [1]);

DEFLABEL (label_209)
  (Wrd572.Obj) = (* (Rsp++));
  (Wrd574.Lng) = (FIXNUM_TO_LONG (Wrd554.Obj));
  (Wrd575.Lng) = (FIXNUM_TO_LONG (Wrd572.Obj));
  (Wrd576.Lng) = ((Wrd574.Lng) + (Wrd575.Lng));
  (Wrd577.Obj) = (* (Rsp++));
  Wrd578 = Wrd576;
  (Wrd579.Lng) = (FIXNUM_TO_LONG (Wrd577.Obj));
  (Wrd580.Lng) = ((Wrd578.Lng) & (Wrd579.Lng));
  (Wrd581.Obj) = (LONG_TO_FIXNUM (Wrd580.Lng));
  (* (--Rsp)) = (Wrd581.Obj);
  (Wrd591.Obj) = (Rsp [1]);
  (Wrd592.uLng) = (OBJECT_TYPE (Wrd591.Obj));
  if (! ((Wrd592.uLng) == 62))
    goto label_208;
  (Wrd588.pObj) = (OBJECT_ADDRESS (Wrd591.Obj));
  (Wrd589.Obj) = ((Wrd588.pObj) [0]);
  (Wrd590.Lng) = (FIXNUM_TO_LONG (Wrd589.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd590.Lng))))
    goto label_208;
  (Wrd582.Obj) = ((Wrd588.pObj) [6]);

DEFLABEL (label_207)
  (Wrd598.Obj) = (* (Rsp++));
  (Wrd608.uLng) = (OBJECT_TYPE (Wrd582.Obj));
  if (! ((Wrd608.uLng) == 10))
    goto label_206;
  (Wrd603.uLng) = (OBJECT_TYPE (Wrd598.Obj));
  if (! ((Wrd603.uLng) == 26))
    goto label_206;
  (Wrd604.Lng) = (FIXNUM_TO_LONG (Wrd598.Obj));
  (Wrd605.pObj) = (OBJECT_ADDRESS (Wrd582.Obj));
  (Wrd606.Obj) = ((Wrd605.pObj) [0]);
  (Wrd607.Lng) = (FIXNUM_TO_LONG (Wrd606.Obj));
  if (! (((unsigned long) (Wrd604.Lng)) < ((unsigned long) (Wrd607.Lng))))
    goto label_206;
  (Wrd600.uLng) = (OBJECT_DATUM (Wrd598.Obj));
  (Wrd602.pObj) = (& ((Wrd605.pObj) [(Wrd600.Lng)]));
  (Wrd599.Obj) = ((Wrd602.pObj) [1]);

DEFLABEL (label_205)
  (Wrd615.pObj) = (OBJECT_ADDRESS (Wrd599.Obj));
  (Wrd614.Obj) = ((Wrd615.pObj) [1]);
  (Wrd617.pObj) = (OBJECT_ADDRESS (Wrd614.Obj));
  (Wrd616.Obj) = ((Wrd617.pObj) [0]);
  (Wrd618.Obj) = (Rsp [2]);
  if (! ((Wrd618.Obj) == (Wrd616.Obj)))
    goto label_189;
  (Wrd628.Obj) = (Rsp [0]);
  (Wrd629.uLng) = (OBJECT_TYPE (Wrd628.Obj));
  if (! ((Wrd629.uLng) == 62))
    goto label_204;
  (Wrd625.pObj) = (OBJECT_ADDRESS (Wrd628.Obj));
  (Wrd626.Obj) = ((Wrd625.pObj) [0]);
  (Wrd627.Lng) = (FIXNUM_TO_LONG (Wrd626.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd627.Lng))))
    goto label_204;
  (Wrd621.Obj) = ((Wrd625.pObj) [3]);
  (* (--Rsp)) = (Wrd621.Obj);

DEFLABEL (label_203)
  (Wrd644.Obj) = (Rsp [1]);
  (Wrd645.uLng) = (OBJECT_TYPE (Wrd644.Obj));
  if (! ((Wrd645.uLng) == 62))
    goto label_202;
  (Wrd641.pObj) = (OBJECT_ADDRESS (Wrd644.Obj));
  (Wrd642.Obj) = ((Wrd641.pObj) [0]);
  (Wrd643.Lng) = (FIXNUM_TO_LONG (Wrd642.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd643.Lng))))
    goto label_202;
  (Wrd635.Obj) = ((Wrd641.pObj) [2]);

DEFLABEL (label_201)
  (Wrd662.Obj) = (Rsp [3]);
  (Wrd663.uLng) = (OBJECT_TYPE (Wrd662.Obj));
  if (! ((Wrd663.uLng) == 62))
    goto label_200;
  (Wrd656.uLng) = (OBJECT_TYPE (Wrd635.Obj));
  if (! ((Wrd656.uLng) == 26))
    goto label_200;
  (Wrd657.Lng) = (FIXNUM_TO_LONG (Wrd635.Obj));
  (Wrd659.pObj) = (OBJECT_ADDRESS (Wrd662.Obj));
  (Wrd660.Obj) = ((Wrd659.pObj) [0]);
  (Wrd661.Lng) = (FIXNUM_TO_LONG (Wrd660.Obj));
  if (! (((unsigned long) (Wrd657.Lng)) < ((unsigned long) (Wrd661.Lng))))
    goto label_200;
  (Wrd651.uLng) = (OBJECT_DATUM (Wrd635.Obj));
  (Wrd654.pObj) = (& ((Wrd659.pObj) [(Wrd651.Lng)]));
  (Wrd655.Obj) = ((Wrd654.pObj) [1]);
  (* (--Rsp)) = (Wrd655.Obj);

DEFLABEL (label_199)
  (Wrd678.Obj) = (Rsp [2]);
  (Wrd679.uLng) = (OBJECT_TYPE (Wrd678.Obj));
  if (! ((Wrd679.uLng) == 62))
    goto label_198;
  (Wrd675.pObj) = (OBJECT_ADDRESS (Wrd678.Obj));
  (Wrd676.Obj) = ((Wrd675.pObj) [0]);
  (Wrd677.Lng) = (FIXNUM_TO_LONG (Wrd676.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd677.Lng))))
    goto label_198;
  (Wrd669.Obj) = ((Wrd675.pObj) [2]);

DEFLABEL (label_197)
  (Wrd696.Obj) = (Rsp [3]);
  (Wrd697.uLng) = (OBJECT_TYPE (Wrd696.Obj));
  if (! ((Wrd697.uLng) == 62))
    goto label_196;
  (Wrd690.uLng) = (OBJECT_TYPE (Wrd669.Obj));
  if (! ((Wrd690.uLng) == 26))
    goto label_196;
  (Wrd691.Lng) = (FIXNUM_TO_LONG (Wrd669.Obj));
  (Wrd693.pObj) = (OBJECT_ADDRESS (Wrd696.Obj));
  (Wrd694.Obj) = ((Wrd693.pObj) [0]);
  (Wrd695.Lng) = (FIXNUM_TO_LONG (Wrd694.Obj));
  if (! (((unsigned long) (Wrd691.Lng)) < ((unsigned long) (Wrd695.Lng))))
    goto label_196;
  (Wrd686.uLng) = (OBJECT_DATUM (Wrd669.Obj));
  (Wrd689.pObj) = (& ((Wrd693.pObj) [(Wrd686.Lng)]));
  (Wrd685.Obj) = ((Wrd689.pObj) [1]);

DEFLABEL (label_195)
  (Wrd703.Obj) = (* (Rsp++));
  (Wrd705.Lng) = (FIXNUM_TO_LONG (Wrd685.Obj));
  (Wrd706.Lng) = (FIXNUM_TO_LONG (Wrd703.Obj));
  (Wrd707.Lng) = ((Wrd705.Lng) + (Wrd706.Lng));
  (Wrd708.Obj) = (* (Rsp++));
  Wrd710 = Wrd707;
  (Wrd711.Lng) = (FIXNUM_TO_LONG (Wrd708.Obj));
  (Wrd712.Lng) = ((Wrd710.Lng) & (Wrd711.Lng));
  (Wrd709.Obj) = (LONG_TO_FIXNUM (Wrd712.Lng));
  (Rsp [2]) = (Wrd709.Obj);
  (Wrd722.Obj) = (Rsp [0]);
  (Wrd723.uLng) = (OBJECT_TYPE (Wrd722.Obj));
  if (! ((Wrd723.uLng) == 62))
    goto label_194;
  (Wrd719.pObj) = (OBJECT_ADDRESS (Wrd722.Obj));
  (Wrd720.Obj) = ((Wrd719.pObj) [0]);
  (Wrd721.Lng) = (FIXNUM_TO_LONG (Wrd720.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd721.Lng))))
    goto label_194;
  (Wrd713.Obj) = ((Wrd719.pObj) [7]);

DEFLABEL (label_193)
  (Rsp [1]) = (Wrd713.Obj);
  Rsp = (& (Rsp [1]));
  (Wrd744.Obj) = (Rsp [0]);
  (Wrd745.uLng) = (OBJECT_TYPE (Wrd744.Obj));
  if ((Wrd745.uLng) == 10)
    goto label_192;

DEFLABEL (label_191)
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_192)
  (Wrd736.Obj) = (Rsp [1]);
  (Wrd737.uLng) = (OBJECT_TYPE (Wrd736.Obj));
  if (! ((Wrd737.uLng) == 26))
    goto label_191;
  (Wrd739.Lng) = (FIXNUM_TO_LONG (Wrd736.Obj));
  (Wrd741.pObj) = (OBJECT_ADDRESS (Wrd744.Obj));
  (Wrd742.Obj) = ((Wrd741.pObj) [0]);
  (Wrd743.Lng) = (FIXNUM_TO_LONG (Wrd742.Obj));
  if (! (((unsigned long) (Wrd739.Lng)) < ((unsigned long) (Wrd743.Lng))))
    goto label_191;
  (Wrd731.uLng) = (OBJECT_DATUM (Wrd736.Obj));
  (Wrd734.pObj) = (& ((Wrd741.pObj) [(Wrd731.Lng)]));
  Rvl = ((Wrd734.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_194)
  (Wrd724.Obj) = (Rsp [0]);
  (Wrd725.Obj) = (current_block [OBJECT_32_5]);
  (Wrd728.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_31]))));
  (* (--Rsp)) = (Wrd728.Obj);
  (* (--Rsp)) = (Wrd725.Obj);
  (* (--Rsp)) = (Wrd724.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_139)
  (Wrd713.Obj) = Rvl;
  goto label_193;

DEFLABEL (label_196)
  (Wrd698.Obj) = (Rsp [3]);
  (Wrd702.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_30]))));
  (* (--Rsp)) = (Wrd702.Obj);
  (* (--Rsp)) = (Wrd669.Obj);
  (* (--Rsp)) = (Wrd698.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_138)
  (Wrd685.Obj) = Rvl;
  goto label_195;

DEFLABEL (label_198)
  (Wrd680.Obj) = (Rsp [2]);
  (Wrd681.Obj) = (current_block [OBJECT_32_2]);
  (Wrd684.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_29]))));
  (* (--Rsp)) = (Wrd684.Obj);
  (* (--Rsp)) = (Wrd681.Obj);
  (* (--Rsp)) = (Wrd680.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_137)
  (Wrd669.Obj) = Rvl;
  goto label_197;

DEFLABEL (label_200)
  (Wrd664.Obj) = (Rsp [3]);
  (Wrd668.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_28]))));
  (* (--Rsp)) = (Wrd668.Obj);
  (* (--Rsp)) = (Wrd635.Obj);
  (* (--Rsp)) = (Wrd664.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_136)
  (* (--Rsp)) = Rvl;
  goto label_199;

DEFLABEL (label_202)
  (Wrd646.Obj) = (Rsp [1]);
  (Wrd647.Obj) = (current_block [OBJECT_32_2]);
  (Wrd650.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_27]))));
  (* (--Rsp)) = (Wrd650.Obj);
  (* (--Rsp)) = (Wrd647.Obj);
  (* (--Rsp)) = (Wrd646.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_135)
  (Wrd635.Obj) = Rvl;
  goto label_201;

DEFLABEL (label_204)
  (Wrd630.Obj) = (Rsp [0]);
  (Wrd631.Obj) = (current_block [OBJECT_32_0]);
  (Wrd634.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_26]))));
  (* (--Rsp)) = (Wrd634.Obj);
  (* (--Rsp)) = (Wrd631.Obj);
  (* (--Rsp)) = (Wrd630.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_134)
  (* (--Rsp)) = Rvl;
  goto label_203;

DEFLABEL (label_206)
  (Wrd613.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_25]))));
  (* (--Rsp)) = (Wrd613.Obj);
  (* (--Rsp)) = (Wrd598.Obj);
  (* (--Rsp)) = (Wrd582.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_133)
  (Wrd599.Obj) = Rvl;
  goto label_205;

DEFLABEL (label_208)
  (Wrd593.Obj) = (Rsp [1]);
  (Wrd594.Obj) = (current_block [OBJECT_32_3]);
  (Wrd597.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_24]))));
  (* (--Rsp)) = (Wrd597.Obj);
  (* (--Rsp)) = (Wrd594.Obj);
  (* (--Rsp)) = (Wrd593.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_132)
  (Wrd582.Obj) = Rvl;
  goto label_207;

DEFLABEL (label_210)
  (Wrd567.Obj) = (Rsp [3]);
  (Wrd571.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_23]))));
  (* (--Rsp)) = (Wrd571.Obj);
  (* (--Rsp)) = (Wrd538.Obj);
  (* (--Rsp)) = (Wrd567.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_131)
  (Wrd554.Obj) = Rvl;
  goto label_209;

DEFLABEL (label_212)
  (Wrd549.Obj) = (Rsp [2]);
  (Wrd550.Obj) = (current_block [OBJECT_32_2]);
  (Wrd553.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_22]))));
  (* (--Rsp)) = (Wrd553.Obj);
  (* (--Rsp)) = (Wrd550.Obj);
  (* (--Rsp)) = (Wrd549.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_130)
  (Wrd538.Obj) = Rvl;
  goto label_211;

DEFLABEL (label_214)
  (Wrd533.Obj) = (Rsp [3]);
  (Wrd537.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_21]))));
  (* (--Rsp)) = (Wrd537.Obj);
  (* (--Rsp)) = (Wrd504.Obj);
  (* (--Rsp)) = (Wrd533.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_129)
  (* (--Rsp)) = Rvl;
  goto label_213;

DEFLABEL (label_216)
  (Wrd515.Obj) = (Rsp [1]);
  (Wrd516.Obj) = (current_block [OBJECT_32_2]);
  (Wrd519.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_20]))));
  (* (--Rsp)) = (Wrd519.Obj);
  (* (--Rsp)) = (Wrd516.Obj);
  (* (--Rsp)) = (Wrd515.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_128)
  (Wrd504.Obj) = Rvl;
  goto label_215;

DEFLABEL (label_218)
  (Wrd499.Obj) = (Rsp [0]);
  (Wrd500.Obj) = (current_block [OBJECT_32_0]);
  (Wrd503.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_19]))));
  (* (--Rsp)) = (Wrd503.Obj);
  (* (--Rsp)) = (Wrd500.Obj);
  (* (--Rsp)) = (Wrd499.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_127)
  (* (--Rsp)) = Rvl;
  goto label_217;

DEFLABEL (label_220)
  (Wrd484.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_18]))));
  (* (--Rsp)) = (Wrd484.Obj);
  (* (--Rsp)) = (Wrd469.Obj);
  (* (--Rsp)) = (Wrd453.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_126)
  (Wrd470.Obj) = Rvl;
  goto label_219;

DEFLABEL (label_222)
  (Wrd464.Obj) = (Rsp [1]);
  (Wrd465.Obj) = (current_block [OBJECT_32_3]);
  (Wrd468.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_17]))));
  (* (--Rsp)) = (Wrd468.Obj);
  (* (--Rsp)) = (Wrd465.Obj);
  (* (--Rsp)) = (Wrd464.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_125)
  (Wrd453.Obj) = Rvl;
  goto label_221;

DEFLABEL (label_224)
  (Wrd438.Obj) = (Rsp [3]);
  (Wrd442.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_16]))));
  (* (--Rsp)) = (Wrd442.Obj);
  (* (--Rsp)) = (Wrd409.Obj);
  (* (--Rsp)) = (Wrd438.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_124)
  (Wrd425.Obj) = Rvl;
  goto label_223;

DEFLABEL (label_226)
  (Wrd420.Obj) = (Rsp [2]);
  (Wrd421.Obj) = (current_block [OBJECT_32_2]);
  (Wrd424.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_15]))));
  (* (--Rsp)) = (Wrd424.Obj);
  (* (--Rsp)) = (Wrd421.Obj);
  (* (--Rsp)) = (Wrd420.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_123)
  (Wrd409.Obj) = Rvl;
  goto label_225;

DEFLABEL (label_228)
  (Wrd404.Obj) = (Rsp [3]);
  (Wrd408.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_14]))));
  (* (--Rsp)) = (Wrd408.Obj);
  (* (--Rsp)) = (Wrd375.Obj);
  (* (--Rsp)) = (Wrd404.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_122)
  (* (--Rsp)) = Rvl;
  goto label_227;

DEFLABEL (label_230)
  (Wrd386.Obj) = (Rsp [1]);
  (Wrd387.Obj) = (current_block [OBJECT_32_2]);
  (Wrd390.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_13]))));
  (* (--Rsp)) = (Wrd390.Obj);
  (* (--Rsp)) = (Wrd387.Obj);
  (* (--Rsp)) = (Wrd386.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_121)
  (Wrd375.Obj) = Rvl;
  goto label_229;

DEFLABEL (label_232)
  (Wrd370.Obj) = (Rsp [0]);
  (Wrd371.Obj) = (current_block [OBJECT_32_0]);
  (Wrd374.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_12]))));
  (* (--Rsp)) = (Wrd374.Obj);
  (* (--Rsp)) = (Wrd371.Obj);
  (* (--Rsp)) = (Wrd370.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_120)
  (* (--Rsp)) = Rvl;
  goto label_231;

DEFLABEL (label_234)
  (Wrd757.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_11]))));
  (* (--Rsp)) = (Wrd757.Obj);
  (* (--Rsp)) = (Wrd115.Obj);
  (* (--Rsp)) = (Wrd99.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_140)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_189;
  goto label_233;

DEFLABEL (label_236)
  (Wrd110.Obj) = (Rsp [1]);
  (Wrd111.Obj) = (current_block [OBJECT_32_3]);
  (Wrd114.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_10]))));
  (* (--Rsp)) = (Wrd114.Obj);
  (* (--Rsp)) = (Wrd111.Obj);
  (* (--Rsp)) = (Wrd110.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_106)
  (Wrd99.Obj) = Rvl;
  goto label_235;

DEFLABEL (label_238)
  (Wrd84.Obj) = (Rsp [3]);
  (Wrd88.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_9]))));
  (* (--Rsp)) = (Wrd88.Obj);
  (* (--Rsp)) = (Wrd55.Obj);
  (* (--Rsp)) = (Wrd84.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_105)
  (Wrd71.Obj) = Rvl;
  goto label_237;

DEFLABEL (label_240)
  (Wrd66.Obj) = (Rsp [2]);
  (Wrd67.Obj) = (current_block [OBJECT_32_2]);
  (Wrd70.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_8]))));
  (* (--Rsp)) = (Wrd70.Obj);
  (* (--Rsp)) = (Wrd67.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_104)
  (Wrd55.Obj) = Rvl;
  goto label_239;

DEFLABEL (label_242)
  (Wrd50.Obj) = (Rsp [3]);
  (Wrd54.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_7]))));
  (* (--Rsp)) = (Wrd54.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = (Wrd50.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_103)
  (* (--Rsp)) = Rvl;
  goto label_241;

DEFLABEL (label_244)
  (Wrd32.Obj) = (Rsp [1]);
  (Wrd33.Obj) = (current_block [OBJECT_32_2]);
  (Wrd36.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_6]))));
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd33.Obj);
  (* (--Rsp)) = (Wrd32.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_102)
  (Wrd21.Obj) = Rvl;
  goto label_243;

DEFLABEL (label_246)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_32_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_101)
  (* (--Rsp)) = Rvl;
  goto label_245;

DEFLABEL (search_lines_159)
DEFLABEL (search_lines_88)
  INTERRUPT_CHECK (26, LABEL_32_45);
  (Wrd5.Obj) = (Rsp [1]);
  (Wrd6.Obj) = (Rsp [2]);
  if ((Wrd5.Obj) == (Wrd6.Obj))
    goto label_272;
  (Wrd16.Obj) = (Rsp [3]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_271;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_271;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_270)
  (Wrd184.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd184.uLng) == 10))
    goto label_269;
  (Wrd177.Obj) = (Rsp [0]);
  (Wrd178.uLng) = (OBJECT_TYPE (Wrd177.Obj));
  if (! ((Wrd178.uLng) == 26))
    goto label_269;
  (Wrd180.Lng) = (FIXNUM_TO_LONG (Wrd177.Obj));
  (Wrd181.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd182.Obj) = ((Wrd181.pObj) [0]);
  (Wrd183.Lng) = (FIXNUM_TO_LONG (Wrd182.Obj));
  if (! (((unsigned long) (Wrd180.Lng)) < ((unsigned long) (Wrd183.Lng))))
    goto label_269;
  (Wrd24.uLng) = (OBJECT_DATUM (Wrd177.Obj));
  (Wrd26.pObj) = (& ((Wrd181.pObj) [(Wrd24.Lng)]));
  (Wrd27.Obj) = ((Wrd26.pObj) [1]);
  if ((Wrd27.Obj) == ((SCHEME_OBJECT) 0))
    goto label_254;

DEFLABEL (label_268)
  (Wrd75.Obj) = (Rsp [3]);
  (Wrd76.uLng) = (OBJECT_TYPE (Wrd75.Obj));
  if (! ((Wrd76.uLng) == 62))
    goto label_267;
  (Wrd72.pObj) = (OBJECT_ADDRESS (Wrd75.Obj));
  (Wrd73.Obj) = ((Wrd72.pObj) [0]);
  (Wrd74.Lng) = (FIXNUM_TO_LONG (Wrd73.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd74.Lng))))
    goto label_267;
  (Wrd66.Obj) = ((Wrd72.pObj) [6]);

DEFLABEL (label_266)
  (Wrd94.uLng) = (OBJECT_TYPE (Wrd66.Obj));
  if (! ((Wrd94.uLng) == 10))
    goto label_265;
  (Wrd87.Obj) = (Rsp [0]);
  (Wrd88.uLng) = (OBJECT_TYPE (Wrd87.Obj));
  if (! ((Wrd88.uLng) == 26))
    goto label_265;
  (Wrd90.Lng) = (FIXNUM_TO_LONG (Wrd87.Obj));
  (Wrd91.pObj) = (OBJECT_ADDRESS (Wrd66.Obj));
  (Wrd92.Obj) = ((Wrd91.pObj) [0]);
  (Wrd93.Lng) = (FIXNUM_TO_LONG (Wrd92.Obj));
  if (! (((unsigned long) (Wrd90.Lng)) < ((unsigned long) (Wrd93.Lng))))
    goto label_265;
  (Wrd84.uLng) = (OBJECT_DATUM (Wrd87.Obj));
  (Wrd86.pObj) = (& ((Wrd91.pObj) [(Wrd84.Lng)]));
  (Wrd82.Obj) = ((Wrd86.pObj) [1]);

DEFLABEL (label_264)
  (Wrd101.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd100.Obj) = ((Wrd101.pObj) [0]);
  (Wrd102.Obj) = (Rsp [4]);
  if ((Wrd102.Obj) == (Wrd100.Obj))
    goto label_255;

DEFLABEL (label_254)
  (Wrd38.Obj) = (Rsp [3]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 62))
    goto label_253;
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (Wrd37.Lng) = (FIXNUM_TO_LONG (Wrd36.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd37.Lng))))
    goto label_253;
  (Wrd29.Obj) = ((Wrd35.pObj) [6]);

DEFLABEL (label_252)
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd49.uLng) == 10))
    goto label_251;
  (Wrd47.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd48.Obj) = ((Wrd47.pObj) [0]);
  (Wrd45.Obj) = (MAKE_OBJECT (26, (Wrd48.uLng)));

DEFLABEL (label_250)
  (Wrd55.Obj) = (Rsp [0]);
  (Wrd56.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd57.Lng) = ((Wrd56.Lng) + 1L);
  (Wrd54.Obj) = (LONG_TO_FIXNUM (Wrd57.Lng));
  if ((Wrd54.Obj) == (Wrd45.Obj))
    goto label_248;
  Wrd58 = Wrd54;
  goto label_247;

DEFLABEL (label_248)
  (Wrd58.Obj) = (current_block [OBJECT_32_7]);

DEFLABEL (label_247)
DEFLABEL (label_249)
  (Rsp [0]) = (Wrd58.Obj);
  (Wrd63.Obj) = (Rsp [1]);
  (Wrd64.Lng) = (FIXNUM_TO_LONG (Wrd63.Obj));
  (Wrd65.Lng) = ((Wrd64.Lng) + 1L);
  (Wrd62.Obj) = (LONG_TO_FIXNUM (Wrd65.Lng));
  (Rsp [1]) = (Wrd62.Obj);
  goto search_lines_88;

DEFLABEL (label_251)
  (Wrd53.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_55]))));
  (* (--Rsp)) = (Wrd53.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_8]), 1);

DEFLABEL (label_143)
  (Wrd45.Obj) = Rvl;
  goto label_250;

DEFLABEL (label_253)
  (Wrd40.Obj) = (Rsp [3]);
  (Wrd41.Obj) = (current_block [OBJECT_32_3]);
  (Wrd44.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_54]))));
  (* (--Rsp)) = (Wrd44.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd40.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_142)
  (Wrd29.Obj) = Rvl;
  goto label_252;

DEFLABEL (label_255)
  (Wrd112.Obj) = (Rsp [3]);
  (Wrd113.uLng) = (OBJECT_TYPE (Wrd112.Obj));
  if (! ((Wrd113.uLng) == 62))
    goto label_263;
  (Wrd109.pObj) = (OBJECT_ADDRESS (Wrd112.Obj));
  (Wrd110.Obj) = ((Wrd109.pObj) [0]);
  (Wrd111.Lng) = (FIXNUM_TO_LONG (Wrd110.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd111.Lng))))
    goto label_263;
  (Wrd103.Obj) = ((Wrd109.pObj) [6]);

DEFLABEL (label_262)
  (Wrd131.uLng) = (OBJECT_TYPE (Wrd103.Obj));
  if (! ((Wrd131.uLng) == 10))
    goto label_261;
  (Wrd124.Obj) = (Rsp [0]);
  (Wrd125.uLng) = (OBJECT_TYPE (Wrd124.Obj));
  if (! ((Wrd125.uLng) == 26))
    goto label_261;
  (Wrd127.Lng) = (FIXNUM_TO_LONG (Wrd124.Obj));
  (Wrd128.pObj) = (OBJECT_ADDRESS (Wrd103.Obj));
  (Wrd129.Obj) = ((Wrd128.pObj) [0]);
  (Wrd130.Lng) = (FIXNUM_TO_LONG (Wrd129.Obj));
  if (! (((unsigned long) (Wrd127.Lng)) < ((unsigned long) (Wrd130.Lng))))
    goto label_261;
  (Wrd121.uLng) = (OBJECT_DATUM (Wrd124.Obj));
  (Wrd123.pObj) = (& ((Wrd128.pObj) [(Wrd121.Lng)]));
  (Wrd119.Obj) = ((Wrd123.pObj) [1]);

DEFLABEL (label_260)
  (Wrd138.pObj) = (OBJECT_ADDRESS (Wrd119.Obj));
  (Wrd137.Obj) = ((Wrd138.pObj) [1]);
  (Wrd140.pObj) = (OBJECT_ADDRESS (Wrd137.Obj));
  (Wrd139.Obj) = ((Wrd140.pObj) [0]);
  (Wrd141.Obj) = (Rsp [5]);
  if (! ((Wrd141.Obj) == (Wrd139.Obj)))
    goto label_254;
  (Wrd151.Obj) = (Rsp [3]);
  (Wrd152.uLng) = (OBJECT_TYPE (Wrd151.Obj));
  if (! ((Wrd152.uLng) == 62))
    goto label_259;
  (Wrd148.pObj) = (OBJECT_ADDRESS (Wrd151.Obj));
  (Wrd149.Obj) = ((Wrd148.pObj) [0]);
  (Wrd150.Lng) = (FIXNUM_TO_LONG (Wrd149.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd150.Lng))))
    goto label_259;
  (Wrd142.Obj) = ((Wrd148.pObj) [7]);

DEFLABEL (label_258)
  (Rsp [4]) = (Wrd142.Obj);
  (Wrd158.Obj) = (Rsp [0]);
  (Rsp [5]) = (Wrd158.Obj);
  Rsp = (& (Rsp [4]));
  (Wrd174.Obj) = (Rsp [0]);
  (Wrd175.uLng) = (OBJECT_TYPE (Wrd174.Obj));
  if ((Wrd175.uLng) == 10)
    goto label_257;

DEFLABEL (label_256)
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_257)
  (Wrd166.Obj) = (Rsp [1]);
  (Wrd167.uLng) = (OBJECT_TYPE (Wrd166.Obj));
  if (! ((Wrd167.uLng) == 26))
    goto label_256;
  (Wrd169.Lng) = (FIXNUM_TO_LONG (Wrd166.Obj));
  (Wrd171.pObj) = (OBJECT_ADDRESS (Wrd174.Obj));
  (Wrd172.Obj) = ((Wrd171.pObj) [0]);
  (Wrd173.Lng) = (FIXNUM_TO_LONG (Wrd172.Obj));
  if (! (((unsigned long) (Wrd169.Lng)) < ((unsigned long) (Wrd173.Lng))))
    goto label_256;
  (Wrd161.uLng) = (OBJECT_DATUM (Wrd166.Obj));
  (Wrd164.pObj) = (& ((Wrd171.pObj) [(Wrd161.Lng)]));
  Rvl = ((Wrd164.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_259)
  (Wrd153.Obj) = (Rsp [3]);
  (Wrd154.Obj) = (current_block [OBJECT_32_5]);
  (Wrd157.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_53]))));
  (* (--Rsp)) = (Wrd157.Obj);
  (* (--Rsp)) = (Wrd154.Obj);
  (* (--Rsp)) = (Wrd153.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_148)
  (Wrd142.Obj) = Rvl;
  goto label_258;

DEFLABEL (label_261)
  (Wrd133.Obj) = (Rsp [0]);
  (Wrd136.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_52]))));
  (* (--Rsp)) = (Wrd136.Obj);
  (* (--Rsp)) = (Wrd133.Obj);
  (* (--Rsp)) = (Wrd103.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_147)
  (Wrd119.Obj) = Rvl;
  goto label_260;

DEFLABEL (label_263)
  (Wrd114.Obj) = (Rsp [3]);
  (Wrd115.Obj) = (current_block [OBJECT_32_3]);
  (Wrd118.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_51]))));
  (* (--Rsp)) = (Wrd118.Obj);
  (* (--Rsp)) = (Wrd115.Obj);
  (* (--Rsp)) = (Wrd114.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_146)
  (Wrd103.Obj) = Rvl;
  goto label_262;

DEFLABEL (label_265)
  (Wrd96.Obj) = (Rsp [0]);
  (Wrd99.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_50]))));
  (* (--Rsp)) = (Wrd99.Obj);
  (* (--Rsp)) = (Wrd96.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_145)
  (Wrd82.Obj) = Rvl;
  goto label_264;

DEFLABEL (label_267)
  (Wrd77.Obj) = (Rsp [3]);
  (Wrd78.Obj) = (current_block [OBJECT_32_3]);
  (Wrd81.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_49]))));
  (* (--Rsp)) = (Wrd81.Obj);
  (* (--Rsp)) = (Wrd78.Obj);
  (* (--Rsp)) = (Wrd77.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_144)
  (Wrd66.Obj) = Rvl;
  goto label_266;

DEFLABEL (label_269)
  (Wrd186.Obj) = (Rsp [0]);
  (Wrd189.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_48]))));
  (* (--Rsp)) = (Wrd189.Obj);
  (* (--Rsp)) = (Wrd186.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_4]), 2);

DEFLABEL (label_149)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_254;
  goto label_268;

DEFLABEL (label_271)
  (Wrd18.Obj) = (Rsp [3]);
  (Wrd19.Obj) = (current_block [OBJECT_32_3]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_47]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_141)
  (Wrd7.Obj) = Rvl;
  goto label_270;

DEFLABEL (label_272)
  (Wrd200.Obj) = (Rsp [3]);
  (Wrd201.uLng) = (OBJECT_TYPE (Wrd200.Obj));
  if (! ((Wrd201.uLng) == 62))
    goto label_274;
  (Wrd197.pObj) = (OBJECT_ADDRESS (Wrd200.Obj));
  (Wrd198.Obj) = ((Wrd197.pObj) [0]);
  (Wrd199.Lng) = (FIXNUM_TO_LONG (Wrd198.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd199.Lng))))
    goto label_274;
  (Wrd191.Obj) = ((Wrd197.pObj) [8]);

DEFLABEL (label_273)
  (Rsp [2]) = (Wrd191.Obj);
  Rsp = (& (Rsp [2]));
  goto search_overflow_86;

DEFLABEL (label_274)
  (Wrd202.Obj) = (Rsp [3]);
  (Wrd203.Obj) = (current_block [OBJECT_32_9]);
  (Wrd206.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_46]))));
  (* (--Rsp)) = (Wrd206.Obj);
  (* (--Rsp)) = (Wrd203.Obj);
  (* (--Rsp)) = (Wrd202.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_1]), 2);

DEFLABEL (label_150)
  (Wrd191.Obj) = Rvl;
  goto label_273;

DEFLABEL (search_overflow_160)
DEFLABEL (search_overflow_86)
  INTERRUPT_CHECK (26, LABEL_32_56);
  (Wrd5.Obj) = (Rsp [0]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_32_10])))
    goto label_275;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_275)
  (Wrd11.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd11.uLng) == 1))
    goto label_290;
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd7.Obj) = ((Wrd9.pObj) [0]);

DEFLABEL (label_289)
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd18.uLng) == 1))
    goto label_288;
  (Wrd17.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd16.Obj) = ((Wrd17.pObj) [0]);

DEFLABEL (label_287)
  (Wrd24.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd23.Obj) = ((Wrd24.pObj) [0]);
  (Wrd25.Obj) = (Rsp [2]);
  if ((Wrd25.Obj) == (Wrd23.Obj))
    goto label_279;

DEFLABEL (label_278)
  (Wrd29.Obj) = (Rsp [0]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 1))
    goto label_277;
  (Wrd28.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd26.Obj) = ((Wrd28.pObj) [1]);

DEFLABEL (label_276)
  (Rsp [0]) = (Wrd26.Obj);
  goto search_overflow_86;

DEFLABEL (label_277)
  (Wrd34.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_62]))));
  (* (--Rsp)) = (Wrd34.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_12]), 1);

DEFLABEL (label_153)
  (Wrd26.Obj) = Rvl;
  goto label_276;

DEFLABEL (label_279)
  (Wrd38.Obj) = (Rsp [0]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 1))
    goto label_286;
  (Wrd37.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd35.Obj) = ((Wrd37.pObj) [0]);

DEFLABEL (label_285)
  (Wrd46.uLng) = (OBJECT_TYPE (Wrd35.Obj));
  if (! ((Wrd46.uLng) == 1))
    goto label_284;
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd35.Obj));
  (Wrd44.Obj) = ((Wrd45.pObj) [0]);

DEFLABEL (label_283)
  (Wrd52.pObj) = (OBJECT_ADDRESS (Wrd44.Obj));
  (Wrd51.Obj) = ((Wrd52.pObj) [1]);
  (Wrd54.pObj) = (OBJECT_ADDRESS (Wrd51.Obj));
  (Wrd53.Obj) = ((Wrd54.pObj) [0]);
  (Wrd55.Obj) = (Rsp [3]);
  if (! ((Wrd55.Obj) == (Wrd53.Obj)))
    goto label_278;
  (Wrd59.Obj) = (Rsp [0]);
  (Wrd60.uLng) = (OBJECT_TYPE (Wrd59.Obj));
  if (! ((Wrd60.uLng) == 1))
    goto label_282;
  (Wrd58.pObj) = (OBJECT_ADDRESS (Wrd59.Obj));
  (Wrd56.Obj) = ((Wrd58.pObj) [0]);

DEFLABEL (label_281)
  (Rsp [3]) = (Wrd56.Obj);
  Rsp = (& (Rsp [3]));
  (Wrd69.Obj) = (Rsp [0]);
  (Wrd70.uLng) = (OBJECT_TYPE (Wrd69.Obj));
  if (! ((Wrd70.uLng) == 1))
    goto label_280;
  (Wrd67.pObj) = (OBJECT_ADDRESS (Wrd69.Obj));
  Rvl = ((Wrd67.pObj) [1]);
  Rsp = (& (Rsp [1]));
  goto pop_return;

DEFLABEL (label_280)
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_12]), 1);

DEFLABEL (label_282)
  (Wrd64.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_61]))));
  (* (--Rsp)) = (Wrd64.Obj);
  (* (--Rsp)) = (Wrd59.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_11]), 1);

DEFLABEL (label_156)
  (Wrd56.Obj) = Rvl;
  goto label_281;

DEFLABEL (label_284)
  (Wrd50.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_60]))));
  (* (--Rsp)) = (Wrd50.Obj);
  (* (--Rsp)) = (Wrd35.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_11]), 1);

DEFLABEL (label_155)
  (Wrd44.Obj) = Rvl;
  goto label_283;

DEFLABEL (label_286)
  (Wrd43.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_59]))));
  (* (--Rsp)) = (Wrd43.Obj);
  (* (--Rsp)) = (Wrd38.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_11]), 1);

DEFLABEL (label_154)
  (Wrd35.Obj) = Rvl;
  goto label_285;

DEFLABEL (label_288)
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_58]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_11]), 1);

DEFLABEL (label_152)
  (Wrd16.Obj) = Rvl;
  goto label_287;

DEFLABEL (label_290)
  (Wrd15.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_32_57]))));
  (* (--Rsp)) = (Wrd15.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_32_11]), 1);

DEFLABEL (label_151)
  (Wrd7.Obj) = Rvl;
  goto label_289;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_33_4 3
#define LABEL_33_5 5
#define LABEL_33_6 7
#define LABEL_33_7 9
#define LABEL_33_8 11
#define LABEL_33_9 13
#define LABEL_33_10 15
#define LABEL_33_11 17
#define LABEL_33_12 19
#define LABEL_33_13 21
#define LABEL_33_14 23
#define LABEL_33_15 25
#define LABEL_33_16 27
#define LABEL_33_17 29
#define LABEL_33_18 31
#define LABEL_33_19 33
#define LABEL_33_20 35
#define LABEL_33_21 37
#define LABEL_33_22 39
#define LABEL_33_23 41
#define LABEL_33_24 43
#define LABEL_33_25 45
#define LABEL_33_26 47
#define LABEL_33_27 49
#define LABEL_33_28 51
#define LABEL_33_29 53
#define LABEL_33_30 55
#define LABEL_33_31 57
#define LABEL_33_32 59
#define LABEL_33_33 61
#define LABEL_33_34 63
#define LABEL_33_35 65
#define LABEL_33_36 67
#define LABEL_33_37 69
#define LABEL_33_38 71
#define LABEL_33_39 73
#define LABEL_33_40 75
#define LABEL_33_41 77
#define LABEL_33_42 79
#define LABEL_33_43 81
#define LABEL_33_44 83
#define LABEL_33_45 85
#define LABEL_33_46 87
#define LABEL_33_47 89
#define LABEL_33_48 91
#define LABEL_33_49 93
#define LABEL_33_50 95
#define LABEL_33_51 97
#define LABEL_33_52 99
#define LABEL_33_53 101
#define LABEL_33_54 103
#define LABEL_33_55 105
#define LABEL_33_56 107
#define LABEL_33_57 109
#define LABEL_33_58 111
#define LABEL_33_59 113
#define LABEL_33_60 115
#define LABEL_33_61 117
#define LABEL_33_62 119
#define LABEL_33_63 121
#define LABEL_33_64 123
#define LABEL_33_65 125
#define LABEL_33_66 127
#define LABEL_33_67 129
#define LABEL_33_68 131
#define LABEL_33_69 133
#define LABEL_33_70 135
#define LABEL_33_71 137
#define LABEL_33_72 139
#define LABEL_33_73 141
#define LABEL_33_74 143
#define LABEL_33_75 145
#define LABEL_33_76 147
#define LABEL_33_77 149
#define LABEL_33_78 151
#define ENVIRONMENT_LABEL_33_3 166
#define DEBUGGING_LABEL_33_2 165
#define OBJECT_33_12 164
#define OBJECT_33_11 163
#define OBJECT_33_10 162
#define OBJECT_33_9 161
#define OBJECT_33_8 160
#define OBJECT_33_7 159
#define OBJECT_33_6 158
#define OBJECT_33_5 157
#define OBJECT_33_4 156
#define OBJECT_33_3 155
#define OBJECT_33_2 154
#define OBJECT_33_1 153
#define OBJECT_33_0 152
#define FREE_REFERENCES_LABEL_33_0 152
#define NUMBER_OF_LINKER_SECTIONS_33_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_33 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd34;
  machine_word Wrd60;
  machine_word Wrd59;
  machine_word Wrd51;
  machine_word Wrd52;
  machine_word Wrd25;
  machine_word Wrd23;
  machine_word Wrd9;
  machine_word Wrd58;
  machine_word Wrd57;
  machine_word Wrd56;
  machine_word Wrd53;
  machine_word Wrd44;
  machine_word Wrd35;
  machine_word Wrd39;
  machine_word Wrd38;
  machine_word Wrd213;
  machine_word Wrd212;
  machine_word Wrd216;
  machine_word Wrd215;
  machine_word Wrd195;
  machine_word Wrd194;
  machine_word Wrd191;
  machine_word Wrd193;
  machine_word Wrd192;
  machine_word Wrd178;
  machine_word Wrd176;
  machine_word Wrd177;
  machine_word Wrd168;
  machine_word Wrd167;
  machine_word Wrd166;
  machine_word Wrd157;
  machine_word Wrd142;
  machine_word Wrd152;
  machine_word Wrd151;
  machine_word Wrd141;
  machine_word Wrd139;
  machine_word Wrd140;
  machine_word Wrd129;
  machine_word Wrd125;
  machine_word Wrd124;
  machine_word Wrd113;
  machine_word Wrd112;
  machine_word Wrd99;
  machine_word Wrd96;
  machine_word Wrd86;
  machine_word Wrd87;
  machine_word Wrd78;
  machine_word Wrd74;
  machine_word Wrd73;
  machine_word Wrd26;
  machine_word Wrd24;
  machine_word Wrd219;
  machine_word Wrd218;
  machine_word Wrd22;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd244;
  machine_word Wrd232;
  machine_word Wrd6;
  machine_word Wrd5;
  machine_word Wrd487;
  machine_word Wrd486;
  machine_word Wrd485;
  machine_word Wrd483;
  machine_word Wrd482;
  machine_word Wrd480;
  machine_word Wrd479;
  machine_word Wrd478;
  machine_word Wrd477;
  machine_word Wrd475;
  machine_word Wrd474;
  machine_word Wrd470;
  machine_word Wrd457;
  machine_word Wrd461;
  machine_word Wrd458;
  machine_word Wrd467;
  machine_word Wrd466;
  machine_word Wrd465;
  machine_word Wrd463;
  machine_word Wrd462;
  machine_word Wrd469;
  machine_word Wrd468;
  machine_word Wrd456;
  machine_word Wrd453;
  machine_word Wrd452;
  machine_word Wrd441;
  machine_word Wrd449;
  machine_word Wrd448;
  machine_word Wrd447;
  machine_word Wrd451;
  machine_word Wrd450;
  machine_word Wrd440;
  machine_word Wrd439;
  machine_word Wrd438;
  machine_word Wrd437;
  machine_word Wrd436;
  machine_word Wrd435;
  machine_word Wrd431;
  machine_word Wrd418;
  machine_word Wrd422;
  machine_word Wrd419;
  machine_word Wrd428;
  machine_word Wrd427;
  machine_word Wrd426;
  machine_word Wrd424;
  machine_word Wrd423;
  machine_word Wrd430;
  machine_word Wrd429;
  machine_word Wrd417;
  machine_word Wrd414;
  machine_word Wrd413;
  machine_word Wrd402;
  machine_word Wrd410;
  machine_word Wrd409;
  machine_word Wrd408;
  machine_word Wrd412;
  machine_word Wrd411;
  machine_word Wrd401;
  machine_word Wrd397;
  machine_word Wrd388;
  machine_word Wrd387;
  machine_word Wrd384;
  machine_word Wrd394;
  machine_word Wrd393;
  machine_word Wrd392;
  machine_word Wrd390;
  machine_word Wrd389;
  machine_word Wrd396;
  machine_word Wrd395;
  machine_word Wrd383;
  machine_word Wrd380;
  machine_word Wrd379;
  machine_word Wrd368;
  machine_word Wrd376;
  machine_word Wrd375;
  machine_word Wrd374;
  machine_word Wrd378;
  machine_word Wrd377;
  machine_word Wrd367;
  machine_word Wrd364;
  machine_word Wrd363;
  machine_word Wrd354;
  machine_word Wrd360;
  machine_word Wrd359;
  machine_word Wrd358;
  machine_word Wrd362;
  machine_word Wrd361;
  machine_word Wrd488;
  machine_word Wrd351;
  machine_word Wrd348;
  machine_word Wrd350;
  machine_word Wrd349;
  machine_word Wrd346;
  machine_word Wrd345;
  machine_word Wrd343;
  machine_word Wrd342;
  machine_word Wrd341;
  machine_word Wrd340;
  machine_word Wrd338;
  machine_word Wrd337;
  machine_word Wrd333;
  machine_word Wrd320;
  machine_word Wrd324;
  machine_word Wrd321;
  machine_word Wrd330;
  machine_word Wrd329;
  machine_word Wrd328;
  machine_word Wrd326;
  machine_word Wrd325;
  machine_word Wrd332;
  machine_word Wrd331;
  machine_word Wrd319;
  machine_word Wrd316;
  machine_word Wrd315;
  machine_word Wrd304;
  machine_word Wrd312;
  machine_word Wrd311;
  machine_word Wrd310;
  machine_word Wrd314;
  machine_word Wrd313;
  machine_word Wrd303;
  machine_word Wrd302;
  machine_word Wrd301;
  machine_word Wrd300;
  machine_word Wrd299;
  machine_word Wrd298;
  machine_word Wrd294;
  machine_word Wrd281;
  machine_word Wrd285;
  machine_word Wrd282;
  machine_word Wrd291;
  machine_word Wrd290;
  machine_word Wrd289;
  machine_word Wrd287;
  machine_word Wrd286;
  machine_word Wrd293;
  machine_word Wrd292;
  machine_word Wrd280;
  machine_word Wrd277;
  machine_word Wrd276;
  machine_word Wrd265;
  machine_word Wrd273;
  machine_word Wrd272;
  machine_word Wrd271;
  machine_word Wrd275;
  machine_word Wrd274;
  machine_word Wrd264;
  machine_word Wrd260;
  machine_word Wrd251;
  machine_word Wrd250;
  machine_word Wrd247;
  machine_word Wrd257;
  machine_word Wrd256;
  machine_word Wrd255;
  machine_word Wrd253;
  machine_word Wrd252;
  machine_word Wrd259;
  machine_word Wrd258;
  machine_word Wrd246;
  machine_word Wrd243;
  machine_word Wrd242;
  machine_word Wrd231;
  machine_word Wrd239;
  machine_word Wrd238;
  machine_word Wrd237;
  machine_word Wrd241;
  machine_word Wrd240;
  machine_word Wrd230;
  machine_word Wrd227;
  machine_word Wrd226;
  machine_word Wrd217;
  machine_word Wrd223;
  machine_word Wrd222;
  machine_word Wrd221;
  machine_word Wrd225;
  machine_word Wrd224;
  machine_word Wrd214;
  machine_word Wrd209;
  machine_word Wrd208;
  machine_word Wrd207;
  machine_word Wrd210;
  machine_word Wrd205;
  machine_word Wrd202;
  machine_word Wrd201;
  machine_word Wrd190;
  machine_word Wrd198;
  machine_word Wrd197;
  machine_word Wrd196;
  machine_word Wrd200;
  machine_word Wrd199;
  machine_word Wrd189;
  machine_word Wrd188;
  machine_word Wrd185;
  machine_word Wrd184;
  machine_word Wrd175;
  machine_word Wrd181;
  machine_word Wrd180;
  machine_word Wrd179;
  machine_word Wrd183;
  machine_word Wrd182;
  machine_word Wrd985;
  machine_word Wrd982;
  machine_word Wrd994;
  machine_word Wrd993;
  machine_word Wrd992;
  machine_word Wrd990;
  machine_word Wrd988;
  machine_word Wrd987;
  machine_word Wrd996;
  machine_word Wrd995;
  machine_word Wrd979;
  machine_word Wrd976;
  machine_word Wrd975;
  machine_word Wrd964;
  machine_word Wrd972;
  machine_word Wrd971;
  machine_word Wrd970;
  machine_word Wrd974;
  machine_word Wrd973;
  machine_word Wrd960;
  machine_word Wrd963;
  machine_word Wrd962;
  machine_word Wrd961;
  machine_word Wrd959;
  machine_word Wrd958;
  machine_word Wrd957;
  machine_word Wrd956;
  machine_word Wrd954;
  machine_word Wrd953;
  machine_word Wrd949;
  machine_word Wrd936;
  machine_word Wrd940;
  machine_word Wrd937;
  machine_word Wrd946;
  machine_word Wrd945;
  machine_word Wrd944;
  machine_word Wrd942;
  machine_word Wrd941;
  machine_word Wrd948;
  machine_word Wrd947;
  machine_word Wrd935;
  machine_word Wrd932;
  machine_word Wrd931;
  machine_word Wrd920;
  machine_word Wrd928;
  machine_word Wrd927;
  machine_word Wrd926;
  machine_word Wrd930;
  machine_word Wrd929;
  machine_word Wrd919;
  machine_word Wrd918;
  machine_word Wrd917;
  machine_word Wrd916;
  machine_word Wrd915;
  machine_word Wrd914;
  machine_word Wrd910;
  machine_word Wrd897;
  machine_word Wrd901;
  machine_word Wrd898;
  machine_word Wrd907;
  machine_word Wrd906;
  machine_word Wrd905;
  machine_word Wrd903;
  machine_word Wrd902;
  machine_word Wrd909;
  machine_word Wrd908;
  machine_word Wrd896;
  machine_word Wrd893;
  machine_word Wrd892;
  machine_word Wrd881;
  machine_word Wrd889;
  machine_word Wrd888;
  machine_word Wrd887;
  machine_word Wrd891;
  machine_word Wrd890;
  machine_word Wrd880;
  machine_word Wrd876;
  machine_word Wrd867;
  machine_word Wrd866;
  machine_word Wrd863;
  machine_word Wrd873;
  machine_word Wrd872;
  machine_word Wrd871;
  machine_word Wrd869;
  machine_word Wrd868;
  machine_word Wrd875;
  machine_word Wrd874;
  machine_word Wrd862;
  machine_word Wrd859;
  machine_word Wrd858;
  machine_word Wrd847;
  machine_word Wrd855;
  machine_word Wrd854;
  machine_word Wrd853;
  machine_word Wrd857;
  machine_word Wrd856;
  machine_word Wrd846;
  machine_word Wrd843;
  machine_word Wrd842;
  machine_word Wrd833;
  machine_word Wrd839;
  machine_word Wrd838;
  machine_word Wrd837;
  machine_word Wrd841;
  machine_word Wrd840;
  machine_word Wrd830;
  machine_word Wrd828;
  machine_word Wrd829;
  machine_word Wrd826;
  machine_word Wrd827;
  machine_word Wrd824;
  machine_word Wrd825;
  machine_word Wrd823;
  machine_word Wrd809;
  machine_word Wrd812;
  machine_word Wrd810;
  machine_word Wrd817;
  machine_word Wrd816;
  machine_word Wrd815;
  machine_word Wrd814;
  machine_word Wrd813;
  machine_word Wrd818;
  machine_word Wrd808;
  machine_word Wrd807;
  machine_word Wrd804;
  machine_word Wrd803;
  machine_word Wrd792;
  machine_word Wrd800;
  machine_word Wrd799;
  machine_word Wrd798;
  machine_word Wrd802;
  machine_word Wrd801;
  machine_word Wrd791;
  machine_word Wrd790;
  machine_word Wrd789;
  machine_word Wrd788;
  machine_word Wrd787;
  machine_word Wrd786;
  machine_word Wrd785;
  machine_word Wrd784;
  machine_word Wrd782;
  machine_word Wrd781;
  machine_word Wrd777;
  machine_word Wrd764;
  machine_word Wrd768;
  machine_word Wrd765;
  machine_word Wrd774;
  machine_word Wrd773;
  machine_word Wrd772;
  machine_word Wrd770;
  machine_word Wrd769;
  machine_word Wrd776;
  machine_word Wrd775;
  machine_word Wrd763;
  machine_word Wrd760;
  machine_word Wrd759;
  machine_word Wrd748;
  machine_word Wrd756;
  machine_word Wrd755;
  machine_word Wrd754;
  machine_word Wrd758;
  machine_word Wrd757;
  machine_word Wrd747;
  machine_word Wrd746;
  machine_word Wrd745;
  machine_word Wrd744;
  machine_word Wrd743;
  machine_word Wrd742;
  machine_word Wrd738;
  machine_word Wrd725;
  machine_word Wrd729;
  machine_word Wrd726;
  machine_word Wrd735;
  machine_word Wrd734;
  machine_word Wrd733;
  machine_word Wrd731;
  machine_word Wrd730;
  machine_word Wrd737;
  machine_word Wrd736;
  machine_word Wrd724;
  machine_word Wrd721;
  machine_word Wrd720;
  machine_word Wrd709;
  machine_word Wrd717;
  machine_word Wrd716;
  machine_word Wrd715;
  machine_word Wrd719;
  machine_word Wrd718;
  machine_word Wrd708;
  machine_word Wrd704;
  machine_word Wrd695;
  machine_word Wrd694;
  machine_word Wrd691;
  machine_word Wrd701;
  machine_word Wrd700;
  machine_word Wrd699;
  machine_word Wrd697;
  machine_word Wrd696;
  machine_word Wrd703;
  machine_word Wrd702;
  machine_word Wrd690;
  machine_word Wrd687;
  machine_word Wrd686;
  machine_word Wrd675;
  machine_word Wrd683;
  machine_word Wrd682;
  machine_word Wrd681;
  machine_word Wrd685;
  machine_word Wrd684;
  machine_word Wrd674;
  machine_word Wrd671;
  machine_word Wrd670;
  machine_word Wrd661;
  machine_word Wrd667;
  machine_word Wrd666;
  machine_word Wrd665;
  machine_word Wrd669;
  machine_word Wrd668;
  machine_word Wrd658;
  machine_word Wrd656;
  machine_word Wrd657;
  machine_word Wrd654;
  machine_word Wrd655;
  machine_word Wrd653;
  machine_word Wrd639;
  machine_word Wrd642;
  machine_word Wrd640;
  machine_word Wrd647;
  machine_word Wrd646;
  machine_word Wrd645;
  machine_word Wrd644;
  machine_word Wrd643;
  machine_word Wrd648;
  machine_word Wrd638;
  machine_word Wrd637;
  machine_word Wrd634;
  machine_word Wrd633;
  machine_word Wrd622;
  machine_word Wrd630;
  machine_word Wrd629;
  machine_word Wrd628;
  machine_word Wrd632;
  machine_word Wrd631;
  machine_word Wrd621;
  machine_word Wrd620;
  machine_word Wrd619;
  machine_word Wrd618;
  machine_word Wrd617;
  machine_word Wrd616;
  machine_word Wrd615;
  machine_word Wrd614;
  machine_word Wrd612;
  machine_word Wrd611;
  machine_word Wrd607;
  machine_word Wrd594;
  machine_word Wrd598;
  machine_word Wrd595;
  machine_word Wrd604;
  machine_word Wrd603;
  machine_word Wrd602;
  machine_word Wrd600;
  machine_word Wrd599;
  machine_word Wrd606;
  machine_word Wrd605;
  machine_word Wrd593;
  machine_word Wrd590;
  machine_word Wrd589;
  machine_word Wrd578;
  machine_word Wrd586;
  machine_word Wrd585;
  machine_word Wrd584;
  machine_word Wrd588;
  machine_word Wrd587;
  machine_word Wrd577;
  machine_word Wrd576;
  machine_word Wrd575;
  machine_word Wrd574;
  machine_word Wrd573;
  machine_word Wrd572;
  machine_word Wrd568;
  machine_word Wrd555;
  machine_word Wrd559;
  machine_word Wrd556;
  machine_word Wrd565;
  machine_word Wrd564;
  machine_word Wrd563;
  machine_word Wrd561;
  machine_word Wrd560;
  machine_word Wrd567;
  machine_word Wrd566;
  machine_word Wrd554;
  machine_word Wrd551;
  machine_word Wrd550;
  machine_word Wrd539;
  machine_word Wrd547;
  machine_word Wrd546;
  machine_word Wrd545;
  machine_word Wrd549;
  machine_word Wrd548;
  machine_word Wrd538;
  machine_word Wrd534;
  machine_word Wrd525;
  machine_word Wrd524;
  machine_word Wrd521;
  machine_word Wrd531;
  machine_word Wrd530;
  machine_word Wrd529;
  machine_word Wrd527;
  machine_word Wrd526;
  machine_word Wrd533;
  machine_word Wrd532;
  machine_word Wrd520;
  machine_word Wrd517;
  machine_word Wrd516;
  machine_word Wrd505;
  machine_word Wrd513;
  machine_word Wrd512;
  machine_word Wrd511;
  machine_word Wrd515;
  machine_word Wrd514;
  machine_word Wrd504;
  machine_word Wrd501;
  machine_word Wrd500;
  machine_word Wrd491;
  machine_word Wrd497;
  machine_word Wrd496;
  machine_word Wrd495;
  machine_word Wrd499;
  machine_word Wrd498;
  machine_word Wrd172;
  machine_word Wrd170;
  machine_word Wrd171;
  machine_word Wrd169;
  machine_word Wrd155;
  machine_word Wrd158;
  machine_word Wrd156;
  machine_word Wrd163;
  machine_word Wrd162;
  machine_word Wrd161;
  machine_word Wrd160;
  machine_word Wrd159;
  machine_word Wrd164;
  machine_word Wrd154;
  machine_word Wrd153;
  machine_word Wrd150;
  machine_word Wrd149;
  machine_word Wrd138;
  machine_word Wrd146;
  machine_word Wrd145;
  machine_word Wrd144;
  machine_word Wrd148;
  machine_word Wrd147;
  machine_word Wrd137;
  machine_word Wrd136;
  machine_word Wrd135;
  machine_word Wrd134;
  machine_word Wrd133;
  machine_word Wrd132;
  machine_word Wrd131;
  machine_word Wrd130;
  machine_word Wrd128;
  machine_word Wrd127;
  machine_word Wrd123;
  machine_word Wrd110;
  machine_word Wrd114;
  machine_word Wrd111;
  machine_word Wrd120;
  machine_word Wrd119;
  machine_word Wrd118;
  machine_word Wrd116;
  machine_word Wrd115;
  machine_word Wrd122;
  machine_word Wrd121;
  machine_word Wrd109;
  machine_word Wrd106;
  machine_word Wrd105;
  machine_word Wrd94;
  machine_word Wrd102;
  machine_word Wrd101;
  machine_word Wrd100;
  machine_word Wrd104;
  machine_word Wrd103;
  machine_word Wrd93;
  machine_word Wrd92;
  machine_word Wrd91;
  machine_word Wrd90;
  machine_word Wrd89;
  machine_word Wrd88;
  machine_word Wrd84;
  machine_word Wrd71;
  machine_word Wrd75;
  machine_word Wrd72;
  machine_word Wrd81;
  machine_word Wrd80;
  machine_word Wrd79;
  machine_word Wrd77;
  machine_word Wrd76;
  machine_word Wrd83;
  machine_word Wrd82;
  machine_word Wrd70;
  machine_word Wrd67;
  machine_word Wrd66;
  machine_word Wrd55;
  machine_word Wrd63;
  machine_word Wrd62;
  machine_word Wrd61;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd54;
  machine_word Wrd50;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd37;
  machine_word Wrd47;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd43;
  machine_word Wrd42;
  machine_word Wrd49;
  machine_word Wrd48;
  machine_word Wrd36;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd21;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd27;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd7;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_33_4);
      goto probe_cache_3_133;

    case 1:
      current_block = (Rpc - LABEL_33_5);
      goto label_135;

    case 2:
      current_block = (Rpc - LABEL_33_6);
      goto label_136;

    case 3:
      current_block = (Rpc - LABEL_33_7);
      goto label_137;

    case 4:
      current_block = (Rpc - LABEL_33_8);
      goto label_138;

    case 5:
      current_block = (Rpc - LABEL_33_9);
      goto label_139;

    case 6:
      current_block = (Rpc - LABEL_33_10);
      goto label_140;

    case 7:
      current_block = (Rpc - LABEL_33_11);
      goto label_141;

    case 8:
      current_block = (Rpc - LABEL_33_12);
      goto label_142;

    case 9:
      current_block = (Rpc - LABEL_33_13);
      goto label_143;

    case 10:
      current_block = (Rpc - LABEL_33_14);
      goto label_161;

    case 11:
      current_block = (Rpc - LABEL_33_15);
      goto label_162;

    case 12:
      current_block = (Rpc - LABEL_33_16);
      goto label_163;

    case 13:
      current_block = (Rpc - LABEL_33_17);
      goto label_164;

    case 14:
      current_block = (Rpc - LABEL_33_18);
      goto label_165;

    case 15:
      current_block = (Rpc - LABEL_33_19);
      goto label_166;

    case 16:
      current_block = (Rpc - LABEL_33_20);
      goto label_167;

    case 17:
      current_block = (Rpc - LABEL_33_21);
      goto label_168;

    case 18:
      current_block = (Rpc - LABEL_33_22);
      goto label_169;

    case 19:
      current_block = (Rpc - LABEL_33_23);
      goto label_170;

    case 20:
      current_block = (Rpc - LABEL_33_24);
      goto label_171;

    case 21:
      current_block = (Rpc - LABEL_33_25);
      goto label_172;

    case 22:
      current_block = (Rpc - LABEL_33_26);
      goto label_173;

    case 23:
      current_block = (Rpc - LABEL_33_27);
      goto label_174;

    case 24:
      current_block = (Rpc - LABEL_33_28);
      goto label_175;

    case 25:
      current_block = (Rpc - LABEL_33_29);
      goto label_176;

    case 26:
      current_block = (Rpc - LABEL_33_30);
      goto label_177;

    case 27:
      current_block = (Rpc - LABEL_33_31);
      goto label_178;

    case 28:
      current_block = (Rpc - LABEL_33_32);
      goto label_179;

    case 29:
      current_block = (Rpc - LABEL_33_33);
      goto label_180;

    case 30:
      current_block = (Rpc - LABEL_33_34);
      goto label_181;

    case 31:
      current_block = (Rpc - LABEL_33_35);
      goto label_182;

    case 32:
      current_block = (Rpc - LABEL_33_36);
      goto label_183;

    case 33:
      current_block = (Rpc - LABEL_33_37);
      goto label_184;

    case 34:
      current_block = (Rpc - LABEL_33_38);
      goto label_185;

    case 35:
      current_block = (Rpc - LABEL_33_39);
      goto label_186;

    case 36:
      current_block = (Rpc - LABEL_33_40);
      goto label_144;

    case 37:
      current_block = (Rpc - LABEL_33_41);
      goto label_145;

    case 38:
      current_block = (Rpc - LABEL_33_42);
      goto label_146;

    case 39:
      current_block = (Rpc - LABEL_33_43);
      goto label_147;

    case 40:
      current_block = (Rpc - LABEL_33_44);
      goto label_148;

    case 41:
      current_block = (Rpc - LABEL_33_45);
      goto label_149;

    case 42:
      current_block = (Rpc - LABEL_33_46);
      goto label_150;

    case 43:
      current_block = (Rpc - LABEL_33_47);
      goto label_151;

    case 44:
      current_block = (Rpc - LABEL_33_48);
      goto label_152;

    case 45:
      current_block = (Rpc - LABEL_33_49);
      goto label_153;

    case 46:
      current_block = (Rpc - LABEL_33_50);
      goto label_154;

    case 47:
      current_block = (Rpc - LABEL_33_51);
      goto label_155;

    case 48:
      current_block = (Rpc - LABEL_33_52);
      goto label_156;

    case 49:
      current_block = (Rpc - LABEL_33_53);
      goto label_157;

    case 50:
      current_block = (Rpc - LABEL_33_54);
      goto label_158;

    case 51:
      current_block = (Rpc - LABEL_33_55);
      goto label_159;

    case 52:
      current_block = (Rpc - LABEL_33_56);
      goto label_160;

    case 53:
      current_block = (Rpc - LABEL_33_57);
      goto search_lines_119;

    case 54:
      current_block = (Rpc - LABEL_33_58);
      goto label_198;

    case 55:
      current_block = (Rpc - LABEL_33_59);
      goto label_187;

    case 56:
      current_block = (Rpc - LABEL_33_60);
      goto label_197;

    case 57:
      current_block = (Rpc - LABEL_33_61);
      goto label_190;

    case 58:
      current_block = (Rpc - LABEL_33_62);
      goto label_191;

    case 59:
      current_block = (Rpc - LABEL_33_63);
      goto label_192;

    case 60:
      current_block = (Rpc - LABEL_33_64);
      goto label_193;

    case 61:
      current_block = (Rpc - LABEL_33_65);
      goto label_194;

    case 62:
      current_block = (Rpc - LABEL_33_66);
      goto label_195;

    case 63:
      current_block = (Rpc - LABEL_33_67);
      goto label_196;

    case 64:
      current_block = (Rpc - LABEL_33_68);
      goto label_188;

    case 65:
      current_block = (Rpc - LABEL_33_69);
      goto label_189;

    case 66:
      current_block = (Rpc - LABEL_33_70);
      goto search_overflow_117;

    case 67:
      current_block = (Rpc - LABEL_33_71);
      goto label_199;

    case 68:
      current_block = (Rpc - LABEL_33_72);
      goto label_200;

    case 69:
      current_block = (Rpc - LABEL_33_73);
      goto label_202;

    case 70:
      current_block = (Rpc - LABEL_33_74);
      goto label_203;

    case 71:
      current_block = (Rpc - LABEL_33_75);
      goto label_204;

    case 72:
      current_block = (Rpc - LABEL_33_76);
      goto label_205;

    case 73:
      current_block = (Rpc - LABEL_33_77);
      goto label_206;

    case 74:
      current_block = (Rpc - LABEL_33_78);
      goto label_201;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (probe_cache_3_208)
DEFLABEL (probe_cache_3_133)
  INTERRUPT_CHECK (26, LABEL_33_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_320;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd13.Lng))))
    goto label_320;
  (Wrd7.Obj) = ((Wrd11.pObj) [3]);
  (* (--Rsp)) = (Wrd7.Obj);

DEFLABEL (label_319)
  (Wrd30.Obj) = (Rsp [1]);
  (Wrd31.uLng) = (OBJECT_TYPE (Wrd30.Obj));
  if (! ((Wrd31.uLng) == 62))
    goto label_318;
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd30.Obj));
  (Wrd28.Obj) = ((Wrd27.pObj) [0]);
  (Wrd29.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd29.Lng))))
    goto label_318;
  (Wrd21.Obj) = ((Wrd27.pObj) [2]);

DEFLABEL (label_317)
  (Wrd48.Obj) = (Rsp [4]);
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd48.Obj));
  if (! ((Wrd49.uLng) == 62))
    goto label_316;
  (Wrd42.uLng) = (OBJECT_TYPE (Wrd21.Obj));
  if (! ((Wrd42.uLng) == 26))
    goto label_316;
  (Wrd43.Lng) = (FIXNUM_TO_LONG (Wrd21.Obj));
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd48.Obj));
  (Wrd46.Obj) = ((Wrd45.pObj) [0]);
  (Wrd47.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  if (! (((unsigned long) (Wrd43.Lng)) < ((unsigned long) (Wrd47.Lng))))
    goto label_316;
  (Wrd37.uLng) = (OBJECT_DATUM (Wrd21.Obj));
  (Wrd40.pObj) = (& ((Wrd45.pObj) [(Wrd37.Lng)]));
  (Wrd41.Obj) = ((Wrd40.pObj) [1]);
  (* (--Rsp)) = (Wrd41.Obj);

DEFLABEL (label_315)
  (Wrd64.Obj) = (Rsp [2]);
  (Wrd65.uLng) = (OBJECT_TYPE (Wrd64.Obj));
  if (! ((Wrd65.uLng) == 62))
    goto label_314;
  (Wrd61.pObj) = (OBJECT_ADDRESS (Wrd64.Obj));
  (Wrd62.Obj) = ((Wrd61.pObj) [0]);
  (Wrd63.Lng) = (FIXNUM_TO_LONG (Wrd62.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd63.Lng))))
    goto label_314;
  (Wrd55.Obj) = ((Wrd61.pObj) [2]);

DEFLABEL (label_313)
  (Wrd82.Obj) = (Rsp [4]);
  (Wrd83.uLng) = (OBJECT_TYPE (Wrd82.Obj));
  if (! ((Wrd83.uLng) == 62))
    goto label_312;
  (Wrd76.uLng) = (OBJECT_TYPE (Wrd55.Obj));
  if (! ((Wrd76.uLng) == 26))
    goto label_312;
  (Wrd77.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd79.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd80.Obj) = ((Wrd79.pObj) [0]);
  (Wrd81.Lng) = (FIXNUM_TO_LONG (Wrd80.Obj));
  if (! (((unsigned long) (Wrd77.Lng)) < ((unsigned long) (Wrd81.Lng))))
    goto label_312;
  (Wrd72.uLng) = (OBJECT_DATUM (Wrd55.Obj));
  (Wrd75.pObj) = (& ((Wrd79.pObj) [(Wrd72.Lng)]));
  (Wrd71.Obj) = ((Wrd75.pObj) [1]);

DEFLABEL (label_311)
  (Wrd89.Obj) = (* (Rsp++));
  (Wrd90.Lng) = (FIXNUM_TO_LONG (Wrd71.Obj));
  (Wrd91.Lng) = (FIXNUM_TO_LONG (Wrd89.Obj));
  (Wrd92.Lng) = ((Wrd90.Lng) + (Wrd91.Lng));
  (Wrd93.Obj) = (LONG_TO_FIXNUM (Wrd92.Lng));
  (* (--Rsp)) = (Wrd93.Obj);
  (Wrd103.Obj) = (Rsp [2]);
  (Wrd104.uLng) = (OBJECT_TYPE (Wrd103.Obj));
  if (! ((Wrd104.uLng) == 62))
    goto label_310;
  (Wrd100.pObj) = (OBJECT_ADDRESS (Wrd103.Obj));
  (Wrd101.Obj) = ((Wrd100.pObj) [0]);
  (Wrd102.Lng) = (FIXNUM_TO_LONG (Wrd101.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd102.Lng))))
    goto label_310;
  (Wrd94.Obj) = ((Wrd100.pObj) [2]);

DEFLABEL (label_309)
  (Wrd121.Obj) = (Rsp [3]);
  (Wrd122.uLng) = (OBJECT_TYPE (Wrd121.Obj));
  if (! ((Wrd122.uLng) == 62))
    goto label_308;
  (Wrd115.uLng) = (OBJECT_TYPE (Wrd94.Obj));
  if (! ((Wrd115.uLng) == 26))
    goto label_308;
  (Wrd116.Lng) = (FIXNUM_TO_LONG (Wrd94.Obj));
  (Wrd118.pObj) = (OBJECT_ADDRESS (Wrd121.Obj));
  (Wrd119.Obj) = ((Wrd118.pObj) [0]);
  (Wrd120.Lng) = (FIXNUM_TO_LONG (Wrd119.Obj));
  if (! (((unsigned long) (Wrd116.Lng)) < ((unsigned long) (Wrd120.Lng))))
    goto label_308;
  (Wrd111.uLng) = (OBJECT_DATUM (Wrd94.Obj));
  (Wrd114.pObj) = (& ((Wrd118.pObj) [(Wrd111.Lng)]));
  (Wrd110.Obj) = ((Wrd114.pObj) [1]);

DEFLABEL (label_307)
  (Wrd128.Obj) = (* (Rsp++));
  (Wrd130.Lng) = (FIXNUM_TO_LONG (Wrd110.Obj));
  (Wrd131.Lng) = (FIXNUM_TO_LONG (Wrd128.Obj));
  (Wrd132.Lng) = ((Wrd130.Lng) + (Wrd131.Lng));
  (Wrd133.Obj) = (* (Rsp++));
  Wrd134 = Wrd132;
  (Wrd135.Lng) = (FIXNUM_TO_LONG (Wrd133.Obj));
  (Wrd136.Lng) = ((Wrd134.Lng) & (Wrd135.Lng));
  (Wrd137.Obj) = (LONG_TO_FIXNUM (Wrd136.Lng));
  (* (--Rsp)) = (Wrd137.Obj);
  (Wrd147.Obj) = (Rsp [1]);
  (Wrd148.uLng) = (OBJECT_TYPE (Wrd147.Obj));
  if (! ((Wrd148.uLng) == 62))
    goto label_306;
  (Wrd144.pObj) = (OBJECT_ADDRESS (Wrd147.Obj));
  (Wrd145.Obj) = ((Wrd144.pObj) [0]);
  (Wrd146.Lng) = (FIXNUM_TO_LONG (Wrd145.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd146.Lng))))
    goto label_306;
  (Wrd138.Obj) = ((Wrd144.pObj) [6]);

DEFLABEL (label_305)
  (Wrd154.Obj) = (* (Rsp++));
  (Wrd164.uLng) = (OBJECT_TYPE (Wrd138.Obj));
  if (! ((Wrd164.uLng) == 10))
    goto label_304;
  (Wrd159.uLng) = (OBJECT_TYPE (Wrd154.Obj));
  if (! ((Wrd159.uLng) == 26))
    goto label_304;
  (Wrd160.Lng) = (FIXNUM_TO_LONG (Wrd154.Obj));
  (Wrd161.pObj) = (OBJECT_ADDRESS (Wrd138.Obj));
  (Wrd162.Obj) = ((Wrd161.pObj) [0]);
  (Wrd163.Lng) = (FIXNUM_TO_LONG (Wrd162.Obj));
  if (! (((unsigned long) (Wrd160.Lng)) < ((unsigned long) (Wrd163.Lng))))
    goto label_304;
  (Wrd156.uLng) = (OBJECT_DATUM (Wrd154.Obj));
  (Wrd158.pObj) = (& ((Wrd161.pObj) [(Wrd156.Lng)]));
  (Wrd155.Obj) = ((Wrd158.pObj) [1]);

DEFLABEL (label_303)
  (Wrd171.pObj) = (OBJECT_ADDRESS (Wrd155.Obj));
  (Wrd170.Obj) = ((Wrd171.pObj) [0]);
  (Wrd172.Obj) = (Rsp [1]);
  if ((Wrd172.Obj) == (Wrd170.Obj))
    goto label_248;

DEFLABEL (label_247)
  (Wrd182.Obj) = (Rsp [0]);
  (Wrd183.uLng) = (OBJECT_TYPE (Wrd182.Obj));
  if (! ((Wrd183.uLng) == 62))
    goto label_246;
  (Wrd179.pObj) = (OBJECT_ADDRESS (Wrd182.Obj));
  (Wrd180.Obj) = ((Wrd179.pObj) [0]);
  (Wrd181.Lng) = (FIXNUM_TO_LONG (Wrd180.Obj));
  if (! (((unsigned long) 3L) < ((unsigned long) (Wrd181.Lng))))
    goto label_246;
  (Wrd175.Obj) = ((Wrd179.pObj) [4]);
  (* (--Rsp)) = (Wrd175.Obj);

DEFLABEL (label_245)
  (Wrd189.Obj) = (current_block [OBJECT_33_7]);
  (* (--Rsp)) = (Wrd189.Obj);
  (Wrd199.Obj) = (Rsp [2]);
  (Wrd200.uLng) = (OBJECT_TYPE (Wrd199.Obj));
  if (! ((Wrd200.uLng) == 62))
    goto label_244;
  (Wrd196.pObj) = (OBJECT_ADDRESS (Wrd199.Obj));
  (Wrd197.Obj) = ((Wrd196.pObj) [0]);
  (Wrd198.Lng) = (FIXNUM_TO_LONG (Wrd197.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd198.Lng))))
    goto label_244;
  (Wrd190.Obj) = ((Wrd196.pObj) [6]);

DEFLABEL (label_243)
  (Wrd210.uLng) = (OBJECT_TYPE (Wrd190.Obj));
  if (! ((Wrd210.uLng) == 10))
    goto label_242;
  (Wrd207.pObj) = (OBJECT_ADDRESS (Wrd190.Obj));
  (Wrd208.Obj) = ((Wrd207.pObj) [0]);
  (Wrd209.Obj) = (MAKE_OBJECT (26, (Wrd208.uLng)));
  (* (--Rsp)) = (Wrd209.Obj);

DEFLABEL (label_241)
  (Wrd224.Obj) = (Rsp [3]);
  (Wrd225.uLng) = (OBJECT_TYPE (Wrd224.Obj));
  if (! ((Wrd225.uLng) == 62))
    goto label_240;
  (Wrd221.pObj) = (OBJECT_ADDRESS (Wrd224.Obj));
  (Wrd222.Obj) = ((Wrd221.pObj) [0]);
  (Wrd223.Lng) = (FIXNUM_TO_LONG (Wrd222.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd223.Lng))))
    goto label_240;
  (Wrd217.Obj) = ((Wrd221.pObj) [3]);
  (* (--Rsp)) = (Wrd217.Obj);

DEFLABEL (label_239)
  (Wrd240.Obj) = (Rsp [4]);
  (Wrd241.uLng) = (OBJECT_TYPE (Wrd240.Obj));
  if (! ((Wrd241.uLng) == 62))
    goto label_238;
  (Wrd237.pObj) = (OBJECT_ADDRESS (Wrd240.Obj));
  (Wrd238.Obj) = ((Wrd237.pObj) [0]);
  (Wrd239.Lng) = (FIXNUM_TO_LONG (Wrd238.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd239.Lng))))
    goto label_238;
  (Wrd231.Obj) = ((Wrd237.pObj) [2]);

DEFLABEL (label_237)
  (Wrd258.Obj) = (Rsp [7]);
  (Wrd259.uLng) = (OBJECT_TYPE (Wrd258.Obj));
  if (! ((Wrd259.uLng) == 62))
    goto label_236;
  (Wrd252.uLng) = (OBJECT_TYPE (Wrd231.Obj));
  if (! ((Wrd252.uLng) == 26))
    goto label_236;
  (Wrd253.Lng) = (FIXNUM_TO_LONG (Wrd231.Obj));
  (Wrd255.pObj) = (OBJECT_ADDRESS (Wrd258.Obj));
  (Wrd256.Obj) = ((Wrd255.pObj) [0]);
  (Wrd257.Lng) = (FIXNUM_TO_LONG (Wrd256.Obj));
  if (! (((unsigned long) (Wrd253.Lng)) < ((unsigned long) (Wrd257.Lng))))
    goto label_236;
  (Wrd247.uLng) = (OBJECT_DATUM (Wrd231.Obj));
  (Wrd250.pObj) = (& ((Wrd255.pObj) [(Wrd247.Lng)]));
  (Wrd251.Obj) = ((Wrd250.pObj) [1]);
  (* (--Rsp)) = (Wrd251.Obj);

DEFLABEL (label_235)
  (Wrd274.Obj) = (Rsp [5]);
  (Wrd275.uLng) = (OBJECT_TYPE (Wrd274.Obj));
  if (! ((Wrd275.uLng) == 62))
    goto label_234;
  (Wrd271.pObj) = (OBJECT_ADDRESS (Wrd274.Obj));
  (Wrd272.Obj) = ((Wrd271.pObj) [0]);
  (Wrd273.Lng) = (FIXNUM_TO_LONG (Wrd272.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd273.Lng))))
    goto label_234;
  (Wrd265.Obj) = ((Wrd271.pObj) [2]);

DEFLABEL (label_233)
  (Wrd292.Obj) = (Rsp [7]);
  (Wrd293.uLng) = (OBJECT_TYPE (Wrd292.Obj));
  if (! ((Wrd293.uLng) == 62))
    goto label_232;
  (Wrd286.uLng) = (OBJECT_TYPE (Wrd265.Obj));
  if (! ((Wrd286.uLng) == 26))
    goto label_232;
  (Wrd287.Lng) = (FIXNUM_TO_LONG (Wrd265.Obj));
  (Wrd289.pObj) = (OBJECT_ADDRESS (Wrd292.Obj));
  (Wrd290.Obj) = ((Wrd289.pObj) [0]);
  (Wrd291.Lng) = (FIXNUM_TO_LONG (Wrd290.Obj));
  if (! (((unsigned long) (Wrd287.Lng)) < ((unsigned long) (Wrd291.Lng))))
    goto label_232;
  (Wrd282.uLng) = (OBJECT_DATUM (Wrd265.Obj));
  (Wrd285.pObj) = (& ((Wrd289.pObj) [(Wrd282.Lng)]));
  (Wrd281.Obj) = ((Wrd285.pObj) [1]);

DEFLABEL (label_231)
  (Wrd299.Obj) = (* (Rsp++));
  (Wrd300.Lng) = (FIXNUM_TO_LONG (Wrd281.Obj));
  (Wrd301.Lng) = (FIXNUM_TO_LONG (Wrd299.Obj));
  (Wrd302.Lng) = ((Wrd300.Lng) + (Wrd301.Lng));
  (Wrd303.Obj) = (LONG_TO_FIXNUM (Wrd302.Lng));
  (* (--Rsp)) = (Wrd303.Obj);
  (Wrd313.Obj) = (Rsp [5]);
  (Wrd314.uLng) = (OBJECT_TYPE (Wrd313.Obj));
  if (! ((Wrd314.uLng) == 62))
    goto label_230;
  (Wrd310.pObj) = (OBJECT_ADDRESS (Wrd313.Obj));
  (Wrd311.Obj) = ((Wrd310.pObj) [0]);
  (Wrd312.Lng) = (FIXNUM_TO_LONG (Wrd311.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd312.Lng))))
    goto label_230;
  (Wrd304.Obj) = ((Wrd310.pObj) [2]);

DEFLABEL (label_229)
  (Wrd331.Obj) = (Rsp [6]);
  (Wrd332.uLng) = (OBJECT_TYPE (Wrd331.Obj));
  if (! ((Wrd332.uLng) == 62))
    goto label_228;
  (Wrd325.uLng) = (OBJECT_TYPE (Wrd304.Obj));
  if (! ((Wrd325.uLng) == 26))
    goto label_228;
  (Wrd326.Lng) = (FIXNUM_TO_LONG (Wrd304.Obj));
  (Wrd328.pObj) = (OBJECT_ADDRESS (Wrd331.Obj));
  (Wrd329.Obj) = ((Wrd328.pObj) [0]);
  (Wrd330.Lng) = (FIXNUM_TO_LONG (Wrd329.Obj));
  if (! (((unsigned long) (Wrd326.Lng)) < ((unsigned long) (Wrd330.Lng))))
    goto label_228;
  (Wrd321.uLng) = (OBJECT_DATUM (Wrd304.Obj));
  (Wrd324.pObj) = (& ((Wrd328.pObj) [(Wrd321.Lng)]));
  (Wrd320.Obj) = ((Wrd324.pObj) [1]);

DEFLABEL (label_227)
  (Wrd338.Obj) = (* (Rsp++));
  (Wrd340.Lng) = (FIXNUM_TO_LONG (Wrd320.Obj));
  (Wrd341.Lng) = (FIXNUM_TO_LONG (Wrd338.Obj));
  (Wrd342.Lng) = ((Wrd340.Lng) + (Wrd341.Lng));
  (Wrd343.Obj) = (* (Rsp++));
  Wrd345 = Wrd342;
  (Wrd346.Lng) = (FIXNUM_TO_LONG (Wrd343.Obj));
  (Wrd349.Lng) = ((Wrd345.Lng) & (Wrd346.Lng));
  (Wrd350.Lng) = ((Wrd349.Lng) + 1L);
  (Wrd348.Obj) = (LONG_TO_FIXNUM (Wrd350.Lng));
  (Wrd351.Obj) = (* (Rsp++));
  if ((Wrd348.Obj) == (Wrd351.Obj))
    goto label_226;
  (Wrd361.Obj) = (Rsp [2]);
  (Wrd362.uLng) = (OBJECT_TYPE (Wrd361.Obj));
  if (! ((Wrd362.uLng) == 62))
    goto label_225;
  (Wrd358.pObj) = (OBJECT_ADDRESS (Wrd361.Obj));
  (Wrd359.Obj) = ((Wrd358.pObj) [0]);
  (Wrd360.Lng) = (FIXNUM_TO_LONG (Wrd359.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd360.Lng))))
    goto label_225;
  (Wrd354.Obj) = ((Wrd358.pObj) [3]);
  (* (--Rsp)) = (Wrd354.Obj);

DEFLABEL (label_224)
  (Wrd377.Obj) = (Rsp [3]);
  (Wrd378.uLng) = (OBJECT_TYPE (Wrd377.Obj));
  if (! ((Wrd378.uLng) == 62))
    goto label_223;
  (Wrd374.pObj) = (OBJECT_ADDRESS (Wrd377.Obj));
  (Wrd375.Obj) = ((Wrd374.pObj) [0]);
  (Wrd376.Lng) = (FIXNUM_TO_LONG (Wrd375.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd376.Lng))))
    goto label_223;
  (Wrd368.Obj) = ((Wrd374.pObj) [2]);

DEFLABEL (label_222)
  (Wrd395.Obj) = (Rsp [6]);
  (Wrd396.uLng) = (OBJECT_TYPE (Wrd395.Obj));
  if (! ((Wrd396.uLng) == 62))
    goto label_221;
  (Wrd389.uLng) = (OBJECT_TYPE (Wrd368.Obj));
  if (! ((Wrd389.uLng) == 26))
    goto label_221;
  (Wrd390.Lng) = (FIXNUM_TO_LONG (Wrd368.Obj));
  (Wrd392.pObj) = (OBJECT_ADDRESS (Wrd395.Obj));
  (Wrd393.Obj) = ((Wrd392.pObj) [0]);
  (Wrd394.Lng) = (FIXNUM_TO_LONG (Wrd393.Obj));
  if (! (((unsigned long) (Wrd390.Lng)) < ((unsigned long) (Wrd394.Lng))))
    goto label_221;
  (Wrd384.uLng) = (OBJECT_DATUM (Wrd368.Obj));
  (Wrd387.pObj) = (& ((Wrd392.pObj) [(Wrd384.Lng)]));
  (Wrd388.Obj) = ((Wrd387.pObj) [1]);
  (* (--Rsp)) = (Wrd388.Obj);

DEFLABEL (label_220)
  (Wrd411.Obj) = (Rsp [4]);
  (Wrd412.uLng) = (OBJECT_TYPE (Wrd411.Obj));
  if (! ((Wrd412.uLng) == 62))
    goto label_219;
  (Wrd408.pObj) = (OBJECT_ADDRESS (Wrd411.Obj));
  (Wrd409.Obj) = ((Wrd408.pObj) [0]);
  (Wrd410.Lng) = (FIXNUM_TO_LONG (Wrd409.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd410.Lng))))
    goto label_219;
  (Wrd402.Obj) = ((Wrd408.pObj) [2]);

DEFLABEL (label_218)
  (Wrd429.Obj) = (Rsp [6]);
  (Wrd430.uLng) = (OBJECT_TYPE (Wrd429.Obj));
  if (! ((Wrd430.uLng) == 62))
    goto label_217;
  (Wrd423.uLng) = (OBJECT_TYPE (Wrd402.Obj));
  if (! ((Wrd423.uLng) == 26))
    goto label_217;
  (Wrd424.Lng) = (FIXNUM_TO_LONG (Wrd402.Obj));
  (Wrd426.pObj) = (OBJECT_ADDRESS (Wrd429.Obj));
  (Wrd427.Obj) = ((Wrd426.pObj) [0]);
  (Wrd428.Lng) = (FIXNUM_TO_LONG (Wrd427.Obj));
  if (! (((unsigned long) (Wrd424.Lng)) < ((unsigned long) (Wrd428.Lng))))
    goto label_217;
  (Wrd419.uLng) = (OBJECT_DATUM (Wrd402.Obj));
  (Wrd422.pObj) = (& ((Wrd426.pObj) [(Wrd419.Lng)]));
  (Wrd418.Obj) = ((Wrd422.pObj) [1]);

DEFLABEL (label_216)
  (Wrd436.Obj) = (* (Rsp++));
  (Wrd437.Lng) = (FIXNUM_TO_LONG (Wrd418.Obj));
  (Wrd438.Lng) = (FIXNUM_TO_LONG (Wrd436.Obj));
  (Wrd439.Lng) = ((Wrd437.Lng) + (Wrd438.Lng));
  (Wrd440.Obj) = (LONG_TO_FIXNUM (Wrd439.Lng));
  (* (--Rsp)) = (Wrd440.Obj);
  (Wrd450.Obj) = (Rsp [4]);
  (Wrd451.uLng) = (OBJECT_TYPE (Wrd450.Obj));
  if (! ((Wrd451.uLng) == 62))
    goto label_215;
  (Wrd447.pObj) = (OBJECT_ADDRESS (Wrd450.Obj));
  (Wrd448.Obj) = ((Wrd447.pObj) [0]);
  (Wrd449.Lng) = (FIXNUM_TO_LONG (Wrd448.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd449.Lng))))
    goto label_215;
  (Wrd441.Obj) = ((Wrd447.pObj) [2]);

DEFLABEL (label_214)
  (Wrd468.Obj) = (Rsp [5]);
  (Wrd469.uLng) = (OBJECT_TYPE (Wrd468.Obj));
  if (! ((Wrd469.uLng) == 62))
    goto label_213;
  (Wrd462.uLng) = (OBJECT_TYPE (Wrd441.Obj));
  if (! ((Wrd462.uLng) == 26))
    goto label_213;
  (Wrd463.Lng) = (FIXNUM_TO_LONG (Wrd441.Obj));
  (Wrd465.pObj) = (OBJECT_ADDRESS (Wrd468.Obj));
  (Wrd466.Obj) = ((Wrd465.pObj) [0]);
  (Wrd467.Lng) = (FIXNUM_TO_LONG (Wrd466.Obj));
  if (! (((unsigned long) (Wrd463.Lng)) < ((unsigned long) (Wrd467.Lng))))
    goto label_213;
  (Wrd458.uLng) = (OBJECT_DATUM (Wrd441.Obj));
  (Wrd461.pObj) = (& ((Wrd465.pObj) [(Wrd458.Lng)]));
  (Wrd457.Obj) = ((Wrd461.pObj) [1]);

DEFLABEL (label_212)
  (Wrd475.Obj) = (* (Rsp++));
  (Wrd477.Lng) = (FIXNUM_TO_LONG (Wrd457.Obj));
  (Wrd478.Lng) = (FIXNUM_TO_LONG (Wrd475.Obj));
  (Wrd479.Lng) = ((Wrd477.Lng) + (Wrd478.Lng));
  (Wrd480.Obj) = (* (Rsp++));
  Wrd482 = Wrd479;
  (Wrd483.Lng) = (FIXNUM_TO_LONG (Wrd480.Obj));
  (Wrd485.Lng) = ((Wrd482.Lng) & (Wrd483.Lng));
  (Wrd486.Lng) = ((Wrd485.Lng) + 1L);
  (Wrd487.Obj) = (LONG_TO_FIXNUM (Wrd486.Lng));
  (* (--Rsp)) = (Wrd487.Obj);

DEFLABEL (label_211)
  goto search_lines_119;

DEFLABEL (label_213)
  (Wrd470.Obj) = (Rsp [5]);
  (Wrd474.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_56]))));
  (* (--Rsp)) = (Wrd474.Obj);
  (* (--Rsp)) = (Wrd441.Obj);
  (* (--Rsp)) = (Wrd470.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_160)
  (Wrd457.Obj) = Rvl;
  goto label_212;

DEFLABEL (label_215)
  (Wrd452.Obj) = (Rsp [4]);
  (Wrd453.Obj) = (current_block [OBJECT_33_2]);
  (Wrd456.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_55]))));
  (* (--Rsp)) = (Wrd456.Obj);
  (* (--Rsp)) = (Wrd453.Obj);
  (* (--Rsp)) = (Wrd452.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_159)
  (Wrd441.Obj) = Rvl;
  goto label_214;

DEFLABEL (label_217)
  (Wrd431.Obj) = (Rsp [6]);
  (Wrd435.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_54]))));
  (* (--Rsp)) = (Wrd435.Obj);
  (* (--Rsp)) = (Wrd402.Obj);
  (* (--Rsp)) = (Wrd431.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_158)
  (Wrd418.Obj) = Rvl;
  goto label_216;

DEFLABEL (label_219)
  (Wrd413.Obj) = (Rsp [4]);
  (Wrd414.Obj) = (current_block [OBJECT_33_2]);
  (Wrd417.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_53]))));
  (* (--Rsp)) = (Wrd417.Obj);
  (* (--Rsp)) = (Wrd414.Obj);
  (* (--Rsp)) = (Wrd413.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_157)
  (Wrd402.Obj) = Rvl;
  goto label_218;

DEFLABEL (label_221)
  (Wrd397.Obj) = (Rsp [6]);
  (Wrd401.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_52]))));
  (* (--Rsp)) = (Wrd401.Obj);
  (* (--Rsp)) = (Wrd368.Obj);
  (* (--Rsp)) = (Wrd397.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_156)
  (* (--Rsp)) = Rvl;
  goto label_220;

DEFLABEL (label_223)
  (Wrd379.Obj) = (Rsp [3]);
  (Wrd380.Obj) = (current_block [OBJECT_33_2]);
  (Wrd383.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_51]))));
  (* (--Rsp)) = (Wrd383.Obj);
  (* (--Rsp)) = (Wrd380.Obj);
  (* (--Rsp)) = (Wrd379.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_155)
  (Wrd368.Obj) = Rvl;
  goto label_222;

DEFLABEL (label_225)
  (Wrd363.Obj) = (Rsp [2]);
  (Wrd364.Obj) = (current_block [OBJECT_33_0]);
  (Wrd367.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_50]))));
  (* (--Rsp)) = (Wrd367.Obj);
  (* (--Rsp)) = (Wrd364.Obj);
  (* (--Rsp)) = (Wrd363.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_154)
  (* (--Rsp)) = Rvl;
  goto label_224;

DEFLABEL (label_226)
  (Wrd488.Obj) = (current_block [OBJECT_33_7]);
  (* (--Rsp)) = (Wrd488.Obj);
  goto label_211;

DEFLABEL (label_228)
  (Wrd333.Obj) = (Rsp [6]);
  (Wrd337.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_49]))));
  (* (--Rsp)) = (Wrd337.Obj);
  (* (--Rsp)) = (Wrd304.Obj);
  (* (--Rsp)) = (Wrd333.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_153)
  (Wrd320.Obj) = Rvl;
  goto label_227;

DEFLABEL (label_230)
  (Wrd315.Obj) = (Rsp [5]);
  (Wrd316.Obj) = (current_block [OBJECT_33_2]);
  (Wrd319.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_48]))));
  (* (--Rsp)) = (Wrd319.Obj);
  (* (--Rsp)) = (Wrd316.Obj);
  (* (--Rsp)) = (Wrd315.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_152)
  (Wrd304.Obj) = Rvl;
  goto label_229;

DEFLABEL (label_232)
  (Wrd294.Obj) = (Rsp [7]);
  (Wrd298.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_47]))));
  (* (--Rsp)) = (Wrd298.Obj);
  (* (--Rsp)) = (Wrd265.Obj);
  (* (--Rsp)) = (Wrd294.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_151)
  (Wrd281.Obj) = Rvl;
  goto label_231;

DEFLABEL (label_234)
  (Wrd276.Obj) = (Rsp [5]);
  (Wrd277.Obj) = (current_block [OBJECT_33_2]);
  (Wrd280.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_46]))));
  (* (--Rsp)) = (Wrd280.Obj);
  (* (--Rsp)) = (Wrd277.Obj);
  (* (--Rsp)) = (Wrd276.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_150)
  (Wrd265.Obj) = Rvl;
  goto label_233;

DEFLABEL (label_236)
  (Wrd260.Obj) = (Rsp [7]);
  (Wrd264.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_45]))));
  (* (--Rsp)) = (Wrd264.Obj);
  (* (--Rsp)) = (Wrd231.Obj);
  (* (--Rsp)) = (Wrd260.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_149)
  (* (--Rsp)) = Rvl;
  goto label_235;

DEFLABEL (label_238)
  (Wrd242.Obj) = (Rsp [4]);
  (Wrd243.Obj) = (current_block [OBJECT_33_2]);
  (Wrd246.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_44]))));
  (* (--Rsp)) = (Wrd246.Obj);
  (* (--Rsp)) = (Wrd243.Obj);
  (* (--Rsp)) = (Wrd242.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_148)
  (Wrd231.Obj) = Rvl;
  goto label_237;

DEFLABEL (label_240)
  (Wrd226.Obj) = (Rsp [3]);
  (Wrd227.Obj) = (current_block [OBJECT_33_0]);
  (Wrd230.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_43]))));
  (* (--Rsp)) = (Wrd230.Obj);
  (* (--Rsp)) = (Wrd227.Obj);
  (* (--Rsp)) = (Wrd226.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_147)
  (* (--Rsp)) = Rvl;
  goto label_239;

DEFLABEL (label_242)
  (Wrd214.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_42]))));
  (* (--Rsp)) = (Wrd214.Obj);
  (* (--Rsp)) = (Wrd190.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_8]), 1);

DEFLABEL (label_146)
  (* (--Rsp)) = Rvl;
  goto label_241;

DEFLABEL (label_244)
  (Wrd201.Obj) = (Rsp [2]);
  (Wrd202.Obj) = (current_block [OBJECT_33_3]);
  (Wrd205.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_41]))));
  (* (--Rsp)) = (Wrd205.Obj);
  (* (--Rsp)) = (Wrd202.Obj);
  (* (--Rsp)) = (Wrd201.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_145)
  (Wrd190.Obj) = Rvl;
  goto label_243;

DEFLABEL (label_246)
  (Wrd184.Obj) = (Rsp [0]);
  (Wrd185.Obj) = (current_block [OBJECT_33_6]);
  (Wrd188.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_40]))));
  (* (--Rsp)) = (Wrd188.Obj);
  (* (--Rsp)) = (Wrd185.Obj);
  (* (--Rsp)) = (Wrd184.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_144)
  (* (--Rsp)) = Rvl;
  goto label_245;

DEFLABEL (label_248)
  (Wrd498.Obj) = (Rsp [0]);
  (Wrd499.uLng) = (OBJECT_TYPE (Wrd498.Obj));
  if (! ((Wrd499.uLng) == 62))
    goto label_302;
  (Wrd495.pObj) = (OBJECT_ADDRESS (Wrd498.Obj));
  (Wrd496.Obj) = ((Wrd495.pObj) [0]);
  (Wrd497.Lng) = (FIXNUM_TO_LONG (Wrd496.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd497.Lng))))
    goto label_302;
  (Wrd491.Obj) = ((Wrd495.pObj) [3]);
  (* (--Rsp)) = (Wrd491.Obj);

DEFLABEL (label_301)
  (Wrd514.Obj) = (Rsp [1]);
  (Wrd515.uLng) = (OBJECT_TYPE (Wrd514.Obj));
  if (! ((Wrd515.uLng) == 62))
    goto label_300;
  (Wrd511.pObj) = (OBJECT_ADDRESS (Wrd514.Obj));
  (Wrd512.Obj) = ((Wrd511.pObj) [0]);
  (Wrd513.Lng) = (FIXNUM_TO_LONG (Wrd512.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd513.Lng))))
    goto label_300;
  (Wrd505.Obj) = ((Wrd511.pObj) [2]);

DEFLABEL (label_299)
  (Wrd532.Obj) = (Rsp [4]);
  (Wrd533.uLng) = (OBJECT_TYPE (Wrd532.Obj));
  if (! ((Wrd533.uLng) == 62))
    goto label_298;
  (Wrd526.uLng) = (OBJECT_TYPE (Wrd505.Obj));
  if (! ((Wrd526.uLng) == 26))
    goto label_298;
  (Wrd527.Lng) = (FIXNUM_TO_LONG (Wrd505.Obj));
  (Wrd529.pObj) = (OBJECT_ADDRESS (Wrd532.Obj));
  (Wrd530.Obj) = ((Wrd529.pObj) [0]);
  (Wrd531.Lng) = (FIXNUM_TO_LONG (Wrd530.Obj));
  if (! (((unsigned long) (Wrd527.Lng)) < ((unsigned long) (Wrd531.Lng))))
    goto label_298;
  (Wrd521.uLng) = (OBJECT_DATUM (Wrd505.Obj));
  (Wrd524.pObj) = (& ((Wrd529.pObj) [(Wrd521.Lng)]));
  (Wrd525.Obj) = ((Wrd524.pObj) [1]);
  (* (--Rsp)) = (Wrd525.Obj);

DEFLABEL (label_297)
  (Wrd548.Obj) = (Rsp [2]);
  (Wrd549.uLng) = (OBJECT_TYPE (Wrd548.Obj));
  if (! ((Wrd549.uLng) == 62))
    goto label_296;
  (Wrd545.pObj) = (OBJECT_ADDRESS (Wrd548.Obj));
  (Wrd546.Obj) = ((Wrd545.pObj) [0]);
  (Wrd547.Lng) = (FIXNUM_TO_LONG (Wrd546.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd547.Lng))))
    goto label_296;
  (Wrd539.Obj) = ((Wrd545.pObj) [2]);

DEFLABEL (label_295)
  (Wrd566.Obj) = (Rsp [4]);
  (Wrd567.uLng) = (OBJECT_TYPE (Wrd566.Obj));
  if (! ((Wrd567.uLng) == 62))
    goto label_294;
  (Wrd560.uLng) = (OBJECT_TYPE (Wrd539.Obj));
  if (! ((Wrd560.uLng) == 26))
    goto label_294;
  (Wrd561.Lng) = (FIXNUM_TO_LONG (Wrd539.Obj));
  (Wrd563.pObj) = (OBJECT_ADDRESS (Wrd566.Obj));
  (Wrd564.Obj) = ((Wrd563.pObj) [0]);
  (Wrd565.Lng) = (FIXNUM_TO_LONG (Wrd564.Obj));
  if (! (((unsigned long) (Wrd561.Lng)) < ((unsigned long) (Wrd565.Lng))))
    goto label_294;
  (Wrd556.uLng) = (OBJECT_DATUM (Wrd539.Obj));
  (Wrd559.pObj) = (& ((Wrd563.pObj) [(Wrd556.Lng)]));
  (Wrd555.Obj) = ((Wrd559.pObj) [1]);

DEFLABEL (label_293)
  (Wrd573.Obj) = (* (Rsp++));
  (Wrd574.Lng) = (FIXNUM_TO_LONG (Wrd555.Obj));
  (Wrd575.Lng) = (FIXNUM_TO_LONG (Wrd573.Obj));
  (Wrd576.Lng) = ((Wrd574.Lng) + (Wrd575.Lng));
  (Wrd577.Obj) = (LONG_TO_FIXNUM (Wrd576.Lng));
  (* (--Rsp)) = (Wrd577.Obj);
  (Wrd587.Obj) = (Rsp [2]);
  (Wrd588.uLng) = (OBJECT_TYPE (Wrd587.Obj));
  if (! ((Wrd588.uLng) == 62))
    goto label_292;
  (Wrd584.pObj) = (OBJECT_ADDRESS (Wrd587.Obj));
  (Wrd585.Obj) = ((Wrd584.pObj) [0]);
  (Wrd586.Lng) = (FIXNUM_TO_LONG (Wrd585.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd586.Lng))))
    goto label_292;
  (Wrd578.Obj) = ((Wrd584.pObj) [2]);

DEFLABEL (label_291)
  (Wrd605.Obj) = (Rsp [3]);
  (Wrd606.uLng) = (OBJECT_TYPE (Wrd605.Obj));
  if (! ((Wrd606.uLng) == 62))
    goto label_290;
  (Wrd599.uLng) = (OBJECT_TYPE (Wrd578.Obj));
  if (! ((Wrd599.uLng) == 26))
    goto label_290;
  (Wrd600.Lng) = (FIXNUM_TO_LONG (Wrd578.Obj));
  (Wrd602.pObj) = (OBJECT_ADDRESS (Wrd605.Obj));
  (Wrd603.Obj) = ((Wrd602.pObj) [0]);
  (Wrd604.Lng) = (FIXNUM_TO_LONG (Wrd603.Obj));
  if (! (((unsigned long) (Wrd600.Lng)) < ((unsigned long) (Wrd604.Lng))))
    goto label_290;
  (Wrd595.uLng) = (OBJECT_DATUM (Wrd578.Obj));
  (Wrd598.pObj) = (& ((Wrd602.pObj) [(Wrd595.Lng)]));
  (Wrd594.Obj) = ((Wrd598.pObj) [1]);

DEFLABEL (label_289)
  (Wrd612.Obj) = (* (Rsp++));
  (Wrd614.Lng) = (FIXNUM_TO_LONG (Wrd594.Obj));
  (Wrd615.Lng) = (FIXNUM_TO_LONG (Wrd612.Obj));
  (Wrd616.Lng) = ((Wrd614.Lng) + (Wrd615.Lng));
  (Wrd617.Obj) = (* (Rsp++));
  Wrd618 = Wrd616;
  (Wrd619.Lng) = (FIXNUM_TO_LONG (Wrd617.Obj));
  (Wrd620.Lng) = ((Wrd618.Lng) & (Wrd619.Lng));
  (Wrd621.Obj) = (LONG_TO_FIXNUM (Wrd620.Lng));
  (* (--Rsp)) = (Wrd621.Obj);
  (Wrd631.Obj) = (Rsp [1]);
  (Wrd632.uLng) = (OBJECT_TYPE (Wrd631.Obj));
  if (! ((Wrd632.uLng) == 62))
    goto label_288;
  (Wrd628.pObj) = (OBJECT_ADDRESS (Wrd631.Obj));
  (Wrd629.Obj) = ((Wrd628.pObj) [0]);
  (Wrd630.Lng) = (FIXNUM_TO_LONG (Wrd629.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd630.Lng))))
    goto label_288;
  (Wrd622.Obj) = ((Wrd628.pObj) [6]);

DEFLABEL (label_287)
  (Wrd638.Obj) = (* (Rsp++));
  (Wrd648.uLng) = (OBJECT_TYPE (Wrd622.Obj));
  if (! ((Wrd648.uLng) == 10))
    goto label_286;
  (Wrd643.uLng) = (OBJECT_TYPE (Wrd638.Obj));
  if (! ((Wrd643.uLng) == 26))
    goto label_286;
  (Wrd644.Lng) = (FIXNUM_TO_LONG (Wrd638.Obj));
  (Wrd645.pObj) = (OBJECT_ADDRESS (Wrd622.Obj));
  (Wrd646.Obj) = ((Wrd645.pObj) [0]);
  (Wrd647.Lng) = (FIXNUM_TO_LONG (Wrd646.Obj));
  if (! (((unsigned long) (Wrd644.Lng)) < ((unsigned long) (Wrd647.Lng))))
    goto label_286;
  (Wrd640.uLng) = (OBJECT_DATUM (Wrd638.Obj));
  (Wrd642.pObj) = (& ((Wrd645.pObj) [(Wrd640.Lng)]));
  (Wrd639.Obj) = ((Wrd642.pObj) [1]);

DEFLABEL (label_285)
  (Wrd655.pObj) = (OBJECT_ADDRESS (Wrd639.Obj));
  (Wrd654.Obj) = ((Wrd655.pObj) [1]);
  (Wrd657.pObj) = (OBJECT_ADDRESS (Wrd654.Obj));
  (Wrd656.Obj) = ((Wrd657.pObj) [0]);
  (Wrd658.Obj) = (Rsp [2]);
  if (! ((Wrd658.Obj) == (Wrd656.Obj)))
    goto label_247;
  (Wrd668.Obj) = (Rsp [0]);
  (Wrd669.uLng) = (OBJECT_TYPE (Wrd668.Obj));
  if (! ((Wrd669.uLng) == 62))
    goto label_284;
  (Wrd665.pObj) = (OBJECT_ADDRESS (Wrd668.Obj));
  (Wrd666.Obj) = ((Wrd665.pObj) [0]);
  (Wrd667.Lng) = (FIXNUM_TO_LONG (Wrd666.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd667.Lng))))
    goto label_284;
  (Wrd661.Obj) = ((Wrd665.pObj) [3]);
  (* (--Rsp)) = (Wrd661.Obj);

DEFLABEL (label_283)
  (Wrd684.Obj) = (Rsp [1]);
  (Wrd685.uLng) = (OBJECT_TYPE (Wrd684.Obj));
  if (! ((Wrd685.uLng) == 62))
    goto label_282;
  (Wrd681.pObj) = (OBJECT_ADDRESS (Wrd684.Obj));
  (Wrd682.Obj) = ((Wrd681.pObj) [0]);
  (Wrd683.Lng) = (FIXNUM_TO_LONG (Wrd682.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd683.Lng))))
    goto label_282;
  (Wrd675.Obj) = ((Wrd681.pObj) [2]);

DEFLABEL (label_281)
  (Wrd702.Obj) = (Rsp [4]);
  (Wrd703.uLng) = (OBJECT_TYPE (Wrd702.Obj));
  if (! ((Wrd703.uLng) == 62))
    goto label_280;
  (Wrd696.uLng) = (OBJECT_TYPE (Wrd675.Obj));
  if (! ((Wrd696.uLng) == 26))
    goto label_280;
  (Wrd697.Lng) = (FIXNUM_TO_LONG (Wrd675.Obj));
  (Wrd699.pObj) = (OBJECT_ADDRESS (Wrd702.Obj));
  (Wrd700.Obj) = ((Wrd699.pObj) [0]);
  (Wrd701.Lng) = (FIXNUM_TO_LONG (Wrd700.Obj));
  if (! (((unsigned long) (Wrd697.Lng)) < ((unsigned long) (Wrd701.Lng))))
    goto label_280;
  (Wrd691.uLng) = (OBJECT_DATUM (Wrd675.Obj));
  (Wrd694.pObj) = (& ((Wrd699.pObj) [(Wrd691.Lng)]));
  (Wrd695.Obj) = ((Wrd694.pObj) [1]);
  (* (--Rsp)) = (Wrd695.Obj);

DEFLABEL (label_279)
  (Wrd718.Obj) = (Rsp [2]);
  (Wrd719.uLng) = (OBJECT_TYPE (Wrd718.Obj));
  if (! ((Wrd719.uLng) == 62))
    goto label_278;
  (Wrd715.pObj) = (OBJECT_ADDRESS (Wrd718.Obj));
  (Wrd716.Obj) = ((Wrd715.pObj) [0]);
  (Wrd717.Lng) = (FIXNUM_TO_LONG (Wrd716.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd717.Lng))))
    goto label_278;
  (Wrd709.Obj) = ((Wrd715.pObj) [2]);

DEFLABEL (label_277)
  (Wrd736.Obj) = (Rsp [4]);
  (Wrd737.uLng) = (OBJECT_TYPE (Wrd736.Obj));
  if (! ((Wrd737.uLng) == 62))
    goto label_276;
  (Wrd730.uLng) = (OBJECT_TYPE (Wrd709.Obj));
  if (! ((Wrd730.uLng) == 26))
    goto label_276;
  (Wrd731.Lng) = (FIXNUM_TO_LONG (Wrd709.Obj));
  (Wrd733.pObj) = (OBJECT_ADDRESS (Wrd736.Obj));
  (Wrd734.Obj) = ((Wrd733.pObj) [0]);
  (Wrd735.Lng) = (FIXNUM_TO_LONG (Wrd734.Obj));
  if (! (((unsigned long) (Wrd731.Lng)) < ((unsigned long) (Wrd735.Lng))))
    goto label_276;
  (Wrd726.uLng) = (OBJECT_DATUM (Wrd709.Obj));
  (Wrd729.pObj) = (& ((Wrd733.pObj) [(Wrd726.Lng)]));
  (Wrd725.Obj) = ((Wrd729.pObj) [1]);

DEFLABEL (label_275)
  (Wrd743.Obj) = (* (Rsp++));
  (Wrd744.Lng) = (FIXNUM_TO_LONG (Wrd725.Obj));
  (Wrd745.Lng) = (FIXNUM_TO_LONG (Wrd743.Obj));
  (Wrd746.Lng) = ((Wrd744.Lng) + (Wrd745.Lng));
  (Wrd747.Obj) = (LONG_TO_FIXNUM (Wrd746.Lng));
  (* (--Rsp)) = (Wrd747.Obj);
  (Wrd757.Obj) = (Rsp [2]);
  (Wrd758.uLng) = (OBJECT_TYPE (Wrd757.Obj));
  if (! ((Wrd758.uLng) == 62))
    goto label_274;
  (Wrd754.pObj) = (OBJECT_ADDRESS (Wrd757.Obj));
  (Wrd755.Obj) = ((Wrd754.pObj) [0]);
  (Wrd756.Lng) = (FIXNUM_TO_LONG (Wrd755.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd756.Lng))))
    goto label_274;
  (Wrd748.Obj) = ((Wrd754.pObj) [2]);

DEFLABEL (label_273)
  (Wrd775.Obj) = (Rsp [3]);
  (Wrd776.uLng) = (OBJECT_TYPE (Wrd775.Obj));
  if (! ((Wrd776.uLng) == 62))
    goto label_272;
  (Wrd769.uLng) = (OBJECT_TYPE (Wrd748.Obj));
  if (! ((Wrd769.uLng) == 26))
    goto label_272;
  (Wrd770.Lng) = (FIXNUM_TO_LONG (Wrd748.Obj));
  (Wrd772.pObj) = (OBJECT_ADDRESS (Wrd775.Obj));
  (Wrd773.Obj) = ((Wrd772.pObj) [0]);
  (Wrd774.Lng) = (FIXNUM_TO_LONG (Wrd773.Obj));
  if (! (((unsigned long) (Wrd770.Lng)) < ((unsigned long) (Wrd774.Lng))))
    goto label_272;
  (Wrd765.uLng) = (OBJECT_DATUM (Wrd748.Obj));
  (Wrd768.pObj) = (& ((Wrd772.pObj) [(Wrd765.Lng)]));
  (Wrd764.Obj) = ((Wrd768.pObj) [1]);

DEFLABEL (label_271)
  (Wrd782.Obj) = (* (Rsp++));
  (Wrd784.Lng) = (FIXNUM_TO_LONG (Wrd764.Obj));
  (Wrd785.Lng) = (FIXNUM_TO_LONG (Wrd782.Obj));
  (Wrd786.Lng) = ((Wrd784.Lng) + (Wrd785.Lng));
  (Wrd787.Obj) = (* (Rsp++));
  Wrd788 = Wrd786;
  (Wrd789.Lng) = (FIXNUM_TO_LONG (Wrd787.Obj));
  (Wrd790.Lng) = ((Wrd788.Lng) & (Wrd789.Lng));
  (Wrd791.Obj) = (LONG_TO_FIXNUM (Wrd790.Lng));
  (* (--Rsp)) = (Wrd791.Obj);
  (Wrd801.Obj) = (Rsp [1]);
  (Wrd802.uLng) = (OBJECT_TYPE (Wrd801.Obj));
  if (! ((Wrd802.uLng) == 62))
    goto label_270;
  (Wrd798.pObj) = (OBJECT_ADDRESS (Wrd801.Obj));
  (Wrd799.Obj) = ((Wrd798.pObj) [0]);
  (Wrd800.Lng) = (FIXNUM_TO_LONG (Wrd799.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd800.Lng))))
    goto label_270;
  (Wrd792.Obj) = ((Wrd798.pObj) [6]);

DEFLABEL (label_269)
  (Wrd808.Obj) = (* (Rsp++));
  (Wrd818.uLng) = (OBJECT_TYPE (Wrd792.Obj));
  if (! ((Wrd818.uLng) == 10))
    goto label_268;
  (Wrd813.uLng) = (OBJECT_TYPE (Wrd808.Obj));
  if (! ((Wrd813.uLng) == 26))
    goto label_268;
  (Wrd814.Lng) = (FIXNUM_TO_LONG (Wrd808.Obj));
  (Wrd815.pObj) = (OBJECT_ADDRESS (Wrd792.Obj));
  (Wrd816.Obj) = ((Wrd815.pObj) [0]);
  (Wrd817.Lng) = (FIXNUM_TO_LONG (Wrd816.Obj));
  if (! (((unsigned long) (Wrd814.Lng)) < ((unsigned long) (Wrd817.Lng))))
    goto label_268;
  (Wrd810.uLng) = (OBJECT_DATUM (Wrd808.Obj));
  (Wrd812.pObj) = (& ((Wrd815.pObj) [(Wrd810.Lng)]));
  (Wrd809.Obj) = ((Wrd812.pObj) [1]);

DEFLABEL (label_267)
  (Wrd825.pObj) = (OBJECT_ADDRESS (Wrd809.Obj));
  (Wrd824.Obj) = ((Wrd825.pObj) [1]);
  (Wrd827.pObj) = (OBJECT_ADDRESS (Wrd824.Obj));
  (Wrd826.Obj) = ((Wrd827.pObj) [1]);
  (Wrd829.pObj) = (OBJECT_ADDRESS (Wrd826.Obj));
  (Wrd828.Obj) = ((Wrd829.pObj) [0]);
  (Wrd830.Obj) = (Rsp [3]);
  if (! ((Wrd830.Obj) == (Wrd828.Obj)))
    goto label_247;
  (Wrd840.Obj) = (Rsp [0]);
  (Wrd841.uLng) = (OBJECT_TYPE (Wrd840.Obj));
  if (! ((Wrd841.uLng) == 62))
    goto label_266;
  (Wrd837.pObj) = (OBJECT_ADDRESS (Wrd840.Obj));
  (Wrd838.Obj) = ((Wrd837.pObj) [0]);
  (Wrd839.Lng) = (FIXNUM_TO_LONG (Wrd838.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd839.Lng))))
    goto label_266;
  (Wrd833.Obj) = ((Wrd837.pObj) [3]);
  (* (--Rsp)) = (Wrd833.Obj);

DEFLABEL (label_265)
  (Wrd856.Obj) = (Rsp [1]);
  (Wrd857.uLng) = (OBJECT_TYPE (Wrd856.Obj));
  if (! ((Wrd857.uLng) == 62))
    goto label_264;
  (Wrd853.pObj) = (OBJECT_ADDRESS (Wrd856.Obj));
  (Wrd854.Obj) = ((Wrd853.pObj) [0]);
  (Wrd855.Lng) = (FIXNUM_TO_LONG (Wrd854.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd855.Lng))))
    goto label_264;
  (Wrd847.Obj) = ((Wrd853.pObj) [2]);

DEFLABEL (label_263)
  (Wrd874.Obj) = (Rsp [4]);
  (Wrd875.uLng) = (OBJECT_TYPE (Wrd874.Obj));
  if (! ((Wrd875.uLng) == 62))
    goto label_262;
  (Wrd868.uLng) = (OBJECT_TYPE (Wrd847.Obj));
  if (! ((Wrd868.uLng) == 26))
    goto label_262;
  (Wrd869.Lng) = (FIXNUM_TO_LONG (Wrd847.Obj));
  (Wrd871.pObj) = (OBJECT_ADDRESS (Wrd874.Obj));
  (Wrd872.Obj) = ((Wrd871.pObj) [0]);
  (Wrd873.Lng) = (FIXNUM_TO_LONG (Wrd872.Obj));
  if (! (((unsigned long) (Wrd869.Lng)) < ((unsigned long) (Wrd873.Lng))))
    goto label_262;
  (Wrd863.uLng) = (OBJECT_DATUM (Wrd847.Obj));
  (Wrd866.pObj) = (& ((Wrd871.pObj) [(Wrd863.Lng)]));
  (Wrd867.Obj) = ((Wrd866.pObj) [1]);
  (* (--Rsp)) = (Wrd867.Obj);

DEFLABEL (label_261)
  (Wrd890.Obj) = (Rsp [2]);
  (Wrd891.uLng) = (OBJECT_TYPE (Wrd890.Obj));
  if (! ((Wrd891.uLng) == 62))
    goto label_260;
  (Wrd887.pObj) = (OBJECT_ADDRESS (Wrd890.Obj));
  (Wrd888.Obj) = ((Wrd887.pObj) [0]);
  (Wrd889.Lng) = (FIXNUM_TO_LONG (Wrd888.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd889.Lng))))
    goto label_260;
  (Wrd881.Obj) = ((Wrd887.pObj) [2]);

DEFLABEL (label_259)
  (Wrd908.Obj) = (Rsp [4]);
  (Wrd909.uLng) = (OBJECT_TYPE (Wrd908.Obj));
  if (! ((Wrd909.uLng) == 62))
    goto label_258;
  (Wrd902.uLng) = (OBJECT_TYPE (Wrd881.Obj));
  if (! ((Wrd902.uLng) == 26))
    goto label_258;
  (Wrd903.Lng) = (FIXNUM_TO_LONG (Wrd881.Obj));
  (Wrd905.pObj) = (OBJECT_ADDRESS (Wrd908.Obj));
  (Wrd906.Obj) = ((Wrd905.pObj) [0]);
  (Wrd907.Lng) = (FIXNUM_TO_LONG (Wrd906.Obj));
  if (! (((unsigned long) (Wrd903.Lng)) < ((unsigned long) (Wrd907.Lng))))
    goto label_258;
  (Wrd898.uLng) = (OBJECT_DATUM (Wrd881.Obj));
  (Wrd901.pObj) = (& ((Wrd905.pObj) [(Wrd898.Lng)]));
  (Wrd897.Obj) = ((Wrd901.pObj) [1]);

DEFLABEL (label_257)
  (Wrd915.Obj) = (* (Rsp++));
  (Wrd916.Lng) = (FIXNUM_TO_LONG (Wrd897.Obj));
  (Wrd917.Lng) = (FIXNUM_TO_LONG (Wrd915.Obj));
  (Wrd918.Lng) = ((Wrd916.Lng) + (Wrd917.Lng));
  (Wrd919.Obj) = (LONG_TO_FIXNUM (Wrd918.Lng));
  (* (--Rsp)) = (Wrd919.Obj);
  (Wrd929.Obj) = (Rsp [2]);
  (Wrd930.uLng) = (OBJECT_TYPE (Wrd929.Obj));
  if (! ((Wrd930.uLng) == 62))
    goto label_256;
  (Wrd926.pObj) = (OBJECT_ADDRESS (Wrd929.Obj));
  (Wrd927.Obj) = ((Wrd926.pObj) [0]);
  (Wrd928.Lng) = (FIXNUM_TO_LONG (Wrd927.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd928.Lng))))
    goto label_256;
  (Wrd920.Obj) = ((Wrd926.pObj) [2]);

DEFLABEL (label_255)
  (Wrd947.Obj) = (Rsp [3]);
  (Wrd948.uLng) = (OBJECT_TYPE (Wrd947.Obj));
  if (! ((Wrd948.uLng) == 62))
    goto label_254;
  (Wrd941.uLng) = (OBJECT_TYPE (Wrd920.Obj));
  if (! ((Wrd941.uLng) == 26))
    goto label_254;
  (Wrd942.Lng) = (FIXNUM_TO_LONG (Wrd920.Obj));
  (Wrd944.pObj) = (OBJECT_ADDRESS (Wrd947.Obj));
  (Wrd945.Obj) = ((Wrd944.pObj) [0]);
  (Wrd946.Lng) = (FIXNUM_TO_LONG (Wrd945.Obj));
  if (! (((unsigned long) (Wrd942.Lng)) < ((unsigned long) (Wrd946.Lng))))
    goto label_254;
  (Wrd937.uLng) = (OBJECT_DATUM (Wrd920.Obj));
  (Wrd940.pObj) = (& ((Wrd944.pObj) [(Wrd937.Lng)]));
  (Wrd936.Obj) = ((Wrd940.pObj) [1]);

DEFLABEL (label_253)
  (Wrd954.Obj) = (* (Rsp++));
  (Wrd956.Lng) = (FIXNUM_TO_LONG (Wrd936.Obj));
  (Wrd957.Lng) = (FIXNUM_TO_LONG (Wrd954.Obj));
  (Wrd958.Lng) = ((Wrd956.Lng) + (Wrd957.Lng));
  (Wrd959.Obj) = (* (Rsp++));
  Wrd961 = Wrd958;
  (Wrd962.Lng) = (FIXNUM_TO_LONG (Wrd959.Obj));
  (Wrd963.Lng) = ((Wrd961.Lng) & (Wrd962.Lng));
  (Wrd960.Obj) = (LONG_TO_FIXNUM (Wrd963.Lng));
  (Rsp [3]) = (Wrd960.Obj);
  (Wrd973.Obj) = (Rsp [0]);
  (Wrd974.uLng) = (OBJECT_TYPE (Wrd973.Obj));
  if (! ((Wrd974.uLng) == 62))
    goto label_252;
  (Wrd970.pObj) = (OBJECT_ADDRESS (Wrd973.Obj));
  (Wrd971.Obj) = ((Wrd970.pObj) [0]);
  (Wrd972.Lng) = (FIXNUM_TO_LONG (Wrd971.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd972.Lng))))
    goto label_252;
  (Wrd964.Obj) = ((Wrd970.pObj) [7]);

DEFLABEL (label_251)
  (Rsp [2]) = (Wrd964.Obj);
  Rsp = (& (Rsp [2]));
  (Wrd995.Obj) = (Rsp [0]);
  (Wrd996.uLng) = (OBJECT_TYPE (Wrd995.Obj));
  if ((Wrd996.uLng) == 10)
    goto label_250;

DEFLABEL (label_249)
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_250)
  (Wrd987.Obj) = (Rsp [1]);
  (Wrd988.uLng) = (OBJECT_TYPE (Wrd987.Obj));
  if (! ((Wrd988.uLng) == 26))
    goto label_249;
  (Wrd990.Lng) = (FIXNUM_TO_LONG (Wrd987.Obj));
  (Wrd992.pObj) = (OBJECT_ADDRESS (Wrd995.Obj));
  (Wrd993.Obj) = ((Wrd992.pObj) [0]);
  (Wrd994.Lng) = (FIXNUM_TO_LONG (Wrd993.Obj));
  if (! (((unsigned long) (Wrd990.Lng)) < ((unsigned long) (Wrd994.Lng))))
    goto label_249;
  (Wrd982.uLng) = (OBJECT_DATUM (Wrd987.Obj));
  (Wrd985.pObj) = (& ((Wrd992.pObj) [(Wrd982.Lng)]));
  Rvl = ((Wrd985.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_252)
  (Wrd975.Obj) = (Rsp [0]);
  (Wrd976.Obj) = (current_block [OBJECT_33_5]);
  (Wrd979.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_39]))));
  (* (--Rsp)) = (Wrd979.Obj);
  (* (--Rsp)) = (Wrd976.Obj);
  (* (--Rsp)) = (Wrd975.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_186)
  (Wrd964.Obj) = Rvl;
  goto label_251;

DEFLABEL (label_254)
  (Wrd949.Obj) = (Rsp [3]);
  (Wrd953.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_38]))));
  (* (--Rsp)) = (Wrd953.Obj);
  (* (--Rsp)) = (Wrd920.Obj);
  (* (--Rsp)) = (Wrd949.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_185)
  (Wrd936.Obj) = Rvl;
  goto label_253;

DEFLABEL (label_256)
  (Wrd931.Obj) = (Rsp [2]);
  (Wrd932.Obj) = (current_block [OBJECT_33_2]);
  (Wrd935.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_37]))));
  (* (--Rsp)) = (Wrd935.Obj);
  (* (--Rsp)) = (Wrd932.Obj);
  (* (--Rsp)) = (Wrd931.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_184)
  (Wrd920.Obj) = Rvl;
  goto label_255;

DEFLABEL (label_258)
  (Wrd910.Obj) = (Rsp [4]);
  (Wrd914.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_36]))));
  (* (--Rsp)) = (Wrd914.Obj);
  (* (--Rsp)) = (Wrd881.Obj);
  (* (--Rsp)) = (Wrd910.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_183)
  (Wrd897.Obj) = Rvl;
  goto label_257;

DEFLABEL (label_260)
  (Wrd892.Obj) = (Rsp [2]);
  (Wrd893.Obj) = (current_block [OBJECT_33_2]);
  (Wrd896.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_35]))));
  (* (--Rsp)) = (Wrd896.Obj);
  (* (--Rsp)) = (Wrd893.Obj);
  (* (--Rsp)) = (Wrd892.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_182)
  (Wrd881.Obj) = Rvl;
  goto label_259;

DEFLABEL (label_262)
  (Wrd876.Obj) = (Rsp [4]);
  (Wrd880.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_34]))));
  (* (--Rsp)) = (Wrd880.Obj);
  (* (--Rsp)) = (Wrd847.Obj);
  (* (--Rsp)) = (Wrd876.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_181)
  (* (--Rsp)) = Rvl;
  goto label_261;

DEFLABEL (label_264)
  (Wrd858.Obj) = (Rsp [1]);
  (Wrd859.Obj) = (current_block [OBJECT_33_2]);
  (Wrd862.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_33]))));
  (* (--Rsp)) = (Wrd862.Obj);
  (* (--Rsp)) = (Wrd859.Obj);
  (* (--Rsp)) = (Wrd858.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_180)
  (Wrd847.Obj) = Rvl;
  goto label_263;

DEFLABEL (label_266)
  (Wrd842.Obj) = (Rsp [0]);
  (Wrd843.Obj) = (current_block [OBJECT_33_0]);
  (Wrd846.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_32]))));
  (* (--Rsp)) = (Wrd846.Obj);
  (* (--Rsp)) = (Wrd843.Obj);
  (* (--Rsp)) = (Wrd842.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_179)
  (* (--Rsp)) = Rvl;
  goto label_265;

DEFLABEL (label_268)
  (Wrd823.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_31]))));
  (* (--Rsp)) = (Wrd823.Obj);
  (* (--Rsp)) = (Wrd808.Obj);
  (* (--Rsp)) = (Wrd792.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_178)
  (Wrd809.Obj) = Rvl;
  goto label_267;

DEFLABEL (label_270)
  (Wrd803.Obj) = (Rsp [1]);
  (Wrd804.Obj) = (current_block [OBJECT_33_3]);
  (Wrd807.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_30]))));
  (* (--Rsp)) = (Wrd807.Obj);
  (* (--Rsp)) = (Wrd804.Obj);
  (* (--Rsp)) = (Wrd803.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_177)
  (Wrd792.Obj) = Rvl;
  goto label_269;

DEFLABEL (label_272)
  (Wrd777.Obj) = (Rsp [3]);
  (Wrd781.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_29]))));
  (* (--Rsp)) = (Wrd781.Obj);
  (* (--Rsp)) = (Wrd748.Obj);
  (* (--Rsp)) = (Wrd777.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_176)
  (Wrd764.Obj) = Rvl;
  goto label_271;

DEFLABEL (label_274)
  (Wrd759.Obj) = (Rsp [2]);
  (Wrd760.Obj) = (current_block [OBJECT_33_2]);
  (Wrd763.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_28]))));
  (* (--Rsp)) = (Wrd763.Obj);
  (* (--Rsp)) = (Wrd760.Obj);
  (* (--Rsp)) = (Wrd759.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_175)
  (Wrd748.Obj) = Rvl;
  goto label_273;

DEFLABEL (label_276)
  (Wrd738.Obj) = (Rsp [4]);
  (Wrd742.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_27]))));
  (* (--Rsp)) = (Wrd742.Obj);
  (* (--Rsp)) = (Wrd709.Obj);
  (* (--Rsp)) = (Wrd738.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_174)
  (Wrd725.Obj) = Rvl;
  goto label_275;

DEFLABEL (label_278)
  (Wrd720.Obj) = (Rsp [2]);
  (Wrd721.Obj) = (current_block [OBJECT_33_2]);
  (Wrd724.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_26]))));
  (* (--Rsp)) = (Wrd724.Obj);
  (* (--Rsp)) = (Wrd721.Obj);
  (* (--Rsp)) = (Wrd720.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_173)
  (Wrd709.Obj) = Rvl;
  goto label_277;

DEFLABEL (label_280)
  (Wrd704.Obj) = (Rsp [4]);
  (Wrd708.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_25]))));
  (* (--Rsp)) = (Wrd708.Obj);
  (* (--Rsp)) = (Wrd675.Obj);
  (* (--Rsp)) = (Wrd704.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_172)
  (* (--Rsp)) = Rvl;
  goto label_279;

DEFLABEL (label_282)
  (Wrd686.Obj) = (Rsp [1]);
  (Wrd687.Obj) = (current_block [OBJECT_33_2]);
  (Wrd690.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_24]))));
  (* (--Rsp)) = (Wrd690.Obj);
  (* (--Rsp)) = (Wrd687.Obj);
  (* (--Rsp)) = (Wrd686.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_171)
  (Wrd675.Obj) = Rvl;
  goto label_281;

DEFLABEL (label_284)
  (Wrd670.Obj) = (Rsp [0]);
  (Wrd671.Obj) = (current_block [OBJECT_33_0]);
  (Wrd674.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_23]))));
  (* (--Rsp)) = (Wrd674.Obj);
  (* (--Rsp)) = (Wrd671.Obj);
  (* (--Rsp)) = (Wrd670.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_170)
  (* (--Rsp)) = Rvl;
  goto label_283;

DEFLABEL (label_286)
  (Wrd653.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_22]))));
  (* (--Rsp)) = (Wrd653.Obj);
  (* (--Rsp)) = (Wrd638.Obj);
  (* (--Rsp)) = (Wrd622.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_169)
  (Wrd639.Obj) = Rvl;
  goto label_285;

DEFLABEL (label_288)
  (Wrd633.Obj) = (Rsp [1]);
  (Wrd634.Obj) = (current_block [OBJECT_33_3]);
  (Wrd637.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_21]))));
  (* (--Rsp)) = (Wrd637.Obj);
  (* (--Rsp)) = (Wrd634.Obj);
  (* (--Rsp)) = (Wrd633.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_168)
  (Wrd622.Obj) = Rvl;
  goto label_287;

DEFLABEL (label_290)
  (Wrd607.Obj) = (Rsp [3]);
  (Wrd611.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_20]))));
  (* (--Rsp)) = (Wrd611.Obj);
  (* (--Rsp)) = (Wrd578.Obj);
  (* (--Rsp)) = (Wrd607.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_167)
  (Wrd594.Obj) = Rvl;
  goto label_289;

DEFLABEL (label_292)
  (Wrd589.Obj) = (Rsp [2]);
  (Wrd590.Obj) = (current_block [OBJECT_33_2]);
  (Wrd593.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_19]))));
  (* (--Rsp)) = (Wrd593.Obj);
  (* (--Rsp)) = (Wrd590.Obj);
  (* (--Rsp)) = (Wrd589.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_166)
  (Wrd578.Obj) = Rvl;
  goto label_291;

DEFLABEL (label_294)
  (Wrd568.Obj) = (Rsp [4]);
  (Wrd572.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_18]))));
  (* (--Rsp)) = (Wrd572.Obj);
  (* (--Rsp)) = (Wrd539.Obj);
  (* (--Rsp)) = (Wrd568.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_165)
  (Wrd555.Obj) = Rvl;
  goto label_293;

DEFLABEL (label_296)
  (Wrd550.Obj) = (Rsp [2]);
  (Wrd551.Obj) = (current_block [OBJECT_33_2]);
  (Wrd554.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_17]))));
  (* (--Rsp)) = (Wrd554.Obj);
  (* (--Rsp)) = (Wrd551.Obj);
  (* (--Rsp)) = (Wrd550.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_164)
  (Wrd539.Obj) = Rvl;
  goto label_295;

DEFLABEL (label_298)
  (Wrd534.Obj) = (Rsp [4]);
  (Wrd538.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_16]))));
  (* (--Rsp)) = (Wrd538.Obj);
  (* (--Rsp)) = (Wrd505.Obj);
  (* (--Rsp)) = (Wrd534.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_163)
  (* (--Rsp)) = Rvl;
  goto label_297;

DEFLABEL (label_300)
  (Wrd516.Obj) = (Rsp [1]);
  (Wrd517.Obj) = (current_block [OBJECT_33_2]);
  (Wrd520.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_15]))));
  (* (--Rsp)) = (Wrd520.Obj);
  (* (--Rsp)) = (Wrd517.Obj);
  (* (--Rsp)) = (Wrd516.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_162)
  (Wrd505.Obj) = Rvl;
  goto label_299;

DEFLABEL (label_302)
  (Wrd500.Obj) = (Rsp [0]);
  (Wrd501.Obj) = (current_block [OBJECT_33_0]);
  (Wrd504.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_14]))));
  (* (--Rsp)) = (Wrd504.Obj);
  (* (--Rsp)) = (Wrd501.Obj);
  (* (--Rsp)) = (Wrd500.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_161)
  (* (--Rsp)) = Rvl;
  goto label_301;

DEFLABEL (label_304)
  (Wrd169.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_13]))));
  (* (--Rsp)) = (Wrd169.Obj);
  (* (--Rsp)) = (Wrd154.Obj);
  (* (--Rsp)) = (Wrd138.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_143)
  (Wrd155.Obj) = Rvl;
  goto label_303;

DEFLABEL (label_306)
  (Wrd149.Obj) = (Rsp [1]);
  (Wrd150.Obj) = (current_block [OBJECT_33_3]);
  (Wrd153.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_12]))));
  (* (--Rsp)) = (Wrd153.Obj);
  (* (--Rsp)) = (Wrd150.Obj);
  (* (--Rsp)) = (Wrd149.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_142)
  (Wrd138.Obj) = Rvl;
  goto label_305;

DEFLABEL (label_308)
  (Wrd123.Obj) = (Rsp [3]);
  (Wrd127.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_11]))));
  (* (--Rsp)) = (Wrd127.Obj);
  (* (--Rsp)) = (Wrd94.Obj);
  (* (--Rsp)) = (Wrd123.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_141)
  (Wrd110.Obj) = Rvl;
  goto label_307;

DEFLABEL (label_310)
  (Wrd105.Obj) = (Rsp [2]);
  (Wrd106.Obj) = (current_block [OBJECT_33_2]);
  (Wrd109.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_10]))));
  (* (--Rsp)) = (Wrd109.Obj);
  (* (--Rsp)) = (Wrd106.Obj);
  (* (--Rsp)) = (Wrd105.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_140)
  (Wrd94.Obj) = Rvl;
  goto label_309;

DEFLABEL (label_312)
  (Wrd84.Obj) = (Rsp [4]);
  (Wrd88.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_9]))));
  (* (--Rsp)) = (Wrd88.Obj);
  (* (--Rsp)) = (Wrd55.Obj);
  (* (--Rsp)) = (Wrd84.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_139)
  (Wrd71.Obj) = Rvl;
  goto label_311;

DEFLABEL (label_314)
  (Wrd66.Obj) = (Rsp [2]);
  (Wrd67.Obj) = (current_block [OBJECT_33_2]);
  (Wrd70.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_8]))));
  (* (--Rsp)) = (Wrd70.Obj);
  (* (--Rsp)) = (Wrd67.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_138)
  (Wrd55.Obj) = Rvl;
  goto label_313;

DEFLABEL (label_316)
  (Wrd50.Obj) = (Rsp [4]);
  (Wrd54.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_7]))));
  (* (--Rsp)) = (Wrd54.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = (Wrd50.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_137)
  (* (--Rsp)) = Rvl;
  goto label_315;

DEFLABEL (label_318)
  (Wrd32.Obj) = (Rsp [1]);
  (Wrd33.Obj) = (current_block [OBJECT_33_2]);
  (Wrd36.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_6]))));
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd33.Obj);
  (* (--Rsp)) = (Wrd32.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_136)
  (Wrd21.Obj) = Rvl;
  goto label_317;

DEFLABEL (label_320)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_33_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_135)
  (* (--Rsp)) = Rvl;
  goto label_319;

DEFLABEL (search_lines_209)
DEFLABEL (search_lines_119)
  INTERRUPT_CHECK (26, LABEL_33_57);
  (Wrd5.Obj) = (Rsp [1]);
  (Wrd6.Obj) = (Rsp [2]);
  if ((Wrd5.Obj) == (Wrd6.Obj))
    goto label_350;
  (Wrd16.Obj) = (Rsp [3]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_349;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_349;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_348)
  (Wrd225.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd225.uLng) == 10))
    goto label_347;
  (Wrd218.Obj) = (Rsp [0]);
  (Wrd219.uLng) = (OBJECT_TYPE (Wrd218.Obj));
  if (! ((Wrd219.uLng) == 26))
    goto label_347;
  (Wrd221.Lng) = (FIXNUM_TO_LONG (Wrd218.Obj));
  (Wrd222.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd223.Obj) = ((Wrd222.pObj) [0]);
  (Wrd224.Lng) = (FIXNUM_TO_LONG (Wrd223.Obj));
  if (! (((unsigned long) (Wrd221.Lng)) < ((unsigned long) (Wrd224.Lng))))
    goto label_347;
  (Wrd24.uLng) = (OBJECT_DATUM (Wrd218.Obj));
  (Wrd26.pObj) = (& ((Wrd222.pObj) [(Wrd24.Lng)]));
  (Wrd27.Obj) = ((Wrd26.pObj) [1]);
  if ((Wrd27.Obj) == ((SCHEME_OBJECT) 0))
    goto label_328;

DEFLABEL (label_346)
  (Wrd75.Obj) = (Rsp [3]);
  (Wrd76.uLng) = (OBJECT_TYPE (Wrd75.Obj));
  if (! ((Wrd76.uLng) == 62))
    goto label_345;
  (Wrd72.pObj) = (OBJECT_ADDRESS (Wrd75.Obj));
  (Wrd73.Obj) = ((Wrd72.pObj) [0]);
  (Wrd74.Lng) = (FIXNUM_TO_LONG (Wrd73.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd74.Lng))))
    goto label_345;
  (Wrd66.Obj) = ((Wrd72.pObj) [6]);

DEFLABEL (label_344)
  (Wrd94.uLng) = (OBJECT_TYPE (Wrd66.Obj));
  if (! ((Wrd94.uLng) == 10))
    goto label_343;
  (Wrd87.Obj) = (Rsp [0]);
  (Wrd88.uLng) = (OBJECT_TYPE (Wrd87.Obj));
  if (! ((Wrd88.uLng) == 26))
    goto label_343;
  (Wrd90.Lng) = (FIXNUM_TO_LONG (Wrd87.Obj));
  (Wrd91.pObj) = (OBJECT_ADDRESS (Wrd66.Obj));
  (Wrd92.Obj) = ((Wrd91.pObj) [0]);
  (Wrd93.Lng) = (FIXNUM_TO_LONG (Wrd92.Obj));
  if (! (((unsigned long) (Wrd90.Lng)) < ((unsigned long) (Wrd93.Lng))))
    goto label_343;
  (Wrd84.uLng) = (OBJECT_DATUM (Wrd87.Obj));
  (Wrd86.pObj) = (& ((Wrd91.pObj) [(Wrd84.Lng)]));
  (Wrd82.Obj) = ((Wrd86.pObj) [1]);

DEFLABEL (label_342)
  (Wrd101.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd100.Obj) = ((Wrd101.pObj) [0]);
  (Wrd102.Obj) = (Rsp [4]);
  if ((Wrd102.Obj) == (Wrd100.Obj))
    goto label_329;

DEFLABEL (label_328)
  (Wrd38.Obj) = (Rsp [3]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 62))
    goto label_327;
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (Wrd37.Lng) = (FIXNUM_TO_LONG (Wrd36.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd37.Lng))))
    goto label_327;
  (Wrd29.Obj) = ((Wrd35.pObj) [6]);

DEFLABEL (label_326)
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd49.uLng) == 10))
    goto label_325;
  (Wrd47.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd48.Obj) = ((Wrd47.pObj) [0]);
  (Wrd45.Obj) = (MAKE_OBJECT (26, (Wrd48.uLng)));

DEFLABEL (label_324)
  (Wrd55.Obj) = (Rsp [0]);
  (Wrd56.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd57.Lng) = ((Wrd56.Lng) + 1L);
  (Wrd54.Obj) = (LONG_TO_FIXNUM (Wrd57.Lng));
  if ((Wrd54.Obj) == (Wrd45.Obj))
    goto label_322;
  Wrd58 = Wrd54;
  goto label_321;

DEFLABEL (label_322)
  (Wrd58.Obj) = (current_block [OBJECT_33_7]);

DEFLABEL (label_321)
DEFLABEL (label_323)
  (Rsp [0]) = (Wrd58.Obj);
  (Wrd63.Obj) = (Rsp [1]);
  (Wrd64.Lng) = (FIXNUM_TO_LONG (Wrd63.Obj));
  (Wrd65.Lng) = ((Wrd64.Lng) + 1L);
  (Wrd62.Obj) = (LONG_TO_FIXNUM (Wrd65.Lng));
  (Rsp [1]) = (Wrd62.Obj);
  goto search_lines_119;

DEFLABEL (label_325)
  (Wrd53.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_69]))));
  (* (--Rsp)) = (Wrd53.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_8]), 1);

DEFLABEL (label_189)
  (Wrd45.Obj) = Rvl;
  goto label_324;

DEFLABEL (label_327)
  (Wrd40.Obj) = (Rsp [3]);
  (Wrd41.Obj) = (current_block [OBJECT_33_3]);
  (Wrd44.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_68]))));
  (* (--Rsp)) = (Wrd44.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd40.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_188)
  (Wrd29.Obj) = Rvl;
  goto label_326;

DEFLABEL (label_329)
  (Wrd112.Obj) = (Rsp [3]);
  (Wrd113.uLng) = (OBJECT_TYPE (Wrd112.Obj));
  if (! ((Wrd113.uLng) == 62))
    goto label_341;
  (Wrd109.pObj) = (OBJECT_ADDRESS (Wrd112.Obj));
  (Wrd110.Obj) = ((Wrd109.pObj) [0]);
  (Wrd111.Lng) = (FIXNUM_TO_LONG (Wrd110.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd111.Lng))))
    goto label_341;
  (Wrd103.Obj) = ((Wrd109.pObj) [6]);

DEFLABEL (label_340)
  (Wrd131.uLng) = (OBJECT_TYPE (Wrd103.Obj));
  if (! ((Wrd131.uLng) == 10))
    goto label_339;
  (Wrd124.Obj) = (Rsp [0]);
  (Wrd125.uLng) = (OBJECT_TYPE (Wrd124.Obj));
  if (! ((Wrd125.uLng) == 26))
    goto label_339;
  (Wrd127.Lng) = (FIXNUM_TO_LONG (Wrd124.Obj));
  (Wrd128.pObj) = (OBJECT_ADDRESS (Wrd103.Obj));
  (Wrd129.Obj) = ((Wrd128.pObj) [0]);
  (Wrd130.Lng) = (FIXNUM_TO_LONG (Wrd129.Obj));
  if (! (((unsigned long) (Wrd127.Lng)) < ((unsigned long) (Wrd130.Lng))))
    goto label_339;
  (Wrd121.uLng) = (OBJECT_DATUM (Wrd124.Obj));
  (Wrd123.pObj) = (& ((Wrd128.pObj) [(Wrd121.Lng)]));
  (Wrd119.Obj) = ((Wrd123.pObj) [1]);

DEFLABEL (label_338)
  (Wrd138.pObj) = (OBJECT_ADDRESS (Wrd119.Obj));
  (Wrd137.Obj) = ((Wrd138.pObj) [1]);
  (Wrd140.pObj) = (OBJECT_ADDRESS (Wrd137.Obj));
  (Wrd139.Obj) = ((Wrd140.pObj) [0]);
  (Wrd141.Obj) = (Rsp [5]);
  if (! ((Wrd141.Obj) == (Wrd139.Obj)))
    goto label_328;
  (Wrd151.Obj) = (Rsp [3]);
  (Wrd152.uLng) = (OBJECT_TYPE (Wrd151.Obj));
  if (! ((Wrd152.uLng) == 62))
    goto label_337;
  (Wrd148.pObj) = (OBJECT_ADDRESS (Wrd151.Obj));
  (Wrd149.Obj) = ((Wrd148.pObj) [0]);
  (Wrd150.Lng) = (FIXNUM_TO_LONG (Wrd149.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd150.Lng))))
    goto label_337;
  (Wrd142.Obj) = ((Wrd148.pObj) [6]);

DEFLABEL (label_336)
  (Wrd170.uLng) = (OBJECT_TYPE (Wrd142.Obj));
  if (! ((Wrd170.uLng) == 10))
    goto label_335;
  (Wrd163.Obj) = (Rsp [0]);
  (Wrd164.uLng) = (OBJECT_TYPE (Wrd163.Obj));
  if (! ((Wrd164.uLng) == 26))
    goto label_335;
  (Wrd166.Lng) = (FIXNUM_TO_LONG (Wrd163.Obj));
  (Wrd167.pObj) = (OBJECT_ADDRESS (Wrd142.Obj));
  (Wrd168.Obj) = ((Wrd167.pObj) [0]);
  (Wrd169.Lng) = (FIXNUM_TO_LONG (Wrd168.Obj));
  if (! (((unsigned long) (Wrd166.Lng)) < ((unsigned long) (Wrd169.Lng))))
    goto label_335;
  (Wrd160.uLng) = (OBJECT_DATUM (Wrd163.Obj));
  (Wrd162.pObj) = (& ((Wrd167.pObj) [(Wrd160.Lng)]));
  (Wrd158.Obj) = ((Wrd162.pObj) [1]);

DEFLABEL (label_334)
  (Wrd177.pObj) = (OBJECT_ADDRESS (Wrd158.Obj));
  (Wrd176.Obj) = ((Wrd177.pObj) [1]);
  (Wrd179.pObj) = (OBJECT_ADDRESS (Wrd176.Obj));
  (Wrd178.Obj) = ((Wrd179.pObj) [1]);
  (Wrd181.pObj) = (OBJECT_ADDRESS (Wrd178.Obj));
  (Wrd180.Obj) = ((Wrd181.pObj) [0]);
  (Wrd182.Obj) = (Rsp [6]);
  if (! ((Wrd182.Obj) == (Wrd180.Obj)))
    goto label_328;
  (Wrd192.Obj) = (Rsp [3]);
  (Wrd193.uLng) = (OBJECT_TYPE (Wrd192.Obj));
  if (! ((Wrd193.uLng) == 62))
    goto label_333;
  (Wrd189.pObj) = (OBJECT_ADDRESS (Wrd192.Obj));
  (Wrd190.Obj) = ((Wrd189.pObj) [0]);
  (Wrd191.Lng) = (FIXNUM_TO_LONG (Wrd190.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd191.Lng))))
    goto label_333;
  (Wrd183.Obj) = ((Wrd189.pObj) [7]);

DEFLABEL (label_332)
  (Rsp [5]) = (Wrd183.Obj);
  (Wrd199.Obj) = (Rsp [0]);
  (Rsp [6]) = (Wrd199.Obj);
  Rsp = (& (Rsp [5]));
  (Wrd215.Obj) = (Rsp [0]);
  (Wrd216.uLng) = (OBJECT_TYPE (Wrd215.Obj));
  if ((Wrd216.uLng) == 10)
    goto label_331;

DEFLABEL (label_330)
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_331)
  (Wrd207.Obj) = (Rsp [1]);
  (Wrd208.uLng) = (OBJECT_TYPE (Wrd207.Obj));
  if (! ((Wrd208.uLng) == 26))
    goto label_330;
  (Wrd210.Lng) = (FIXNUM_TO_LONG (Wrd207.Obj));
  (Wrd212.pObj) = (OBJECT_ADDRESS (Wrd215.Obj));
  (Wrd213.Obj) = ((Wrd212.pObj) [0]);
  (Wrd214.Lng) = (FIXNUM_TO_LONG (Wrd213.Obj));
  if (! (((unsigned long) (Wrd210.Lng)) < ((unsigned long) (Wrd214.Lng))))
    goto label_330;
  (Wrd202.uLng) = (OBJECT_DATUM (Wrd207.Obj));
  (Wrd205.pObj) = (& ((Wrd212.pObj) [(Wrd202.Lng)]));
  Rvl = ((Wrd205.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_333)
  (Wrd194.Obj) = (Rsp [3]);
  (Wrd195.Obj) = (current_block [OBJECT_33_5]);
  (Wrd198.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_67]))));
  (* (--Rsp)) = (Wrd198.Obj);
  (* (--Rsp)) = (Wrd195.Obj);
  (* (--Rsp)) = (Wrd194.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_196)
  (Wrd183.Obj) = Rvl;
  goto label_332;

DEFLABEL (label_335)
  (Wrd172.Obj) = (Rsp [0]);
  (Wrd175.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_66]))));
  (* (--Rsp)) = (Wrd175.Obj);
  (* (--Rsp)) = (Wrd172.Obj);
  (* (--Rsp)) = (Wrd142.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_195)
  (Wrd158.Obj) = Rvl;
  goto label_334;

DEFLABEL (label_337)
  (Wrd153.Obj) = (Rsp [3]);
  (Wrd154.Obj) = (current_block [OBJECT_33_3]);
  (Wrd157.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_65]))));
  (* (--Rsp)) = (Wrd157.Obj);
  (* (--Rsp)) = (Wrd154.Obj);
  (* (--Rsp)) = (Wrd153.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_194)
  (Wrd142.Obj) = Rvl;
  goto label_336;

DEFLABEL (label_339)
  (Wrd133.Obj) = (Rsp [0]);
  (Wrd136.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_64]))));
  (* (--Rsp)) = (Wrd136.Obj);
  (* (--Rsp)) = (Wrd133.Obj);
  (* (--Rsp)) = (Wrd103.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_193)
  (Wrd119.Obj) = Rvl;
  goto label_338;

DEFLABEL (label_341)
  (Wrd114.Obj) = (Rsp [3]);
  (Wrd115.Obj) = (current_block [OBJECT_33_3]);
  (Wrd118.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_63]))));
  (* (--Rsp)) = (Wrd118.Obj);
  (* (--Rsp)) = (Wrd115.Obj);
  (* (--Rsp)) = (Wrd114.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_192)
  (Wrd103.Obj) = Rvl;
  goto label_340;

DEFLABEL (label_343)
  (Wrd96.Obj) = (Rsp [0]);
  (Wrd99.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_62]))));
  (* (--Rsp)) = (Wrd99.Obj);
  (* (--Rsp)) = (Wrd96.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_191)
  (Wrd82.Obj) = Rvl;
  goto label_342;

DEFLABEL (label_345)
  (Wrd77.Obj) = (Rsp [3]);
  (Wrd78.Obj) = (current_block [OBJECT_33_3]);
  (Wrd81.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_61]))));
  (* (--Rsp)) = (Wrd81.Obj);
  (* (--Rsp)) = (Wrd78.Obj);
  (* (--Rsp)) = (Wrd77.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_190)
  (Wrd66.Obj) = Rvl;
  goto label_344;

DEFLABEL (label_347)
  (Wrd227.Obj) = (Rsp [0]);
  (Wrd230.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_60]))));
  (* (--Rsp)) = (Wrd230.Obj);
  (* (--Rsp)) = (Wrd227.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_4]), 2);

DEFLABEL (label_197)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_328;
  goto label_346;

DEFLABEL (label_349)
  (Wrd18.Obj) = (Rsp [3]);
  (Wrd19.Obj) = (current_block [OBJECT_33_3]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_59]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_187)
  (Wrd7.Obj) = Rvl;
  goto label_348;

DEFLABEL (label_350)
  (Wrd241.Obj) = (Rsp [3]);
  (Wrd242.uLng) = (OBJECT_TYPE (Wrd241.Obj));
  if (! ((Wrd242.uLng) == 62))
    goto label_352;
  (Wrd238.pObj) = (OBJECT_ADDRESS (Wrd241.Obj));
  (Wrd239.Obj) = ((Wrd238.pObj) [0]);
  (Wrd240.Lng) = (FIXNUM_TO_LONG (Wrd239.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd240.Lng))))
    goto label_352;
  (Wrd232.Obj) = ((Wrd238.pObj) [8]);

DEFLABEL (label_351)
  (Rsp [2]) = (Wrd232.Obj);
  Rsp = (& (Rsp [2]));
  goto search_overflow_117;

DEFLABEL (label_352)
  (Wrd243.Obj) = (Rsp [3]);
  (Wrd244.Obj) = (current_block [OBJECT_33_9]);
  (Wrd247.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_58]))));
  (* (--Rsp)) = (Wrd247.Obj);
  (* (--Rsp)) = (Wrd244.Obj);
  (* (--Rsp)) = (Wrd243.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_1]), 2);

DEFLABEL (label_198)
  (Wrd232.Obj) = Rvl;
  goto label_351;

DEFLABEL (search_overflow_210)
DEFLABEL (search_overflow_117)
  INTERRUPT_CHECK (26, LABEL_33_70);
  (Wrd5.Obj) = (Rsp [0]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_33_10])))
    goto label_353;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [5]));
  goto pop_return;

DEFLABEL (label_353)
  (Wrd11.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd11.uLng) == 1))
    goto label_372;
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd7.Obj) = ((Wrd9.pObj) [0]);

DEFLABEL (label_371)
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd18.uLng) == 1))
    goto label_370;
  (Wrd17.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd16.Obj) = ((Wrd17.pObj) [0]);

DEFLABEL (label_369)
  (Wrd24.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd23.Obj) = ((Wrd24.pObj) [0]);
  (Wrd25.Obj) = (Rsp [2]);
  if ((Wrd25.Obj) == (Wrd23.Obj))
    goto label_357;

DEFLABEL (label_356)
  (Wrd29.Obj) = (Rsp [0]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 1))
    goto label_355;
  (Wrd28.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd26.Obj) = ((Wrd28.pObj) [1]);

DEFLABEL (label_354)
  (Rsp [0]) = (Wrd26.Obj);
  goto search_overflow_117;

DEFLABEL (label_355)
  (Wrd34.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_78]))));
  (* (--Rsp)) = (Wrd34.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_12]), 1);

DEFLABEL (label_201)
  (Wrd26.Obj) = Rvl;
  goto label_354;

DEFLABEL (label_357)
  (Wrd38.Obj) = (Rsp [0]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 1))
    goto label_368;
  (Wrd37.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd35.Obj) = ((Wrd37.pObj) [0]);

DEFLABEL (label_367)
  (Wrd46.uLng) = (OBJECT_TYPE (Wrd35.Obj));
  if (! ((Wrd46.uLng) == 1))
    goto label_366;
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd35.Obj));
  (Wrd44.Obj) = ((Wrd45.pObj) [0]);

DEFLABEL (label_365)
  (Wrd52.pObj) = (OBJECT_ADDRESS (Wrd44.Obj));
  (Wrd51.Obj) = ((Wrd52.pObj) [1]);
  (Wrd54.pObj) = (OBJECT_ADDRESS (Wrd51.Obj));
  (Wrd53.Obj) = ((Wrd54.pObj) [0]);
  (Wrd55.Obj) = (Rsp [3]);
  if (! ((Wrd55.Obj) == (Wrd53.Obj)))
    goto label_356;
  (Wrd59.Obj) = (Rsp [0]);
  (Wrd60.uLng) = (OBJECT_TYPE (Wrd59.Obj));
  if (! ((Wrd60.uLng) == 1))
    goto label_364;
  (Wrd58.pObj) = (OBJECT_ADDRESS (Wrd59.Obj));
  (Wrd56.Obj) = ((Wrd58.pObj) [0]);

DEFLABEL (label_363)
  (Wrd67.uLng) = (OBJECT_TYPE (Wrd56.Obj));
  if (! ((Wrd67.uLng) == 1))
    goto label_362;
  (Wrd66.pObj) = (OBJECT_ADDRESS (Wrd56.Obj));
  (Wrd65.Obj) = ((Wrd66.pObj) [0]);

DEFLABEL (label_361)
  (Wrd73.pObj) = (OBJECT_ADDRESS (Wrd65.Obj));
  (Wrd72.Obj) = ((Wrd73.pObj) [1]);
  (Wrd75.pObj) = (OBJECT_ADDRESS (Wrd72.Obj));
  (Wrd74.Obj) = ((Wrd75.pObj) [1]);
  (Wrd77.pObj) = (OBJECT_ADDRESS (Wrd74.Obj));
  (Wrd76.Obj) = ((Wrd77.pObj) [0]);
  (Wrd78.Obj) = (Rsp [4]);
  if (! ((Wrd78.Obj) == (Wrd76.Obj)))
    goto label_356;
  (Wrd82.Obj) = (Rsp [0]);
  (Wrd83.uLng) = (OBJECT_TYPE (Wrd82.Obj));
  if (! ((Wrd83.uLng) == 1))
    goto label_360;
  (Wrd81.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd79.Obj) = ((Wrd81.pObj) [0]);

DEFLABEL (label_359)
  (Rsp [4]) = (Wrd79.Obj);
  Rsp = (& (Rsp [4]));
  (Wrd92.Obj) = (Rsp [0]);
  (Wrd93.uLng) = (OBJECT_TYPE (Wrd92.Obj));
  if (! ((Wrd93.uLng) == 1))
    goto label_358;
  (Wrd90.pObj) = (OBJECT_ADDRESS (Wrd92.Obj));
  Rvl = ((Wrd90.pObj) [1]);
  Rsp = (& (Rsp [1]));
  goto pop_return;

DEFLABEL (label_358)
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_12]), 1);

DEFLABEL (label_360)
  (Wrd87.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_77]))));
  (* (--Rsp)) = (Wrd87.Obj);
  (* (--Rsp)) = (Wrd82.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_11]), 1);

DEFLABEL (label_206)
  (Wrd79.Obj) = Rvl;
  goto label_359;

DEFLABEL (label_362)
  (Wrd71.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_76]))));
  (* (--Rsp)) = (Wrd71.Obj);
  (* (--Rsp)) = (Wrd56.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_11]), 1);

DEFLABEL (label_205)
  (Wrd65.Obj) = Rvl;
  goto label_361;

DEFLABEL (label_364)
  (Wrd64.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_75]))));
  (* (--Rsp)) = (Wrd64.Obj);
  (* (--Rsp)) = (Wrd59.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_11]), 1);

DEFLABEL (label_204)
  (Wrd56.Obj) = Rvl;
  goto label_363;

DEFLABEL (label_366)
  (Wrd50.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_74]))));
  (* (--Rsp)) = (Wrd50.Obj);
  (* (--Rsp)) = (Wrd35.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_11]), 1);

DEFLABEL (label_203)
  (Wrd44.Obj) = Rvl;
  goto label_365;

DEFLABEL (label_368)
  (Wrd43.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_73]))));
  (* (--Rsp)) = (Wrd43.Obj);
  (* (--Rsp)) = (Wrd38.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_11]), 1);

DEFLABEL (label_202)
  (Wrd35.Obj) = Rvl;
  goto label_367;

DEFLABEL (label_370)
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_72]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_11]), 1);

DEFLABEL (label_200)
  (Wrd16.Obj) = Rvl;
  goto label_369;

DEFLABEL (label_372)
  (Wrd15.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_33_71]))));
  (* (--Rsp)) = (Wrd15.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_33_11]), 1);

DEFLABEL (label_199)
  (Wrd7.Obj) = Rvl;
  goto label_371;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_34_4 3
#define LABEL_34_5 5
#define LABEL_34_6 7
#define LABEL_34_7 9
#define LABEL_34_8 11
#define LABEL_34_9 13
#define LABEL_34_10 15
#define LABEL_34_11 17
#define LABEL_34_12 19
#define LABEL_34_13 21
#define LABEL_34_14 23
#define LABEL_34_15 25
#define LABEL_34_16 27
#define LABEL_34_17 29
#define LABEL_34_18 31
#define LABEL_34_19 33
#define LABEL_34_20 35
#define LABEL_34_21 37
#define LABEL_34_22 39
#define LABEL_34_23 41
#define LABEL_34_24 43
#define LABEL_34_25 45
#define LABEL_34_26 47
#define LABEL_34_27 49
#define LABEL_34_28 51
#define LABEL_34_29 53
#define LABEL_34_30 55
#define LABEL_34_31 57
#define LABEL_34_32 59
#define LABEL_34_33 61
#define LABEL_34_34 63
#define LABEL_34_35 65
#define LABEL_34_36 67
#define LABEL_34_37 69
#define LABEL_34_38 71
#define LABEL_34_39 73
#define LABEL_34_40 75
#define LABEL_34_41 77
#define LABEL_34_42 79
#define LABEL_34_43 81
#define LABEL_34_44 83
#define LABEL_34_45 85
#define LABEL_34_46 87
#define LABEL_34_47 89
#define LABEL_34_48 91
#define LABEL_34_49 93
#define LABEL_34_50 95
#define LABEL_34_51 97
#define LABEL_34_52 99
#define LABEL_34_53 101
#define LABEL_34_54 103
#define LABEL_34_55 105
#define LABEL_34_56 107
#define LABEL_34_57 109
#define LABEL_34_58 111
#define LABEL_34_59 113
#define LABEL_34_60 115
#define LABEL_34_61 117
#define LABEL_34_62 119
#define LABEL_34_63 121
#define LABEL_34_64 123
#define LABEL_34_65 125
#define LABEL_34_66 127
#define LABEL_34_67 129
#define LABEL_34_68 131
#define LABEL_34_69 133
#define LABEL_34_70 135
#define LABEL_34_71 137
#define LABEL_34_72 139
#define LABEL_34_73 141
#define LABEL_34_74 143
#define LABEL_34_75 145
#define LABEL_34_76 147
#define LABEL_34_77 149
#define LABEL_34_78 151
#define LABEL_34_79 153
#define LABEL_34_80 155
#define LABEL_34_81 157
#define LABEL_34_82 159
#define LABEL_34_83 161
#define LABEL_34_84 163
#define LABEL_34_85 165
#define LABEL_34_86 167
#define LABEL_34_87 169
#define LABEL_34_88 171
#define LABEL_34_89 173
#define LABEL_34_90 175
#define LABEL_34_91 177
#define LABEL_34_92 179
#define LABEL_34_93 181
#define LABEL_34_94 183
#define LABEL_34_95 185
#define LABEL_34_96 187
#define LABEL_34_97 189
#define LABEL_34_98 191
#define LABEL_34_99 193
#define LABEL_34_100 195
#define LABEL_34_101 197
#define LABEL_34_102 199
#define LABEL_34_103 201
#define LABEL_34_104 203
#define LABEL_34_105 205
#define ENVIRONMENT_LABEL_34_3 220
#define DEBUGGING_LABEL_34_2 219
#define OBJECT_34_12 218
#define OBJECT_34_11 217
#define OBJECT_34_10 216
#define OBJECT_34_9 215
#define OBJECT_34_8 214
#define OBJECT_34_7 213
#define OBJECT_34_6 212
#define OBJECT_34_5 211
#define OBJECT_34_4 210
#define OBJECT_34_3 209
#define OBJECT_34_2 208
#define OBJECT_34_1 207
#define OBJECT_34_0 206
#define FREE_REFERENCES_LABEL_34_0 206
#define NUMBER_OF_LINKER_SECTIONS_34_1 0

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_34 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd34;
  machine_word Wrd117;
  machine_word Wrd108;
  machine_word Wrd107;
  machine_word Wrd97;
  machine_word Wrd98;
  machine_word Wrd95;
  machine_word Wrd60;
  machine_word Wrd59;
  machine_word Wrd51;
  machine_word Wrd52;
  machine_word Wrd25;
  machine_word Wrd23;
  machine_word Wrd9;
  machine_word Wrd58;
  machine_word Wrd57;
  machine_word Wrd56;
  machine_word Wrd53;
  machine_word Wrd44;
  machine_word Wrd35;
  machine_word Wrd39;
  machine_word Wrd38;
  machine_word Wrd245;
  machine_word Wrd257;
  machine_word Wrd255;
  machine_word Wrd251;
  machine_word Wrd250;
  machine_word Wrd259;
  machine_word Wrd258;
  machine_word Wrd242;
  machine_word Wrd226;
  machine_word Wrd234;
  machine_word Wrd233;
  machine_word Wrd232;
  machine_word Wrd225;
  machine_word Wrd217;
  machine_word Wrd216;
  machine_word Wrd213;
  machine_word Wrd207;
  machine_word Wrd205;
  machine_word Wrd204;
  machine_word Wrd191;
  machine_word Wrd190;
  machine_word Wrd182;
  machine_word Wrd180;
  machine_word Wrd181;
  machine_word Wrd178;
  machine_word Wrd179;
  machine_word Wrd158;
  machine_word Wrd160;
  machine_word Wrd168;
  machine_word Wrd163;
  machine_word Wrd142;
  machine_word Wrd151;
  machine_word Wrd141;
  machine_word Wrd133;
  machine_word Wrd130;
  machine_word Wrd129;
  machine_word Wrd125;
  machine_word Wrd124;
  machine_word Wrd131;
  machine_word Wrd111;
  machine_word Wrd112;
  machine_word Wrd99;
  machine_word Wrd96;
  machine_word Wrd86;
  machine_word Wrd87;
  machine_word Wrd78;
  machine_word Wrd74;
  machine_word Wrd73;
  machine_word Wrd273;
  machine_word Wrd26;
  machine_word Wrd24;
  machine_word Wrd267;
  machine_word Wrd268;
  machine_word Wrd22;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd287;
  machine_word Wrd275;
  machine_word Wrd283;
  machine_word Wrd284;
  machine_word Wrd6;
  machine_word Wrd5;
  machine_word Wrd604;
  machine_word Wrd603;
  machine_word Wrd602;
  machine_word Wrd600;
  machine_word Wrd599;
  machine_word Wrd597;
  machine_word Wrd596;
  machine_word Wrd595;
  machine_word Wrd594;
  machine_word Wrd592;
  machine_word Wrd591;
  machine_word Wrd590;
  machine_word Wrd589;
  machine_word Wrd587;
  machine_word Wrd586;
  machine_word Wrd582;
  machine_word Wrd569;
  machine_word Wrd573;
  machine_word Wrd570;
  machine_word Wrd579;
  machine_word Wrd578;
  machine_word Wrd577;
  machine_word Wrd575;
  machine_word Wrd574;
  machine_word Wrd581;
  machine_word Wrd580;
  machine_word Wrd568;
  machine_word Wrd565;
  machine_word Wrd564;
  machine_word Wrd553;
  machine_word Wrd561;
  machine_word Wrd560;
  machine_word Wrd559;
  machine_word Wrd563;
  machine_word Wrd562;
  machine_word Wrd552;
  machine_word Wrd548;
  machine_word Wrd539;
  machine_word Wrd538;
  machine_word Wrd535;
  machine_word Wrd545;
  machine_word Wrd544;
  machine_word Wrd543;
  machine_word Wrd541;
  machine_word Wrd540;
  machine_word Wrd547;
  machine_word Wrd546;
  machine_word Wrd534;
  machine_word Wrd531;
  machine_word Wrd530;
  machine_word Wrd519;
  machine_word Wrd527;
  machine_word Wrd526;
  machine_word Wrd525;
  machine_word Wrd529;
  machine_word Wrd528;
  machine_word Wrd518;
  machine_word Wrd517;
  machine_word Wrd516;
  machine_word Wrd515;
  machine_word Wrd514;
  machine_word Wrd513;
  machine_word Wrd509;
  machine_word Wrd496;
  machine_word Wrd500;
  machine_word Wrd497;
  machine_word Wrd506;
  machine_word Wrd505;
  machine_word Wrd504;
  machine_word Wrd502;
  machine_word Wrd501;
  machine_word Wrd508;
  machine_word Wrd507;
  machine_word Wrd495;
  machine_word Wrd492;
  machine_word Wrd491;
  machine_word Wrd480;
  machine_word Wrd488;
  machine_word Wrd487;
  machine_word Wrd486;
  machine_word Wrd490;
  machine_word Wrd489;
  machine_word Wrd479;
  machine_word Wrd475;
  machine_word Wrd466;
  machine_word Wrd465;
  machine_word Wrd462;
  machine_word Wrd472;
  machine_word Wrd471;
  machine_word Wrd470;
  machine_word Wrd468;
  machine_word Wrd467;
  machine_word Wrd474;
  machine_word Wrd473;
  machine_word Wrd461;
  machine_word Wrd458;
  machine_word Wrd457;
  machine_word Wrd446;
  machine_word Wrd454;
  machine_word Wrd453;
  machine_word Wrd452;
  machine_word Wrd456;
  machine_word Wrd455;
  machine_word Wrd445;
  machine_word Wrd442;
  machine_word Wrd441;
  machine_word Wrd432;
  machine_word Wrd438;
  machine_word Wrd437;
  machine_word Wrd436;
  machine_word Wrd440;
  machine_word Wrd439;
  machine_word Wrd605;
  machine_word Wrd429;
  machine_word Wrd426;
  machine_word Wrd428;
  machine_word Wrd427;
  machine_word Wrd424;
  machine_word Wrd423;
  machine_word Wrd421;
  machine_word Wrd420;
  machine_word Wrd419;
  machine_word Wrd418;
  machine_word Wrd416;
  machine_word Wrd415;
  machine_word Wrd414;
  machine_word Wrd413;
  machine_word Wrd411;
  machine_word Wrd410;
  machine_word Wrd406;
  machine_word Wrd393;
  machine_word Wrd397;
  machine_word Wrd394;
  machine_word Wrd403;
  machine_word Wrd402;
  machine_word Wrd401;
  machine_word Wrd399;
  machine_word Wrd398;
  machine_word Wrd405;
  machine_word Wrd404;
  machine_word Wrd392;
  machine_word Wrd389;
  machine_word Wrd388;
  machine_word Wrd377;
  machine_word Wrd385;
  machine_word Wrd384;
  machine_word Wrd383;
  machine_word Wrd387;
  machine_word Wrd386;
  machine_word Wrd376;
  machine_word Wrd372;
  machine_word Wrd363;
  machine_word Wrd362;
  machine_word Wrd359;
  machine_word Wrd369;
  machine_word Wrd368;
  machine_word Wrd367;
  machine_word Wrd365;
  machine_word Wrd364;
  machine_word Wrd371;
  machine_word Wrd370;
  machine_word Wrd358;
  machine_word Wrd355;
  machine_word Wrd354;
  machine_word Wrd343;
  machine_word Wrd351;
  machine_word Wrd350;
  machine_word Wrd349;
  machine_word Wrd353;
  machine_word Wrd352;
  machine_word Wrd342;
  machine_word Wrd341;
  machine_word Wrd340;
  machine_word Wrd339;
  machine_word Wrd338;
  machine_word Wrd337;
  machine_word Wrd333;
  machine_word Wrd320;
  machine_word Wrd324;
  machine_word Wrd321;
  machine_word Wrd330;
  machine_word Wrd329;
  machine_word Wrd328;
  machine_word Wrd326;
  machine_word Wrd325;
  machine_word Wrd332;
  machine_word Wrd331;
  machine_word Wrd319;
  machine_word Wrd316;
  machine_word Wrd315;
  machine_word Wrd304;
  machine_word Wrd312;
  machine_word Wrd311;
  machine_word Wrd310;
  machine_word Wrd314;
  machine_word Wrd313;
  machine_word Wrd303;
  machine_word Wrd299;
  machine_word Wrd290;
  machine_word Wrd289;
  machine_word Wrd286;
  machine_word Wrd296;
  machine_word Wrd295;
  machine_word Wrd294;
  machine_word Wrd292;
  machine_word Wrd291;
  machine_word Wrd298;
  machine_word Wrd297;
  machine_word Wrd285;
  machine_word Wrd282;
  machine_word Wrd281;
  machine_word Wrd270;
  machine_word Wrd278;
  machine_word Wrd277;
  machine_word Wrd276;
  machine_word Wrd280;
  machine_word Wrd279;
  machine_word Wrd269;
  machine_word Wrd266;
  machine_word Wrd265;
  machine_word Wrd256;
  machine_word Wrd262;
  machine_word Wrd261;
  machine_word Wrd260;
  machine_word Wrd264;
  machine_word Wrd263;
  machine_word Wrd253;
  machine_word Wrd248;
  machine_word Wrd247;
  machine_word Wrd246;
  machine_word Wrd249;
  machine_word Wrd244;
  machine_word Wrd241;
  machine_word Wrd240;
  machine_word Wrd229;
  machine_word Wrd237;
  machine_word Wrd236;
  machine_word Wrd235;
  machine_word Wrd239;
  machine_word Wrd238;
  machine_word Wrd228;
  machine_word Wrd227;
  machine_word Wrd224;
  machine_word Wrd223;
  machine_word Wrd214;
  machine_word Wrd220;
  machine_word Wrd219;
  machine_word Wrd218;
  machine_word Wrd222;
  machine_word Wrd221;
  machine_word Wrd1432;
  machine_word Wrd1429;
  machine_word Wrd1441;
  machine_word Wrd1440;
  machine_word Wrd1439;
  machine_word Wrd1437;
  machine_word Wrd1435;
  machine_word Wrd1434;
  machine_word Wrd1443;
  machine_word Wrd1442;
  machine_word Wrd1426;
  machine_word Wrd1423;
  machine_word Wrd1422;
  machine_word Wrd1411;
  machine_word Wrd1419;
  machine_word Wrd1418;
  machine_word Wrd1417;
  machine_word Wrd1421;
  machine_word Wrd1420;
  machine_word Wrd1407;
  machine_word Wrd1410;
  machine_word Wrd1409;
  machine_word Wrd1408;
  machine_word Wrd1406;
  machine_word Wrd1405;
  machine_word Wrd1404;
  machine_word Wrd1403;
  machine_word Wrd1401;
  machine_word Wrd1400;
  machine_word Wrd1399;
  machine_word Wrd1398;
  machine_word Wrd1396;
  machine_word Wrd1395;
  machine_word Wrd1391;
  machine_word Wrd1378;
  machine_word Wrd1382;
  machine_word Wrd1379;
  machine_word Wrd1388;
  machine_word Wrd1387;
  machine_word Wrd1386;
  machine_word Wrd1384;
  machine_word Wrd1383;
  machine_word Wrd1390;
  machine_word Wrd1389;
  machine_word Wrd1377;
  machine_word Wrd1374;
  machine_word Wrd1373;
  machine_word Wrd1362;
  machine_word Wrd1370;
  machine_word Wrd1369;
  machine_word Wrd1368;
  machine_word Wrd1372;
  machine_word Wrd1371;
  machine_word Wrd1361;
  machine_word Wrd1357;
  machine_word Wrd1348;
  machine_word Wrd1347;
  machine_word Wrd1344;
  machine_word Wrd1354;
  machine_word Wrd1353;
  machine_word Wrd1352;
  machine_word Wrd1350;
  machine_word Wrd1349;
  machine_word Wrd1356;
  machine_word Wrd1355;
  machine_word Wrd1343;
  machine_word Wrd1340;
  machine_word Wrd1339;
  machine_word Wrd1328;
  machine_word Wrd1336;
  machine_word Wrd1335;
  machine_word Wrd1334;
  machine_word Wrd1338;
  machine_word Wrd1337;
  machine_word Wrd1327;
  machine_word Wrd1326;
  machine_word Wrd1325;
  machine_word Wrd1324;
  machine_word Wrd1323;
  machine_word Wrd1322;
  machine_word Wrd1318;
  machine_word Wrd1305;
  machine_word Wrd1309;
  machine_word Wrd1306;
  machine_word Wrd1315;
  machine_word Wrd1314;
  machine_word Wrd1313;
  machine_word Wrd1311;
  machine_word Wrd1310;
  machine_word Wrd1317;
  machine_word Wrd1316;
  machine_word Wrd1304;
  machine_word Wrd1301;
  machine_word Wrd1300;
  machine_word Wrd1289;
  machine_word Wrd1297;
  machine_word Wrd1296;
  machine_word Wrd1295;
  machine_word Wrd1299;
  machine_word Wrd1298;
  machine_word Wrd1288;
  machine_word Wrd1284;
  machine_word Wrd1275;
  machine_word Wrd1274;
  machine_word Wrd1271;
  machine_word Wrd1281;
  machine_word Wrd1280;
  machine_word Wrd1279;
  machine_word Wrd1277;
  machine_word Wrd1276;
  machine_word Wrd1283;
  machine_word Wrd1282;
  machine_word Wrd1270;
  machine_word Wrd1267;
  machine_word Wrd1266;
  machine_word Wrd1255;
  machine_word Wrd1263;
  machine_word Wrd1262;
  machine_word Wrd1261;
  machine_word Wrd1265;
  machine_word Wrd1264;
  machine_word Wrd1254;
  machine_word Wrd1251;
  machine_word Wrd1250;
  machine_word Wrd1241;
  machine_word Wrd1247;
  machine_word Wrd1246;
  machine_word Wrd1245;
  machine_word Wrd1249;
  machine_word Wrd1248;
  machine_word Wrd1238;
  machine_word Wrd1236;
  machine_word Wrd1237;
  machine_word Wrd1234;
  machine_word Wrd1235;
  machine_word Wrd1232;
  machine_word Wrd1233;
  machine_word Wrd1230;
  machine_word Wrd1231;
  machine_word Wrd1229;
  machine_word Wrd1215;
  machine_word Wrd1218;
  machine_word Wrd1216;
  machine_word Wrd1223;
  machine_word Wrd1222;
  machine_word Wrd1221;
  machine_word Wrd1220;
  machine_word Wrd1219;
  machine_word Wrd1224;
  machine_word Wrd1214;
  machine_word Wrd1213;
  machine_word Wrd1210;
  machine_word Wrd1209;
  machine_word Wrd1198;
  machine_word Wrd1206;
  machine_word Wrd1205;
  machine_word Wrd1204;
  machine_word Wrd1208;
  machine_word Wrd1207;
  machine_word Wrd1197;
  machine_word Wrd1196;
  machine_word Wrd1195;
  machine_word Wrd1194;
  machine_word Wrd1193;
  machine_word Wrd1192;
  machine_word Wrd1191;
  machine_word Wrd1190;
  machine_word Wrd1188;
  machine_word Wrd1187;
  machine_word Wrd1186;
  machine_word Wrd1185;
  machine_word Wrd1183;
  machine_word Wrd1182;
  machine_word Wrd1178;
  machine_word Wrd1165;
  machine_word Wrd1169;
  machine_word Wrd1166;
  machine_word Wrd1175;
  machine_word Wrd1174;
  machine_word Wrd1173;
  machine_word Wrd1171;
  machine_word Wrd1170;
  machine_word Wrd1177;
  machine_word Wrd1176;
  machine_word Wrd1164;
  machine_word Wrd1161;
  machine_word Wrd1160;
  machine_word Wrd1149;
  machine_word Wrd1157;
  machine_word Wrd1156;
  machine_word Wrd1155;
  machine_word Wrd1159;
  machine_word Wrd1158;
  machine_word Wrd1148;
  machine_word Wrd1144;
  machine_word Wrd1135;
  machine_word Wrd1134;
  machine_word Wrd1131;
  machine_word Wrd1141;
  machine_word Wrd1140;
  machine_word Wrd1139;
  machine_word Wrd1137;
  machine_word Wrd1136;
  machine_word Wrd1143;
  machine_word Wrd1142;
  machine_word Wrd1130;
  machine_word Wrd1127;
  machine_word Wrd1126;
  machine_word Wrd1115;
  machine_word Wrd1123;
  machine_word Wrd1122;
  machine_word Wrd1121;
  machine_word Wrd1125;
  machine_word Wrd1124;
  machine_word Wrd1114;
  machine_word Wrd1113;
  machine_word Wrd1112;
  machine_word Wrd1111;
  machine_word Wrd1110;
  machine_word Wrd1109;
  machine_word Wrd1105;
  machine_word Wrd1092;
  machine_word Wrd1096;
  machine_word Wrd1093;
  machine_word Wrd1102;
  machine_word Wrd1101;
  machine_word Wrd1100;
  machine_word Wrd1098;
  machine_word Wrd1097;
  machine_word Wrd1104;
  machine_word Wrd1103;
  machine_word Wrd1091;
  machine_word Wrd1088;
  machine_word Wrd1087;
  machine_word Wrd1076;
  machine_word Wrd1084;
  machine_word Wrd1083;
  machine_word Wrd1082;
  machine_word Wrd1086;
  machine_word Wrd1085;
  machine_word Wrd1075;
  machine_word Wrd1071;
  machine_word Wrd1062;
  machine_word Wrd1061;
  machine_word Wrd1058;
  machine_word Wrd1068;
  machine_word Wrd1067;
  machine_word Wrd1066;
  machine_word Wrd1064;
  machine_word Wrd1063;
  machine_word Wrd1070;
  machine_word Wrd1069;
  machine_word Wrd1057;
  machine_word Wrd1054;
  machine_word Wrd1053;
  machine_word Wrd1042;
  machine_word Wrd1050;
  machine_word Wrd1049;
  machine_word Wrd1048;
  machine_word Wrd1052;
  machine_word Wrd1051;
  machine_word Wrd1041;
  machine_word Wrd1038;
  machine_word Wrd1037;
  machine_word Wrd1028;
  machine_word Wrd1034;
  machine_word Wrd1033;
  machine_word Wrd1032;
  machine_word Wrd1036;
  machine_word Wrd1035;
  machine_word Wrd1025;
  machine_word Wrd1023;
  machine_word Wrd1024;
  machine_word Wrd1021;
  machine_word Wrd1022;
  machine_word Wrd1019;
  machine_word Wrd1020;
  machine_word Wrd1018;
  machine_word Wrd1004;
  machine_word Wrd1007;
  machine_word Wrd1005;
  machine_word Wrd1012;
  machine_word Wrd1011;
  machine_word Wrd1010;
  machine_word Wrd1009;
  machine_word Wrd1008;
  machine_word Wrd1013;
  machine_word Wrd1003;
  machine_word Wrd1002;
  machine_word Wrd999;
  machine_word Wrd998;
  machine_word Wrd987;
  machine_word Wrd995;
  machine_word Wrd994;
  machine_word Wrd993;
  machine_word Wrd997;
  machine_word Wrd996;
  machine_word Wrd986;
  machine_word Wrd985;
  machine_word Wrd984;
  machine_word Wrd983;
  machine_word Wrd982;
  machine_word Wrd981;
  machine_word Wrd980;
  machine_word Wrd979;
  machine_word Wrd977;
  machine_word Wrd976;
  machine_word Wrd975;
  machine_word Wrd974;
  machine_word Wrd972;
  machine_word Wrd971;
  machine_word Wrd967;
  machine_word Wrd954;
  machine_word Wrd958;
  machine_word Wrd955;
  machine_word Wrd964;
  machine_word Wrd963;
  machine_word Wrd962;
  machine_word Wrd960;
  machine_word Wrd959;
  machine_word Wrd966;
  machine_word Wrd965;
  machine_word Wrd953;
  machine_word Wrd950;
  machine_word Wrd949;
  machine_word Wrd938;
  machine_word Wrd946;
  machine_word Wrd945;
  machine_word Wrd944;
  machine_word Wrd948;
  machine_word Wrd947;
  machine_word Wrd937;
  machine_word Wrd933;
  machine_word Wrd924;
  machine_word Wrd923;
  machine_word Wrd920;
  machine_word Wrd930;
  machine_word Wrd929;
  machine_word Wrd928;
  machine_word Wrd926;
  machine_word Wrd925;
  machine_word Wrd932;
  machine_word Wrd931;
  machine_word Wrd919;
  machine_word Wrd916;
  machine_word Wrd915;
  machine_word Wrd904;
  machine_word Wrd912;
  machine_word Wrd911;
  machine_word Wrd910;
  machine_word Wrd914;
  machine_word Wrd913;
  machine_word Wrd903;
  machine_word Wrd902;
  machine_word Wrd901;
  machine_word Wrd900;
  machine_word Wrd899;
  machine_word Wrd898;
  machine_word Wrd894;
  machine_word Wrd881;
  machine_word Wrd885;
  machine_word Wrd882;
  machine_word Wrd891;
  machine_word Wrd890;
  machine_word Wrd889;
  machine_word Wrd887;
  machine_word Wrd886;
  machine_word Wrd893;
  machine_word Wrd892;
  machine_word Wrd880;
  machine_word Wrd877;
  machine_word Wrd876;
  machine_word Wrd865;
  machine_word Wrd873;
  machine_word Wrd872;
  machine_word Wrd871;
  machine_word Wrd875;
  machine_word Wrd874;
  machine_word Wrd864;
  machine_word Wrd860;
  machine_word Wrd851;
  machine_word Wrd850;
  machine_word Wrd847;
  machine_word Wrd857;
  machine_word Wrd856;
  machine_word Wrd855;
  machine_word Wrd853;
  machine_word Wrd852;
  machine_word Wrd859;
  machine_word Wrd858;
  machine_word Wrd846;
  machine_word Wrd843;
  machine_word Wrd842;
  machine_word Wrd831;
  machine_word Wrd839;
  machine_word Wrd838;
  machine_word Wrd837;
  machine_word Wrd841;
  machine_word Wrd840;
  machine_word Wrd830;
  machine_word Wrd827;
  machine_word Wrd826;
  machine_word Wrd817;
  machine_word Wrd823;
  machine_word Wrd822;
  machine_word Wrd821;
  machine_word Wrd825;
  machine_word Wrd824;
  machine_word Wrd814;
  machine_word Wrd812;
  machine_word Wrd813;
  machine_word Wrd810;
  machine_word Wrd811;
  machine_word Wrd809;
  machine_word Wrd795;
  machine_word Wrd798;
  machine_word Wrd796;
  machine_word Wrd803;
  machine_word Wrd802;
  machine_word Wrd801;
  machine_word Wrd800;
  machine_word Wrd799;
  machine_word Wrd804;
  machine_word Wrd794;
  machine_word Wrd793;
  machine_word Wrd790;
  machine_word Wrd789;
  machine_word Wrd778;
  machine_word Wrd786;
  machine_word Wrd785;
  machine_word Wrd784;
  machine_word Wrd788;
  machine_word Wrd787;
  machine_word Wrd777;
  machine_word Wrd776;
  machine_word Wrd775;
  machine_word Wrd774;
  machine_word Wrd773;
  machine_word Wrd772;
  machine_word Wrd771;
  machine_word Wrd770;
  machine_word Wrd768;
  machine_word Wrd767;
  machine_word Wrd766;
  machine_word Wrd765;
  machine_word Wrd763;
  machine_word Wrd762;
  machine_word Wrd758;
  machine_word Wrd745;
  machine_word Wrd749;
  machine_word Wrd746;
  machine_word Wrd755;
  machine_word Wrd754;
  machine_word Wrd753;
  machine_word Wrd751;
  machine_word Wrd750;
  machine_word Wrd757;
  machine_word Wrd756;
  machine_word Wrd744;
  machine_word Wrd741;
  machine_word Wrd740;
  machine_word Wrd729;
  machine_word Wrd737;
  machine_word Wrd736;
  machine_word Wrd735;
  machine_word Wrd739;
  machine_word Wrd738;
  machine_word Wrd728;
  machine_word Wrd724;
  machine_word Wrd715;
  machine_word Wrd714;
  machine_word Wrd711;
  machine_word Wrd721;
  machine_word Wrd720;
  machine_word Wrd719;
  machine_word Wrd717;
  machine_word Wrd716;
  machine_word Wrd723;
  machine_word Wrd722;
  machine_word Wrd710;
  machine_word Wrd707;
  machine_word Wrd706;
  machine_word Wrd695;
  machine_word Wrd703;
  machine_word Wrd702;
  machine_word Wrd701;
  machine_word Wrd705;
  machine_word Wrd704;
  machine_word Wrd694;
  machine_word Wrd693;
  machine_word Wrd692;
  machine_word Wrd691;
  machine_word Wrd690;
  machine_word Wrd689;
  machine_word Wrd685;
  machine_word Wrd672;
  machine_word Wrd676;
  machine_word Wrd673;
  machine_word Wrd682;
  machine_word Wrd681;
  machine_word Wrd680;
  machine_word Wrd678;
  machine_word Wrd677;
  machine_word Wrd684;
  machine_word Wrd683;
  machine_word Wrd671;
  machine_word Wrd668;
  machine_word Wrd667;
  machine_word Wrd656;
  machine_word Wrd664;
  machine_word Wrd663;
  machine_word Wrd662;
  machine_word Wrd666;
  machine_word Wrd665;
  machine_word Wrd655;
  machine_word Wrd651;
  machine_word Wrd642;
  machine_word Wrd641;
  machine_word Wrd638;
  machine_word Wrd648;
  machine_word Wrd647;
  machine_word Wrd646;
  machine_word Wrd644;
  machine_word Wrd643;
  machine_word Wrd650;
  machine_word Wrd649;
  machine_word Wrd637;
  machine_word Wrd634;
  machine_word Wrd633;
  machine_word Wrd622;
  machine_word Wrd630;
  machine_word Wrd629;
  machine_word Wrd628;
  machine_word Wrd632;
  machine_word Wrd631;
  machine_word Wrd621;
  machine_word Wrd618;
  machine_word Wrd617;
  machine_word Wrd608;
  machine_word Wrd614;
  machine_word Wrd613;
  machine_word Wrd612;
  machine_word Wrd616;
  machine_word Wrd615;
  machine_word Wrd211;
  machine_word Wrd209;
  machine_word Wrd210;
  machine_word Wrd208;
  machine_word Wrd194;
  machine_word Wrd197;
  machine_word Wrd195;
  machine_word Wrd202;
  machine_word Wrd201;
  machine_word Wrd200;
  machine_word Wrd199;
  machine_word Wrd198;
  machine_word Wrd203;
  machine_word Wrd193;
  machine_word Wrd192;
  machine_word Wrd189;
  machine_word Wrd188;
  machine_word Wrd177;
  machine_word Wrd185;
  machine_word Wrd184;
  machine_word Wrd183;
  machine_word Wrd187;
  machine_word Wrd186;
  machine_word Wrd176;
  machine_word Wrd175;
  machine_word Wrd174;
  machine_word Wrd173;
  machine_word Wrd172;
  machine_word Wrd171;
  machine_word Wrd170;
  machine_word Wrd169;
  machine_word Wrd167;
  machine_word Wrd166;
  machine_word Wrd165;
  machine_word Wrd164;
  machine_word Wrd162;
  machine_word Wrd161;
  machine_word Wrd157;
  machine_word Wrd144;
  machine_word Wrd148;
  machine_word Wrd145;
  machine_word Wrd154;
  machine_word Wrd153;
  machine_word Wrd152;
  machine_word Wrd150;
  machine_word Wrd149;
  machine_word Wrd156;
  machine_word Wrd155;
  machine_word Wrd143;
  machine_word Wrd140;
  machine_word Wrd139;
  machine_word Wrd128;
  machine_word Wrd136;
  machine_word Wrd135;
  machine_word Wrd134;
  machine_word Wrd138;
  machine_word Wrd137;
  machine_word Wrd127;
  machine_word Wrd123;
  machine_word Wrd114;
  machine_word Wrd113;
  machine_word Wrd110;
  machine_word Wrd120;
  machine_word Wrd119;
  machine_word Wrd118;
  machine_word Wrd116;
  machine_word Wrd115;
  machine_word Wrd122;
  machine_word Wrd121;
  machine_word Wrd109;
  machine_word Wrd106;
  machine_word Wrd105;
  machine_word Wrd94;
  machine_word Wrd102;
  machine_word Wrd101;
  machine_word Wrd100;
  machine_word Wrd104;
  machine_word Wrd103;
  machine_word Wrd93;
  machine_word Wrd92;
  machine_word Wrd91;
  machine_word Wrd90;
  machine_word Wrd89;
  machine_word Wrd88;
  machine_word Wrd84;
  machine_word Wrd71;
  machine_word Wrd75;
  machine_word Wrd72;
  machine_word Wrd81;
  machine_word Wrd80;
  machine_word Wrd79;
  machine_word Wrd77;
  machine_word Wrd76;
  machine_word Wrd83;
  machine_word Wrd82;
  machine_word Wrd70;
  machine_word Wrd67;
  machine_word Wrd66;
  machine_word Wrd55;
  machine_word Wrd63;
  machine_word Wrd62;
  machine_word Wrd61;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd54;
  machine_word Wrd50;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd37;
  machine_word Wrd47;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd43;
  machine_word Wrd42;
  machine_word Wrd49;
  machine_word Wrd48;
  machine_word Wrd36;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd21;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd27;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd7;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_34_4);
      goto probe_cache_4_185;

    case 1:
      current_block = (Rpc - LABEL_34_5);
      goto label_187;

    case 2:
      current_block = (Rpc - LABEL_34_6);
      goto label_188;

    case 3:
      current_block = (Rpc - LABEL_34_7);
      goto label_189;

    case 4:
      current_block = (Rpc - LABEL_34_8);
      goto label_190;

    case 5:
      current_block = (Rpc - LABEL_34_9);
      goto label_191;

    case 6:
      current_block = (Rpc - LABEL_34_10);
      goto label_192;

    case 7:
      current_block = (Rpc - LABEL_34_11);
      goto label_193;

    case 8:
      current_block = (Rpc - LABEL_34_12);
      goto label_194;

    case 9:
      current_block = (Rpc - LABEL_34_13);
      goto label_195;

    case 10:
      current_block = (Rpc - LABEL_34_14);
      goto label_196;

    case 11:
      current_block = (Rpc - LABEL_34_15);
      goto label_197;

    case 12:
      current_block = (Rpc - LABEL_34_16);
      goto label_219;

    case 13:
      current_block = (Rpc - LABEL_34_17);
      goto label_220;

    case 14:
      current_block = (Rpc - LABEL_34_18);
      goto label_221;

    case 15:
      current_block = (Rpc - LABEL_34_19);
      goto label_222;

    case 16:
      current_block = (Rpc - LABEL_34_20);
      goto label_223;

    case 17:
      current_block = (Rpc - LABEL_34_21);
      goto label_224;

    case 18:
      current_block = (Rpc - LABEL_34_22);
      goto label_225;

    case 19:
      current_block = (Rpc - LABEL_34_23);
      goto label_226;

    case 20:
      current_block = (Rpc - LABEL_34_24);
      goto label_227;

    case 21:
      current_block = (Rpc - LABEL_34_25);
      goto label_228;

    case 22:
      current_block = (Rpc - LABEL_34_26);
      goto label_229;

    case 23:
      current_block = (Rpc - LABEL_34_27);
      goto label_230;

    case 24:
      current_block = (Rpc - LABEL_34_28);
      goto label_231;

    case 25:
      current_block = (Rpc - LABEL_34_29);
      goto label_232;

    case 26:
      current_block = (Rpc - LABEL_34_30);
      goto label_233;

    case 27:
      current_block = (Rpc - LABEL_34_31);
      goto label_234;

    case 28:
      current_block = (Rpc - LABEL_34_32);
      goto label_235;

    case 29:
      current_block = (Rpc - LABEL_34_33);
      goto label_236;

    case 30:
      current_block = (Rpc - LABEL_34_34);
      goto label_237;

    case 31:
      current_block = (Rpc - LABEL_34_35);
      goto label_238;

    case 32:
      current_block = (Rpc - LABEL_34_36);
      goto label_239;

    case 33:
      current_block = (Rpc - LABEL_34_37);
      goto label_240;

    case 34:
      current_block = (Rpc - LABEL_34_38);
      goto label_241;

    case 35:
      current_block = (Rpc - LABEL_34_39);
      goto label_242;

    case 36:
      current_block = (Rpc - LABEL_34_40);
      goto label_243;

    case 37:
      current_block = (Rpc - LABEL_34_41);
      goto label_244;

    case 38:
      current_block = (Rpc - LABEL_34_42);
      goto label_245;

    case 39:
      current_block = (Rpc - LABEL_34_43);
      goto label_246;

    case 40:
      current_block = (Rpc - LABEL_34_44);
      goto label_247;

    case 41:
      current_block = (Rpc - LABEL_34_45);
      goto label_248;

    case 42:
      current_block = (Rpc - LABEL_34_46);
      goto label_249;

    case 43:
      current_block = (Rpc - LABEL_34_47);
      goto label_250;

    case 44:
      current_block = (Rpc - LABEL_34_48);
      goto label_251;

    case 45:
      current_block = (Rpc - LABEL_34_49);
      goto label_252;

    case 46:
      current_block = (Rpc - LABEL_34_50);
      goto label_253;

    case 47:
      current_block = (Rpc - LABEL_34_51);
      goto label_254;

    case 48:
      current_block = (Rpc - LABEL_34_52);
      goto label_255;

    case 49:
      current_block = (Rpc - LABEL_34_53);
      goto label_256;

    case 50:
      current_block = (Rpc - LABEL_34_54);
      goto label_257;

    case 51:
      current_block = (Rpc - LABEL_34_55);
      goto label_258;

    case 52:
      current_block = (Rpc - LABEL_34_56);
      goto label_259;

    case 53:
      current_block = (Rpc - LABEL_34_57);
      goto label_260;

    case 54:
      current_block = (Rpc - LABEL_34_58);
      goto label_261;

    case 55:
      current_block = (Rpc - LABEL_34_59);
      goto label_198;

    case 56:
      current_block = (Rpc - LABEL_34_60);
      goto label_199;

    case 57:
      current_block = (Rpc - LABEL_34_61);
      goto label_200;

    case 58:
      current_block = (Rpc - LABEL_34_62);
      goto label_201;

    case 59:
      current_block = (Rpc - LABEL_34_63);
      goto label_202;

    case 60:
      current_block = (Rpc - LABEL_34_64);
      goto label_203;

    case 61:
      current_block = (Rpc - LABEL_34_65);
      goto label_204;

    case 62:
      current_block = (Rpc - LABEL_34_66);
      goto label_205;

    case 63:
      current_block = (Rpc - LABEL_34_67);
      goto label_206;

    case 64:
      current_block = (Rpc - LABEL_34_68);
      goto label_207;

    case 65:
      current_block = (Rpc - LABEL_34_69);
      goto label_208;

    case 66:
      current_block = (Rpc - LABEL_34_70);
      goto label_209;

    case 67:
      current_block = (Rpc - LABEL_34_71);
      goto label_210;

    case 68:
      current_block = (Rpc - LABEL_34_72);
      goto label_211;

    case 69:
      current_block = (Rpc - LABEL_34_73);
      goto label_212;

    case 70:
      current_block = (Rpc - LABEL_34_74);
      goto label_213;

    case 71:
      current_block = (Rpc - LABEL_34_75);
      goto label_214;

    case 72:
      current_block = (Rpc - LABEL_34_76);
      goto label_215;

    case 73:
      current_block = (Rpc - LABEL_34_77);
      goto label_216;

    case 74:
      current_block = (Rpc - LABEL_34_78);
      goto label_217;

    case 75:
      current_block = (Rpc - LABEL_34_79);
      goto label_218;

    case 76:
      current_block = (Rpc - LABEL_34_80);
      goto search_lines_168;

    case 77:
      current_block = (Rpc - LABEL_34_81);
      goto label_275;

    case 78:
      current_block = (Rpc - LABEL_34_82);
      goto label_262;

    case 79:
      current_block = (Rpc - LABEL_34_83);
      goto label_274;

    case 80:
      current_block = (Rpc - LABEL_34_84);
      goto label_265;

    case 81:
      current_block = (Rpc - LABEL_34_85);
      goto label_266;

    case 82:
      current_block = (Rpc - LABEL_34_86);
      goto label_267;

    case 83:
      current_block = (Rpc - LABEL_34_87);
      goto label_268;

    case 84:
      current_block = (Rpc - LABEL_34_88);
      goto label_269;

    case 85:
      current_block = (Rpc - LABEL_34_89);
      goto label_270;

    case 86:
      current_block = (Rpc - LABEL_34_90);
      goto label_271;

    case 87:
      current_block = (Rpc - LABEL_34_91);
      goto label_272;

    case 88:
      current_block = (Rpc - LABEL_34_92);
      goto label_273;

    case 89:
      current_block = (Rpc - LABEL_34_93);
      goto label_263;

    case 90:
      current_block = (Rpc - LABEL_34_94);
      goto label_264;

    case 91:
      current_block = (Rpc - LABEL_34_95);
      goto search_overflow_166;

    case 92:
      current_block = (Rpc - LABEL_34_96);
      goto label_276;

    case 93:
      current_block = (Rpc - LABEL_34_97);
      goto label_277;

    case 94:
      current_block = (Rpc - LABEL_34_98);
      goto label_279;

    case 95:
      current_block = (Rpc - LABEL_34_99);
      goto label_280;

    case 96:
      current_block = (Rpc - LABEL_34_100);
      goto label_281;

    case 97:
      current_block = (Rpc - LABEL_34_101);
      goto label_282;

    case 98:
      current_block = (Rpc - LABEL_34_102);
      goto label_283;

    case 99:
      current_block = (Rpc - LABEL_34_103);
      goto label_284;

    case 100:
      current_block = (Rpc - LABEL_34_104);
      goto label_285;

    case 101:
      current_block = (Rpc - LABEL_34_105);
      goto label_278;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (probe_cache_4_287)
DEFLABEL (probe_cache_4_185)
  INTERRUPT_CHECK (26, LABEL_34_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_445;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd13.Lng))))
    goto label_445;
  (Wrd7.Obj) = ((Wrd11.pObj) [3]);
  (* (--Rsp)) = (Wrd7.Obj);

DEFLABEL (label_444)
  (Wrd30.Obj) = (Rsp [1]);
  (Wrd31.uLng) = (OBJECT_TYPE (Wrd30.Obj));
  if (! ((Wrd31.uLng) == 62))
    goto label_443;
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd30.Obj));
  (Wrd28.Obj) = ((Wrd27.pObj) [0]);
  (Wrd29.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd29.Lng))))
    goto label_443;
  (Wrd21.Obj) = ((Wrd27.pObj) [2]);

DEFLABEL (label_442)
  (Wrd48.Obj) = (Rsp [5]);
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd48.Obj));
  if (! ((Wrd49.uLng) == 62))
    goto label_441;
  (Wrd42.uLng) = (OBJECT_TYPE (Wrd21.Obj));
  if (! ((Wrd42.uLng) == 26))
    goto label_441;
  (Wrd43.Lng) = (FIXNUM_TO_LONG (Wrd21.Obj));
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd48.Obj));
  (Wrd46.Obj) = ((Wrd45.pObj) [0]);
  (Wrd47.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  if (! (((unsigned long) (Wrd43.Lng)) < ((unsigned long) (Wrd47.Lng))))
    goto label_441;
  (Wrd37.uLng) = (OBJECT_DATUM (Wrd21.Obj));
  (Wrd40.pObj) = (& ((Wrd45.pObj) [(Wrd37.Lng)]));
  (Wrd41.Obj) = ((Wrd40.pObj) [1]);
  (* (--Rsp)) = (Wrd41.Obj);

DEFLABEL (label_440)
  (Wrd64.Obj) = (Rsp [2]);
  (Wrd65.uLng) = (OBJECT_TYPE (Wrd64.Obj));
  if (! ((Wrd65.uLng) == 62))
    goto label_439;
  (Wrd61.pObj) = (OBJECT_ADDRESS (Wrd64.Obj));
  (Wrd62.Obj) = ((Wrd61.pObj) [0]);
  (Wrd63.Lng) = (FIXNUM_TO_LONG (Wrd62.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd63.Lng))))
    goto label_439;
  (Wrd55.Obj) = ((Wrd61.pObj) [2]);

DEFLABEL (label_438)
  (Wrd82.Obj) = (Rsp [5]);
  (Wrd83.uLng) = (OBJECT_TYPE (Wrd82.Obj));
  if (! ((Wrd83.uLng) == 62))
    goto label_437;
  (Wrd76.uLng) = (OBJECT_TYPE (Wrd55.Obj));
  if (! ((Wrd76.uLng) == 26))
    goto label_437;
  (Wrd77.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd79.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd80.Obj) = ((Wrd79.pObj) [0]);
  (Wrd81.Lng) = (FIXNUM_TO_LONG (Wrd80.Obj));
  if (! (((unsigned long) (Wrd77.Lng)) < ((unsigned long) (Wrd81.Lng))))
    goto label_437;
  (Wrd72.uLng) = (OBJECT_DATUM (Wrd55.Obj));
  (Wrd75.pObj) = (& ((Wrd79.pObj) [(Wrd72.Lng)]));
  (Wrd71.Obj) = ((Wrd75.pObj) [1]);

DEFLABEL (label_436)
  (Wrd89.Obj) = (* (Rsp++));
  (Wrd90.Lng) = (FIXNUM_TO_LONG (Wrd71.Obj));
  (Wrd91.Lng) = (FIXNUM_TO_LONG (Wrd89.Obj));
  (Wrd92.Lng) = ((Wrd90.Lng) + (Wrd91.Lng));
  (Wrd93.Obj) = (LONG_TO_FIXNUM (Wrd92.Lng));
  (* (--Rsp)) = (Wrd93.Obj);
  (Wrd103.Obj) = (Rsp [2]);
  (Wrd104.uLng) = (OBJECT_TYPE (Wrd103.Obj));
  if (! ((Wrd104.uLng) == 62))
    goto label_435;
  (Wrd100.pObj) = (OBJECT_ADDRESS (Wrd103.Obj));
  (Wrd101.Obj) = ((Wrd100.pObj) [0]);
  (Wrd102.Lng) = (FIXNUM_TO_LONG (Wrd101.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd102.Lng))))
    goto label_435;
  (Wrd94.Obj) = ((Wrd100.pObj) [2]);

DEFLABEL (label_434)
  (Wrd121.Obj) = (Rsp [4]);
  (Wrd122.uLng) = (OBJECT_TYPE (Wrd121.Obj));
  if (! ((Wrd122.uLng) == 62))
    goto label_433;
  (Wrd115.uLng) = (OBJECT_TYPE (Wrd94.Obj));
  if (! ((Wrd115.uLng) == 26))
    goto label_433;
  (Wrd116.Lng) = (FIXNUM_TO_LONG (Wrd94.Obj));
  (Wrd118.pObj) = (OBJECT_ADDRESS (Wrd121.Obj));
  (Wrd119.Obj) = ((Wrd118.pObj) [0]);
  (Wrd120.Lng) = (FIXNUM_TO_LONG (Wrd119.Obj));
  if (! (((unsigned long) (Wrd116.Lng)) < ((unsigned long) (Wrd120.Lng))))
    goto label_433;
  (Wrd110.uLng) = (OBJECT_DATUM (Wrd94.Obj));
  (Wrd113.pObj) = (& ((Wrd118.pObj) [(Wrd110.Lng)]));
  (Wrd114.Obj) = ((Wrd113.pObj) [1]);
  (* (--Rsp)) = (Wrd114.Obj);

DEFLABEL (label_432)
  (Wrd137.Obj) = (Rsp [3]);
  (Wrd138.uLng) = (OBJECT_TYPE (Wrd137.Obj));
  if (! ((Wrd138.uLng) == 62))
    goto label_431;
  (Wrd134.pObj) = (OBJECT_ADDRESS (Wrd137.Obj));
  (Wrd135.Obj) = ((Wrd134.pObj) [0]);
  (Wrd136.Lng) = (FIXNUM_TO_LONG (Wrd135.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd136.Lng))))
    goto label_431;
  (Wrd128.Obj) = ((Wrd134.pObj) [2]);

DEFLABEL (label_430)
  (Wrd155.Obj) = (Rsp [4]);
  (Wrd156.uLng) = (OBJECT_TYPE (Wrd155.Obj));
  if (! ((Wrd156.uLng) == 62))
    goto label_429;
  (Wrd149.uLng) = (OBJECT_TYPE (Wrd128.Obj));
  if (! ((Wrd149.uLng) == 26))
    goto label_429;
  (Wrd150.Lng) = (FIXNUM_TO_LONG (Wrd128.Obj));
  (Wrd152.pObj) = (OBJECT_ADDRESS (Wrd155.Obj));
  (Wrd153.Obj) = ((Wrd152.pObj) [0]);
  (Wrd154.Lng) = (FIXNUM_TO_LONG (Wrd153.Obj));
  if (! (((unsigned long) (Wrd150.Lng)) < ((unsigned long) (Wrd154.Lng))))
    goto label_429;
  (Wrd145.uLng) = (OBJECT_DATUM (Wrd128.Obj));
  (Wrd148.pObj) = (& ((Wrd152.pObj) [(Wrd145.Lng)]));
  (Wrd144.Obj) = ((Wrd148.pObj) [1]);

DEFLABEL (label_428)
  (Wrd162.Obj) = (* (Rsp++));
  (Wrd164.Lng) = (FIXNUM_TO_LONG (Wrd144.Obj));
  (Wrd165.Lng) = (FIXNUM_TO_LONG (Wrd162.Obj));
  (Wrd166.Lng) = ((Wrd164.Lng) + (Wrd165.Lng));
  (Wrd167.Obj) = (* (Rsp++));
  Wrd169 = Wrd166;
  (Wrd170.Lng) = (FIXNUM_TO_LONG (Wrd167.Obj));
  (Wrd171.Lng) = ((Wrd169.Lng) + (Wrd170.Lng));
  (Wrd172.Obj) = (* (Rsp++));
  Wrd173 = Wrd171;
  (Wrd174.Lng) = (FIXNUM_TO_LONG (Wrd172.Obj));
  (Wrd175.Lng) = ((Wrd173.Lng) & (Wrd174.Lng));
  (Wrd176.Obj) = (LONG_TO_FIXNUM (Wrd175.Lng));
  (* (--Rsp)) = (Wrd176.Obj);
  (Wrd186.Obj) = (Rsp [1]);
  (Wrd187.uLng) = (OBJECT_TYPE (Wrd186.Obj));
  if (! ((Wrd187.uLng) == 62))
    goto label_427;
  (Wrd183.pObj) = (OBJECT_ADDRESS (Wrd186.Obj));
  (Wrd184.Obj) = ((Wrd183.pObj) [0]);
  (Wrd185.Lng) = (FIXNUM_TO_LONG (Wrd184.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd185.Lng))))
    goto label_427;
  (Wrd177.Obj) = ((Wrd183.pObj) [6]);

DEFLABEL (label_426)
  (Wrd193.Obj) = (* (Rsp++));
  (Wrd203.uLng) = (OBJECT_TYPE (Wrd177.Obj));
  if (! ((Wrd203.uLng) == 10))
    goto label_425;
  (Wrd198.uLng) = (OBJECT_TYPE (Wrd193.Obj));
  if (! ((Wrd198.uLng) == 26))
    goto label_425;
  (Wrd199.Lng) = (FIXNUM_TO_LONG (Wrd193.Obj));
  (Wrd200.pObj) = (OBJECT_ADDRESS (Wrd177.Obj));
  (Wrd201.Obj) = ((Wrd200.pObj) [0]);
  (Wrd202.Lng) = (FIXNUM_TO_LONG (Wrd201.Obj));
  if (! (((unsigned long) (Wrd199.Lng)) < ((unsigned long) (Wrd202.Lng))))
    goto label_425;
  (Wrd195.uLng) = (OBJECT_DATUM (Wrd193.Obj));
  (Wrd197.pObj) = (& ((Wrd200.pObj) [(Wrd195.Lng)]));
  (Wrd194.Obj) = ((Wrd197.pObj) [1]);

DEFLABEL (label_424)
  (Wrd210.pObj) = (OBJECT_ADDRESS (Wrd194.Obj));
  (Wrd209.Obj) = ((Wrd210.pObj) [0]);
  (Wrd211.Obj) = (Rsp [1]);
  if ((Wrd211.Obj) == (Wrd209.Obj))
    goto label_335;

DEFLABEL (label_334)
  (Wrd221.Obj) = (Rsp [0]);
  (Wrd222.uLng) = (OBJECT_TYPE (Wrd221.Obj));
  if (! ((Wrd222.uLng) == 62))
    goto label_333;
  (Wrd218.pObj) = (OBJECT_ADDRESS (Wrd221.Obj));
  (Wrd219.Obj) = ((Wrd218.pObj) [0]);
  (Wrd220.Lng) = (FIXNUM_TO_LONG (Wrd219.Obj));
  if (! (((unsigned long) 3L) < ((unsigned long) (Wrd220.Lng))))
    goto label_333;
  (Wrd214.Obj) = ((Wrd218.pObj) [4]);
  (* (--Rsp)) = (Wrd214.Obj);

DEFLABEL (label_332)
  (Wrd228.Obj) = (current_block [OBJECT_34_7]);
  (* (--Rsp)) = (Wrd228.Obj);
  (Wrd238.Obj) = (Rsp [2]);
  (Wrd239.uLng) = (OBJECT_TYPE (Wrd238.Obj));
  if (! ((Wrd239.uLng) == 62))
    goto label_331;
  (Wrd235.pObj) = (OBJECT_ADDRESS (Wrd238.Obj));
  (Wrd236.Obj) = ((Wrd235.pObj) [0]);
  (Wrd237.Lng) = (FIXNUM_TO_LONG (Wrd236.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd237.Lng))))
    goto label_331;
  (Wrd229.Obj) = ((Wrd235.pObj) [6]);

DEFLABEL (label_330)
  (Wrd249.uLng) = (OBJECT_TYPE (Wrd229.Obj));
  if (! ((Wrd249.uLng) == 10))
    goto label_329;
  (Wrd246.pObj) = (OBJECT_ADDRESS (Wrd229.Obj));
  (Wrd247.Obj) = ((Wrd246.pObj) [0]);
  (Wrd248.Obj) = (MAKE_OBJECT (26, (Wrd247.uLng)));
  (* (--Rsp)) = (Wrd248.Obj);

DEFLABEL (label_328)
  (Wrd263.Obj) = (Rsp [3]);
  (Wrd264.uLng) = (OBJECT_TYPE (Wrd263.Obj));
  if (! ((Wrd264.uLng) == 62))
    goto label_327;
  (Wrd260.pObj) = (OBJECT_ADDRESS (Wrd263.Obj));
  (Wrd261.Obj) = ((Wrd260.pObj) [0]);
  (Wrd262.Lng) = (FIXNUM_TO_LONG (Wrd261.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd262.Lng))))
    goto label_327;
  (Wrd256.Obj) = ((Wrd260.pObj) [3]);
  (* (--Rsp)) = (Wrd256.Obj);

DEFLABEL (label_326)
  (Wrd279.Obj) = (Rsp [4]);
  (Wrd280.uLng) = (OBJECT_TYPE (Wrd279.Obj));
  if (! ((Wrd280.uLng) == 62))
    goto label_325;
  (Wrd276.pObj) = (OBJECT_ADDRESS (Wrd279.Obj));
  (Wrd277.Obj) = ((Wrd276.pObj) [0]);
  (Wrd278.Lng) = (FIXNUM_TO_LONG (Wrd277.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd278.Lng))))
    goto label_325;
  (Wrd270.Obj) = ((Wrd276.pObj) [2]);

DEFLABEL (label_324)
  (Wrd297.Obj) = (Rsp [8]);
  (Wrd298.uLng) = (OBJECT_TYPE (Wrd297.Obj));
  if (! ((Wrd298.uLng) == 62))
    goto label_323;
  (Wrd291.uLng) = (OBJECT_TYPE (Wrd270.Obj));
  if (! ((Wrd291.uLng) == 26))
    goto label_323;
  (Wrd292.Lng) = (FIXNUM_TO_LONG (Wrd270.Obj));
  (Wrd294.pObj) = (OBJECT_ADDRESS (Wrd297.Obj));
  (Wrd295.Obj) = ((Wrd294.pObj) [0]);
  (Wrd296.Lng) = (FIXNUM_TO_LONG (Wrd295.Obj));
  if (! (((unsigned long) (Wrd292.Lng)) < ((unsigned long) (Wrd296.Lng))))
    goto label_323;
  (Wrd286.uLng) = (OBJECT_DATUM (Wrd270.Obj));
  (Wrd289.pObj) = (& ((Wrd294.pObj) [(Wrd286.Lng)]));
  (Wrd290.Obj) = ((Wrd289.pObj) [1]);
  (* (--Rsp)) = (Wrd290.Obj);

DEFLABEL (label_322)
  (Wrd313.Obj) = (Rsp [5]);
  (Wrd314.uLng) = (OBJECT_TYPE (Wrd313.Obj));
  if (! ((Wrd314.uLng) == 62))
    goto label_321;
  (Wrd310.pObj) = (OBJECT_ADDRESS (Wrd313.Obj));
  (Wrd311.Obj) = ((Wrd310.pObj) [0]);
  (Wrd312.Lng) = (FIXNUM_TO_LONG (Wrd311.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd312.Lng))))
    goto label_321;
  (Wrd304.Obj) = ((Wrd310.pObj) [2]);

DEFLABEL (label_320)
  (Wrd331.Obj) = (Rsp [8]);
  (Wrd332.uLng) = (OBJECT_TYPE (Wrd331.Obj));
  if (! ((Wrd332.uLng) == 62))
    goto label_319;
  (Wrd325.uLng) = (OBJECT_TYPE (Wrd304.Obj));
  if (! ((Wrd325.uLng) == 26))
    goto label_319;
  (Wrd326.Lng) = (FIXNUM_TO_LONG (Wrd304.Obj));
  (Wrd328.pObj) = (OBJECT_ADDRESS (Wrd331.Obj));
  (Wrd329.Obj) = ((Wrd328.pObj) [0]);
  (Wrd330.Lng) = (FIXNUM_TO_LONG (Wrd329.Obj));
  if (! (((unsigned long) (Wrd326.Lng)) < ((unsigned long) (Wrd330.Lng))))
    goto label_319;
  (Wrd321.uLng) = (OBJECT_DATUM (Wrd304.Obj));
  (Wrd324.pObj) = (& ((Wrd328.pObj) [(Wrd321.Lng)]));
  (Wrd320.Obj) = ((Wrd324.pObj) [1]);

DEFLABEL (label_318)
  (Wrd338.Obj) = (* (Rsp++));
  (Wrd339.Lng) = (FIXNUM_TO_LONG (Wrd320.Obj));
  (Wrd340.Lng) = (FIXNUM_TO_LONG (Wrd338.Obj));
  (Wrd341.Lng) = ((Wrd339.Lng) + (Wrd340.Lng));
  (Wrd342.Obj) = (LONG_TO_FIXNUM (Wrd341.Lng));
  (* (--Rsp)) = (Wrd342.Obj);
  (Wrd352.Obj) = (Rsp [5]);
  (Wrd353.uLng) = (OBJECT_TYPE (Wrd352.Obj));
  if (! ((Wrd353.uLng) == 62))
    goto label_317;
  (Wrd349.pObj) = (OBJECT_ADDRESS (Wrd352.Obj));
  (Wrd350.Obj) = ((Wrd349.pObj) [0]);
  (Wrd351.Lng) = (FIXNUM_TO_LONG (Wrd350.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd351.Lng))))
    goto label_317;
  (Wrd343.Obj) = ((Wrd349.pObj) [2]);

DEFLABEL (label_316)
  (Wrd370.Obj) = (Rsp [7]);
  (Wrd371.uLng) = (OBJECT_TYPE (Wrd370.Obj));
  if (! ((Wrd371.uLng) == 62))
    goto label_315;
  (Wrd364.uLng) = (OBJECT_TYPE (Wrd343.Obj));
  if (! ((Wrd364.uLng) == 26))
    goto label_315;
  (Wrd365.Lng) = (FIXNUM_TO_LONG (Wrd343.Obj));
  (Wrd367.pObj) = (OBJECT_ADDRESS (Wrd370.Obj));
  (Wrd368.Obj) = ((Wrd367.pObj) [0]);
  (Wrd369.Lng) = (FIXNUM_TO_LONG (Wrd368.Obj));
  if (! (((unsigned long) (Wrd365.Lng)) < ((unsigned long) (Wrd369.Lng))))
    goto label_315;
  (Wrd359.uLng) = (OBJECT_DATUM (Wrd343.Obj));
  (Wrd362.pObj) = (& ((Wrd367.pObj) [(Wrd359.Lng)]));
  (Wrd363.Obj) = ((Wrd362.pObj) [1]);
  (* (--Rsp)) = (Wrd363.Obj);

DEFLABEL (label_314)
  (Wrd386.Obj) = (Rsp [6]);
  (Wrd387.uLng) = (OBJECT_TYPE (Wrd386.Obj));
  if (! ((Wrd387.uLng) == 62))
    goto label_313;
  (Wrd383.pObj) = (OBJECT_ADDRESS (Wrd386.Obj));
  (Wrd384.Obj) = ((Wrd383.pObj) [0]);
  (Wrd385.Lng) = (FIXNUM_TO_LONG (Wrd384.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd385.Lng))))
    goto label_313;
  (Wrd377.Obj) = ((Wrd383.pObj) [2]);

DEFLABEL (label_312)
  (Wrd404.Obj) = (Rsp [7]);
  (Wrd405.uLng) = (OBJECT_TYPE (Wrd404.Obj));
  if (! ((Wrd405.uLng) == 62))
    goto label_311;
  (Wrd398.uLng) = (OBJECT_TYPE (Wrd377.Obj));
  if (! ((Wrd398.uLng) == 26))
    goto label_311;
  (Wrd399.Lng) = (FIXNUM_TO_LONG (Wrd377.Obj));
  (Wrd401.pObj) = (OBJECT_ADDRESS (Wrd404.Obj));
  (Wrd402.Obj) = ((Wrd401.pObj) [0]);
  (Wrd403.Lng) = (FIXNUM_TO_LONG (Wrd402.Obj));
  if (! (((unsigned long) (Wrd399.Lng)) < ((unsigned long) (Wrd403.Lng))))
    goto label_311;
  (Wrd394.uLng) = (OBJECT_DATUM (Wrd377.Obj));
  (Wrd397.pObj) = (& ((Wrd401.pObj) [(Wrd394.Lng)]));
  (Wrd393.Obj) = ((Wrd397.pObj) [1]);

DEFLABEL (label_310)
  (Wrd411.Obj) = (* (Rsp++));
  (Wrd413.Lng) = (FIXNUM_TO_LONG (Wrd393.Obj));
  (Wrd414.Lng) = (FIXNUM_TO_LONG (Wrd411.Obj));
  (Wrd415.Lng) = ((Wrd413.Lng) + (Wrd414.Lng));
  (Wrd416.Obj) = (* (Rsp++));
  Wrd418 = Wrd415;
  (Wrd419.Lng) = (FIXNUM_TO_LONG (Wrd416.Obj));
  (Wrd420.Lng) = ((Wrd418.Lng) + (Wrd419.Lng));
  (Wrd421.Obj) = (* (Rsp++));
  Wrd423 = Wrd420;
  (Wrd424.Lng) = (FIXNUM_TO_LONG (Wrd421.Obj));
  (Wrd427.Lng) = ((Wrd423.Lng) & (Wrd424.Lng));
  (Wrd428.Lng) = ((Wrd427.Lng) + 1L);
  (Wrd426.Obj) = (LONG_TO_FIXNUM (Wrd428.Lng));
  (Wrd429.Obj) = (* (Rsp++));
  if ((Wrd426.Obj) == (Wrd429.Obj))
    goto label_309;
  (Wrd439.Obj) = (Rsp [2]);
  (Wrd440.uLng) = (OBJECT_TYPE (Wrd439.Obj));
  if (! ((Wrd440.uLng) == 62))
    goto label_308;
  (Wrd436.pObj) = (OBJECT_ADDRESS (Wrd439.Obj));
  (Wrd437.Obj) = ((Wrd436.pObj) [0]);
  (Wrd438.Lng) = (FIXNUM_TO_LONG (Wrd437.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd438.Lng))))
    goto label_308;
  (Wrd432.Obj) = ((Wrd436.pObj) [3]);
  (* (--Rsp)) = (Wrd432.Obj);

DEFLABEL (label_307)
  (Wrd455.Obj) = (Rsp [3]);
  (Wrd456.uLng) = (OBJECT_TYPE (Wrd455.Obj));
  if (! ((Wrd456.uLng) == 62))
    goto label_306;
  (Wrd452.pObj) = (OBJECT_ADDRESS (Wrd455.Obj));
  (Wrd453.Obj) = ((Wrd452.pObj) [0]);
  (Wrd454.Lng) = (FIXNUM_TO_LONG (Wrd453.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd454.Lng))))
    goto label_306;
  (Wrd446.Obj) = ((Wrd452.pObj) [2]);

DEFLABEL (label_305)
  (Wrd473.Obj) = (Rsp [7]);
  (Wrd474.uLng) = (OBJECT_TYPE (Wrd473.Obj));
  if (! ((Wrd474.uLng) == 62))
    goto label_304;
  (Wrd467.uLng) = (OBJECT_TYPE (Wrd446.Obj));
  if (! ((Wrd467.uLng) == 26))
    goto label_304;
  (Wrd468.Lng) = (FIXNUM_TO_LONG (Wrd446.Obj));
  (Wrd470.pObj) = (OBJECT_ADDRESS (Wrd473.Obj));
  (Wrd471.Obj) = ((Wrd470.pObj) [0]);
  (Wrd472.Lng) = (FIXNUM_TO_LONG (Wrd471.Obj));
  if (! (((unsigned long) (Wrd468.Lng)) < ((unsigned long) (Wrd472.Lng))))
    goto label_304;
  (Wrd462.uLng) = (OBJECT_DATUM (Wrd446.Obj));
  (Wrd465.pObj) = (& ((Wrd470.pObj) [(Wrd462.Lng)]));
  (Wrd466.Obj) = ((Wrd465.pObj) [1]);
  (* (--Rsp)) = (Wrd466.Obj);

DEFLABEL (label_303)
  (Wrd489.Obj) = (Rsp [4]);
  (Wrd490.uLng) = (OBJECT_TYPE (Wrd489.Obj));
  if (! ((Wrd490.uLng) == 62))
    goto label_302;
  (Wrd486.pObj) = (OBJECT_ADDRESS (Wrd489.Obj));
  (Wrd487.Obj) = ((Wrd486.pObj) [0]);
  (Wrd488.Lng) = (FIXNUM_TO_LONG (Wrd487.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd488.Lng))))
    goto label_302;
  (Wrd480.Obj) = ((Wrd486.pObj) [2]);

DEFLABEL (label_301)
  (Wrd507.Obj) = (Rsp [7]);
  (Wrd508.uLng) = (OBJECT_TYPE (Wrd507.Obj));
  if (! ((Wrd508.uLng) == 62))
    goto label_300;
  (Wrd501.uLng) = (OBJECT_TYPE (Wrd480.Obj));
  if (! ((Wrd501.uLng) == 26))
    goto label_300;
  (Wrd502.Lng) = (FIXNUM_TO_LONG (Wrd480.Obj));
  (Wrd504.pObj) = (OBJECT_ADDRESS (Wrd507.Obj));
  (Wrd505.Obj) = ((Wrd504.pObj) [0]);
  (Wrd506.Lng) = (FIXNUM_TO_LONG (Wrd505.Obj));
  if (! (((unsigned long) (Wrd502.Lng)) < ((unsigned long) (Wrd506.Lng))))
    goto label_300;
  (Wrd497.uLng) = (OBJECT_DATUM (Wrd480.Obj));
  (Wrd500.pObj) = (& ((Wrd504.pObj) [(Wrd497.Lng)]));
  (Wrd496.Obj) = ((Wrd500.pObj) [1]);

DEFLABEL (label_299)
  (Wrd514.Obj) = (* (Rsp++));
  (Wrd515.Lng) = (FIXNUM_TO_LONG (Wrd496.Obj));
  (Wrd516.Lng) = (FIXNUM_TO_LONG (Wrd514.Obj));
  (Wrd517.Lng) = ((Wrd515.Lng) + (Wrd516.Lng));
  (Wrd518.Obj) = (LONG_TO_FIXNUM (Wrd517.Lng));
  (* (--Rsp)) = (Wrd518.Obj);
  (Wrd528.Obj) = (Rsp [4]);
  (Wrd529.uLng) = (OBJECT_TYPE (Wrd528.Obj));
  if (! ((Wrd529.uLng) == 62))
    goto label_298;
  (Wrd525.pObj) = (OBJECT_ADDRESS (Wrd528.Obj));
  (Wrd526.Obj) = ((Wrd525.pObj) [0]);
  (Wrd527.Lng) = (FIXNUM_TO_LONG (Wrd526.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd527.Lng))))
    goto label_298;
  (Wrd519.Obj) = ((Wrd525.pObj) [2]);

DEFLABEL (label_297)
  (Wrd546.Obj) = (Rsp [6]);
  (Wrd547.uLng) = (OBJECT_TYPE (Wrd546.Obj));
  if (! ((Wrd547.uLng) == 62))
    goto label_296;
  (Wrd540.uLng) = (OBJECT_TYPE (Wrd519.Obj));
  if (! ((Wrd540.uLng) == 26))
    goto label_296;
  (Wrd541.Lng) = (FIXNUM_TO_LONG (Wrd519.Obj));
  (Wrd543.pObj) = (OBJECT_ADDRESS (Wrd546.Obj));
  (Wrd544.Obj) = ((Wrd543.pObj) [0]);
  (Wrd545.Lng) = (FIXNUM_TO_LONG (Wrd544.Obj));
  if (! (((unsigned long) (Wrd541.Lng)) < ((unsigned long) (Wrd545.Lng))))
    goto label_296;
  (Wrd535.uLng) = (OBJECT_DATUM (Wrd519.Obj));
  (Wrd538.pObj) = (& ((Wrd543.pObj) [(Wrd535.Lng)]));
  (Wrd539.Obj) = ((Wrd538.pObj) [1]);
  (* (--Rsp)) = (Wrd539.Obj);

DEFLABEL (label_295)
  (Wrd562.Obj) = (Rsp [5]);
  (Wrd563.uLng) = (OBJECT_TYPE (Wrd562.Obj));
  if (! ((Wrd563.uLng) == 62))
    goto label_294;
  (Wrd559.pObj) = (OBJECT_ADDRESS (Wrd562.Obj));
  (Wrd560.Obj) = ((Wrd559.pObj) [0]);
  (Wrd561.Lng) = (FIXNUM_TO_LONG (Wrd560.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd561.Lng))))
    goto label_294;
  (Wrd553.Obj) = ((Wrd559.pObj) [2]);

DEFLABEL (label_293)
  (Wrd580.Obj) = (Rsp [6]);
  (Wrd581.uLng) = (OBJECT_TYPE (Wrd580.Obj));
  if (! ((Wrd581.uLng) == 62))
    goto label_292;
  (Wrd574.uLng) = (OBJECT_TYPE (Wrd553.Obj));
  if (! ((Wrd574.uLng) == 26))
    goto label_292;
  (Wrd575.Lng) = (FIXNUM_TO_LONG (Wrd553.Obj));
  (Wrd577.pObj) = (OBJECT_ADDRESS (Wrd580.Obj));
  (Wrd578.Obj) = ((Wrd577.pObj) [0]);
  (Wrd579.Lng) = (FIXNUM_TO_LONG (Wrd578.Obj));
  if (! (((unsigned long) (Wrd575.Lng)) < ((unsigned long) (Wrd579.Lng))))
    goto label_292;
  (Wrd570.uLng) = (OBJECT_DATUM (Wrd553.Obj));
  (Wrd573.pObj) = (& ((Wrd577.pObj) [(Wrd570.Lng)]));
  (Wrd569.Obj) = ((Wrd573.pObj) [1]);

DEFLABEL (label_291)
  (Wrd587.Obj) = (* (Rsp++));
  (Wrd589.Lng) = (FIXNUM_TO_LONG (Wrd569.Obj));
  (Wrd590.Lng) = (FIXNUM_TO_LONG (Wrd587.Obj));
  (Wrd591.Lng) = ((Wrd589.Lng) + (Wrd590.Lng));
  (Wrd592.Obj) = (* (Rsp++));
  Wrd594 = Wrd591;
  (Wrd595.Lng) = (FIXNUM_TO_LONG (Wrd592.Obj));
  (Wrd596.Lng) = ((Wrd594.Lng) + (Wrd595.Lng));
  (Wrd597.Obj) = (* (Rsp++));
  Wrd599 = Wrd596;
  (Wrd600.Lng) = (FIXNUM_TO_LONG (Wrd597.Obj));
  (Wrd602.Lng) = ((Wrd599.Lng) & (Wrd600.Lng));
  (Wrd603.Lng) = ((Wrd602.Lng) + 1L);
  (Wrd604.Obj) = (LONG_TO_FIXNUM (Wrd603.Lng));
  (* (--Rsp)) = (Wrd604.Obj);

DEFLABEL (label_290)
  goto search_lines_168;

DEFLABEL (label_292)
  (Wrd582.Obj) = (Rsp [6]);
  (Wrd586.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_79]))));
  (* (--Rsp)) = (Wrd586.Obj);
  (* (--Rsp)) = (Wrd553.Obj);
  (* (--Rsp)) = (Wrd582.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_218)
  (Wrd569.Obj) = Rvl;
  goto label_291;

DEFLABEL (label_294)
  (Wrd564.Obj) = (Rsp [5]);
  (Wrd565.Obj) = (current_block [OBJECT_34_2]);
  (Wrd568.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_78]))));
  (* (--Rsp)) = (Wrd568.Obj);
  (* (--Rsp)) = (Wrd565.Obj);
  (* (--Rsp)) = (Wrd564.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_217)
  (Wrd553.Obj) = Rvl;
  goto label_293;

DEFLABEL (label_296)
  (Wrd548.Obj) = (Rsp [6]);
  (Wrd552.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_77]))));
  (* (--Rsp)) = (Wrd552.Obj);
  (* (--Rsp)) = (Wrd519.Obj);
  (* (--Rsp)) = (Wrd548.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_216)
  (* (--Rsp)) = Rvl;
  goto label_295;

DEFLABEL (label_298)
  (Wrd530.Obj) = (Rsp [4]);
  (Wrd531.Obj) = (current_block [OBJECT_34_2]);
  (Wrd534.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_76]))));
  (* (--Rsp)) = (Wrd534.Obj);
  (* (--Rsp)) = (Wrd531.Obj);
  (* (--Rsp)) = (Wrd530.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_215)
  (Wrd519.Obj) = Rvl;
  goto label_297;

DEFLABEL (label_300)
  (Wrd509.Obj) = (Rsp [7]);
  (Wrd513.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_75]))));
  (* (--Rsp)) = (Wrd513.Obj);
  (* (--Rsp)) = (Wrd480.Obj);
  (* (--Rsp)) = (Wrd509.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_214)
  (Wrd496.Obj) = Rvl;
  goto label_299;

DEFLABEL (label_302)
  (Wrd491.Obj) = (Rsp [4]);
  (Wrd492.Obj) = (current_block [OBJECT_34_2]);
  (Wrd495.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_74]))));
  (* (--Rsp)) = (Wrd495.Obj);
  (* (--Rsp)) = (Wrd492.Obj);
  (* (--Rsp)) = (Wrd491.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_213)
  (Wrd480.Obj) = Rvl;
  goto label_301;

DEFLABEL (label_304)
  (Wrd475.Obj) = (Rsp [7]);
  (Wrd479.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_73]))));
  (* (--Rsp)) = (Wrd479.Obj);
  (* (--Rsp)) = (Wrd446.Obj);
  (* (--Rsp)) = (Wrd475.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_212)
  (* (--Rsp)) = Rvl;
  goto label_303;

DEFLABEL (label_306)
  (Wrd457.Obj) = (Rsp [3]);
  (Wrd458.Obj) = (current_block [OBJECT_34_2]);
  (Wrd461.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_72]))));
  (* (--Rsp)) = (Wrd461.Obj);
  (* (--Rsp)) = (Wrd458.Obj);
  (* (--Rsp)) = (Wrd457.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_211)
  (Wrd446.Obj) = Rvl;
  goto label_305;

DEFLABEL (label_308)
  (Wrd441.Obj) = (Rsp [2]);
  (Wrd442.Obj) = (current_block [OBJECT_34_0]);
  (Wrd445.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_71]))));
  (* (--Rsp)) = (Wrd445.Obj);
  (* (--Rsp)) = (Wrd442.Obj);
  (* (--Rsp)) = (Wrd441.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_210)
  (* (--Rsp)) = Rvl;
  goto label_307;

DEFLABEL (label_309)
  (Wrd605.Obj) = (current_block [OBJECT_34_7]);
  (* (--Rsp)) = (Wrd605.Obj);
  goto label_290;

DEFLABEL (label_311)
  (Wrd406.Obj) = (Rsp [7]);
  (Wrd410.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_70]))));
  (* (--Rsp)) = (Wrd410.Obj);
  (* (--Rsp)) = (Wrd377.Obj);
  (* (--Rsp)) = (Wrd406.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_209)
  (Wrd393.Obj) = Rvl;
  goto label_310;

DEFLABEL (label_313)
  (Wrd388.Obj) = (Rsp [6]);
  (Wrd389.Obj) = (current_block [OBJECT_34_2]);
  (Wrd392.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_69]))));
  (* (--Rsp)) = (Wrd392.Obj);
  (* (--Rsp)) = (Wrd389.Obj);
  (* (--Rsp)) = (Wrd388.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_208)
  (Wrd377.Obj) = Rvl;
  goto label_312;

DEFLABEL (label_315)
  (Wrd372.Obj) = (Rsp [7]);
  (Wrd376.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_68]))));
  (* (--Rsp)) = (Wrd376.Obj);
  (* (--Rsp)) = (Wrd343.Obj);
  (* (--Rsp)) = (Wrd372.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_207)
  (* (--Rsp)) = Rvl;
  goto label_314;

DEFLABEL (label_317)
  (Wrd354.Obj) = (Rsp [5]);
  (Wrd355.Obj) = (current_block [OBJECT_34_2]);
  (Wrd358.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_67]))));
  (* (--Rsp)) = (Wrd358.Obj);
  (* (--Rsp)) = (Wrd355.Obj);
  (* (--Rsp)) = (Wrd354.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_206)
  (Wrd343.Obj) = Rvl;
  goto label_316;

DEFLABEL (label_319)
  (Wrd333.Obj) = (Rsp [8]);
  (Wrd337.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_66]))));
  (* (--Rsp)) = (Wrd337.Obj);
  (* (--Rsp)) = (Wrd304.Obj);
  (* (--Rsp)) = (Wrd333.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_205)
  (Wrd320.Obj) = Rvl;
  goto label_318;

DEFLABEL (label_321)
  (Wrd315.Obj) = (Rsp [5]);
  (Wrd316.Obj) = (current_block [OBJECT_34_2]);
  (Wrd319.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_65]))));
  (* (--Rsp)) = (Wrd319.Obj);
  (* (--Rsp)) = (Wrd316.Obj);
  (* (--Rsp)) = (Wrd315.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_204)
  (Wrd304.Obj) = Rvl;
  goto label_320;

DEFLABEL (label_323)
  (Wrd299.Obj) = (Rsp [8]);
  (Wrd303.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_64]))));
  (* (--Rsp)) = (Wrd303.Obj);
  (* (--Rsp)) = (Wrd270.Obj);
  (* (--Rsp)) = (Wrd299.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_203)
  (* (--Rsp)) = Rvl;
  goto label_322;

DEFLABEL (label_325)
  (Wrd281.Obj) = (Rsp [4]);
  (Wrd282.Obj) = (current_block [OBJECT_34_2]);
  (Wrd285.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_63]))));
  (* (--Rsp)) = (Wrd285.Obj);
  (* (--Rsp)) = (Wrd282.Obj);
  (* (--Rsp)) = (Wrd281.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_202)
  (Wrd270.Obj) = Rvl;
  goto label_324;

DEFLABEL (label_327)
  (Wrd265.Obj) = (Rsp [3]);
  (Wrd266.Obj) = (current_block [OBJECT_34_0]);
  (Wrd269.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_62]))));
  (* (--Rsp)) = (Wrd269.Obj);
  (* (--Rsp)) = (Wrd266.Obj);
  (* (--Rsp)) = (Wrd265.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_201)
  (* (--Rsp)) = Rvl;
  goto label_326;

DEFLABEL (label_329)
  (Wrd253.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_61]))));
  (* (--Rsp)) = (Wrd253.Obj);
  (* (--Rsp)) = (Wrd229.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_8]), 1);

DEFLABEL (label_200)
  (* (--Rsp)) = Rvl;
  goto label_328;

DEFLABEL (label_331)
  (Wrd240.Obj) = (Rsp [2]);
  (Wrd241.Obj) = (current_block [OBJECT_34_3]);
  (Wrd244.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_60]))));
  (* (--Rsp)) = (Wrd244.Obj);
  (* (--Rsp)) = (Wrd241.Obj);
  (* (--Rsp)) = (Wrd240.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_199)
  (Wrd229.Obj) = Rvl;
  goto label_330;

DEFLABEL (label_333)
  (Wrd223.Obj) = (Rsp [0]);
  (Wrd224.Obj) = (current_block [OBJECT_34_6]);
  (Wrd227.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_59]))));
  (* (--Rsp)) = (Wrd227.Obj);
  (* (--Rsp)) = (Wrd224.Obj);
  (* (--Rsp)) = (Wrd223.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_198)
  (* (--Rsp)) = Rvl;
  goto label_332;

DEFLABEL (label_335)
  (Wrd615.Obj) = (Rsp [0]);
  (Wrd616.uLng) = (OBJECT_TYPE (Wrd615.Obj));
  if (! ((Wrd616.uLng) == 62))
    goto label_423;
  (Wrd612.pObj) = (OBJECT_ADDRESS (Wrd615.Obj));
  (Wrd613.Obj) = ((Wrd612.pObj) [0]);
  (Wrd614.Lng) = (FIXNUM_TO_LONG (Wrd613.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd614.Lng))))
    goto label_423;
  (Wrd608.Obj) = ((Wrd612.pObj) [3]);
  (* (--Rsp)) = (Wrd608.Obj);

DEFLABEL (label_422)
  (Wrd631.Obj) = (Rsp [1]);
  (Wrd632.uLng) = (OBJECT_TYPE (Wrd631.Obj));
  if (! ((Wrd632.uLng) == 62))
    goto label_421;
  (Wrd628.pObj) = (OBJECT_ADDRESS (Wrd631.Obj));
  (Wrd629.Obj) = ((Wrd628.pObj) [0]);
  (Wrd630.Lng) = (FIXNUM_TO_LONG (Wrd629.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd630.Lng))))
    goto label_421;
  (Wrd622.Obj) = ((Wrd628.pObj) [2]);

DEFLABEL (label_420)
  (Wrd649.Obj) = (Rsp [5]);
  (Wrd650.uLng) = (OBJECT_TYPE (Wrd649.Obj));
  if (! ((Wrd650.uLng) == 62))
    goto label_419;
  (Wrd643.uLng) = (OBJECT_TYPE (Wrd622.Obj));
  if (! ((Wrd643.uLng) == 26))
    goto label_419;
  (Wrd644.Lng) = (FIXNUM_TO_LONG (Wrd622.Obj));
  (Wrd646.pObj) = (OBJECT_ADDRESS (Wrd649.Obj));
  (Wrd647.Obj) = ((Wrd646.pObj) [0]);
  (Wrd648.Lng) = (FIXNUM_TO_LONG (Wrd647.Obj));
  if (! (((unsigned long) (Wrd644.Lng)) < ((unsigned long) (Wrd648.Lng))))
    goto label_419;
  (Wrd638.uLng) = (OBJECT_DATUM (Wrd622.Obj));
  (Wrd641.pObj) = (& ((Wrd646.pObj) [(Wrd638.Lng)]));
  (Wrd642.Obj) = ((Wrd641.pObj) [1]);
  (* (--Rsp)) = (Wrd642.Obj);

DEFLABEL (label_418)
  (Wrd665.Obj) = (Rsp [2]);
  (Wrd666.uLng) = (OBJECT_TYPE (Wrd665.Obj));
  if (! ((Wrd666.uLng) == 62))
    goto label_417;
  (Wrd662.pObj) = (OBJECT_ADDRESS (Wrd665.Obj));
  (Wrd663.Obj) = ((Wrd662.pObj) [0]);
  (Wrd664.Lng) = (FIXNUM_TO_LONG (Wrd663.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd664.Lng))))
    goto label_417;
  (Wrd656.Obj) = ((Wrd662.pObj) [2]);

DEFLABEL (label_416)
  (Wrd683.Obj) = (Rsp [5]);
  (Wrd684.uLng) = (OBJECT_TYPE (Wrd683.Obj));
  if (! ((Wrd684.uLng) == 62))
    goto label_415;
  (Wrd677.uLng) = (OBJECT_TYPE (Wrd656.Obj));
  if (! ((Wrd677.uLng) == 26))
    goto label_415;
  (Wrd678.Lng) = (FIXNUM_TO_LONG (Wrd656.Obj));
  (Wrd680.pObj) = (OBJECT_ADDRESS (Wrd683.Obj));
  (Wrd681.Obj) = ((Wrd680.pObj) [0]);
  (Wrd682.Lng) = (FIXNUM_TO_LONG (Wrd681.Obj));
  if (! (((unsigned long) (Wrd678.Lng)) < ((unsigned long) (Wrd682.Lng))))
    goto label_415;
  (Wrd673.uLng) = (OBJECT_DATUM (Wrd656.Obj));
  (Wrd676.pObj) = (& ((Wrd680.pObj) [(Wrd673.Lng)]));
  (Wrd672.Obj) = ((Wrd676.pObj) [1]);

DEFLABEL (label_414)
  (Wrd690.Obj) = (* (Rsp++));
  (Wrd691.Lng) = (FIXNUM_TO_LONG (Wrd672.Obj));
  (Wrd692.Lng) = (FIXNUM_TO_LONG (Wrd690.Obj));
  (Wrd693.Lng) = ((Wrd691.Lng) + (Wrd692.Lng));
  (Wrd694.Obj) = (LONG_TO_FIXNUM (Wrd693.Lng));
  (* (--Rsp)) = (Wrd694.Obj);
  (Wrd704.Obj) = (Rsp [2]);
  (Wrd705.uLng) = (OBJECT_TYPE (Wrd704.Obj));
  if (! ((Wrd705.uLng) == 62))
    goto label_413;
  (Wrd701.pObj) = (OBJECT_ADDRESS (Wrd704.Obj));
  (Wrd702.Obj) = ((Wrd701.pObj) [0]);
  (Wrd703.Lng) = (FIXNUM_TO_LONG (Wrd702.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd703.Lng))))
    goto label_413;
  (Wrd695.Obj) = ((Wrd701.pObj) [2]);

DEFLABEL (label_412)
  (Wrd722.Obj) = (Rsp [4]);
  (Wrd723.uLng) = (OBJECT_TYPE (Wrd722.Obj));
  if (! ((Wrd723.uLng) == 62))
    goto label_411;
  (Wrd716.uLng) = (OBJECT_TYPE (Wrd695.Obj));
  if (! ((Wrd716.uLng) == 26))
    goto label_411;
  (Wrd717.Lng) = (FIXNUM_TO_LONG (Wrd695.Obj));
  (Wrd719.pObj) = (OBJECT_ADDRESS (Wrd722.Obj));
  (Wrd720.Obj) = ((Wrd719.pObj) [0]);
  (Wrd721.Lng) = (FIXNUM_TO_LONG (Wrd720.Obj));
  if (! (((unsigned long) (Wrd717.Lng)) < ((unsigned long) (Wrd721.Lng))))
    goto label_411;
  (Wrd711.uLng) = (OBJECT_DATUM (Wrd695.Obj));
  (Wrd714.pObj) = (& ((Wrd719.pObj) [(Wrd711.Lng)]));
  (Wrd715.Obj) = ((Wrd714.pObj) [1]);
  (* (--Rsp)) = (Wrd715.Obj);

DEFLABEL (label_410)
  (Wrd738.Obj) = (Rsp [3]);
  (Wrd739.uLng) = (OBJECT_TYPE (Wrd738.Obj));
  if (! ((Wrd739.uLng) == 62))
    goto label_409;
  (Wrd735.pObj) = (OBJECT_ADDRESS (Wrd738.Obj));
  (Wrd736.Obj) = ((Wrd735.pObj) [0]);
  (Wrd737.Lng) = (FIXNUM_TO_LONG (Wrd736.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd737.Lng))))
    goto label_409;
  (Wrd729.Obj) = ((Wrd735.pObj) [2]);

DEFLABEL (label_408)
  (Wrd756.Obj) = (Rsp [4]);
  (Wrd757.uLng) = (OBJECT_TYPE (Wrd756.Obj));
  if (! ((Wrd757.uLng) == 62))
    goto label_407;
  (Wrd750.uLng) = (OBJECT_TYPE (Wrd729.Obj));
  if (! ((Wrd750.uLng) == 26))
    goto label_407;
  (Wrd751.Lng) = (FIXNUM_TO_LONG (Wrd729.Obj));
  (Wrd753.pObj) = (OBJECT_ADDRESS (Wrd756.Obj));
  (Wrd754.Obj) = ((Wrd753.pObj) [0]);
  (Wrd755.Lng) = (FIXNUM_TO_LONG (Wrd754.Obj));
  if (! (((unsigned long) (Wrd751.Lng)) < ((unsigned long) (Wrd755.Lng))))
    goto label_407;
  (Wrd746.uLng) = (OBJECT_DATUM (Wrd729.Obj));
  (Wrd749.pObj) = (& ((Wrd753.pObj) [(Wrd746.Lng)]));
  (Wrd745.Obj) = ((Wrd749.pObj) [1]);

DEFLABEL (label_406)
  (Wrd763.Obj) = (* (Rsp++));
  (Wrd765.Lng) = (FIXNUM_TO_LONG (Wrd745.Obj));
  (Wrd766.Lng) = (FIXNUM_TO_LONG (Wrd763.Obj));
  (Wrd767.Lng) = ((Wrd765.Lng) + (Wrd766.Lng));
  (Wrd768.Obj) = (* (Rsp++));
  Wrd770 = Wrd767;
  (Wrd771.Lng) = (FIXNUM_TO_LONG (Wrd768.Obj));
  (Wrd772.Lng) = ((Wrd770.Lng) + (Wrd771.Lng));
  (Wrd773.Obj) = (* (Rsp++));
  Wrd774 = Wrd772;
  (Wrd775.Lng) = (FIXNUM_TO_LONG (Wrd773.Obj));
  (Wrd776.Lng) = ((Wrd774.Lng) & (Wrd775.Lng));
  (Wrd777.Obj) = (LONG_TO_FIXNUM (Wrd776.Lng));
  (* (--Rsp)) = (Wrd777.Obj);
  (Wrd787.Obj) = (Rsp [1]);
  (Wrd788.uLng) = (OBJECT_TYPE (Wrd787.Obj));
  if (! ((Wrd788.uLng) == 62))
    goto label_405;
  (Wrd784.pObj) = (OBJECT_ADDRESS (Wrd787.Obj));
  (Wrd785.Obj) = ((Wrd784.pObj) [0]);
  (Wrd786.Lng) = (FIXNUM_TO_LONG (Wrd785.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd786.Lng))))
    goto label_405;
  (Wrd778.Obj) = ((Wrd784.pObj) [6]);

DEFLABEL (label_404)
  (Wrd794.Obj) = (* (Rsp++));
  (Wrd804.uLng) = (OBJECT_TYPE (Wrd778.Obj));
  if (! ((Wrd804.uLng) == 10))
    goto label_403;
  (Wrd799.uLng) = (OBJECT_TYPE (Wrd794.Obj));
  if (! ((Wrd799.uLng) == 26))
    goto label_403;
  (Wrd800.Lng) = (FIXNUM_TO_LONG (Wrd794.Obj));
  (Wrd801.pObj) = (OBJECT_ADDRESS (Wrd778.Obj));
  (Wrd802.Obj) = ((Wrd801.pObj) [0]);
  (Wrd803.Lng) = (FIXNUM_TO_LONG (Wrd802.Obj));
  if (! (((unsigned long) (Wrd800.Lng)) < ((unsigned long) (Wrd803.Lng))))
    goto label_403;
  (Wrd796.uLng) = (OBJECT_DATUM (Wrd794.Obj));
  (Wrd798.pObj) = (& ((Wrd801.pObj) [(Wrd796.Lng)]));
  (Wrd795.Obj) = ((Wrd798.pObj) [1]);

DEFLABEL (label_402)
  (Wrd811.pObj) = (OBJECT_ADDRESS (Wrd795.Obj));
  (Wrd810.Obj) = ((Wrd811.pObj) [1]);
  (Wrd813.pObj) = (OBJECT_ADDRESS (Wrd810.Obj));
  (Wrd812.Obj) = ((Wrd813.pObj) [0]);
  (Wrd814.Obj) = (Rsp [2]);
  if (! ((Wrd814.Obj) == (Wrd812.Obj)))
    goto label_334;
  (Wrd824.Obj) = (Rsp [0]);
  (Wrd825.uLng) = (OBJECT_TYPE (Wrd824.Obj));
  if (! ((Wrd825.uLng) == 62))
    goto label_401;
  (Wrd821.pObj) = (OBJECT_ADDRESS (Wrd824.Obj));
  (Wrd822.Obj) = ((Wrd821.pObj) [0]);
  (Wrd823.Lng) = (FIXNUM_TO_LONG (Wrd822.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd823.Lng))))
    goto label_401;
  (Wrd817.Obj) = ((Wrd821.pObj) [3]);
  (* (--Rsp)) = (Wrd817.Obj);

DEFLABEL (label_400)
  (Wrd840.Obj) = (Rsp [1]);
  (Wrd841.uLng) = (OBJECT_TYPE (Wrd840.Obj));
  if (! ((Wrd841.uLng) == 62))
    goto label_399;
  (Wrd837.pObj) = (OBJECT_ADDRESS (Wrd840.Obj));
  (Wrd838.Obj) = ((Wrd837.pObj) [0]);
  (Wrd839.Lng) = (FIXNUM_TO_LONG (Wrd838.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd839.Lng))))
    goto label_399;
  (Wrd831.Obj) = ((Wrd837.pObj) [2]);

DEFLABEL (label_398)
  (Wrd858.Obj) = (Rsp [5]);
  (Wrd859.uLng) = (OBJECT_TYPE (Wrd858.Obj));
  if (! ((Wrd859.uLng) == 62))
    goto label_397;
  (Wrd852.uLng) = (OBJECT_TYPE (Wrd831.Obj));
  if (! ((Wrd852.uLng) == 26))
    goto label_397;
  (Wrd853.Lng) = (FIXNUM_TO_LONG (Wrd831.Obj));
  (Wrd855.pObj) = (OBJECT_ADDRESS (Wrd858.Obj));
  (Wrd856.Obj) = ((Wrd855.pObj) [0]);
  (Wrd857.Lng) = (FIXNUM_TO_LONG (Wrd856.Obj));
  if (! (((unsigned long) (Wrd853.Lng)) < ((unsigned long) (Wrd857.Lng))))
    goto label_397;
  (Wrd847.uLng) = (OBJECT_DATUM (Wrd831.Obj));
  (Wrd850.pObj) = (& ((Wrd855.pObj) [(Wrd847.Lng)]));
  (Wrd851.Obj) = ((Wrd850.pObj) [1]);
  (* (--Rsp)) = (Wrd851.Obj);

DEFLABEL (label_396)
  (Wrd874.Obj) = (Rsp [2]);
  (Wrd875.uLng) = (OBJECT_TYPE (Wrd874.Obj));
  if (! ((Wrd875.uLng) == 62))
    goto label_395;
  (Wrd871.pObj) = (OBJECT_ADDRESS (Wrd874.Obj));
  (Wrd872.Obj) = ((Wrd871.pObj) [0]);
  (Wrd873.Lng) = (FIXNUM_TO_LONG (Wrd872.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd873.Lng))))
    goto label_395;
  (Wrd865.Obj) = ((Wrd871.pObj) [2]);

DEFLABEL (label_394)
  (Wrd892.Obj) = (Rsp [5]);
  (Wrd893.uLng) = (OBJECT_TYPE (Wrd892.Obj));
  if (! ((Wrd893.uLng) == 62))
    goto label_393;
  (Wrd886.uLng) = (OBJECT_TYPE (Wrd865.Obj));
  if (! ((Wrd886.uLng) == 26))
    goto label_393;
  (Wrd887.Lng) = (FIXNUM_TO_LONG (Wrd865.Obj));
  (Wrd889.pObj) = (OBJECT_ADDRESS (Wrd892.Obj));
  (Wrd890.Obj) = ((Wrd889.pObj) [0]);
  (Wrd891.Lng) = (FIXNUM_TO_LONG (Wrd890.Obj));
  if (! (((unsigned long) (Wrd887.Lng)) < ((unsigned long) (Wrd891.Lng))))
    goto label_393;
  (Wrd882.uLng) = (OBJECT_DATUM (Wrd865.Obj));
  (Wrd885.pObj) = (& ((Wrd889.pObj) [(Wrd882.Lng)]));
  (Wrd881.Obj) = ((Wrd885.pObj) [1]);

DEFLABEL (label_392)
  (Wrd899.Obj) = (* (Rsp++));
  (Wrd900.Lng) = (FIXNUM_TO_LONG (Wrd881.Obj));
  (Wrd901.Lng) = (FIXNUM_TO_LONG (Wrd899.Obj));
  (Wrd902.Lng) = ((Wrd900.Lng) + (Wrd901.Lng));
  (Wrd903.Obj) = (LONG_TO_FIXNUM (Wrd902.Lng));
  (* (--Rsp)) = (Wrd903.Obj);
  (Wrd913.Obj) = (Rsp [2]);
  (Wrd914.uLng) = (OBJECT_TYPE (Wrd913.Obj));
  if (! ((Wrd914.uLng) == 62))
    goto label_391;
  (Wrd910.pObj) = (OBJECT_ADDRESS (Wrd913.Obj));
  (Wrd911.Obj) = ((Wrd910.pObj) [0]);
  (Wrd912.Lng) = (FIXNUM_TO_LONG (Wrd911.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd912.Lng))))
    goto label_391;
  (Wrd904.Obj) = ((Wrd910.pObj) [2]);

DEFLABEL (label_390)
  (Wrd931.Obj) = (Rsp [4]);
  (Wrd932.uLng) = (OBJECT_TYPE (Wrd931.Obj));
  if (! ((Wrd932.uLng) == 62))
    goto label_389;
  (Wrd925.uLng) = (OBJECT_TYPE (Wrd904.Obj));
  if (! ((Wrd925.uLng) == 26))
    goto label_389;
  (Wrd926.Lng) = (FIXNUM_TO_LONG (Wrd904.Obj));
  (Wrd928.pObj) = (OBJECT_ADDRESS (Wrd931.Obj));
  (Wrd929.Obj) = ((Wrd928.pObj) [0]);
  (Wrd930.Lng) = (FIXNUM_TO_LONG (Wrd929.Obj));
  if (! (((unsigned long) (Wrd926.Lng)) < ((unsigned long) (Wrd930.Lng))))
    goto label_389;
  (Wrd920.uLng) = (OBJECT_DATUM (Wrd904.Obj));
  (Wrd923.pObj) = (& ((Wrd928.pObj) [(Wrd920.Lng)]));
  (Wrd924.Obj) = ((Wrd923.pObj) [1]);
  (* (--Rsp)) = (Wrd924.Obj);

DEFLABEL (label_388)
  (Wrd947.Obj) = (Rsp [3]);
  (Wrd948.uLng) = (OBJECT_TYPE (Wrd947.Obj));
  if (! ((Wrd948.uLng) == 62))
    goto label_387;
  (Wrd944.pObj) = (OBJECT_ADDRESS (Wrd947.Obj));
  (Wrd945.Obj) = ((Wrd944.pObj) [0]);
  (Wrd946.Lng) = (FIXNUM_TO_LONG (Wrd945.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd946.Lng))))
    goto label_387;
  (Wrd938.Obj) = ((Wrd944.pObj) [2]);

DEFLABEL (label_386)
  (Wrd965.Obj) = (Rsp [4]);
  (Wrd966.uLng) = (OBJECT_TYPE (Wrd965.Obj));
  if (! ((Wrd966.uLng) == 62))
    goto label_385;
  (Wrd959.uLng) = (OBJECT_TYPE (Wrd938.Obj));
  if (! ((Wrd959.uLng) == 26))
    goto label_385;
  (Wrd960.Lng) = (FIXNUM_TO_LONG (Wrd938.Obj));
  (Wrd962.pObj) = (OBJECT_ADDRESS (Wrd965.Obj));
  (Wrd963.Obj) = ((Wrd962.pObj) [0]);
  (Wrd964.Lng) = (FIXNUM_TO_LONG (Wrd963.Obj));
  if (! (((unsigned long) (Wrd960.Lng)) < ((unsigned long) (Wrd964.Lng))))
    goto label_385;
  (Wrd955.uLng) = (OBJECT_DATUM (Wrd938.Obj));
  (Wrd958.pObj) = (& ((Wrd962.pObj) [(Wrd955.Lng)]));
  (Wrd954.Obj) = ((Wrd958.pObj) [1]);

DEFLABEL (label_384)
  (Wrd972.Obj) = (* (Rsp++));
  (Wrd974.Lng) = (FIXNUM_TO_LONG (Wrd954.Obj));
  (Wrd975.Lng) = (FIXNUM_TO_LONG (Wrd972.Obj));
  (Wrd976.Lng) = ((Wrd974.Lng) + (Wrd975.Lng));
  (Wrd977.Obj) = (* (Rsp++));
  Wrd979 = Wrd976;
  (Wrd980.Lng) = (FIXNUM_TO_LONG (Wrd977.Obj));
  (Wrd981.Lng) = ((Wrd979.Lng) + (Wrd980.Lng));
  (Wrd982.Obj) = (* (Rsp++));
  Wrd983 = Wrd981;
  (Wrd984.Lng) = (FIXNUM_TO_LONG (Wrd982.Obj));
  (Wrd985.Lng) = ((Wrd983.Lng) & (Wrd984.Lng));
  (Wrd986.Obj) = (LONG_TO_FIXNUM (Wrd985.Lng));
  (* (--Rsp)) = (Wrd986.Obj);
  (Wrd996.Obj) = (Rsp [1]);
  (Wrd997.uLng) = (OBJECT_TYPE (Wrd996.Obj));
  if (! ((Wrd997.uLng) == 62))
    goto label_383;
  (Wrd993.pObj) = (OBJECT_ADDRESS (Wrd996.Obj));
  (Wrd994.Obj) = ((Wrd993.pObj) [0]);
  (Wrd995.Lng) = (FIXNUM_TO_LONG (Wrd994.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd995.Lng))))
    goto label_383;
  (Wrd987.Obj) = ((Wrd993.pObj) [6]);

DEFLABEL (label_382)
  (Wrd1003.Obj) = (* (Rsp++));
  (Wrd1013.uLng) = (OBJECT_TYPE (Wrd987.Obj));
  if (! ((Wrd1013.uLng) == 10))
    goto label_381;
  (Wrd1008.uLng) = (OBJECT_TYPE (Wrd1003.Obj));
  if (! ((Wrd1008.uLng) == 26))
    goto label_381;
  (Wrd1009.Lng) = (FIXNUM_TO_LONG (Wrd1003.Obj));
  (Wrd1010.pObj) = (OBJECT_ADDRESS (Wrd987.Obj));
  (Wrd1011.Obj) = ((Wrd1010.pObj) [0]);
  (Wrd1012.Lng) = (FIXNUM_TO_LONG (Wrd1011.Obj));
  if (! (((unsigned long) (Wrd1009.Lng)) < ((unsigned long) (Wrd1012.Lng))))
    goto label_381;
  (Wrd1005.uLng) = (OBJECT_DATUM (Wrd1003.Obj));
  (Wrd1007.pObj) = (& ((Wrd1010.pObj) [(Wrd1005.Lng)]));
  (Wrd1004.Obj) = ((Wrd1007.pObj) [1]);

DEFLABEL (label_380)
  (Wrd1020.pObj) = (OBJECT_ADDRESS (Wrd1004.Obj));
  (Wrd1019.Obj) = ((Wrd1020.pObj) [1]);
  (Wrd1022.pObj) = (OBJECT_ADDRESS (Wrd1019.Obj));
  (Wrd1021.Obj) = ((Wrd1022.pObj) [1]);
  (Wrd1024.pObj) = (OBJECT_ADDRESS (Wrd1021.Obj));
  (Wrd1023.Obj) = ((Wrd1024.pObj) [0]);
  (Wrd1025.Obj) = (Rsp [3]);
  if (! ((Wrd1025.Obj) == (Wrd1023.Obj)))
    goto label_334;
  (Wrd1035.Obj) = (Rsp [0]);
  (Wrd1036.uLng) = (OBJECT_TYPE (Wrd1035.Obj));
  if (! ((Wrd1036.uLng) == 62))
    goto label_379;
  (Wrd1032.pObj) = (OBJECT_ADDRESS (Wrd1035.Obj));
  (Wrd1033.Obj) = ((Wrd1032.pObj) [0]);
  (Wrd1034.Lng) = (FIXNUM_TO_LONG (Wrd1033.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd1034.Lng))))
    goto label_379;
  (Wrd1028.Obj) = ((Wrd1032.pObj) [3]);
  (* (--Rsp)) = (Wrd1028.Obj);

DEFLABEL (label_378)
  (Wrd1051.Obj) = (Rsp [1]);
  (Wrd1052.uLng) = (OBJECT_TYPE (Wrd1051.Obj));
  if (! ((Wrd1052.uLng) == 62))
    goto label_377;
  (Wrd1048.pObj) = (OBJECT_ADDRESS (Wrd1051.Obj));
  (Wrd1049.Obj) = ((Wrd1048.pObj) [0]);
  (Wrd1050.Lng) = (FIXNUM_TO_LONG (Wrd1049.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1050.Lng))))
    goto label_377;
  (Wrd1042.Obj) = ((Wrd1048.pObj) [2]);

DEFLABEL (label_376)
  (Wrd1069.Obj) = (Rsp [5]);
  (Wrd1070.uLng) = (OBJECT_TYPE (Wrd1069.Obj));
  if (! ((Wrd1070.uLng) == 62))
    goto label_375;
  (Wrd1063.uLng) = (OBJECT_TYPE (Wrd1042.Obj));
  if (! ((Wrd1063.uLng) == 26))
    goto label_375;
  (Wrd1064.Lng) = (FIXNUM_TO_LONG (Wrd1042.Obj));
  (Wrd1066.pObj) = (OBJECT_ADDRESS (Wrd1069.Obj));
  (Wrd1067.Obj) = ((Wrd1066.pObj) [0]);
  (Wrd1068.Lng) = (FIXNUM_TO_LONG (Wrd1067.Obj));
  if (! (((unsigned long) (Wrd1064.Lng)) < ((unsigned long) (Wrd1068.Lng))))
    goto label_375;
  (Wrd1058.uLng) = (OBJECT_DATUM (Wrd1042.Obj));
  (Wrd1061.pObj) = (& ((Wrd1066.pObj) [(Wrd1058.Lng)]));
  (Wrd1062.Obj) = ((Wrd1061.pObj) [1]);
  (* (--Rsp)) = (Wrd1062.Obj);

DEFLABEL (label_374)
  (Wrd1085.Obj) = (Rsp [2]);
  (Wrd1086.uLng) = (OBJECT_TYPE (Wrd1085.Obj));
  if (! ((Wrd1086.uLng) == 62))
    goto label_373;
  (Wrd1082.pObj) = (OBJECT_ADDRESS (Wrd1085.Obj));
  (Wrd1083.Obj) = ((Wrd1082.pObj) [0]);
  (Wrd1084.Lng) = (FIXNUM_TO_LONG (Wrd1083.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1084.Lng))))
    goto label_373;
  (Wrd1076.Obj) = ((Wrd1082.pObj) [2]);

DEFLABEL (label_372)
  (Wrd1103.Obj) = (Rsp [5]);
  (Wrd1104.uLng) = (OBJECT_TYPE (Wrd1103.Obj));
  if (! ((Wrd1104.uLng) == 62))
    goto label_371;
  (Wrd1097.uLng) = (OBJECT_TYPE (Wrd1076.Obj));
  if (! ((Wrd1097.uLng) == 26))
    goto label_371;
  (Wrd1098.Lng) = (FIXNUM_TO_LONG (Wrd1076.Obj));
  (Wrd1100.pObj) = (OBJECT_ADDRESS (Wrd1103.Obj));
  (Wrd1101.Obj) = ((Wrd1100.pObj) [0]);
  (Wrd1102.Lng) = (FIXNUM_TO_LONG (Wrd1101.Obj));
  if (! (((unsigned long) (Wrd1098.Lng)) < ((unsigned long) (Wrd1102.Lng))))
    goto label_371;
  (Wrd1093.uLng) = (OBJECT_DATUM (Wrd1076.Obj));
  (Wrd1096.pObj) = (& ((Wrd1100.pObj) [(Wrd1093.Lng)]));
  (Wrd1092.Obj) = ((Wrd1096.pObj) [1]);

DEFLABEL (label_370)
  (Wrd1110.Obj) = (* (Rsp++));
  (Wrd1111.Lng) = (FIXNUM_TO_LONG (Wrd1092.Obj));
  (Wrd1112.Lng) = (FIXNUM_TO_LONG (Wrd1110.Obj));
  (Wrd1113.Lng) = ((Wrd1111.Lng) + (Wrd1112.Lng));
  (Wrd1114.Obj) = (LONG_TO_FIXNUM (Wrd1113.Lng));
  (* (--Rsp)) = (Wrd1114.Obj);
  (Wrd1124.Obj) = (Rsp [2]);
  (Wrd1125.uLng) = (OBJECT_TYPE (Wrd1124.Obj));
  if (! ((Wrd1125.uLng) == 62))
    goto label_369;
  (Wrd1121.pObj) = (OBJECT_ADDRESS (Wrd1124.Obj));
  (Wrd1122.Obj) = ((Wrd1121.pObj) [0]);
  (Wrd1123.Lng) = (FIXNUM_TO_LONG (Wrd1122.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1123.Lng))))
    goto label_369;
  (Wrd1115.Obj) = ((Wrd1121.pObj) [2]);

DEFLABEL (label_368)
  (Wrd1142.Obj) = (Rsp [4]);
  (Wrd1143.uLng) = (OBJECT_TYPE (Wrd1142.Obj));
  if (! ((Wrd1143.uLng) == 62))
    goto label_367;
  (Wrd1136.uLng) = (OBJECT_TYPE (Wrd1115.Obj));
  if (! ((Wrd1136.uLng) == 26))
    goto label_367;
  (Wrd1137.Lng) = (FIXNUM_TO_LONG (Wrd1115.Obj));
  (Wrd1139.pObj) = (OBJECT_ADDRESS (Wrd1142.Obj));
  (Wrd1140.Obj) = ((Wrd1139.pObj) [0]);
  (Wrd1141.Lng) = (FIXNUM_TO_LONG (Wrd1140.Obj));
  if (! (((unsigned long) (Wrd1137.Lng)) < ((unsigned long) (Wrd1141.Lng))))
    goto label_367;
  (Wrd1131.uLng) = (OBJECT_DATUM (Wrd1115.Obj));
  (Wrd1134.pObj) = (& ((Wrd1139.pObj) [(Wrd1131.Lng)]));
  (Wrd1135.Obj) = ((Wrd1134.pObj) [1]);
  (* (--Rsp)) = (Wrd1135.Obj);

DEFLABEL (label_366)
  (Wrd1158.Obj) = (Rsp [3]);
  (Wrd1159.uLng) = (OBJECT_TYPE (Wrd1158.Obj));
  if (! ((Wrd1159.uLng) == 62))
    goto label_365;
  (Wrd1155.pObj) = (OBJECT_ADDRESS (Wrd1158.Obj));
  (Wrd1156.Obj) = ((Wrd1155.pObj) [0]);
  (Wrd1157.Lng) = (FIXNUM_TO_LONG (Wrd1156.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1157.Lng))))
    goto label_365;
  (Wrd1149.Obj) = ((Wrd1155.pObj) [2]);

DEFLABEL (label_364)
  (Wrd1176.Obj) = (Rsp [4]);
  (Wrd1177.uLng) = (OBJECT_TYPE (Wrd1176.Obj));
  if (! ((Wrd1177.uLng) == 62))
    goto label_363;
  (Wrd1170.uLng) = (OBJECT_TYPE (Wrd1149.Obj));
  if (! ((Wrd1170.uLng) == 26))
    goto label_363;
  (Wrd1171.Lng) = (FIXNUM_TO_LONG (Wrd1149.Obj));
  (Wrd1173.pObj) = (OBJECT_ADDRESS (Wrd1176.Obj));
  (Wrd1174.Obj) = ((Wrd1173.pObj) [0]);
  (Wrd1175.Lng) = (FIXNUM_TO_LONG (Wrd1174.Obj));
  if (! (((unsigned long) (Wrd1171.Lng)) < ((unsigned long) (Wrd1175.Lng))))
    goto label_363;
  (Wrd1166.uLng) = (OBJECT_DATUM (Wrd1149.Obj));
  (Wrd1169.pObj) = (& ((Wrd1173.pObj) [(Wrd1166.Lng)]));
  (Wrd1165.Obj) = ((Wrd1169.pObj) [1]);

DEFLABEL (label_362)
  (Wrd1183.Obj) = (* (Rsp++));
  (Wrd1185.Lng) = (FIXNUM_TO_LONG (Wrd1165.Obj));
  (Wrd1186.Lng) = (FIXNUM_TO_LONG (Wrd1183.Obj));
  (Wrd1187.Lng) = ((Wrd1185.Lng) + (Wrd1186.Lng));
  (Wrd1188.Obj) = (* (Rsp++));
  Wrd1190 = Wrd1187;
  (Wrd1191.Lng) = (FIXNUM_TO_LONG (Wrd1188.Obj));
  (Wrd1192.Lng) = ((Wrd1190.Lng) + (Wrd1191.Lng));
  (Wrd1193.Obj) = (* (Rsp++));
  Wrd1194 = Wrd1192;
  (Wrd1195.Lng) = (FIXNUM_TO_LONG (Wrd1193.Obj));
  (Wrd1196.Lng) = ((Wrd1194.Lng) & (Wrd1195.Lng));
  (Wrd1197.Obj) = (LONG_TO_FIXNUM (Wrd1196.Lng));
  (* (--Rsp)) = (Wrd1197.Obj);
  (Wrd1207.Obj) = (Rsp [1]);
  (Wrd1208.uLng) = (OBJECT_TYPE (Wrd1207.Obj));
  if (! ((Wrd1208.uLng) == 62))
    goto label_361;
  (Wrd1204.pObj) = (OBJECT_ADDRESS (Wrd1207.Obj));
  (Wrd1205.Obj) = ((Wrd1204.pObj) [0]);
  (Wrd1206.Lng) = (FIXNUM_TO_LONG (Wrd1205.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd1206.Lng))))
    goto label_361;
  (Wrd1198.Obj) = ((Wrd1204.pObj) [6]);

DEFLABEL (label_360)
  (Wrd1214.Obj) = (* (Rsp++));
  (Wrd1224.uLng) = (OBJECT_TYPE (Wrd1198.Obj));
  if (! ((Wrd1224.uLng) == 10))
    goto label_359;
  (Wrd1219.uLng) = (OBJECT_TYPE (Wrd1214.Obj));
  if (! ((Wrd1219.uLng) == 26))
    goto label_359;
  (Wrd1220.Lng) = (FIXNUM_TO_LONG (Wrd1214.Obj));
  (Wrd1221.pObj) = (OBJECT_ADDRESS (Wrd1198.Obj));
  (Wrd1222.Obj) = ((Wrd1221.pObj) [0]);
  (Wrd1223.Lng) = (FIXNUM_TO_LONG (Wrd1222.Obj));
  if (! (((unsigned long) (Wrd1220.Lng)) < ((unsigned long) (Wrd1223.Lng))))
    goto label_359;
  (Wrd1216.uLng) = (OBJECT_DATUM (Wrd1214.Obj));
  (Wrd1218.pObj) = (& ((Wrd1221.pObj) [(Wrd1216.Lng)]));
  (Wrd1215.Obj) = ((Wrd1218.pObj) [1]);

DEFLABEL (label_358)
  (Wrd1231.pObj) = (OBJECT_ADDRESS (Wrd1215.Obj));
  (Wrd1230.Obj) = ((Wrd1231.pObj) [1]);
  (Wrd1233.pObj) = (OBJECT_ADDRESS (Wrd1230.Obj));
  (Wrd1232.Obj) = ((Wrd1233.pObj) [1]);
  (Wrd1235.pObj) = (OBJECT_ADDRESS (Wrd1232.Obj));
  (Wrd1234.Obj) = ((Wrd1235.pObj) [1]);
  (Wrd1237.pObj) = (OBJECT_ADDRESS (Wrd1234.Obj));
  (Wrd1236.Obj) = ((Wrd1237.pObj) [0]);
  (Wrd1238.Obj) = (Rsp [4]);
  if (! ((Wrd1238.Obj) == (Wrd1236.Obj)))
    goto label_334;
  (Wrd1248.Obj) = (Rsp [0]);
  (Wrd1249.uLng) = (OBJECT_TYPE (Wrd1248.Obj));
  if (! ((Wrd1249.uLng) == 62))
    goto label_357;
  (Wrd1245.pObj) = (OBJECT_ADDRESS (Wrd1248.Obj));
  (Wrd1246.Obj) = ((Wrd1245.pObj) [0]);
  (Wrd1247.Lng) = (FIXNUM_TO_LONG (Wrd1246.Obj));
  if (! (((unsigned long) 2L) < ((unsigned long) (Wrd1247.Lng))))
    goto label_357;
  (Wrd1241.Obj) = ((Wrd1245.pObj) [3]);
  (* (--Rsp)) = (Wrd1241.Obj);

DEFLABEL (label_356)
  (Wrd1264.Obj) = (Rsp [1]);
  (Wrd1265.uLng) = (OBJECT_TYPE (Wrd1264.Obj));
  if (! ((Wrd1265.uLng) == 62))
    goto label_355;
  (Wrd1261.pObj) = (OBJECT_ADDRESS (Wrd1264.Obj));
  (Wrd1262.Obj) = ((Wrd1261.pObj) [0]);
  (Wrd1263.Lng) = (FIXNUM_TO_LONG (Wrd1262.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1263.Lng))))
    goto label_355;
  (Wrd1255.Obj) = ((Wrd1261.pObj) [2]);

DEFLABEL (label_354)
  (Wrd1282.Obj) = (Rsp [5]);
  (Wrd1283.uLng) = (OBJECT_TYPE (Wrd1282.Obj));
  if (! ((Wrd1283.uLng) == 62))
    goto label_353;
  (Wrd1276.uLng) = (OBJECT_TYPE (Wrd1255.Obj));
  if (! ((Wrd1276.uLng) == 26))
    goto label_353;
  (Wrd1277.Lng) = (FIXNUM_TO_LONG (Wrd1255.Obj));
  (Wrd1279.pObj) = (OBJECT_ADDRESS (Wrd1282.Obj));
  (Wrd1280.Obj) = ((Wrd1279.pObj) [0]);
  (Wrd1281.Lng) = (FIXNUM_TO_LONG (Wrd1280.Obj));
  if (! (((unsigned long) (Wrd1277.Lng)) < ((unsigned long) (Wrd1281.Lng))))
    goto label_353;
  (Wrd1271.uLng) = (OBJECT_DATUM (Wrd1255.Obj));
  (Wrd1274.pObj) = (& ((Wrd1279.pObj) [(Wrd1271.Lng)]));
  (Wrd1275.Obj) = ((Wrd1274.pObj) [1]);
  (* (--Rsp)) = (Wrd1275.Obj);

DEFLABEL (label_352)
  (Wrd1298.Obj) = (Rsp [2]);
  (Wrd1299.uLng) = (OBJECT_TYPE (Wrd1298.Obj));
  if (! ((Wrd1299.uLng) == 62))
    goto label_351;
  (Wrd1295.pObj) = (OBJECT_ADDRESS (Wrd1298.Obj));
  (Wrd1296.Obj) = ((Wrd1295.pObj) [0]);
  (Wrd1297.Lng) = (FIXNUM_TO_LONG (Wrd1296.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1297.Lng))))
    goto label_351;
  (Wrd1289.Obj) = ((Wrd1295.pObj) [2]);

DEFLABEL (label_350)
  (Wrd1316.Obj) = (Rsp [5]);
  (Wrd1317.uLng) = (OBJECT_TYPE (Wrd1316.Obj));
  if (! ((Wrd1317.uLng) == 62))
    goto label_349;
  (Wrd1310.uLng) = (OBJECT_TYPE (Wrd1289.Obj));
  if (! ((Wrd1310.uLng) == 26))
    goto label_349;
  (Wrd1311.Lng) = (FIXNUM_TO_LONG (Wrd1289.Obj));
  (Wrd1313.pObj) = (OBJECT_ADDRESS (Wrd1316.Obj));
  (Wrd1314.Obj) = ((Wrd1313.pObj) [0]);
  (Wrd1315.Lng) = (FIXNUM_TO_LONG (Wrd1314.Obj));
  if (! (((unsigned long) (Wrd1311.Lng)) < ((unsigned long) (Wrd1315.Lng))))
    goto label_349;
  (Wrd1306.uLng) = (OBJECT_DATUM (Wrd1289.Obj));
  (Wrd1309.pObj) = (& ((Wrd1313.pObj) [(Wrd1306.Lng)]));
  (Wrd1305.Obj) = ((Wrd1309.pObj) [1]);

DEFLABEL (label_348)
  (Wrd1323.Obj) = (* (Rsp++));
  (Wrd1324.Lng) = (FIXNUM_TO_LONG (Wrd1305.Obj));
  (Wrd1325.Lng) = (FIXNUM_TO_LONG (Wrd1323.Obj));
  (Wrd1326.Lng) = ((Wrd1324.Lng) + (Wrd1325.Lng));
  (Wrd1327.Obj) = (LONG_TO_FIXNUM (Wrd1326.Lng));
  (* (--Rsp)) = (Wrd1327.Obj);
  (Wrd1337.Obj) = (Rsp [2]);
  (Wrd1338.uLng) = (OBJECT_TYPE (Wrd1337.Obj));
  if (! ((Wrd1338.uLng) == 62))
    goto label_347;
  (Wrd1334.pObj) = (OBJECT_ADDRESS (Wrd1337.Obj));
  (Wrd1335.Obj) = ((Wrd1334.pObj) [0]);
  (Wrd1336.Lng) = (FIXNUM_TO_LONG (Wrd1335.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1336.Lng))))
    goto label_347;
  (Wrd1328.Obj) = ((Wrd1334.pObj) [2]);

DEFLABEL (label_346)
  (Wrd1355.Obj) = (Rsp [4]);
  (Wrd1356.uLng) = (OBJECT_TYPE (Wrd1355.Obj));
  if (! ((Wrd1356.uLng) == 62))
    goto label_345;
  (Wrd1349.uLng) = (OBJECT_TYPE (Wrd1328.Obj));
  if (! ((Wrd1349.uLng) == 26))
    goto label_345;
  (Wrd1350.Lng) = (FIXNUM_TO_LONG (Wrd1328.Obj));
  (Wrd1352.pObj) = (OBJECT_ADDRESS (Wrd1355.Obj));
  (Wrd1353.Obj) = ((Wrd1352.pObj) [0]);
  (Wrd1354.Lng) = (FIXNUM_TO_LONG (Wrd1353.Obj));
  if (! (((unsigned long) (Wrd1350.Lng)) < ((unsigned long) (Wrd1354.Lng))))
    goto label_345;
  (Wrd1344.uLng) = (OBJECT_DATUM (Wrd1328.Obj));
  (Wrd1347.pObj) = (& ((Wrd1352.pObj) [(Wrd1344.Lng)]));
  (Wrd1348.Obj) = ((Wrd1347.pObj) [1]);
  (* (--Rsp)) = (Wrd1348.Obj);

DEFLABEL (label_344)
  (Wrd1371.Obj) = (Rsp [3]);
  (Wrd1372.uLng) = (OBJECT_TYPE (Wrd1371.Obj));
  if (! ((Wrd1372.uLng) == 62))
    goto label_343;
  (Wrd1368.pObj) = (OBJECT_ADDRESS (Wrd1371.Obj));
  (Wrd1369.Obj) = ((Wrd1368.pObj) [0]);
  (Wrd1370.Lng) = (FIXNUM_TO_LONG (Wrd1369.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd1370.Lng))))
    goto label_343;
  (Wrd1362.Obj) = ((Wrd1368.pObj) [2]);

DEFLABEL (label_342)
  (Wrd1389.Obj) = (Rsp [4]);
  (Wrd1390.uLng) = (OBJECT_TYPE (Wrd1389.Obj));
  if (! ((Wrd1390.uLng) == 62))
    goto label_341;
  (Wrd1383.uLng) = (OBJECT_TYPE (Wrd1362.Obj));
  if (! ((Wrd1383.uLng) == 26))
    goto label_341;
  (Wrd1384.Lng) = (FIXNUM_TO_LONG (Wrd1362.Obj));
  (Wrd1386.pObj) = (OBJECT_ADDRESS (Wrd1389.Obj));
  (Wrd1387.Obj) = ((Wrd1386.pObj) [0]);
  (Wrd1388.Lng) = (FIXNUM_TO_LONG (Wrd1387.Obj));
  if (! (((unsigned long) (Wrd1384.Lng)) < ((unsigned long) (Wrd1388.Lng))))
    goto label_341;
  (Wrd1379.uLng) = (OBJECT_DATUM (Wrd1362.Obj));
  (Wrd1382.pObj) = (& ((Wrd1386.pObj) [(Wrd1379.Lng)]));
  (Wrd1378.Obj) = ((Wrd1382.pObj) [1]);

DEFLABEL (label_340)
  (Wrd1396.Obj) = (* (Rsp++));
  (Wrd1398.Lng) = (FIXNUM_TO_LONG (Wrd1378.Obj));
  (Wrd1399.Lng) = (FIXNUM_TO_LONG (Wrd1396.Obj));
  (Wrd1400.Lng) = ((Wrd1398.Lng) + (Wrd1399.Lng));
  (Wrd1401.Obj) = (* (Rsp++));
  Wrd1403 = Wrd1400;
  (Wrd1404.Lng) = (FIXNUM_TO_LONG (Wrd1401.Obj));
  (Wrd1405.Lng) = ((Wrd1403.Lng) + (Wrd1404.Lng));
  (Wrd1406.Obj) = (* (Rsp++));
  Wrd1408 = Wrd1405;
  (Wrd1409.Lng) = (FIXNUM_TO_LONG (Wrd1406.Obj));
  (Wrd1410.Lng) = ((Wrd1408.Lng) & (Wrd1409.Lng));
  (Wrd1407.Obj) = (LONG_TO_FIXNUM (Wrd1410.Lng));
  (Rsp [4]) = (Wrd1407.Obj);
  (Wrd1420.Obj) = (Rsp [0]);
  (Wrd1421.uLng) = (OBJECT_TYPE (Wrd1420.Obj));
  if (! ((Wrd1421.uLng) == 62))
    goto label_339;
  (Wrd1417.pObj) = (OBJECT_ADDRESS (Wrd1420.Obj));
  (Wrd1418.Obj) = ((Wrd1417.pObj) [0]);
  (Wrd1419.Lng) = (FIXNUM_TO_LONG (Wrd1418.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd1419.Lng))))
    goto label_339;
  (Wrd1411.Obj) = ((Wrd1417.pObj) [7]);

DEFLABEL (label_338)
  (Rsp [3]) = (Wrd1411.Obj);
  Rsp = (& (Rsp [3]));
  (Wrd1442.Obj) = (Rsp [0]);
  (Wrd1443.uLng) = (OBJECT_TYPE (Wrd1442.Obj));
  if ((Wrd1443.uLng) == 10)
    goto label_337;

DEFLABEL (label_336)
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_337)
  (Wrd1434.Obj) = (Rsp [1]);
  (Wrd1435.uLng) = (OBJECT_TYPE (Wrd1434.Obj));
  if (! ((Wrd1435.uLng) == 26))
    goto label_336;
  (Wrd1437.Lng) = (FIXNUM_TO_LONG (Wrd1434.Obj));
  (Wrd1439.pObj) = (OBJECT_ADDRESS (Wrd1442.Obj));
  (Wrd1440.Obj) = ((Wrd1439.pObj) [0]);
  (Wrd1441.Lng) = (FIXNUM_TO_LONG (Wrd1440.Obj));
  if (! (((unsigned long) (Wrd1437.Lng)) < ((unsigned long) (Wrd1441.Lng))))
    goto label_336;
  (Wrd1429.uLng) = (OBJECT_DATUM (Wrd1434.Obj));
  (Wrd1432.pObj) = (& ((Wrd1439.pObj) [(Wrd1429.Lng)]));
  Rvl = ((Wrd1432.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_339)
  (Wrd1422.Obj) = (Rsp [0]);
  (Wrd1423.Obj) = (current_block [OBJECT_34_5]);
  (Wrd1426.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_58]))));
  (* (--Rsp)) = (Wrd1426.Obj);
  (* (--Rsp)) = (Wrd1423.Obj);
  (* (--Rsp)) = (Wrd1422.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_261)
  (Wrd1411.Obj) = Rvl;
  goto label_338;

DEFLABEL (label_341)
  (Wrd1391.Obj) = (Rsp [4]);
  (Wrd1395.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_57]))));
  (* (--Rsp)) = (Wrd1395.Obj);
  (* (--Rsp)) = (Wrd1362.Obj);
  (* (--Rsp)) = (Wrd1391.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_260)
  (Wrd1378.Obj) = Rvl;
  goto label_340;

DEFLABEL (label_343)
  (Wrd1373.Obj) = (Rsp [3]);
  (Wrd1374.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1377.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_56]))));
  (* (--Rsp)) = (Wrd1377.Obj);
  (* (--Rsp)) = (Wrd1374.Obj);
  (* (--Rsp)) = (Wrd1373.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_259)
  (Wrd1362.Obj) = Rvl;
  goto label_342;

DEFLABEL (label_345)
  (Wrd1357.Obj) = (Rsp [4]);
  (Wrd1361.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_55]))));
  (* (--Rsp)) = (Wrd1361.Obj);
  (* (--Rsp)) = (Wrd1328.Obj);
  (* (--Rsp)) = (Wrd1357.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_258)
  (* (--Rsp)) = Rvl;
  goto label_344;

DEFLABEL (label_347)
  (Wrd1339.Obj) = (Rsp [2]);
  (Wrd1340.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1343.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_54]))));
  (* (--Rsp)) = (Wrd1343.Obj);
  (* (--Rsp)) = (Wrd1340.Obj);
  (* (--Rsp)) = (Wrd1339.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_257)
  (Wrd1328.Obj) = Rvl;
  goto label_346;

DEFLABEL (label_349)
  (Wrd1318.Obj) = (Rsp [5]);
  (Wrd1322.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_53]))));
  (* (--Rsp)) = (Wrd1322.Obj);
  (* (--Rsp)) = (Wrd1289.Obj);
  (* (--Rsp)) = (Wrd1318.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_256)
  (Wrd1305.Obj) = Rvl;
  goto label_348;

DEFLABEL (label_351)
  (Wrd1300.Obj) = (Rsp [2]);
  (Wrd1301.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1304.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_52]))));
  (* (--Rsp)) = (Wrd1304.Obj);
  (* (--Rsp)) = (Wrd1301.Obj);
  (* (--Rsp)) = (Wrd1300.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_255)
  (Wrd1289.Obj) = Rvl;
  goto label_350;

DEFLABEL (label_353)
  (Wrd1284.Obj) = (Rsp [5]);
  (Wrd1288.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_51]))));
  (* (--Rsp)) = (Wrd1288.Obj);
  (* (--Rsp)) = (Wrd1255.Obj);
  (* (--Rsp)) = (Wrd1284.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_254)
  (* (--Rsp)) = Rvl;
  goto label_352;

DEFLABEL (label_355)
  (Wrd1266.Obj) = (Rsp [1]);
  (Wrd1267.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1270.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_50]))));
  (* (--Rsp)) = (Wrd1270.Obj);
  (* (--Rsp)) = (Wrd1267.Obj);
  (* (--Rsp)) = (Wrd1266.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_253)
  (Wrd1255.Obj) = Rvl;
  goto label_354;

DEFLABEL (label_357)
  (Wrd1250.Obj) = (Rsp [0]);
  (Wrd1251.Obj) = (current_block [OBJECT_34_0]);
  (Wrd1254.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_49]))));
  (* (--Rsp)) = (Wrd1254.Obj);
  (* (--Rsp)) = (Wrd1251.Obj);
  (* (--Rsp)) = (Wrd1250.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_252)
  (* (--Rsp)) = Rvl;
  goto label_356;

DEFLABEL (label_359)
  (Wrd1229.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_48]))));
  (* (--Rsp)) = (Wrd1229.Obj);
  (* (--Rsp)) = (Wrd1214.Obj);
  (* (--Rsp)) = (Wrd1198.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_251)
  (Wrd1215.Obj) = Rvl;
  goto label_358;

DEFLABEL (label_361)
  (Wrd1209.Obj) = (Rsp [1]);
  (Wrd1210.Obj) = (current_block [OBJECT_34_3]);
  (Wrd1213.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_47]))));
  (* (--Rsp)) = (Wrd1213.Obj);
  (* (--Rsp)) = (Wrd1210.Obj);
  (* (--Rsp)) = (Wrd1209.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_250)
  (Wrd1198.Obj) = Rvl;
  goto label_360;

DEFLABEL (label_363)
  (Wrd1178.Obj) = (Rsp [4]);
  (Wrd1182.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_46]))));
  (* (--Rsp)) = (Wrd1182.Obj);
  (* (--Rsp)) = (Wrd1149.Obj);
  (* (--Rsp)) = (Wrd1178.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_249)
  (Wrd1165.Obj) = Rvl;
  goto label_362;

DEFLABEL (label_365)
  (Wrd1160.Obj) = (Rsp [3]);
  (Wrd1161.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1164.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_45]))));
  (* (--Rsp)) = (Wrd1164.Obj);
  (* (--Rsp)) = (Wrd1161.Obj);
  (* (--Rsp)) = (Wrd1160.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_248)
  (Wrd1149.Obj) = Rvl;
  goto label_364;

DEFLABEL (label_367)
  (Wrd1144.Obj) = (Rsp [4]);
  (Wrd1148.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_44]))));
  (* (--Rsp)) = (Wrd1148.Obj);
  (* (--Rsp)) = (Wrd1115.Obj);
  (* (--Rsp)) = (Wrd1144.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_247)
  (* (--Rsp)) = Rvl;
  goto label_366;

DEFLABEL (label_369)
  (Wrd1126.Obj) = (Rsp [2]);
  (Wrd1127.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1130.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_43]))));
  (* (--Rsp)) = (Wrd1130.Obj);
  (* (--Rsp)) = (Wrd1127.Obj);
  (* (--Rsp)) = (Wrd1126.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_246)
  (Wrd1115.Obj) = Rvl;
  goto label_368;

DEFLABEL (label_371)
  (Wrd1105.Obj) = (Rsp [5]);
  (Wrd1109.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_42]))));
  (* (--Rsp)) = (Wrd1109.Obj);
  (* (--Rsp)) = (Wrd1076.Obj);
  (* (--Rsp)) = (Wrd1105.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_245)
  (Wrd1092.Obj) = Rvl;
  goto label_370;

DEFLABEL (label_373)
  (Wrd1087.Obj) = (Rsp [2]);
  (Wrd1088.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1091.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_41]))));
  (* (--Rsp)) = (Wrd1091.Obj);
  (* (--Rsp)) = (Wrd1088.Obj);
  (* (--Rsp)) = (Wrd1087.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_244)
  (Wrd1076.Obj) = Rvl;
  goto label_372;

DEFLABEL (label_375)
  (Wrd1071.Obj) = (Rsp [5]);
  (Wrd1075.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_40]))));
  (* (--Rsp)) = (Wrd1075.Obj);
  (* (--Rsp)) = (Wrd1042.Obj);
  (* (--Rsp)) = (Wrd1071.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_243)
  (* (--Rsp)) = Rvl;
  goto label_374;

DEFLABEL (label_377)
  (Wrd1053.Obj) = (Rsp [1]);
  (Wrd1054.Obj) = (current_block [OBJECT_34_2]);
  (Wrd1057.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_39]))));
  (* (--Rsp)) = (Wrd1057.Obj);
  (* (--Rsp)) = (Wrd1054.Obj);
  (* (--Rsp)) = (Wrd1053.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_242)
  (Wrd1042.Obj) = Rvl;
  goto label_376;

DEFLABEL (label_379)
  (Wrd1037.Obj) = (Rsp [0]);
  (Wrd1038.Obj) = (current_block [OBJECT_34_0]);
  (Wrd1041.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_38]))));
  (* (--Rsp)) = (Wrd1041.Obj);
  (* (--Rsp)) = (Wrd1038.Obj);
  (* (--Rsp)) = (Wrd1037.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_241)
  (* (--Rsp)) = Rvl;
  goto label_378;

DEFLABEL (label_381)
  (Wrd1018.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_37]))));
  (* (--Rsp)) = (Wrd1018.Obj);
  (* (--Rsp)) = (Wrd1003.Obj);
  (* (--Rsp)) = (Wrd987.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_240)
  (Wrd1004.Obj) = Rvl;
  goto label_380;

DEFLABEL (label_383)
  (Wrd998.Obj) = (Rsp [1]);
  (Wrd999.Obj) = (current_block [OBJECT_34_3]);
  (Wrd1002.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_36]))));
  (* (--Rsp)) = (Wrd1002.Obj);
  (* (--Rsp)) = (Wrd999.Obj);
  (* (--Rsp)) = (Wrd998.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_239)
  (Wrd987.Obj) = Rvl;
  goto label_382;

DEFLABEL (label_385)
  (Wrd967.Obj) = (Rsp [4]);
  (Wrd971.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_35]))));
  (* (--Rsp)) = (Wrd971.Obj);
  (* (--Rsp)) = (Wrd938.Obj);
  (* (--Rsp)) = (Wrd967.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_238)
  (Wrd954.Obj) = Rvl;
  goto label_384;

DEFLABEL (label_387)
  (Wrd949.Obj) = (Rsp [3]);
  (Wrd950.Obj) = (current_block [OBJECT_34_2]);
  (Wrd953.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_34]))));
  (* (--Rsp)) = (Wrd953.Obj);
  (* (--Rsp)) = (Wrd950.Obj);
  (* (--Rsp)) = (Wrd949.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_237)
  (Wrd938.Obj) = Rvl;
  goto label_386;

DEFLABEL (label_389)
  (Wrd933.Obj) = (Rsp [4]);
  (Wrd937.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_33]))));
  (* (--Rsp)) = (Wrd937.Obj);
  (* (--Rsp)) = (Wrd904.Obj);
  (* (--Rsp)) = (Wrd933.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_236)
  (* (--Rsp)) = Rvl;
  goto label_388;

DEFLABEL (label_391)
  (Wrd915.Obj) = (Rsp [2]);
  (Wrd916.Obj) = (current_block [OBJECT_34_2]);
  (Wrd919.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_32]))));
  (* (--Rsp)) = (Wrd919.Obj);
  (* (--Rsp)) = (Wrd916.Obj);
  (* (--Rsp)) = (Wrd915.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_235)
  (Wrd904.Obj) = Rvl;
  goto label_390;

DEFLABEL (label_393)
  (Wrd894.Obj) = (Rsp [5]);
  (Wrd898.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_31]))));
  (* (--Rsp)) = (Wrd898.Obj);
  (* (--Rsp)) = (Wrd865.Obj);
  (* (--Rsp)) = (Wrd894.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_234)
  (Wrd881.Obj) = Rvl;
  goto label_392;

DEFLABEL (label_395)
  (Wrd876.Obj) = (Rsp [2]);
  (Wrd877.Obj) = (current_block [OBJECT_34_2]);
  (Wrd880.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_30]))));
  (* (--Rsp)) = (Wrd880.Obj);
  (* (--Rsp)) = (Wrd877.Obj);
  (* (--Rsp)) = (Wrd876.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_233)
  (Wrd865.Obj) = Rvl;
  goto label_394;

DEFLABEL (label_397)
  (Wrd860.Obj) = (Rsp [5]);
  (Wrd864.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_29]))));
  (* (--Rsp)) = (Wrd864.Obj);
  (* (--Rsp)) = (Wrd831.Obj);
  (* (--Rsp)) = (Wrd860.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_232)
  (* (--Rsp)) = Rvl;
  goto label_396;

DEFLABEL (label_399)
  (Wrd842.Obj) = (Rsp [1]);
  (Wrd843.Obj) = (current_block [OBJECT_34_2]);
  (Wrd846.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_28]))));
  (* (--Rsp)) = (Wrd846.Obj);
  (* (--Rsp)) = (Wrd843.Obj);
  (* (--Rsp)) = (Wrd842.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_231)
  (Wrd831.Obj) = Rvl;
  goto label_398;

DEFLABEL (label_401)
  (Wrd826.Obj) = (Rsp [0]);
  (Wrd827.Obj) = (current_block [OBJECT_34_0]);
  (Wrd830.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_27]))));
  (* (--Rsp)) = (Wrd830.Obj);
  (* (--Rsp)) = (Wrd827.Obj);
  (* (--Rsp)) = (Wrd826.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_230)
  (* (--Rsp)) = Rvl;
  goto label_400;

DEFLABEL (label_403)
  (Wrd809.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_26]))));
  (* (--Rsp)) = (Wrd809.Obj);
  (* (--Rsp)) = (Wrd794.Obj);
  (* (--Rsp)) = (Wrd778.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_229)
  (Wrd795.Obj) = Rvl;
  goto label_402;

DEFLABEL (label_405)
  (Wrd789.Obj) = (Rsp [1]);
  (Wrd790.Obj) = (current_block [OBJECT_34_3]);
  (Wrd793.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_25]))));
  (* (--Rsp)) = (Wrd793.Obj);
  (* (--Rsp)) = (Wrd790.Obj);
  (* (--Rsp)) = (Wrd789.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_228)
  (Wrd778.Obj) = Rvl;
  goto label_404;

DEFLABEL (label_407)
  (Wrd758.Obj) = (Rsp [4]);
  (Wrd762.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_24]))));
  (* (--Rsp)) = (Wrd762.Obj);
  (* (--Rsp)) = (Wrd729.Obj);
  (* (--Rsp)) = (Wrd758.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_227)
  (Wrd745.Obj) = Rvl;
  goto label_406;

DEFLABEL (label_409)
  (Wrd740.Obj) = (Rsp [3]);
  (Wrd741.Obj) = (current_block [OBJECT_34_2]);
  (Wrd744.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_23]))));
  (* (--Rsp)) = (Wrd744.Obj);
  (* (--Rsp)) = (Wrd741.Obj);
  (* (--Rsp)) = (Wrd740.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_226)
  (Wrd729.Obj) = Rvl;
  goto label_408;

DEFLABEL (label_411)
  (Wrd724.Obj) = (Rsp [4]);
  (Wrd728.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_22]))));
  (* (--Rsp)) = (Wrd728.Obj);
  (* (--Rsp)) = (Wrd695.Obj);
  (* (--Rsp)) = (Wrd724.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_225)
  (* (--Rsp)) = Rvl;
  goto label_410;

DEFLABEL (label_413)
  (Wrd706.Obj) = (Rsp [2]);
  (Wrd707.Obj) = (current_block [OBJECT_34_2]);
  (Wrd710.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_21]))));
  (* (--Rsp)) = (Wrd710.Obj);
  (* (--Rsp)) = (Wrd707.Obj);
  (* (--Rsp)) = (Wrd706.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_224)
  (Wrd695.Obj) = Rvl;
  goto label_412;

DEFLABEL (label_415)
  (Wrd685.Obj) = (Rsp [5]);
  (Wrd689.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_20]))));
  (* (--Rsp)) = (Wrd689.Obj);
  (* (--Rsp)) = (Wrd656.Obj);
  (* (--Rsp)) = (Wrd685.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_223)
  (Wrd672.Obj) = Rvl;
  goto label_414;

DEFLABEL (label_417)
  (Wrd667.Obj) = (Rsp [2]);
  (Wrd668.Obj) = (current_block [OBJECT_34_2]);
  (Wrd671.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_19]))));
  (* (--Rsp)) = (Wrd671.Obj);
  (* (--Rsp)) = (Wrd668.Obj);
  (* (--Rsp)) = (Wrd667.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_222)
  (Wrd656.Obj) = Rvl;
  goto label_416;

DEFLABEL (label_419)
  (Wrd651.Obj) = (Rsp [5]);
  (Wrd655.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_18]))));
  (* (--Rsp)) = (Wrd655.Obj);
  (* (--Rsp)) = (Wrd622.Obj);
  (* (--Rsp)) = (Wrd651.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_221)
  (* (--Rsp)) = Rvl;
  goto label_418;

DEFLABEL (label_421)
  (Wrd633.Obj) = (Rsp [1]);
  (Wrd634.Obj) = (current_block [OBJECT_34_2]);
  (Wrd637.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_17]))));
  (* (--Rsp)) = (Wrd637.Obj);
  (* (--Rsp)) = (Wrd634.Obj);
  (* (--Rsp)) = (Wrd633.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_220)
  (Wrd622.Obj) = Rvl;
  goto label_420;

DEFLABEL (label_423)
  (Wrd617.Obj) = (Rsp [0]);
  (Wrd618.Obj) = (current_block [OBJECT_34_0]);
  (Wrd621.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_16]))));
  (* (--Rsp)) = (Wrd621.Obj);
  (* (--Rsp)) = (Wrd618.Obj);
  (* (--Rsp)) = (Wrd617.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_219)
  (* (--Rsp)) = Rvl;
  goto label_422;

DEFLABEL (label_425)
  (Wrd208.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_15]))));
  (* (--Rsp)) = (Wrd208.Obj);
  (* (--Rsp)) = (Wrd193.Obj);
  (* (--Rsp)) = (Wrd177.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_197)
  (Wrd194.Obj) = Rvl;
  goto label_424;

DEFLABEL (label_427)
  (Wrd188.Obj) = (Rsp [1]);
  (Wrd189.Obj) = (current_block [OBJECT_34_3]);
  (Wrd192.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_14]))));
  (* (--Rsp)) = (Wrd192.Obj);
  (* (--Rsp)) = (Wrd189.Obj);
  (* (--Rsp)) = (Wrd188.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_196)
  (Wrd177.Obj) = Rvl;
  goto label_426;

DEFLABEL (label_429)
  (Wrd157.Obj) = (Rsp [4]);
  (Wrd161.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_13]))));
  (* (--Rsp)) = (Wrd161.Obj);
  (* (--Rsp)) = (Wrd128.Obj);
  (* (--Rsp)) = (Wrd157.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_195)
  (Wrd144.Obj) = Rvl;
  goto label_428;

DEFLABEL (label_431)
  (Wrd139.Obj) = (Rsp [3]);
  (Wrd140.Obj) = (current_block [OBJECT_34_2]);
  (Wrd143.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_12]))));
  (* (--Rsp)) = (Wrd143.Obj);
  (* (--Rsp)) = (Wrd140.Obj);
  (* (--Rsp)) = (Wrd139.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_194)
  (Wrd128.Obj) = Rvl;
  goto label_430;

DEFLABEL (label_433)
  (Wrd123.Obj) = (Rsp [4]);
  (Wrd127.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_11]))));
  (* (--Rsp)) = (Wrd127.Obj);
  (* (--Rsp)) = (Wrd94.Obj);
  (* (--Rsp)) = (Wrd123.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_193)
  (* (--Rsp)) = Rvl;
  goto label_432;

DEFLABEL (label_435)
  (Wrd105.Obj) = (Rsp [2]);
  (Wrd106.Obj) = (current_block [OBJECT_34_2]);
  (Wrd109.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_10]))));
  (* (--Rsp)) = (Wrd109.Obj);
  (* (--Rsp)) = (Wrd106.Obj);
  (* (--Rsp)) = (Wrd105.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_192)
  (Wrd94.Obj) = Rvl;
  goto label_434;

DEFLABEL (label_437)
  (Wrd84.Obj) = (Rsp [5]);
  (Wrd88.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_9]))));
  (* (--Rsp)) = (Wrd88.Obj);
  (* (--Rsp)) = (Wrd55.Obj);
  (* (--Rsp)) = (Wrd84.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_191)
  (Wrd71.Obj) = Rvl;
  goto label_436;

DEFLABEL (label_439)
  (Wrd66.Obj) = (Rsp [2]);
  (Wrd67.Obj) = (current_block [OBJECT_34_2]);
  (Wrd70.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_8]))));
  (* (--Rsp)) = (Wrd70.Obj);
  (* (--Rsp)) = (Wrd67.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_190)
  (Wrd55.Obj) = Rvl;
  goto label_438;

DEFLABEL (label_441)
  (Wrd50.Obj) = (Rsp [5]);
  (Wrd54.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_7]))));
  (* (--Rsp)) = (Wrd54.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = (Wrd50.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_189)
  (* (--Rsp)) = Rvl;
  goto label_440;

DEFLABEL (label_443)
  (Wrd32.Obj) = (Rsp [1]);
  (Wrd33.Obj) = (current_block [OBJECT_34_2]);
  (Wrd36.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_6]))));
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd33.Obj);
  (* (--Rsp)) = (Wrd32.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_188)
  (Wrd21.Obj) = Rvl;
  goto label_442;

DEFLABEL (label_445)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_34_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_187)
  (* (--Rsp)) = Rvl;
  goto label_444;

DEFLABEL (search_lines_288)
DEFLABEL (search_lines_168)
  INTERRUPT_CHECK (26, LABEL_34_80);
  (Wrd5.Obj) = (Rsp [1]);
  (Wrd6.Obj) = (Rsp [2]);
  if ((Wrd5.Obj) == (Wrd6.Obj))
    goto label_479;
  (Wrd16.Obj) = (Rsp [3]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_478;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_478;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_477)
  (Wrd268.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd268.uLng) == 10))
    goto label_476;
  (Wrd261.Obj) = (Rsp [0]);
  (Wrd262.uLng) = (OBJECT_TYPE (Wrd261.Obj));
  if (! ((Wrd262.uLng) == 26))
    goto label_476;
  (Wrd264.Lng) = (FIXNUM_TO_LONG (Wrd261.Obj));
  (Wrd265.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd266.Obj) = ((Wrd265.pObj) [0]);
  (Wrd267.Lng) = (FIXNUM_TO_LONG (Wrd266.Obj));
  if (! (((unsigned long) (Wrd264.Lng)) < ((unsigned long) (Wrd267.Lng))))
    goto label_476;
  (Wrd24.uLng) = (OBJECT_DATUM (Wrd261.Obj));
  (Wrd26.pObj) = (& ((Wrd265.pObj) [(Wrd24.Lng)]));
  (Wrd27.Obj) = ((Wrd26.pObj) [1]);
  if ((Wrd27.Obj) == ((SCHEME_OBJECT) 0))
    goto label_453;

DEFLABEL (label_475)
  (Wrd75.Obj) = (Rsp [3]);
  (Wrd76.uLng) = (OBJECT_TYPE (Wrd75.Obj));
  if (! ((Wrd76.uLng) == 62))
    goto label_474;
  (Wrd72.pObj) = (OBJECT_ADDRESS (Wrd75.Obj));
  (Wrd73.Obj) = ((Wrd72.pObj) [0]);
  (Wrd74.Lng) = (FIXNUM_TO_LONG (Wrd73.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd74.Lng))))
    goto label_474;
  (Wrd66.Obj) = ((Wrd72.pObj) [6]);

DEFLABEL (label_473)
  (Wrd94.uLng) = (OBJECT_TYPE (Wrd66.Obj));
  if (! ((Wrd94.uLng) == 10))
    goto label_472;
  (Wrd87.Obj) = (Rsp [0]);
  (Wrd88.uLng) = (OBJECT_TYPE (Wrd87.Obj));
  if (! ((Wrd88.uLng) == 26))
    goto label_472;
  (Wrd90.Lng) = (FIXNUM_TO_LONG (Wrd87.Obj));
  (Wrd91.pObj) = (OBJECT_ADDRESS (Wrd66.Obj));
  (Wrd92.Obj) = ((Wrd91.pObj) [0]);
  (Wrd93.Lng) = (FIXNUM_TO_LONG (Wrd92.Obj));
  if (! (((unsigned long) (Wrd90.Lng)) < ((unsigned long) (Wrd93.Lng))))
    goto label_472;
  (Wrd84.uLng) = (OBJECT_DATUM (Wrd87.Obj));
  (Wrd86.pObj) = (& ((Wrd91.pObj) [(Wrd84.Lng)]));
  (Wrd82.Obj) = ((Wrd86.pObj) [1]);

DEFLABEL (label_471)
  (Wrd101.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd100.Obj) = ((Wrd101.pObj) [0]);
  (Wrd102.Obj) = (Rsp [4]);
  if ((Wrd102.Obj) == (Wrd100.Obj))
    goto label_454;

DEFLABEL (label_453)
  (Wrd38.Obj) = (Rsp [3]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 62))
    goto label_452;
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (Wrd37.Lng) = (FIXNUM_TO_LONG (Wrd36.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd37.Lng))))
    goto label_452;
  (Wrd29.Obj) = ((Wrd35.pObj) [6]);

DEFLABEL (label_451)
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd49.uLng) == 10))
    goto label_450;
  (Wrd47.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd48.Obj) = ((Wrd47.pObj) [0]);
  (Wrd45.Obj) = (MAKE_OBJECT (26, (Wrd48.uLng)));

DEFLABEL (label_449)
  (Wrd55.Obj) = (Rsp [0]);
  (Wrd56.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd57.Lng) = ((Wrd56.Lng) + 1L);
  (Wrd54.Obj) = (LONG_TO_FIXNUM (Wrd57.Lng));
  if ((Wrd54.Obj) == (Wrd45.Obj))
    goto label_447;
  Wrd58 = Wrd54;
  goto label_446;

DEFLABEL (label_447)
  (Wrd58.Obj) = (current_block [OBJECT_34_7]);

DEFLABEL (label_446)
DEFLABEL (label_448)
  (Rsp [0]) = (Wrd58.Obj);
  (Wrd63.Obj) = (Rsp [1]);
  (Wrd64.Lng) = (FIXNUM_TO_LONG (Wrd63.Obj));
  (Wrd65.Lng) = ((Wrd64.Lng) + 1L);
  (Wrd62.Obj) = (LONG_TO_FIXNUM (Wrd65.Lng));
  (Rsp [1]) = (Wrd62.Obj);
  goto search_lines_168;

DEFLABEL (label_450)
  (Wrd53.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_94]))));
  (* (--Rsp)) = (Wrd53.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_8]), 1);

DEFLABEL (label_264)
  (Wrd45.Obj) = Rvl;
  goto label_449;

DEFLABEL (label_452)
  (Wrd40.Obj) = (Rsp [3]);
  (Wrd41.Obj) = (current_block [OBJECT_34_3]);
  (Wrd44.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_93]))));
  (* (--Rsp)) = (Wrd44.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd40.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_263)
  (Wrd29.Obj) = Rvl;
  goto label_451;

DEFLABEL (label_454)
  (Wrd112.Obj) = (Rsp [3]);
  (Wrd113.uLng) = (OBJECT_TYPE (Wrd112.Obj));
  if (! ((Wrd113.uLng) == 62))
    goto label_470;
  (Wrd109.pObj) = (OBJECT_ADDRESS (Wrd112.Obj));
  (Wrd110.Obj) = ((Wrd109.pObj) [0]);
  (Wrd111.Lng) = (FIXNUM_TO_LONG (Wrd110.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd111.Lng))))
    goto label_470;
  (Wrd103.Obj) = ((Wrd109.pObj) [6]);

DEFLABEL (label_469)
  (Wrd131.uLng) = (OBJECT_TYPE (Wrd103.Obj));
  if (! ((Wrd131.uLng) == 10))
    goto label_468;
  (Wrd124.Obj) = (Rsp [0]);
  (Wrd125.uLng) = (OBJECT_TYPE (Wrd124.Obj));
  if (! ((Wrd125.uLng) == 26))
    goto label_468;
  (Wrd127.Lng) = (FIXNUM_TO_LONG (Wrd124.Obj));
  (Wrd128.pObj) = (OBJECT_ADDRESS (Wrd103.Obj));
  (Wrd129.Obj) = ((Wrd128.pObj) [0]);
  (Wrd130.Lng) = (FIXNUM_TO_LONG (Wrd129.Obj));
  if (! (((unsigned long) (Wrd127.Lng)) < ((unsigned long) (Wrd130.Lng))))
    goto label_468;
  (Wrd121.uLng) = (OBJECT_DATUM (Wrd124.Obj));
  (Wrd123.pObj) = (& ((Wrd128.pObj) [(Wrd121.Lng)]));
  (Wrd119.Obj) = ((Wrd123.pObj) [1]);

DEFLABEL (label_467)
  (Wrd138.pObj) = (OBJECT_ADDRESS (Wrd119.Obj));
  (Wrd137.Obj) = ((Wrd138.pObj) [1]);
  (Wrd140.pObj) = (OBJECT_ADDRESS (Wrd137.Obj));
  (Wrd139.Obj) = ((Wrd140.pObj) [0]);
  (Wrd141.Obj) = (Rsp [5]);
  if (! ((Wrd141.Obj) == (Wrd139.Obj)))
    goto label_453;
  (Wrd151.Obj) = (Rsp [3]);
  (Wrd152.uLng) = (OBJECT_TYPE (Wrd151.Obj));
  if (! ((Wrd152.uLng) == 62))
    goto label_466;
  (Wrd148.pObj) = (OBJECT_ADDRESS (Wrd151.Obj));
  (Wrd149.Obj) = ((Wrd148.pObj) [0]);
  (Wrd150.Lng) = (FIXNUM_TO_LONG (Wrd149.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd150.Lng))))
    goto label_466;
  (Wrd142.Obj) = ((Wrd148.pObj) [6]);

DEFLABEL (label_465)
  (Wrd170.uLng) = (OBJECT_TYPE (Wrd142.Obj));
  if (! ((Wrd170.uLng) == 10))
    goto label_464;
  (Wrd163.Obj) = (Rsp [0]);
  (Wrd164.uLng) = (OBJECT_TYPE (Wrd163.Obj));
  if (! ((Wrd164.uLng) == 26))
    goto label_464;
  (Wrd166.Lng) = (FIXNUM_TO_LONG (Wrd163.Obj));
  (Wrd167.pObj) = (OBJECT_ADDRESS (Wrd142.Obj));
  (Wrd168.Obj) = ((Wrd167.pObj) [0]);
  (Wrd169.Lng) = (FIXNUM_TO_LONG (Wrd168.Obj));
  if (! (((unsigned long) (Wrd166.Lng)) < ((unsigned long) (Wrd169.Lng))))
    goto label_464;
  (Wrd160.uLng) = (OBJECT_DATUM (Wrd163.Obj));
  (Wrd162.pObj) = (& ((Wrd167.pObj) [(Wrd160.Lng)]));
  (Wrd158.Obj) = ((Wrd162.pObj) [1]);

DEFLABEL (label_463)
  (Wrd177.pObj) = (OBJECT_ADDRESS (Wrd158.Obj));
  (Wrd176.Obj) = ((Wrd177.pObj) [1]);
  (Wrd179.pObj) = (OBJECT_ADDRESS (Wrd176.Obj));
  (Wrd178.Obj) = ((Wrd179.pObj) [1]);
  (Wrd181.pObj) = (OBJECT_ADDRESS (Wrd178.Obj));
  (Wrd180.Obj) = ((Wrd181.pObj) [0]);
  (Wrd182.Obj) = (Rsp [6]);
  if (! ((Wrd182.Obj) == (Wrd180.Obj)))
    goto label_453;
  (Wrd192.Obj) = (Rsp [3]);
  (Wrd193.uLng) = (OBJECT_TYPE (Wrd192.Obj));
  if (! ((Wrd193.uLng) == 62))
    goto label_462;
  (Wrd189.pObj) = (OBJECT_ADDRESS (Wrd192.Obj));
  (Wrd190.Obj) = ((Wrd189.pObj) [0]);
  (Wrd191.Lng) = (FIXNUM_TO_LONG (Wrd190.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd191.Lng))))
    goto label_462;
  (Wrd183.Obj) = ((Wrd189.pObj) [6]);

DEFLABEL (label_461)
  (Wrd211.uLng) = (OBJECT_TYPE (Wrd183.Obj));
  if (! ((Wrd211.uLng) == 10))
    goto label_460;
  (Wrd204.Obj) = (Rsp [0]);
  (Wrd205.uLng) = (OBJECT_TYPE (Wrd204.Obj));
  if (! ((Wrd205.uLng) == 26))
    goto label_460;
  (Wrd207.Lng) = (FIXNUM_TO_LONG (Wrd204.Obj));
  (Wrd208.pObj) = (OBJECT_ADDRESS (Wrd183.Obj));
  (Wrd209.Obj) = ((Wrd208.pObj) [0]);
  (Wrd210.Lng) = (FIXNUM_TO_LONG (Wrd209.Obj));
  if (! (((unsigned long) (Wrd207.Lng)) < ((unsigned long) (Wrd210.Lng))))
    goto label_460;
  (Wrd201.uLng) = (OBJECT_DATUM (Wrd204.Obj));
  (Wrd203.pObj) = (& ((Wrd208.pObj) [(Wrd201.Lng)]));
  (Wrd199.Obj) = ((Wrd203.pObj) [1]);

DEFLABEL (label_459)
  (Wrd218.pObj) = (OBJECT_ADDRESS (Wrd199.Obj));
  (Wrd217.Obj) = ((Wrd218.pObj) [1]);
  (Wrd220.pObj) = (OBJECT_ADDRESS (Wrd217.Obj));
  (Wrd219.Obj) = ((Wrd220.pObj) [1]);
  (Wrd222.pObj) = (OBJECT_ADDRESS (Wrd219.Obj));
  (Wrd221.Obj) = ((Wrd222.pObj) [1]);
  (Wrd224.pObj) = (OBJECT_ADDRESS (Wrd221.Obj));
  (Wrd223.Obj) = ((Wrd224.pObj) [0]);
  (Wrd225.Obj) = (Rsp [7]);
  if (! ((Wrd225.Obj) == (Wrd223.Obj)))
    goto label_453;
  (Wrd235.Obj) = (Rsp [3]);
  (Wrd236.uLng) = (OBJECT_TYPE (Wrd235.Obj));
  if (! ((Wrd236.uLng) == 62))
    goto label_458;
  (Wrd232.pObj) = (OBJECT_ADDRESS (Wrd235.Obj));
  (Wrd233.Obj) = ((Wrd232.pObj) [0]);
  (Wrd234.Lng) = (FIXNUM_TO_LONG (Wrd233.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd234.Lng))))
    goto label_458;
  (Wrd226.Obj) = ((Wrd232.pObj) [7]);

DEFLABEL (label_457)
  (Rsp [6]) = (Wrd226.Obj);
  (Wrd242.Obj) = (Rsp [0]);
  (Rsp [7]) = (Wrd242.Obj);
  Rsp = (& (Rsp [6]));
  (Wrd258.Obj) = (Rsp [0]);
  (Wrd259.uLng) = (OBJECT_TYPE (Wrd258.Obj));
  if ((Wrd259.uLng) == 10)
    goto label_456;

DEFLABEL (label_455)
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_456)
  (Wrd250.Obj) = (Rsp [1]);
  (Wrd251.uLng) = (OBJECT_TYPE (Wrd250.Obj));
  if (! ((Wrd251.uLng) == 26))
    goto label_455;
  (Wrd253.Lng) = (FIXNUM_TO_LONG (Wrd250.Obj));
  (Wrd255.pObj) = (OBJECT_ADDRESS (Wrd258.Obj));
  (Wrd256.Obj) = ((Wrd255.pObj) [0]);
  (Wrd257.Lng) = (FIXNUM_TO_LONG (Wrd256.Obj));
  if (! (((unsigned long) (Wrd253.Lng)) < ((unsigned long) (Wrd257.Lng))))
    goto label_455;
  (Wrd245.uLng) = (OBJECT_DATUM (Wrd250.Obj));
  (Wrd248.pObj) = (& ((Wrd255.pObj) [(Wrd245.Lng)]));
  Rvl = ((Wrd248.pObj) [1]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_458)
  (Wrd237.Obj) = (Rsp [3]);
  (Wrd238.Obj) = (current_block [OBJECT_34_5]);
  (Wrd241.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_92]))));
  (* (--Rsp)) = (Wrd241.Obj);
  (* (--Rsp)) = (Wrd238.Obj);
  (* (--Rsp)) = (Wrd237.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_273)
  (Wrd226.Obj) = Rvl;
  goto label_457;

DEFLABEL (label_460)
  (Wrd213.Obj) = (Rsp [0]);
  (Wrd216.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_91]))));
  (* (--Rsp)) = (Wrd216.Obj);
  (* (--Rsp)) = (Wrd213.Obj);
  (* (--Rsp)) = (Wrd183.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_272)
  (Wrd199.Obj) = Rvl;
  goto label_459;

DEFLABEL (label_462)
  (Wrd194.Obj) = (Rsp [3]);
  (Wrd195.Obj) = (current_block [OBJECT_34_3]);
  (Wrd198.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_90]))));
  (* (--Rsp)) = (Wrd198.Obj);
  (* (--Rsp)) = (Wrd195.Obj);
  (* (--Rsp)) = (Wrd194.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_271)
  (Wrd183.Obj) = Rvl;
  goto label_461;

DEFLABEL (label_464)
  (Wrd172.Obj) = (Rsp [0]);
  (Wrd175.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_89]))));
  (* (--Rsp)) = (Wrd175.Obj);
  (* (--Rsp)) = (Wrd172.Obj);
  (* (--Rsp)) = (Wrd142.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_270)
  (Wrd158.Obj) = Rvl;
  goto label_463;

DEFLABEL (label_466)
  (Wrd153.Obj) = (Rsp [3]);
  (Wrd154.Obj) = (current_block [OBJECT_34_3]);
  (Wrd157.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_88]))));
  (* (--Rsp)) = (Wrd157.Obj);
  (* (--Rsp)) = (Wrd154.Obj);
  (* (--Rsp)) = (Wrd153.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_269)
  (Wrd142.Obj) = Rvl;
  goto label_465;

DEFLABEL (label_468)
  (Wrd133.Obj) = (Rsp [0]);
  (Wrd136.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_87]))));
  (* (--Rsp)) = (Wrd136.Obj);
  (* (--Rsp)) = (Wrd133.Obj);
  (* (--Rsp)) = (Wrd103.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_268)
  (Wrd119.Obj) = Rvl;
  goto label_467;

DEFLABEL (label_470)
  (Wrd114.Obj) = (Rsp [3]);
  (Wrd115.Obj) = (current_block [OBJECT_34_3]);
  (Wrd118.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_86]))));
  (* (--Rsp)) = (Wrd118.Obj);
  (* (--Rsp)) = (Wrd115.Obj);
  (* (--Rsp)) = (Wrd114.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_267)
  (Wrd103.Obj) = Rvl;
  goto label_469;

DEFLABEL (label_472)
  (Wrd96.Obj) = (Rsp [0]);
  (Wrd99.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_85]))));
  (* (--Rsp)) = (Wrd99.Obj);
  (* (--Rsp)) = (Wrd96.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_266)
  (Wrd82.Obj) = Rvl;
  goto label_471;

DEFLABEL (label_474)
  (Wrd77.Obj) = (Rsp [3]);
  (Wrd78.Obj) = (current_block [OBJECT_34_3]);
  (Wrd81.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_84]))));
  (* (--Rsp)) = (Wrd81.Obj);
  (* (--Rsp)) = (Wrd78.Obj);
  (* (--Rsp)) = (Wrd77.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_265)
  (Wrd66.Obj) = Rvl;
  goto label_473;

DEFLABEL (label_476)
  (Wrd270.Obj) = (Rsp [0]);
  (Wrd273.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_83]))));
  (* (--Rsp)) = (Wrd273.Obj);
  (* (--Rsp)) = (Wrd270.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_4]), 2);

DEFLABEL (label_274)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_453;
  goto label_475;

DEFLABEL (label_478)
  (Wrd18.Obj) = (Rsp [3]);
  (Wrd19.Obj) = (current_block [OBJECT_34_3]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_82]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_262)
  (Wrd7.Obj) = Rvl;
  goto label_477;

DEFLABEL (label_479)
  (Wrd284.Obj) = (Rsp [3]);
  (Wrd285.uLng) = (OBJECT_TYPE (Wrd284.Obj));
  if (! ((Wrd285.uLng) == 62))
    goto label_481;
  (Wrd281.pObj) = (OBJECT_ADDRESS (Wrd284.Obj));
  (Wrd282.Obj) = ((Wrd281.pObj) [0]);
  (Wrd283.Lng) = (FIXNUM_TO_LONG (Wrd282.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd283.Lng))))
    goto label_481;
  (Wrd275.Obj) = ((Wrd281.pObj) [8]);

DEFLABEL (label_480)
  (Rsp [2]) = (Wrd275.Obj);
  Rsp = (& (Rsp [2]));
  goto search_overflow_166;

DEFLABEL (label_481)
  (Wrd286.Obj) = (Rsp [3]);
  (Wrd287.Obj) = (current_block [OBJECT_34_9]);
  (Wrd290.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_81]))));
  (* (--Rsp)) = (Wrd290.Obj);
  (* (--Rsp)) = (Wrd287.Obj);
  (* (--Rsp)) = (Wrd286.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_1]), 2);

DEFLABEL (label_275)
  (Wrd275.Obj) = Rvl;
  goto label_480;

DEFLABEL (search_overflow_289)
DEFLABEL (search_overflow_166)
  INTERRUPT_CHECK (26, LABEL_34_95);
  (Wrd5.Obj) = (Rsp [0]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_34_10])))
    goto label_482;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [6]));
  goto pop_return;

DEFLABEL (label_482)
  (Wrd11.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd11.uLng) == 1))
    goto label_505;
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd7.Obj) = ((Wrd9.pObj) [0]);

DEFLABEL (label_504)
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd18.uLng) == 1))
    goto label_503;
  (Wrd17.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd16.Obj) = ((Wrd17.pObj) [0]);

DEFLABEL (label_502)
  (Wrd24.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd23.Obj) = ((Wrd24.pObj) [0]);
  (Wrd25.Obj) = (Rsp [2]);
  if ((Wrd25.Obj) == (Wrd23.Obj))
    goto label_486;

DEFLABEL (label_485)
  (Wrd29.Obj) = (Rsp [0]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 1))
    goto label_484;
  (Wrd28.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd26.Obj) = ((Wrd28.pObj) [1]);

DEFLABEL (label_483)
  (Rsp [0]) = (Wrd26.Obj);
  goto search_overflow_166;

DEFLABEL (label_484)
  (Wrd34.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_105]))));
  (* (--Rsp)) = (Wrd34.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_12]), 1);

DEFLABEL (label_278)
  (Wrd26.Obj) = Rvl;
  goto label_483;

DEFLABEL (label_486)
  (Wrd38.Obj) = (Rsp [0]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 1))
    goto label_501;
  (Wrd37.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd35.Obj) = ((Wrd37.pObj) [0]);

DEFLABEL (label_500)
  (Wrd46.uLng) = (OBJECT_TYPE (Wrd35.Obj));
  if (! ((Wrd46.uLng) == 1))
    goto label_499;
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd35.Obj));
  (Wrd44.Obj) = ((Wrd45.pObj) [0]);

DEFLABEL (label_498)
  (Wrd52.pObj) = (OBJECT_ADDRESS (Wrd44.Obj));
  (Wrd51.Obj) = ((Wrd52.pObj) [1]);
  (Wrd54.pObj) = (OBJECT_ADDRESS (Wrd51.Obj));
  (Wrd53.Obj) = ((Wrd54.pObj) [0]);
  (Wrd55.Obj) = (Rsp [3]);
  if (! ((Wrd55.Obj) == (Wrd53.Obj)))
    goto label_485;
  (Wrd59.Obj) = (Rsp [0]);
  (Wrd60.uLng) = (OBJECT_TYPE (Wrd59.Obj));
  if (! ((Wrd60.uLng) == 1))
    goto label_497;
  (Wrd58.pObj) = (OBJECT_ADDRESS (Wrd59.Obj));
  (Wrd56.Obj) = ((Wrd58.pObj) [0]);

DEFLABEL (label_496)
  (Wrd67.uLng) = (OBJECT_TYPE (Wrd56.Obj));
  if (! ((Wrd67.uLng) == 1))
    goto label_495;
  (Wrd66.pObj) = (OBJECT_ADDRESS (Wrd56.Obj));
  (Wrd65.Obj) = ((Wrd66.pObj) [0]);

DEFLABEL (label_494)
  (Wrd73.pObj) = (OBJECT_ADDRESS (Wrd65.Obj));
  (Wrd72.Obj) = ((Wrd73.pObj) [1]);
  (Wrd75.pObj) = (OBJECT_ADDRESS (Wrd72.Obj));
  (Wrd74.Obj) = ((Wrd75.pObj) [1]);
  (Wrd77.pObj) = (OBJECT_ADDRESS (Wrd74.Obj));
  (Wrd76.Obj) = ((Wrd77.pObj) [0]);
  (Wrd78.Obj) = (Rsp [4]);
  if (! ((Wrd78.Obj) == (Wrd76.Obj)))
    goto label_485;
  (Wrd82.Obj) = (Rsp [0]);
  (Wrd83.uLng) = (OBJECT_TYPE (Wrd82.Obj));
  if (! ((Wrd83.uLng) == 1))
    goto label_493;
  (Wrd81.pObj) = (OBJECT_ADDRESS (Wrd82.Obj));
  (Wrd79.Obj) = ((Wrd81.pObj) [0]);

DEFLABEL (label_492)
  (Wrd90.uLng) = (OBJECT_TYPE (Wrd79.Obj));
  if (! ((Wrd90.uLng) == 1))
    goto label_491;
  (Wrd89.pObj) = (OBJECT_ADDRESS (Wrd79.Obj));
  (Wrd88.Obj) = ((Wrd89.pObj) [0]);

DEFLABEL (label_490)
  (Wrd96.pObj) = (OBJECT_ADDRESS (Wrd88.Obj));
  (Wrd95.Obj) = ((Wrd96.pObj) [1]);
  (Wrd98.pObj) = (OBJECT_ADDRESS (Wrd95.Obj));
  (Wrd97.Obj) = ((Wrd98.pObj) [1]);
  (Wrd100.pObj) = (OBJECT_ADDRESS (Wrd97.Obj));
  (Wrd99.Obj) = ((Wrd100.pObj) [1]);
  (Wrd102.pObj) = (OBJECT_ADDRESS (Wrd99.Obj));
  (Wrd101.Obj) = ((Wrd102.pObj) [0]);
  (Wrd103.Obj) = (Rsp [5]);
  if (! ((Wrd103.Obj) == (Wrd101.Obj)))
    goto label_485;
  (Wrd107.Obj) = (Rsp [0]);
  (Wrd108.uLng) = (OBJECT_TYPE (Wrd107.Obj));
  if (! ((Wrd108.uLng) == 1))
    goto label_489;
  (Wrd106.pObj) = (OBJECT_ADDRESS (Wrd107.Obj));
  (Wrd104.Obj) = ((Wrd106.pObj) [0]);

DEFLABEL (label_488)
  (Rsp [5]) = (Wrd104.Obj);
  Rsp = (& (Rsp [5]));
  (Wrd117.Obj) = (Rsp [0]);
  (Wrd118.uLng) = (OBJECT_TYPE (Wrd117.Obj));
  if (! ((Wrd118.uLng) == 1))
    goto label_487;
  (Wrd115.pObj) = (OBJECT_ADDRESS (Wrd117.Obj));
  Rvl = ((Wrd115.pObj) [1]);
  Rsp = (& (Rsp [1]));
  goto pop_return;

DEFLABEL (label_487)
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_12]), 1);

DEFLABEL (label_489)
  (Wrd112.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_104]))));
  (* (--Rsp)) = (Wrd112.Obj);
  (* (--Rsp)) = (Wrd107.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_285)
  (Wrd104.Obj) = Rvl;
  goto label_488;

DEFLABEL (label_491)
  (Wrd94.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_103]))));
  (* (--Rsp)) = (Wrd94.Obj);
  (* (--Rsp)) = (Wrd79.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_284)
  (Wrd88.Obj) = Rvl;
  goto label_490;

DEFLABEL (label_493)
  (Wrd87.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_102]))));
  (* (--Rsp)) = (Wrd87.Obj);
  (* (--Rsp)) = (Wrd82.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_283)
  (Wrd79.Obj) = Rvl;
  goto label_492;

DEFLABEL (label_495)
  (Wrd71.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_101]))));
  (* (--Rsp)) = (Wrd71.Obj);
  (* (--Rsp)) = (Wrd56.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_282)
  (Wrd65.Obj) = Rvl;
  goto label_494;

DEFLABEL (label_497)
  (Wrd64.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_100]))));
  (* (--Rsp)) = (Wrd64.Obj);
  (* (--Rsp)) = (Wrd59.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_281)
  (Wrd56.Obj) = Rvl;
  goto label_496;

DEFLABEL (label_499)
  (Wrd50.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_99]))));
  (* (--Rsp)) = (Wrd50.Obj);
  (* (--Rsp)) = (Wrd35.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_280)
  (Wrd44.Obj) = Rvl;
  goto label_498;

DEFLABEL (label_501)
  (Wrd43.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_98]))));
  (* (--Rsp)) = (Wrd43.Obj);
  (* (--Rsp)) = (Wrd38.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_279)
  (Wrd35.Obj) = Rvl;
  goto label_500;

DEFLABEL (label_503)
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_97]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_277)
  (Wrd16.Obj) = Rvl;
  goto label_502;

DEFLABEL (label_505)
  (Wrd15.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_34_96]))));
  (* (--Rsp)) = (Wrd15.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_34_11]), 1);

DEFLABEL (label_276)
  (Wrd7.Obj) = Rvl;
  goto label_504;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_35_4 3
#define LABEL_35_5 5
#define LABEL_35_7 7
#define LABEL_35_10 9
#define LABEL_35_11 11
#define LABEL_35_12 13
#define LABEL_35_13 15
#define LABEL_35_15 17
#define LABEL_35_9 19
#define ENVIRONMENT_LABEL_35_3 37
#define DEBUGGING_LABEL_35_2 36
#define OBJECT_35_4 35
#define OBJECT_35_3 34
#define OBJECT_35_2 33
#define OBJECT_35_1 32
#define OBJECT_35_0 31
#define EXECUTE_CACHE_35_17 21
#define EXECUTE_CACHE_35_16 23
#define EXECUTE_CACHE_35_14 25
#define EXECUTE_CACHE_35_8 27
#define EXECUTE_CACHE_35_6 29
#define FREE_REFERENCES_LABEL_35_0 20
#define NUMBER_OF_LINKER_SECTIONS_35_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_35 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd25;
  machine_word Wrd5;
  machine_word Wrd26;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd13;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd41;
  machine_word Wrd38;
  machine_word Wrd36;
  machine_word Wrd28;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd32;
  machine_word Wrd27;
  machine_word Wrd24;
  machine_word Wrd23;
  machine_word Wrd12;
  machine_word Wrd20;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd22;
  machine_word Wrd21;
  machine_word Wrd11;
  machine_word Wrd10;
  machine_word Wrd8;
  machine_word Wrd7;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_35_4);
      goto fill_cache_11;

    case 1:
      current_block = (Rpc - LABEL_35_5);
      goto continuation_0;

    case 2:
      current_block = (Rpc - LABEL_35_7);
      goto continuation_1;

    case 3:
      current_block = (Rpc - LABEL_35_10);
      goto label_13;

    case 4:
      current_block = (Rpc - LABEL_35_11);
      goto label_14;

    case 5:
      current_block = (Rpc - LABEL_35_12);
      goto label_15;

    case 6:
      current_block = (Rpc - LABEL_35_13);
      goto continuation_2;

    case 7:
      current_block = (Rpc - LABEL_35_15);
      goto label_16;

    case 8:
      current_block = (Rpc - LABEL_35_9);
      goto continuation_7;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (fill_cache_18)
DEFLABEL (fill_cache_11)
  INTERRUPT_CHECK (26, LABEL_35_4);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_5]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd8.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_35_6]));

DEFLABEL (continuation_0)
  INTERRUPT_CHECK (27, LABEL_35_5);
  (* (--Rsp)) = Rvl;
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_7]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd8.Obj);
  (* (--Rsp)) = Rvl;
  (Wrd10.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd10.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_35_8]));

DEFLABEL (continuation_1)
  INTERRUPT_CHECK (27, LABEL_35_7);
  (* (--Rsp)) = Rvl;
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_19;
  Rvl = Rvl;
  Rsp = (& (Rsp [5]));
  goto pop_return;

DEFLABEL (label_19)
  (Wrd11.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_9]))));
  (* (--Rsp)) = (Wrd11.Obj);
  (Wrd21.Obj) = (Rsp [3]);
  (Wrd22.uLng) = (OBJECT_TYPE (Wrd21.Obj));
  if (! ((Wrd22.uLng) == 62))
    goto label_28;
  (Wrd18.pObj) = (OBJECT_ADDRESS (Wrd21.Obj));
  (Wrd19.Obj) = ((Wrd18.pObj) [0]);
  (Wrd20.Lng) = (FIXNUM_TO_LONG (Wrd19.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd20.Lng))))
    goto label_28;
  (Wrd12.Obj) = ((Wrd18.pObj) [6]);

DEFLABEL (label_27)
  (Wrd32.uLng) = (OBJECT_TYPE (Wrd12.Obj));
  if (! ((Wrd32.uLng) == 10))
    goto label_26;
  (Wrd30.pObj) = (OBJECT_ADDRESS (Wrd12.Obj));
  (Wrd31.Obj) = ((Wrd30.pObj) [0]);
  (Wrd28.Obj) = (MAKE_OBJECT (26, (Wrd31.uLng)));

DEFLABEL (label_25)
  (Wrd38.Obj) = (current_block [OBJECT_35_3]);
  (Wrd41.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_12]))));
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd38.Obj);
  (* (--Rsp)) = (Wrd28.Obj);
  INVOKE_INTERFACE_0 (41);

DEFLABEL (label_15)
  (* (--Rsp)) = Rvl;
  (Wrd45.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_13]))));
  (* (--Rsp)) = (Wrd45.Obj);
  (Wrd46.Obj) = (Rsp [5]);
  (* (--Rsp)) = (Wrd46.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_35_14]));

DEFLABEL (continuation_2)
  INTERRUPT_CHECK (27, LABEL_35_13);
  (Wrd13.Obj) = Rvl;
  (Wrd12.Obj) = (* (Rsp++));
  (Wrd14.uLng) = (OBJECT_TYPE (Rvl));
  if (! ((Wrd14.uLng) == 26))
    goto label_24;
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd12.Obj));
  if (! ((Wrd15.uLng) == 26))
    goto label_24;
  (Wrd26.Lng) = (FIXNUM_TO_LONG (Rvl));
  (Wrd27.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! ((Wrd26.Lng) < (Wrd27.Lng)))
    goto label_23;

DEFLABEL (label_22)
  (Wrd23.Obj) = (Rsp [5]);
  (* (--Rsp)) = (Wrd23.Obj);
  (Wrd24.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd24.Obj);
  (Wrd25.Obj) = (Rsp [5]);
  (* (--Rsp)) = (Wrd25.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_35_16]));

DEFLABEL (continuation_7)
  INTERRUPT_CHECK (27, LABEL_35_9);
  (Wrd5.Obj) = Rvl;

DEFLABEL (label_21)
  (Rsp [0]) = (Wrd5.Obj);
  if ((Wrd5.Obj) == ((SCHEME_OBJECT) 0))
    goto label_20;
  Rvl = (Wrd5.Obj);
  Rsp = (& (Rsp [5]));
  goto pop_return;

DEFLABEL (label_20)
  (Wrd10.Obj) = (Rsp [1]);
  (Rsp [3]) = (Wrd10.Obj);
  Rsp = (& (Rsp [2]));
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_35_17]));

DEFLABEL (label_23)
  (Wrd5.Obj) = (current_block [OBJECT_35_4]);
  Rsp = (& (Rsp [1]));
  goto label_21;

DEFLABEL (label_24)
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_15]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd12.Obj);
  (* (--Rsp)) = (Wrd13.Obj);
  INVOKE_INTERFACE_0 (39);

DEFLABEL (label_16)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_23;
  goto label_22;

DEFLABEL (label_26)
  (Wrd36.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_11]))));
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd12.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_35_2]), 1);

DEFLABEL (label_14)
  (Wrd28.Obj) = Rvl;
  goto label_25;

DEFLABEL (label_28)
  (Wrd23.Obj) = (Rsp [3]);
  (Wrd24.Obj) = (current_block [OBJECT_35_0]);
  (Wrd27.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_35_10]))));
  (* (--Rsp)) = (Wrd27.Obj);
  (* (--Rsp)) = (Wrd24.Obj);
  (* (--Rsp)) = (Wrd23.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_35_1]), 2);

DEFLABEL (label_13)
  (Wrd12.Obj) = Rvl;
  goto label_27;

INVOKE_INTERFACE_TARGET_0
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_36_4 3
#define LABEL_36_5 5
#define LABEL_36_7 7
#define LABEL_36_9 9
#define LABEL_36_10 11
#define LABEL_36_11 13
#define LABEL_36_12 15
#define ENVIRONMENT_LABEL_36_3 26
#define DEBUGGING_LABEL_36_2 25
#define OBJECT_36_3 24
#define OBJECT_36_2 23
#define OBJECT_36_1 22
#define OBJECT_36_0 21
#define EXECUTE_CACHE_36_8 17
#define EXECUTE_CACHE_36_6 19
#define FREE_REFERENCES_LABEL_36_0 16
#define NUMBER_OF_LINKER_SECTIONS_36_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_36 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd60;
  machine_word Wrd57;
  machine_word Wrd56;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd43;
  machine_word Wrd53;
  machine_word Wrd52;
  machine_word Wrd51;
  machine_word Wrd50;
  machine_word Wrd48;
  machine_word Wrd47;
  machine_word Wrd54;
  machine_word Wrd39;
  machine_word Wrd36;
  machine_word Wrd35;
  machine_word Wrd24;
  machine_word Wrd32;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd79;
  machine_word Wrd76;
  machine_word Wrd75;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd62;
  machine_word Wrd72;
  machine_word Wrd71;
  machine_word Wrd70;
  machine_word Wrd69;
  machine_word Wrd67;
  machine_word Wrd66;
  machine_word Wrd73;
  machine_word Wrd23;
  machine_word Wrd20;
  machine_word Wrd19;
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd17;
  machine_word Wrd12;
  machine_word Wrd10;
  machine_word Wrd9;
  machine_word Wrd8;
  machine_word Wrd7;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_36_4);
      goto fill_cache_if_possible_8;

    case 1:
      current_block = (Rpc - LABEL_36_5);
      goto continuation_0;

    case 2:
      current_block = (Rpc - LABEL_36_7);
      goto continuation_1;

    case 3:
      current_block = (Rpc - LABEL_36_9);
      goto label_10;

    case 4:
      current_block = (Rpc - LABEL_36_10);
      goto label_13;

    case 5:
      current_block = (Rpc - LABEL_36_11);
      goto label_11;

    case 6:
      current_block = (Rpc - LABEL_36_12);
      goto label_12;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (fill_cache_if_possible_15)
DEFLABEL (fill_cache_if_possible_8)
  INTERRUPT_CHECK (26, LABEL_36_4);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_36_5]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd8.Obj);
  (Wrd9.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd9.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_36_6]));

DEFLABEL (continuation_0)
  INTERRUPT_CHECK (27, LABEL_36_5);
  (* (--Rsp)) = Rvl;
  if (! (Rvl == ((SCHEME_OBJECT) 0)))
    goto label_16;
  Rvl = (Rsp [1]);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_16)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_36_7]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd10.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd10.Obj);
  (* (--Rsp)) = Rvl;
  (Wrd12.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd12.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_36_8]));

DEFLABEL (continuation_1)
  INTERRUPT_CHECK (27, LABEL_36_7);
  (Rsp [0]) = Rvl;
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_26;
  (Wrd17.Obj) = (Rsp [1]);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd17.Obj));
  if (! ((Wrd18.uLng) == 62))
    goto label_25;
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd17.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd16.Lng))))
    goto label_25;
  (Wrd8.Obj) = ((Wrd14.pObj) [6]);

DEFLABEL (label_24)
  (Wrd73.uLng) = (OBJECT_TYPE (Wrd8.Obj));
  if (! ((Wrd73.uLng) == 10))
    goto label_23;
  (Wrd66.Obj) = (Rsp [0]);
  (Wrd67.uLng) = (OBJECT_TYPE (Wrd66.Obj));
  if (! ((Wrd67.uLng) == 26))
    goto label_23;
  (Wrd69.Lng) = (FIXNUM_TO_LONG (Wrd66.Obj));
  (Wrd70.pObj) = (OBJECT_ADDRESS (Wrd8.Obj));
  (Wrd71.Obj) = ((Wrd70.pObj) [0]);
  (Wrd72.Lng) = (FIXNUM_TO_LONG (Wrd71.Obj));
  if (! (((unsigned long) (Wrd69.Lng)) < ((unsigned long) (Wrd72.Lng))))
    goto label_23;
  (Wrd62.uLng) = (OBJECT_DATUM (Wrd66.Obj));
  (Wrd64.pObj) = (& ((Wrd70.pObj) [(Wrd62.Lng)]));
  (Wrd65.Obj) = (Rsp [2]);
  ((Wrd64.pObj) [1]) = (Wrd65.Obj);

DEFLABEL (label_22)
  (Wrd33.Obj) = (Rsp [1]);
  (Wrd34.uLng) = (OBJECT_TYPE (Wrd33.Obj));
  if (! ((Wrd34.uLng) == 62))
    goto label_21;
  (Wrd30.pObj) = (OBJECT_ADDRESS (Wrd33.Obj));
  (Wrd31.Obj) = ((Wrd30.pObj) [0]);
  (Wrd32.Lng) = (FIXNUM_TO_LONG (Wrd31.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd32.Lng))))
    goto label_21;
  (Wrd24.Obj) = ((Wrd30.pObj) [7]);

DEFLABEL (label_20)
  (Wrd54.uLng) = (OBJECT_TYPE (Wrd24.Obj));
  if (! ((Wrd54.uLng) == 10))
    goto label_19;
  (Wrd47.Obj) = (Rsp [0]);
  (Wrd48.uLng) = (OBJECT_TYPE (Wrd47.Obj));
  if (! ((Wrd48.uLng) == 26))
    goto label_19;
  (Wrd50.Lng) = (FIXNUM_TO_LONG (Wrd47.Obj));
  (Wrd51.pObj) = (OBJECT_ADDRESS (Wrd24.Obj));
  (Wrd52.Obj) = ((Wrd51.pObj) [0]);
  (Wrd53.Lng) = (FIXNUM_TO_LONG (Wrd52.Obj));
  if (! (((unsigned long) (Wrd50.Lng)) < ((unsigned long) (Wrd53.Lng))))
    goto label_19;
  (Wrd43.uLng) = (OBJECT_DATUM (Wrd47.Obj));
  (Wrd45.pObj) = (& ((Wrd51.pObj) [(Wrd43.Lng)]));
  (Wrd46.Obj) = (Rsp [3]);
  ((Wrd45.pObj) [1]) = (Wrd46.Obj);

DEFLABEL (label_18)
  Rvl = (Rsp [1]);

DEFLABEL (label_17)
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_19)
  (Wrd56.Obj) = (Rsp [0]);
  (Wrd57.Obj) = (Rsp [3]);
  (Wrd60.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_36_12]))));
  (* (--Rsp)) = (Wrd60.Obj);
  (* (--Rsp)) = (Wrd57.Obj);
  (* (--Rsp)) = (Wrd56.Obj);
  (* (--Rsp)) = (Wrd24.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_36_2]), 3);

DEFLABEL (label_12)
  goto label_18;

DEFLABEL (label_21)
  (Wrd35.Obj) = (Rsp [1]);
  (Wrd36.Obj) = (current_block [OBJECT_36_3]);
  (Wrd39.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_36_11]))));
  (* (--Rsp)) = (Wrd39.Obj);
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd35.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_36_1]), 2);

DEFLABEL (label_11)
  (Wrd24.Obj) = Rvl;
  goto label_20;

DEFLABEL (label_23)
  (Wrd75.Obj) = (Rsp [0]);
  (Wrd76.Obj) = (Rsp [2]);
  (Wrd79.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_36_10]))));
  (* (--Rsp)) = (Wrd79.Obj);
  (* (--Rsp)) = (Wrd76.Obj);
  (* (--Rsp)) = (Wrd75.Obj);
  (* (--Rsp)) = (Wrd8.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_36_2]), 3);

DEFLABEL (label_13)
  goto label_22;

DEFLABEL (label_25)
  (Wrd19.Obj) = (Rsp [1]);
  (Wrd20.Obj) = (current_block [OBJECT_36_0]);
  (Wrd23.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_36_9]))));
  (* (--Rsp)) = (Wrd23.Obj);
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_36_1]), 2);

DEFLABEL (label_10)
  (Wrd8.Obj) = Rvl;
  goto label_24;

DEFLABEL (label_26)
  Rvl = ((SCHEME_OBJECT) 0);
  goto label_17;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_37_4 3
#define LABEL_37_5 5
#define LABEL_37_6 7
#define LABEL_37_8 9
#define LABEL_37_9 11
#define LABEL_37_7 13
#define LABEL_37_11 15
#define TAG_37_12 6
#define LABEL_37_19 17
#define LABEL_37_20 19
#define LABEL_37_13 21
#define TAG_37_14 9
#define LABEL_37_15 23
#define TAG_37_16 10
#define LABEL_37_26 25
#define LABEL_37_27 27
#define LABEL_37_28 29
#define LABEL_37_29 31
#define LABEL_37_17 33
#define TAG_37_18 15
#define LABEL_37_30 35
#define LABEL_37_32 37
#define LABEL_37_33 39
#define LABEL_37_34 41
#define LABEL_37_35 43
#define LABEL_37_21 45
#define LABEL_37_25 47
#define LABEL_37_36 49
#define LABEL_37_23 51
#define LABEL_37_31 53
#define ENVIRONMENT_LABEL_37_3 75
#define DEBUGGING_LABEL_37_2 74
#define OBJECT_37_12 73
#define OBJECT_37_11 72
#define OBJECT_37_10 71
#define OBJECT_37_9 70
#define OBJECT_37_8 69
#define OBJECT_37_7 68
#define OBJECT_37_6 67
#define OBJECT_37_5 66
#define OBJECT_37_4 65
#define OBJECT_37_3 64
#define OBJECT_37_2 63
#define OBJECT_37_1 62
#define OBJECT_37_0 61
#define EXECUTE_CACHE_37_24 55
#define EXECUTE_CACHE_37_22 57
#define EXECUTE_CACHE_37_10 59
#define FREE_REFERENCES_LABEL_37_0 54
#define NUMBER_OF_LINKER_SECTIONS_37_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_37 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd100;
  machine_word Wrd99;
  machine_word Wrd98;
  machine_word Wrd97;
  machine_word Wrd96;
  machine_word Wrd95;
  machine_word Wrd92;
  machine_word Wrd81;
  machine_word Wrd79;
  machine_word Wrd89;
  machine_word Wrd88;
  machine_word Wrd87;
  machine_word Wrd86;
  machine_word Wrd90;
  machine_word Wrd77;
  machine_word Wrd74;
  machine_word Wrd71;
  machine_word Wrd73;
  machine_word Wrd72;
  machine_word Wrd69;
  machine_word Wrd47;
  machine_word Wrd48;
  machine_word Wrd27;
  machine_word Wrd125;
  machine_word Wrd129;
  machine_word Wrd128;
  machine_word Wrd127;
  machine_word Wrd126;
  machine_word Wrd124;
  machine_word Wrd121;
  machine_word Wrd118;
  machine_word Wrd120;
  machine_word Wrd119;
  machine_word Wrd101;
  machine_word Wrd113;
  machine_word Wrd112;
  machine_word Wrd111;
  machine_word Wrd117;
  machine_word Wrd116;
  machine_word Wrd37;
  machine_word Wrd34;
  machine_word Wrd26;
  machine_word Wrd51;
  machine_word Wrd50;
  machine_word Wrd8;
  machine_word Wrd70;
  machine_word Wrd63;
  machine_word Wrd64;
  machine_word Wrd38;
  machine_word Wrd31;
  machine_word Wrd28;
  machine_word Wrd9;
  machine_word Wrd21;
  machine_word Wrd85;
  machine_word Wrd82;
  machine_word Wrd84;
  machine_word Wrd83;
  machine_word Wrd66;
  machine_word Wrd68;
  machine_word Wrd67;
  machine_word Wrd55;
  machine_word Wrd54;
  machine_word Wrd53;
  machine_word Wrd39;
  machine_word Wrd35;
  machine_word Wrd30;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd7;
  machine_word Wrd6;
  machine_word Wrd10;
  machine_word Wrd65;
  machine_word Wrd62;
  machine_word Wrd61;
  machine_word Wrd52;
  machine_word Wrd58;
  machine_word Wrd57;
  machine_word Wrd56;
  machine_word Wrd60;
  machine_word Wrd59;
  machine_word Wrd49;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd36;
  machine_word Wrd42;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd44;
  machine_word Wrd43;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd29;
  machine_word Wrd24;
  machine_word Wrd23;
  machine_word Wrd22;
  machine_word Wrd25;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_37_4);
      goto adjust_cache_40;

    case 1:
      current_block = (Rpc - LABEL_37_5);
      goto label_42;

    case 2:
      current_block = (Rpc - LABEL_37_6);
      goto label_43;

    case 3:
      current_block = (Rpc - LABEL_37_8);
      goto label_44;

    case 4:
      current_block = (Rpc - LABEL_37_9);
      goto label_45;

    case 5:
      current_block = (Rpc - LABEL_37_7);
      goto continuation_4;

    case 6:
      current_block = (Rpc - LABEL_37_11);
      goto lambda_60;

    case 7:
      current_block = (Rpc - LABEL_37_19);
      goto label_46;

    case 8:
      current_block = (Rpc - LABEL_37_20);
      goto label_47;

    case 9:
      current_block = (Rpc - LABEL_37_13);
      goto lambda_61;

    case 10:
      current_block = (Rpc - LABEL_37_15);
      goto lambda_62;

    case 11:
      current_block = (Rpc - LABEL_37_26);
      goto label_48;

    case 12:
      current_block = (Rpc - LABEL_37_27);
      goto label_49;

    case 13:
      current_block = (Rpc - LABEL_37_28);
      goto label_50;

    case 14:
      current_block = (Rpc - LABEL_37_29);
      goto label_51;

    case 15:
      current_block = (Rpc - LABEL_37_17);
      goto lambda_63;

    case 16:
      current_block = (Rpc - LABEL_37_30);
      goto label_56;

    case 17:
      current_block = (Rpc - LABEL_37_32);
      goto label_52;

    case 18:
      current_block = (Rpc - LABEL_37_33);
      goto label_53;

    case 19:
      current_block = (Rpc - LABEL_37_34);
      goto label_54;

    case 20:
      current_block = (Rpc - LABEL_37_35);
      goto label_55;

    case 21:
      current_block = (Rpc - LABEL_37_21);
      goto continuation_24;

    case 22:
      current_block = (Rpc - LABEL_37_25);
      goto continuation_19;

    case 23:
      current_block = (Rpc - LABEL_37_36);
      goto label_57;

    case 24:
      current_block = (Rpc - LABEL_37_23);
      goto continuation_21;

    case 25:
      current_block = (Rpc - LABEL_37_31);
      goto continuation_10;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (adjust_cache_59)
DEFLABEL (adjust_cache_40)
  INTERRUPT_CHECK (26, LABEL_37_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_71;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_71;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_70)
  (Wrd25.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd25.uLng) == 10))
    goto label_69;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Obj) = (MAKE_OBJECT (26, (Wrd23.uLng)));
  (* (--Rsp)) = (Wrd24.Obj);

DEFLABEL (label_68)
  (Wrd32.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_7]))));
  (* (--Rsp)) = (Wrd32.Obj);
  (Wrd33.Obj) = (Rsp [1]);
  (* (--Rsp)) = (Wrd33.Obj);
  (Wrd43.Obj) = (Rsp [3]);
  (Wrd44.uLng) = (OBJECT_TYPE (Wrd43.Obj));
  if (! ((Wrd44.uLng) == 62))
    goto label_67;
  (Wrd40.pObj) = (OBJECT_ADDRESS (Wrd43.Obj));
  (Wrd41.Obj) = ((Wrd40.pObj) [0]);
  (Wrd42.Lng) = (FIXNUM_TO_LONG (Wrd41.Obj));
  if (! (((unsigned long) 4L) < ((unsigned long) (Wrd42.Lng))))
    goto label_67;
  (Wrd36.Obj) = ((Wrd40.pObj) [5]);
  (* (--Rsp)) = (Wrd36.Obj);

DEFLABEL (label_66)
  (Wrd59.Obj) = (Rsp [4]);
  (Wrd60.uLng) = (OBJECT_TYPE (Wrd59.Obj));
  if (! ((Wrd60.uLng) == 62))
    goto label_65;
  (Wrd56.pObj) = (OBJECT_ADDRESS (Wrd59.Obj));
  (Wrd57.Obj) = ((Wrd56.pObj) [0]);
  (Wrd58.Lng) = (FIXNUM_TO_LONG (Wrd57.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd58.Lng))))
    goto label_65;
  (Wrd52.Obj) = ((Wrd56.pObj) [2]);
  (* (--Rsp)) = (Wrd52.Obj);

DEFLABEL (label_64)
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_37_10]));

DEFLABEL (continuation_4)
  INTERRUPT_CHECK (27, LABEL_37_7);
  (* (--Rsp)) = Rvl;
  (Wrd10.Obj) = (MAKE_OBJECT (50, 0));
  (* (Rhp++)) = (Wrd10.Obj);
  (Wrd6.pObj) = (& (Rhp [-1]));
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd6.pObj)));
  (* (--Rsp)) = (Wrd7.Obj);
  (* (Rhp++)) = (Wrd10.Obj);
  (Wrd12.pObj) = (& (Rhp [-1]));
  (Wrd13.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd12.pObj)));
  (* (--Rsp)) = (Wrd13.Obj);
  (* (Rhp++)) = (Wrd10.Obj);
  (Wrd18.pObj) = (& (Rhp [-1]));
  (Wrd19.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd18.pObj)));
  (* (--Rsp)) = (Wrd19.Obj);
  (* (Rhp++)) = (Wrd10.Obj);
  (Wrd24.pObj) = (& (Rhp [-1]));
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd24.pObj)));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 5));
  (Wrd30.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x101, 2);
  (* (Rhp++)) = (dispatch_base + TAG_37_12);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_37_11])));
  Rhp += 2;
  (Wrd29.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd30.pObj)));
  Wrd33 = Wrd30;
  ((Wrd33.pObj) [2]) = Rvl;
  ((Wrd33.pObj) [3]) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 5));
  (Wrd36.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x303, 2);
  (* (Rhp++)) = (dispatch_base + TAG_37_14);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_37_13])));
  Rhp += 2;
  (Wrd35.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd36.pObj)));
  Wrd39 = Wrd36;
  (Wrd40.Obj) = (Rsp [8]);
  ((Wrd39.pObj) [2]) = (Wrd40.Obj);
  ((Wrd39.pObj) [3]) = Rvl;
  (* (--Rsp)) = (Wrd35.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 9));
  (Wrd42.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x202, 2);
  (* (Rhp++)) = (dispatch_base + TAG_37_16);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_37_15])));
  Rhp += 6;
  (Wrd41.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd42.pObj)));
  Wrd53 = Wrd42;
  (Wrd54.Obj) = (Rsp [10]);
  ((Wrd53.pObj) [2]) = (Wrd54.Obj);
  ((Wrd53.pObj) [3]) = (Wrd40.Obj);
  ((Wrd53.pObj) [4]) = Rvl;
  ((Wrd53.pObj) [5]) = (Wrd7.Obj);
  ((Wrd53.pObj) [6]) = (Wrd13.Obj);
  ((Wrd53.pObj) [7]) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 9));
  (Wrd56.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x202, 2);
  (* (Rhp++)) = (dispatch_base + TAG_37_18);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_37_17])));
  Rhp += 6;
  (Wrd55.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd56.pObj)));
  Wrd67 = Wrd56;
  (Wrd68.Obj) = (Rsp [9]);
  ((Wrd67.pObj) [2]) = (Wrd68.Obj);
  (Wrd66.Obj) = (Rsp [8]);
  ((Wrd67.pObj) [3]) = (Wrd66.Obj);
  ((Wrd67.pObj) [4]) = (Wrd7.Obj);
  ((Wrd67.pObj) [5]) = (Wrd13.Obj);
  ((Wrd67.pObj) [6]) = (Wrd19.Obj);
  ((Wrd67.pObj) [7]) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd55.Obj);
  ((Wrd24.pObj) [0]) = (Wrd55.Obj);
  ((Wrd18.pObj) [0]) = (Wrd41.Obj);
  ((Wrd12.pObj) [0]) = (Wrd35.Obj);
  ((Wrd6.pObj) [0]) = (Wrd29.Obj);
  Rsp = (& (Rsp [4]));
  (Wrd83.Obj) = (Rsp [0]);
  (Wrd84.pObj) = (OBJECT_ADDRESS (Wrd83.Obj));
  (Wrd82.Obj) = ((Wrd84.pObj) [0]);
  (Rsp [7]) = (Wrd82.Obj);
  (Wrd85.Obj) = (current_block [OBJECT_37_5]);
  (Rsp [8]) = (Wrd85.Obj);
  Rsp = (& (Rsp [7]));
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (label_65)
  (Wrd61.Obj) = (Rsp [4]);
  (Wrd62.Obj) = (current_block [OBJECT_37_4]);
  (Wrd65.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_9]))));
  (* (--Rsp)) = (Wrd65.Obj);
  (* (--Rsp)) = (Wrd62.Obj);
  (* (--Rsp)) = (Wrd61.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_1]), 2);

DEFLABEL (label_45)
  (* (--Rsp)) = Rvl;
  goto label_64;

DEFLABEL (label_67)
  (Wrd45.Obj) = (Rsp [3]);
  (Wrd46.Obj) = (current_block [OBJECT_37_3]);
  (Wrd49.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_8]))));
  (* (--Rsp)) = (Wrd49.Obj);
  (* (--Rsp)) = (Wrd46.Obj);
  (* (--Rsp)) = (Wrd45.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_1]), 2);

DEFLABEL (label_44)
  (* (--Rsp)) = Rvl;
  goto label_66;

DEFLABEL (label_69)
  (Wrd29.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_6]))));
  (* (--Rsp)) = (Wrd29.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_2]), 1);

DEFLABEL (label_43)
  (* (--Rsp)) = Rvl;
  goto label_68;

DEFLABEL (label_71)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_37_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_1]), 2);

DEFLABEL (label_42)
  (Wrd5.Obj) = Rvl;
  goto label_70;

DEFLABEL (lambda_60)
  CLOSURE_HEADER (LABEL_37_11);

DEFLABEL (lambda_34)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd18.Obj) = (Rsp [0]);
  (Wrd19.pObj) = (OBJECT_ADDRESS (Wrd18.Obj));
  (Wrd20.Obj) = ((Wrd19.pObj) [2]);
  (Wrd21.uLng) = (OBJECT_TYPE (Wrd20.Obj));
  if (! ((Wrd21.uLng) == 62))
    goto label_79;
  (Wrd15.pObj) = (OBJECT_ADDRESS (Wrd20.Obj));
  (Wrd16.Obj) = ((Wrd15.pObj) [0]);
  (Wrd17.Lng) = (FIXNUM_TO_LONG (Wrd16.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd17.Lng))))
    goto label_79;
  (Wrd9.Obj) = ((Wrd15.pObj) [2]);
  (* (--Rsp)) = (Wrd9.Obj);

DEFLABEL (label_78)
  (Wrd30.Obj) = (Rsp [0]);
  (Wrd31.Lng) = (FIXNUM_TO_LONG (Wrd30.Obj));
  (Wrd32.Lng) = ((Wrd31.Lng) + 1L);
  (Wrd29.Obj) = (LONG_TO_FIXNUM (Wrd32.Lng));
  Wrd33 = Wrd32;
  if ((Wrd33.Lng) < 10L)
    goto label_73;
  Rsp = (& (Rsp [1]));
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  goto label_72;

DEFLABEL (label_73)
  Rsp = (& (Rsp [1]));
  (* (--Rsp)) = (Wrd29.Obj);

DEFLABEL (label_72)
DEFLABEL (label_77)
  (Wrd38.Obj) = (Rsp [0]);
  if (! ((Wrd38.Obj) == ((SCHEME_OBJECT) 0)))
    goto label_74;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_74)
  (Wrd59.Obj) = (Rsp [1]);
  (Wrd60.pObj) = (OBJECT_ADDRESS (Wrd59.Obj));
  (Wrd61.Obj) = ((Wrd60.pObj) [2]);
  (Wrd62.uLng) = (OBJECT_TYPE (Wrd61.Obj));
  if (! ((Wrd62.uLng) == 62))
    goto label_76;
  (Wrd56.pObj) = (OBJECT_ADDRESS (Wrd61.Obj));
  (Wrd57.Obj) = ((Wrd56.pObj) [0]);
  (Wrd58.Lng) = (FIXNUM_TO_LONG (Wrd57.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd58.Lng))))
    goto label_76;
  ((Wrd56.pObj) [2]) = (Wrd38.Obj);

DEFLABEL (label_75)
  (Wrd41.Obj) = (Rsp [1]);
  (Wrd42.pObj) = (OBJECT_ADDRESS (Wrd41.Obj));
  (Wrd43.Obj) = ((Wrd42.pObj) [3]);
  (Wrd44.pObj) = (OBJECT_ADDRESS (Wrd43.Obj));
  (Wrd40.Obj) = ((Wrd44.pObj) [0]);
  (Rsp [0]) = (Wrd40.Obj);
  (Wrd45.Obj) = (current_block [OBJECT_37_5]);
  (Rsp [1]) = (Wrd45.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (label_76)
  (Wrd64.Obj) = (Rsp [1]);
  (Wrd65.pObj) = (OBJECT_ADDRESS (Wrd64.Obj));
  (Wrd63.Obj) = ((Wrd65.pObj) [2]);
  (Wrd66.Obj) = (current_block [OBJECT_37_4]);
  (Wrd67.Obj) = (Rsp [0]);
  (Wrd70.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_20]))));
  (* (--Rsp)) = (Wrd70.Obj);
  (* (--Rsp)) = (Wrd67.Obj);
  (* (--Rsp)) = (Wrd66.Obj);
  (* (--Rsp)) = (Wrd63.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_6]), 3);

DEFLABEL (label_47)
  goto label_75;

DEFLABEL (label_79)
  (Wrd23.Obj) = (Rsp [0]);
  (Wrd24.pObj) = (OBJECT_ADDRESS (Wrd23.Obj));
  (Wrd22.Obj) = ((Wrd24.pObj) [2]);
  (Wrd25.Obj) = (current_block [OBJECT_37_4]);
  (Wrd28.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_19]))));
  (* (--Rsp)) = (Wrd28.Obj);
  (* (--Rsp)) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd22.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_1]), 2);

DEFLABEL (label_46)
  (* (--Rsp)) = Rvl;
  goto label_78;

DEFLABEL (lambda_61)
  CLOSURE_HEADER (LABEL_37_13);

DEFLABEL (lambda_26)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_21]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [1]);
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd8.Obj));
  (Wrd10.Obj) = ((Wrd9.pObj) [2]);
  (* (--Rsp)) = (Wrd10.Obj);
  (Wrd11.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd11.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_37_22]));

DEFLABEL (continuation_24)
  INTERRUPT_CHECK (27, LABEL_37_21);
  (* (--Rsp)) = Rvl;
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_80;
  Rvl = Rvl;
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_80)
  (Wrd10.Obj) = (Rsp [1]);
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd9.Obj) = ((Wrd11.pObj) [3]);
  (Rsp [1]) = (Wrd9.Obj);
  Rsp = (& (Rsp [1]));
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_37_24]));

DEFLABEL (lambda_62)
  CLOSURE_HEADER (LABEL_37_15);

DEFLABEL (lambda_23)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd5.Obj) = (Rsp [1]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_37_7])))
    goto label_82;
  (Wrd49.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_23]))));
  (* (--Rsp)) = (Wrd49.Obj);
  (Wrd50.Obj) = (Rsp [1]);
  (Wrd51.pObj) = (OBJECT_ADDRESS (Wrd50.Obj));
  (Wrd52.Obj) = ((Wrd51.pObj) [2]);
  (* (--Rsp)) = (Wrd52.Obj);
  (Wrd55.Obj) = ((Wrd51.pObj) [3]);
  (* (--Rsp)) = (Wrd55.Obj);
  (Wrd58.Obj) = ((Wrd51.pObj) [4]);
  (* (--Rsp)) = (Wrd58.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_37_24]));

DEFLABEL (continuation_21)
  INTERRUPT_CHECK (27, LABEL_37_23);
  (* (--Rsp)) = Rvl;
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_81;
  Rvl = Rvl;
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_81)
  (Wrd10.Obj) = (Rsp [1]);
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [5]);
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd12.Obj));
  (Wrd9.Obj) = ((Wrd13.pObj) [0]);
  (Rsp [2]) = (Wrd9.Obj);
  Rsp = (& (Rsp [2]));
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 1);
  }

DEFLABEL (label_82)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_25]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd14.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd14.uLng) == 1))
    goto label_93;
  (Wrd12.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd10.Obj) = ((Wrd12.pObj) [0]);

DEFLABEL (label_92)
  (Wrd21.uLng) = (OBJECT_TYPE (Wrd10.Obj));
  if (! ((Wrd21.uLng) == 1))
    goto label_91;
  (Wrd19.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd20.Obj) = ((Wrd19.pObj) [1]);
  (* (--Rsp)) = (Wrd20.Obj);

DEFLABEL (label_90)
  (Wrd29.Obj) = (Rsp [3]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 1))
    goto label_89;
  (Wrd28.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd26.Obj) = ((Wrd28.pObj) [0]);

DEFLABEL (label_88)
  (Wrd37.uLng) = (OBJECT_TYPE (Wrd26.Obj));
  if (! ((Wrd37.uLng) == 1))
    goto label_87;
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd26.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (* (--Rsp)) = (Wrd36.Obj);

DEFLABEL (label_86)
  (Wrd42.Obj) = (Rsp [3]);
  (Wrd43.pObj) = (OBJECT_ADDRESS (Wrd42.Obj));
  (Wrd44.Obj) = ((Wrd43.pObj) [6]);
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd44.Obj));
  (Wrd46.Obj) = ((Wrd45.pObj) [0]);
  (* (--Rsp)) = (Wrd46.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (continuation_19)
  INTERRUPT_CHECK (27, LABEL_37_25);
  if (! (Rvl == ((SCHEME_OBJECT) 0)))
    goto label_83;
  (Wrd22.Obj) = (Rsp [0]);
  (Wrd23.pObj) = (OBJECT_ADDRESS (Wrd22.Obj));
  (Wrd24.Obj) = ((Wrd23.pObj) [5]);
  (Wrd25.pObj) = (OBJECT_ADDRESS (Wrd24.Obj));
  (Wrd21.Obj) = ((Wrd25.pObj) [0]);
  (Rsp [1]) = (Wrd21.Obj);
  Rsp = (& (Rsp [1]));
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 1);
  }

DEFLABEL (label_83)
  (Wrd8.Obj) = (Rsp [0]);
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd8.Obj));
  (Wrd10.Obj) = ((Wrd9.pObj) [7]);
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd7.Obj) = ((Wrd11.pObj) [0]);
  (Rsp [0]) = (Wrd7.Obj);
  (Wrd15.Obj) = (Rsp [1]);
  (Wrd16.uLng) = (OBJECT_TYPE (Wrd15.Obj));
  if (! ((Wrd16.uLng) == 1))
    goto label_85;
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd15.Obj));
  (Wrd12.Obj) = ((Wrd14.pObj) [1]);

DEFLABEL (label_84)
  (Rsp [1]) = (Wrd12.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (label_85)
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_36]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd15.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_9]), 1);

DEFLABEL (label_57)
  (Wrd12.Obj) = Rvl;
  goto label_84;

DEFLABEL (label_87)
  (Wrd41.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_29]))));
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd26.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_8]), 1);

DEFLABEL (label_51)
  (* (--Rsp)) = Rvl;
  goto label_86;

DEFLABEL (label_89)
  (Wrd34.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_28]))));
  (* (--Rsp)) = (Wrd34.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_8]), 1);

DEFLABEL (label_50)
  (Wrd26.Obj) = Rvl;
  goto label_88;

DEFLABEL (label_91)
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_27]))));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd10.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_9]), 1);

DEFLABEL (label_49)
  (* (--Rsp)) = Rvl;
  goto label_90;

DEFLABEL (label_93)
  (Wrd18.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_26]))));
  (* (--Rsp)) = (Wrd18.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_8]), 1);

DEFLABEL (label_48)
  (Wrd10.Obj) = Rvl;
  goto label_92;

DEFLABEL (lambda_63)
  CLOSURE_HEADER (LABEL_37_17);

DEFLABEL (lambda_13)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd5.Obj) = (Rsp [1]);
  (Wrd6.Obj) = (Rsp [0]);
  (Wrd7.pObj) = (OBJECT_ADDRESS (Wrd6.Obj));
  (Wrd8.Obj) = ((Wrd7.pObj) [3]);
  if ((Wrd5.Obj) == (Wrd8.Obj))
    goto label_103;
  (Wrd11.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_31]))));
  (* (--Rsp)) = (Wrd11.Obj);
  (Wrd27.Obj) = ((Wrd7.pObj) [2]);
  (Wrd28.uLng) = (OBJECT_TYPE (Wrd27.Obj));
  if (! ((Wrd28.uLng) == 62))
    goto label_102;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd27.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Lng) = (FIXNUM_TO_LONG (Wrd23.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd24.Lng))))
    goto label_102;
  (Wrd12.Obj) = ((Wrd22.pObj) [7]);

DEFLABEL (label_101)
  (Wrd48.uLng) = (OBJECT_TYPE (Wrd12.Obj));
  if (! ((Wrd48.uLng) == 10))
    goto label_100;
  (Wrd41.Obj) = (Rsp [2]);
  (Wrd42.uLng) = (OBJECT_TYPE (Wrd41.Obj));
  if (! ((Wrd42.uLng) == 26))
    goto label_100;
  (Wrd44.Lng) = (FIXNUM_TO_LONG (Wrd41.Obj));
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd12.Obj));
  (Wrd46.Obj) = ((Wrd45.pObj) [0]);
  (Wrd47.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  if (! (((unsigned long) (Wrd44.Lng)) < ((unsigned long) (Wrd47.Lng))))
    goto label_100;
  (Wrd37.uLng) = (OBJECT_DATUM (Wrd41.Obj));
  (Wrd39.pObj) = (& ((Wrd45.pObj) [(Wrd37.Lng)]));
  (Wrd40.Obj) = ((Wrd39.pObj) [1]);
  (* (--Rsp)) = (Wrd40.Obj);

DEFLABEL (label_99)
  (Wrd67.Obj) = (Rsp [2]);
  (Wrd68.pObj) = (OBJECT_ADDRESS (Wrd67.Obj));
  (Wrd69.Obj) = ((Wrd68.pObj) [2]);
  (Wrd70.uLng) = (OBJECT_TYPE (Wrd69.Obj));
  if (! ((Wrd70.uLng) == 62))
    goto label_98;
  (Wrd64.pObj) = (OBJECT_ADDRESS (Wrd69.Obj));
  (Wrd65.Obj) = ((Wrd64.pObj) [0]);
  (Wrd66.Lng) = (FIXNUM_TO_LONG (Wrd65.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd66.Lng))))
    goto label_98;
  (Wrd54.Obj) = ((Wrd64.pObj) [6]);

DEFLABEL (label_97)
  (Wrd90.uLng) = (OBJECT_TYPE (Wrd54.Obj));
  if (! ((Wrd90.uLng) == 10))
    goto label_96;
  (Wrd83.Obj) = (Rsp [3]);
  (Wrd84.uLng) = (OBJECT_TYPE (Wrd83.Obj));
  if (! ((Wrd84.uLng) == 26))
    goto label_96;
  (Wrd86.Lng) = (FIXNUM_TO_LONG (Wrd83.Obj));
  (Wrd87.pObj) = (OBJECT_ADDRESS (Wrd54.Obj));
  (Wrd88.Obj) = ((Wrd87.pObj) [0]);
  (Wrd89.Lng) = (FIXNUM_TO_LONG (Wrd88.Obj));
  if (! (((unsigned long) (Wrd86.Lng)) < ((unsigned long) (Wrd89.Lng))))
    goto label_96;
  (Wrd79.uLng) = (OBJECT_DATUM (Wrd83.Obj));
  (Wrd81.pObj) = (& ((Wrd87.pObj) [(Wrd79.Lng)]));
  (Wrd82.Obj) = ((Wrd81.pObj) [1]);
  (* (--Rsp)) = (Wrd82.Obj);

DEFLABEL (label_95)
  (Wrd96.Obj) = (Rsp [3]);
  (Wrd97.pObj) = (OBJECT_ADDRESS (Wrd96.Obj));
  (Wrd98.Obj) = ((Wrd97.pObj) [5]);
  (Wrd99.pObj) = (OBJECT_ADDRESS (Wrd98.Obj));
  (Wrd100.Obj) = ((Wrd99.pObj) [0]);
  (* (--Rsp)) = (Wrd100.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (continuation_10)
  INTERRUPT_CHECK (27, LABEL_37_31);
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_94;
  (Wrd8.Obj) = (Rsp [0]);
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd8.Obj));
  (Wrd10.Obj) = ((Wrd9.pObj) [7]);
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd7.Obj) = ((Wrd11.pObj) [0]);
  (Rsp [0]) = (Wrd7.Obj);
  (Wrd13.Obj) = (Rsp [1]);
  (Wrd14.Lng) = (FIXNUM_TO_LONG (Wrd13.Obj));
  (Wrd15.Lng) = ((Wrd14.Lng) + 1L);
  (Wrd12.Obj) = (LONG_TO_FIXNUM (Wrd15.Lng));
  (Rsp [1]) = (Wrd12.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (label_94)
  (Wrd17.Obj) = (Rsp [0]);
  (Wrd18.pObj) = (OBJECT_ADDRESS (Wrd17.Obj));
  (Wrd19.Obj) = ((Wrd18.pObj) [4]);
  (Wrd20.pObj) = (OBJECT_ADDRESS (Wrd19.Obj));
  (Wrd16.Obj) = ((Wrd20.pObj) [0]);
  (Rsp [1]) = (Wrd16.Obj);
  Rsp = (& (Rsp [1]));
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 1);
  }

DEFLABEL (label_96)
  (Wrd92.Obj) = (Rsp [3]);
  (Wrd95.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_35]))));
  (* (--Rsp)) = (Wrd95.Obj);
  (* (--Rsp)) = (Wrd92.Obj);
  (* (--Rsp)) = (Wrd54.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_12]), 2);

DEFLABEL (label_55)
  (* (--Rsp)) = Rvl;
  goto label_95;

DEFLABEL (label_98)
  (Wrd72.Obj) = (Rsp [2]);
  (Wrd73.pObj) = (OBJECT_ADDRESS (Wrd72.Obj));
  (Wrd71.Obj) = ((Wrd73.pObj) [2]);
  (Wrd74.Obj) = (current_block [OBJECT_37_0]);
  (Wrd77.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_34]))));
  (* (--Rsp)) = (Wrd77.Obj);
  (* (--Rsp)) = (Wrd74.Obj);
  (* (--Rsp)) = (Wrd71.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_1]), 2);

DEFLABEL (label_54)
  (Wrd54.Obj) = Rvl;
  goto label_97;

DEFLABEL (label_100)
  (Wrd50.Obj) = (Rsp [2]);
  (Wrd53.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_33]))));
  (* (--Rsp)) = (Wrd53.Obj);
  (* (--Rsp)) = (Wrd50.Obj);
  (* (--Rsp)) = (Wrd12.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_12]), 2);

DEFLABEL (label_53)
  (* (--Rsp)) = Rvl;
  goto label_99;

DEFLABEL (label_102)
  (Wrd30.Obj) = (Rsp [1]);
  (Wrd31.pObj) = (OBJECT_ADDRESS (Wrd30.Obj));
  (Wrd29.Obj) = ((Wrd31.pObj) [2]);
  (Wrd32.Obj) = (current_block [OBJECT_37_11]);
  (Wrd35.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_32]))));
  (* (--Rsp)) = (Wrd35.Obj);
  (* (--Rsp)) = (Wrd32.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_1]), 2);

DEFLABEL (label_52)
  (Wrd12.Obj) = Rvl;
  goto label_101;

DEFLABEL (label_103)
  (Wrd116.Obj) = ((Wrd7.pObj) [2]);
  (Wrd117.uLng) = (OBJECT_TYPE (Wrd116.Obj));
  if (! ((Wrd117.uLng) == 62))
    goto label_105;
  (Wrd111.pObj) = (OBJECT_ADDRESS (Wrd116.Obj));
  (Wrd112.Obj) = ((Wrd111.pObj) [0]);
  (Wrd113.Lng) = (FIXNUM_TO_LONG (Wrd112.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd113.Lng))))
    goto label_105;
  (Wrd101.Obj) = ((Wrd111.pObj) [8]);

DEFLABEL (label_104)
  (Rsp [1]) = (Wrd101.Obj);
  (Wrd126.Obj) = (Rsp [0]);
  (Wrd127.pObj) = (OBJECT_ADDRESS (Wrd126.Obj));
  (Wrd128.Obj) = ((Wrd127.pObj) [6]);
  (Wrd129.pObj) = (OBJECT_ADDRESS (Wrd128.Obj));
  (Wrd125.Obj) = ((Wrd129.pObj) [0]);
  (Rsp [0]) = (Wrd125.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (label_105)
  (Wrd119.Obj) = (Rsp [0]);
  (Wrd120.pObj) = (OBJECT_ADDRESS (Wrd119.Obj));
  (Wrd118.Obj) = ((Wrd120.pObj) [2]);
  (Wrd121.Obj) = (current_block [OBJECT_37_10]);
  (Wrd124.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_37_30]))));
  (* (--Rsp)) = (Wrd124.Obj);
  (* (--Rsp)) = (Wrd121.Obj);
  (* (--Rsp)) = (Wrd118.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_37_1]), 2);

DEFLABEL (label_56)
  (Wrd101.Obj) = Rvl;
  goto label_104;

INVOKE_INTERFACE_TARGET_0
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_38_4 3
#define LABEL_38_5 5
#define LABEL_38_6 7
#define LABEL_38_15 9
#define LABEL_38_16 11
#define LABEL_38_7 13
#define TAG_38_8 5
#define LABEL_38_9 15
#define TAG_38_10 6
#define LABEL_38_21 17
#define LABEL_38_22 19
#define LABEL_38_23 21
#define LABEL_38_24 23
#define LABEL_38_11 25
#define TAG_38_12 11
#define LABEL_38_25 27
#define LABEL_38_27 29
#define LABEL_38_28 31
#define LABEL_38_29 33
#define LABEL_38_30 35
#define LABEL_38_13 37
#define LABEL_38_14 39
#define LABEL_38_18 41
#define LABEL_38_20 43
#define LABEL_38_33 45
#define LABEL_38_26 47
#define LABEL_38_31 49
#define LABEL_38_34 51
#define LABEL_38_38 53
#define LABEL_38_39 55
#define LABEL_38_40 57
#define LABEL_38_41 59
#define LABEL_38_36 61
#define LABEL_38_42 63
#define LABEL_38_43 65
#define LABEL_38_44 67
#define LABEL_38_45 69
#define LABEL_38_46 71
#define LABEL_38_47 73
#define LABEL_38_48 75
#define LABEL_38_49 77
#define LABEL_38_50 79
#define LABEL_38_51 81
#define ENVIRONMENT_LABEL_38_3 108
#define DEBUGGING_LABEL_38_2 107
#define OBJECT_38_13 106
#define OBJECT_38_12 105
#define OBJECT_38_11 104
#define OBJECT_38_10 103
#define OBJECT_38_9 102
#define OBJECT_38_8 101
#define OBJECT_38_7 100
#define OBJECT_38_6 99
#define OBJECT_38_5 98
#define OBJECT_38_4 97
#define OBJECT_38_3 96
#define OBJECT_38_2 95
#define OBJECT_38_1 94
#define OBJECT_38_0 93
#define EXECUTE_CACHE_38_37 83
#define EXECUTE_CACHE_38_35 85
#define EXECUTE_CACHE_38_32 87
#define EXECUTE_CACHE_38_19 89
#define EXECUTE_CACHE_38_17 91
#define FREE_REFERENCES_LABEL_38_0 82
#define NUMBER_OF_LINKER_SECTIONS_38_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_38 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd154;
  machine_word Wrd151;
  machine_word Wrd150;
  machine_word Wrd140;
  machine_word Wrd139;
  machine_word Wrd137;
  machine_word Wrd147;
  machine_word Wrd146;
  machine_word Wrd145;
  machine_word Wrd144;
  machine_word Wrd142;
  machine_word Wrd141;
  machine_word Wrd148;
  machine_word Wrd124;
  machine_word Wrd173;
  machine_word Wrd170;
  machine_word Wrd169;
  machine_word Wrd159;
  machine_word Wrd158;
  machine_word Wrd156;
  machine_word Wrd166;
  machine_word Wrd165;
  machine_word Wrd164;
  machine_word Wrd163;
  machine_word Wrd161;
  machine_word Wrd160;
  machine_word Wrd167;
  machine_word Wrd110;
  machine_word Wrd108;
  machine_word Wrd111;
  machine_word Wrd189;
  machine_word Wrd185;
  machine_word Wrd184;
  machine_word Wrd181;
  machine_word Wrd180;
  machine_word Wrd179;
  machine_word Wrd183;
  machine_word Wrd182;
  machine_word Wrd93;
  machine_word Wrd76;
  machine_word Wrd80;
  machine_word Wrd85;
  machine_word Wrd33;
  machine_word Wrd78;
  machine_word Wrd75;
  machine_word Wrd63;
  machine_word Wrd99;
  machine_word Wrd98;
  machine_word Wrd97;
  machine_word Wrd95;
  machine_word Wrd92;
  machine_word Wrd79;
  machine_word Wrd89;
  machine_word Wrd88;
  machine_word Wrd87;
  machine_word Wrd86;
  machine_word Wrd84;
  machine_word Wrd90;
  machine_word Wrd77;
  machine_word Wrd74;
  machine_word Wrd66;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd69;
  machine_word Wrd68;
  machine_word Wrd67;
  machine_word Wrd40;
  machine_word Wrd39;
  machine_word Wrd27;
  machine_word Wrd126;
  machine_word Wrd128;
  machine_word Wrd127;
  machine_word Wrd121;
  machine_word Wrd120;
  machine_word Wrd112;
  machine_word Wrd6;
  machine_word Wrd47;
  machine_word Wrd46;
  machine_word Wrd45;
  machine_word Wrd42;
  machine_word Wrd41;
  machine_word Wrd36;
  machine_word Wrd34;
  machine_word Wrd26;
  machine_word Wrd28;
  machine_word Wrd30;
  machine_word Wrd19;
  machine_word Wrd21;
  machine_word Wrd18;
  machine_word Wrd56;
  machine_word Wrd53;
  machine_word Wrd52;
  machine_word Wrd51;
  machine_word Wrd48;
  machine_word Wrd10;
  machine_word Wrd9;
  machine_word Wrd8;
  machine_word Wrd7;
  machine_word Wrd138;
  machine_word Wrd135;
  machine_word Wrd134;
  machine_word Wrd125;
  machine_word Wrd131;
  machine_word Wrd130;
  machine_word Wrd129;
  machine_word Wrd133;
  machine_word Wrd132;
  machine_word Wrd122;
  machine_word Wrd119;
  machine_word Wrd118;
  machine_word Wrd109;
  machine_word Wrd115;
  machine_word Wrd114;
  machine_word Wrd113;
  machine_word Wrd117;
  machine_word Wrd116;
  machine_word Wrd106;
  machine_word Wrd105;
  machine_word Wrd102;
  machine_word Wrd101;
  machine_word Wrd100;
  machine_word Wrd96;
  machine_word Wrd94;
  machine_word Wrd81;
  machine_word Wrd83;
  machine_word Wrd82;
  machine_word Wrd72;
  machine_word Wrd73;
  machine_word Wrd71;
  machine_word Wrd70;
  machine_word Wrd60;
  machine_word Wrd61;
  machine_word Wrd59;
  machine_word Wrd58;
  machine_word Wrd54;
  machine_word Wrd55;
  machine_word Wrd50;
  machine_word Wrd49;
  machine_word Wrd44;
  machine_word Wrd43;
  machine_word Wrd38;
  machine_word Wrd37;
  machine_word Wrd32;
  machine_word Wrd31;
  machine_word Wrd35;
  machine_word Wrd29;
  machine_word Wrd24;
  machine_word Wrd23;
  machine_word Wrd22;
  machine_word Wrd25;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_38_4);
      goto expand_cache_52;

    case 1:
      current_block = (Rpc - LABEL_38_5);
      goto label_54;

    case 2:
      current_block = (Rpc - LABEL_38_6);
      goto label_55;

    case 3:
      current_block = (Rpc - LABEL_38_15);
      goto label_56;

    case 4:
      current_block = (Rpc - LABEL_38_16);
      goto label_57;

    case 5:
      current_block = (Rpc - LABEL_38_7);
      goto lambda_84;

    case 6:
      current_block = (Rpc - LABEL_38_9);
      goto lambda_85;

    case 7:
      current_block = (Rpc - LABEL_38_21);
      goto label_58;

    case 8:
      current_block = (Rpc - LABEL_38_22);
      goto label_59;

    case 9:
      current_block = (Rpc - LABEL_38_23);
      goto label_60;

    case 10:
      current_block = (Rpc - LABEL_38_24);
      goto label_61;

    case 11:
      current_block = (Rpc - LABEL_38_11);
      goto lambda_86;

    case 12:
      current_block = (Rpc - LABEL_38_25);
      goto label_66;

    case 13:
      current_block = (Rpc - LABEL_38_27);
      goto label_62;

    case 14:
      current_block = (Rpc - LABEL_38_28);
      goto label_63;

    case 15:
      current_block = (Rpc - LABEL_38_29);
      goto label_64;

    case 16:
      current_block = (Rpc - LABEL_38_30);
      goto label_65;

    case 17:
      current_block = (Rpc - LABEL_38_13);
      goto lambda_43;

    case 18:
      current_block = (Rpc - LABEL_38_14);
      goto continuation_49;

    case 19:
      current_block = (Rpc - LABEL_38_18);
      goto continuation_19;

    case 20:
      current_block = (Rpc - LABEL_38_20);
      goto continuation_16;

    case 21:
      current_block = (Rpc - LABEL_38_33);
      goto label_67;

    case 22:
      current_block = (Rpc - LABEL_38_26);
      goto continuation_7;

    case 23:
      current_block = (Rpc - LABEL_38_31);
      goto continuation_21;

    case 24:
      current_block = (Rpc - LABEL_38_34);
      goto continuation_22;

    case 25:
      current_block = (Rpc - LABEL_38_38);
      goto label_68;

    case 26:
      current_block = (Rpc - LABEL_38_39);
      goto label_71;

    case 27:
      current_block = (Rpc - LABEL_38_40);
      goto label_69;

    case 28:
      current_block = (Rpc - LABEL_38_41);
      goto label_70;

    case 29:
      current_block = (Rpc - LABEL_38_36);
      goto continuation_23;

    case 30:
      current_block = (Rpc - LABEL_38_42);
      goto label_72;

    case 31:
      current_block = (Rpc - LABEL_38_43);
      goto label_73;

    case 32:
      current_block = (Rpc - LABEL_38_44);
      goto label_74;

    case 33:
      current_block = (Rpc - LABEL_38_45);
      goto label_75;

    case 34:
      current_block = (Rpc - LABEL_38_46);
      goto label_76;

    case 35:
      current_block = (Rpc - LABEL_38_47);
      goto label_81;

    case 36:
      current_block = (Rpc - LABEL_38_48);
      goto label_77;

    case 37:
      current_block = (Rpc - LABEL_38_49);
      goto label_80;

    case 38:
      current_block = (Rpc - LABEL_38_50);
      goto label_78;

    case 39:
      current_block = (Rpc - LABEL_38_51);
      goto label_79;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (expand_cache_83)
DEFLABEL (expand_cache_52)
  INTERRUPT_CHECK (26, LABEL_38_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_95;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_95;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_94)
  (Wrd25.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd25.uLng) == 10))
    goto label_93;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Obj) = (MAKE_OBJECT (26, (Wrd23.uLng)));
  (* (--Rsp)) = (Wrd24.Obj);

DEFLABEL (label_92)
  (Wrd35.Obj) = (MAKE_OBJECT (50, 0));
  (* (Rhp++)) = (Wrd35.Obj);
  (Wrd31.pObj) = (& (Rhp [-1]));
  (Wrd32.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd31.pObj)));
  (* (--Rsp)) = (Wrd32.Obj);
  (* (Rhp++)) = (Wrd35.Obj);
  (Wrd37.pObj) = (& (Rhp [-1]));
  (Wrd38.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd37.pObj)));
  (* (--Rsp)) = (Wrd38.Obj);
  (* (Rhp++)) = (Wrd35.Obj);
  (Wrd43.pObj) = (& (Rhp [-1]));
  (Wrd44.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd43.pObj)));
  (* (--Rsp)) = (Wrd44.Obj);
  (* (Rhp++)) = (Wrd35.Obj);
  (Wrd49.pObj) = (& (Rhp [-1]));
  (Wrd50.Obj) = (MAKE_POINTER_OBJECT (54, (Wrd49.pObj)));
  (* (--Rsp)) = (Wrd50.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 5));
  (Wrd55.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x404, 2);
  (* (Rhp++)) = (dispatch_base + TAG_38_8);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_38_7])));
  Rhp += 2;
  (Wrd54.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd55.pObj)));
  Wrd58 = Wrd55;
  (Wrd59.Obj) = (Rsp [6]);
  ((Wrd58.pObj) [2]) = (Wrd59.Obj);
  ((Wrd58.pObj) [3]) = (Wrd32.Obj);
  (* (--Rsp)) = (Wrd54.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 8));
  (Wrd61.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x303, 2);
  (* (Rhp++)) = (dispatch_base + TAG_38_10);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_38_9])));
  Rhp += 5;
  (Wrd60.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd61.pObj)));
  Wrd70 = Wrd61;
  (Wrd71.Obj) = (Rsp [8]);
  ((Wrd70.pObj) [2]) = (Wrd71.Obj);
  ((Wrd70.pObj) [3]) = (Wrd59.Obj);
  ((Wrd70.pObj) [4]) = (Wrd32.Obj);
  ((Wrd70.pObj) [5]) = (Wrd38.Obj);
  ((Wrd70.pObj) [6]) = (Wrd44.Obj);
  (* (--Rsp)) = (Wrd60.Obj);
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 8));
  (Wrd73.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x303, 2);
  (* (Rhp++)) = (dispatch_base + TAG_38_12);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_38_11])));
  Rhp += 5;
  (Wrd72.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd73.pObj)));
  Wrd82 = Wrd73;
  (Wrd83.Obj) = (Rsp [7]);
  ((Wrd82.pObj) [2]) = (Wrd83.Obj);
  (Wrd81.Obj) = (Rsp [6]);
  ((Wrd82.pObj) [3]) = (Wrd81.Obj);
  ((Wrd82.pObj) [4]) = (Wrd38.Obj);
  ((Wrd82.pObj) [5]) = (Wrd44.Obj);
  ((Wrd82.pObj) [6]) = (Wrd50.Obj);
  (* (--Rsp)) = (Wrd72.Obj);
  ((Wrd49.pObj) [0]) = (Wrd72.Obj);
  ((Wrd43.pObj) [0]) = (Wrd60.Obj);
  ((Wrd37.pObj) [0]) = (Wrd54.Obj);
  Wrd94 = Wrd31;
  (Wrd96.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_13]))));
  ((Wrd94.pObj) [0]) = (Wrd96.Obj);
  Rsp = (& (Rsp [3]));
  (Wrd100.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_14]))));
  (* (--Rsp)) = (Wrd100.Obj);
  (Wrd101.Obj) = (Rsp [5]);
  (Wrd102.Lng) = (FIXNUM_TO_LONG (Wrd101.Obj));
  (Wrd105.Lng) = ((Wrd102.Lng) + (Wrd102.Lng));
  (Wrd106.Obj) = (LONG_TO_FIXNUM (Wrd105.Lng));
  (* (--Rsp)) = (Wrd106.Obj);
  (Wrd116.Obj) = (Rsp [7]);
  (Wrd117.uLng) = (OBJECT_TYPE (Wrd116.Obj));
  if (! ((Wrd117.uLng) == 62))
    goto label_91;
  (Wrd113.pObj) = (OBJECT_ADDRESS (Wrd116.Obj));
  (Wrd114.Obj) = ((Wrd113.pObj) [0]);
  (Wrd115.Lng) = (FIXNUM_TO_LONG (Wrd114.Obj));
  if (! (((unsigned long) 4L) < ((unsigned long) (Wrd115.Lng))))
    goto label_91;
  (Wrd109.Obj) = ((Wrd113.pObj) [5]);
  (* (--Rsp)) = (Wrd109.Obj);

DEFLABEL (label_90)
  (Wrd132.Obj) = (Rsp [8]);
  (Wrd133.uLng) = (OBJECT_TYPE (Wrd132.Obj));
  if (! ((Wrd133.uLng) == 62))
    goto label_89;
  (Wrd129.pObj) = (OBJECT_ADDRESS (Wrd132.Obj));
  (Wrd130.Obj) = ((Wrd129.pObj) [0]);
  (Wrd131.Lng) = (FIXNUM_TO_LONG (Wrd130.Obj));
  if (! (((unsigned long) 1L) < ((unsigned long) (Wrd131.Lng))))
    goto label_89;
  (Wrd125.Obj) = ((Wrd129.pObj) [2]);
  (* (--Rsp)) = (Wrd125.Obj);

DEFLABEL (label_88)
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_38_17]));

DEFLABEL (continuation_49)
  INTERRUPT_CHECK (27, LABEL_38_14);
  (Rsp [6]) = Rvl;
  (Wrd6.Obj) = (current_block [OBJECT_38_11]);
  (Rsp [7]) = (Wrd6.Obj);
  (Wrd8.Obj) = (Rsp [0]);
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd8.Obj));
  (Wrd7.Obj) = ((Wrd9.pObj) [0]);
  (Rsp [5]) = (Wrd7.Obj);
  Rsp = (& (Rsp [5]));
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (label_89)
  (Wrd134.Obj) = (Rsp [8]);
  (Wrd135.Obj) = (current_block [OBJECT_38_4]);
  (Wrd138.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_16]))));
  (* (--Rsp)) = (Wrd138.Obj);
  (* (--Rsp)) = (Wrd135.Obj);
  (* (--Rsp)) = (Wrd134.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_57)
  (* (--Rsp)) = Rvl;
  goto label_88;

DEFLABEL (label_91)
  (Wrd118.Obj) = (Rsp [7]);
  (Wrd119.Obj) = (current_block [OBJECT_38_3]);
  (Wrd122.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_15]))));
  (* (--Rsp)) = (Wrd122.Obj);
  (* (--Rsp)) = (Wrd119.Obj);
  (* (--Rsp)) = (Wrd118.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_56)
  (* (--Rsp)) = Rvl;
  goto label_90;

DEFLABEL (label_93)
  (Wrd29.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_6]))));
  (* (--Rsp)) = (Wrd29.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_2]), 1);

DEFLABEL (label_55)
  (* (--Rsp)) = Rvl;
  goto label_92;

DEFLABEL (label_95)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_38_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_54)
  (Wrd5.Obj) = Rvl;
  goto label_94;

DEFLABEL (lambda_84)
  CLOSURE_HEADER (LABEL_38_7);

DEFLABEL (lambda_20)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_18]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [1]);
  (Wrd9.pObj) = (OBJECT_ADDRESS (Wrd8.Obj));
  (Wrd10.Obj) = ((Wrd9.pObj) [2]);
  (* (--Rsp)) = (Wrd10.Obj);
  (Wrd11.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd11.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_38_19]));

DEFLABEL (continuation_19)
  INTERRUPT_CHECK (27, LABEL_38_18);
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_96;
  Rvl = (Rsp [1]);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_96)
  (Wrd10.Obj) = (Rsp [0]);
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [3]);
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd12.Obj));
  (Wrd9.Obj) = ((Wrd13.pObj) [0]);
  (Rsp [0]) = (Wrd9.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 4);
  }

DEFLABEL (lambda_85)
  CLOSURE_HEADER (LABEL_38_9);

DEFLABEL (lambda_18)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd5.Obj) = (Rsp [2]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_38_5])))
    goto label_97;
  (Wrd48.Obj) = (Rsp [0]);
  (Wrd49.pObj) = (OBJECT_ADDRESS (Wrd48.Obj));
  (Wrd50.Obj) = ((Wrd49.pObj) [4]);
  (Wrd51.pObj) = (OBJECT_ADDRESS (Wrd50.Obj));
  (Wrd52.Obj) = ((Wrd51.pObj) [0]);
  (* (--Rsp)) = (Wrd52.Obj);
  (Wrd53.Obj) = ((Wrd49.pObj) [2]);
  (Rsp [3]) = (Wrd53.Obj);
  (Wrd56.Obj) = ((Wrd49.pObj) [3]);
  (Wrd59.Obj) = (Rsp [2]);
  (Rsp [1]) = (Wrd59.Obj);
  (Rsp [2]) = (Wrd56.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 4);
  }

DEFLABEL (label_97)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_20]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd14.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd14.uLng) == 1))
    goto label_107;
  (Wrd12.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd10.Obj) = ((Wrd12.pObj) [0]);

DEFLABEL (label_106)
  (Wrd21.uLng) = (OBJECT_TYPE (Wrd10.Obj));
  if (! ((Wrd21.uLng) == 1))
    goto label_105;
  (Wrd19.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd20.Obj) = ((Wrd19.pObj) [1]);
  (* (--Rsp)) = (Wrd20.Obj);

DEFLABEL (label_104)
  (Wrd29.Obj) = (Rsp [4]);
  (Wrd30.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd30.uLng) == 1))
    goto label_103;
  (Wrd28.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd26.Obj) = ((Wrd28.pObj) [0]);

DEFLABEL (label_102)
  (Wrd37.uLng) = (OBJECT_TYPE (Wrd26.Obj));
  if (! ((Wrd37.uLng) == 1))
    goto label_101;
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd26.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (* (--Rsp)) = (Wrd36.Obj);

DEFLABEL (label_100)
  (Wrd42.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd42.Obj);
  (Wrd43.Obj) = (Rsp [4]);
  (Wrd44.pObj) = (OBJECT_ADDRESS (Wrd43.Obj));
  (Wrd45.Obj) = ((Wrd44.pObj) [5]);
  (Wrd46.pObj) = (OBJECT_ADDRESS (Wrd45.Obj));
  (Wrd47.Obj) = ((Wrd46.pObj) [0]);
  (* (--Rsp)) = (Wrd47.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 4);
  }

DEFLABEL (continuation_16)
  INTERRUPT_CHECK (27, LABEL_38_20);
  (Rsp [1]) = Rvl;
  (Wrd7.Obj) = (Rsp [0]);
  (Wrd8.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd9.Obj) = ((Wrd8.pObj) [6]);
  (Wrd10.pObj) = (OBJECT_ADDRESS (Wrd9.Obj));
  (Wrd6.Obj) = ((Wrd10.pObj) [0]);
  (Rsp [0]) = (Wrd6.Obj);
  (Wrd14.Obj) = (Rsp [2]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 1))
    goto label_99;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd11.Obj) = ((Wrd13.pObj) [1]);

DEFLABEL (label_98)
  (Rsp [2]) = (Wrd11.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (label_99)
  (Wrd19.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_33]))));
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd14.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_7]), 1);

DEFLABEL (label_67)
  (Wrd11.Obj) = Rvl;
  goto label_98;

DEFLABEL (label_101)
  (Wrd41.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_24]))));
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd26.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_6]), 1);

DEFLABEL (label_61)
  (* (--Rsp)) = Rvl;
  goto label_100;

DEFLABEL (label_103)
  (Wrd34.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_23]))));
  (* (--Rsp)) = (Wrd34.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_6]), 1);

DEFLABEL (label_60)
  (Wrd26.Obj) = Rvl;
  goto label_102;

DEFLABEL (label_105)
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_22]))));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd10.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_7]), 1);

DEFLABEL (label_59)
  (* (--Rsp)) = Rvl;
  goto label_104;

DEFLABEL (label_107)
  (Wrd18.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_21]))));
  (* (--Rsp)) = (Wrd18.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_6]), 1);

DEFLABEL (label_58)
  (Wrd10.Obj) = Rvl;
  goto label_106;

DEFLABEL (lambda_86)
  CLOSURE_HEADER (LABEL_38_11);

DEFLABEL (lambda_10)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd5.Obj) = (Rsp [2]);
  (Wrd6.Obj) = (Rsp [0]);
  (Wrd7.pObj) = (OBJECT_ADDRESS (Wrd6.Obj));
  (Wrd8.Obj) = ((Wrd7.pObj) [3]);
  if ((Wrd5.Obj) == (Wrd8.Obj))
    goto label_116;
  (Wrd11.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_26]))));
  (* (--Rsp)) = (Wrd11.Obj);
  (Wrd27.Obj) = ((Wrd7.pObj) [2]);
  (Wrd28.uLng) = (OBJECT_TYPE (Wrd27.Obj));
  if (! ((Wrd28.uLng) == 62))
    goto label_115;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd27.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Lng) = (FIXNUM_TO_LONG (Wrd23.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd24.Lng))))
    goto label_115;
  (Wrd12.Obj) = ((Wrd22.pObj) [7]);

DEFLABEL (label_114)
  (Wrd48.uLng) = (OBJECT_TYPE (Wrd12.Obj));
  if (! ((Wrd48.uLng) == 10))
    goto label_113;
  (Wrd41.Obj) = (Rsp [3]);
  (Wrd42.uLng) = (OBJECT_TYPE (Wrd41.Obj));
  if (! ((Wrd42.uLng) == 26))
    goto label_113;
  (Wrd44.Lng) = (FIXNUM_TO_LONG (Wrd41.Obj));
  (Wrd45.pObj) = (OBJECT_ADDRESS (Wrd12.Obj));
  (Wrd46.Obj) = ((Wrd45.pObj) [0]);
  (Wrd47.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  if (! (((unsigned long) (Wrd44.Lng)) < ((unsigned long) (Wrd47.Lng))))
    goto label_113;
  (Wrd37.uLng) = (OBJECT_DATUM (Wrd41.Obj));
  (Wrd39.pObj) = (& ((Wrd45.pObj) [(Wrd37.Lng)]));
  (Wrd40.Obj) = ((Wrd39.pObj) [1]);
  (* (--Rsp)) = (Wrd40.Obj);

DEFLABEL (label_112)
  (Wrd67.Obj) = (Rsp [2]);
  (Wrd68.pObj) = (OBJECT_ADDRESS (Wrd67.Obj));
  (Wrd69.Obj) = ((Wrd68.pObj) [2]);
  (Wrd70.uLng) = (OBJECT_TYPE (Wrd69.Obj));
  if (! ((Wrd70.uLng) == 62))
    goto label_111;
  (Wrd64.pObj) = (OBJECT_ADDRESS (Wrd69.Obj));
  (Wrd65.Obj) = ((Wrd64.pObj) [0]);
  (Wrd66.Lng) = (FIXNUM_TO_LONG (Wrd65.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd66.Lng))))
    goto label_111;
  (Wrd54.Obj) = ((Wrd64.pObj) [6]);

DEFLABEL (label_110)
  (Wrd90.uLng) = (OBJECT_TYPE (Wrd54.Obj));
  if (! ((Wrd90.uLng) == 10))
    goto label_109;
  (Wrd83.Obj) = (Rsp [4]);
  (Wrd84.uLng) = (OBJECT_TYPE (Wrd83.Obj));
  if (! ((Wrd84.uLng) == 26))
    goto label_109;
  (Wrd86.Lng) = (FIXNUM_TO_LONG (Wrd83.Obj));
  (Wrd87.pObj) = (OBJECT_ADDRESS (Wrd54.Obj));
  (Wrd88.Obj) = ((Wrd87.pObj) [0]);
  (Wrd89.Lng) = (FIXNUM_TO_LONG (Wrd88.Obj));
  if (! (((unsigned long) (Wrd86.Lng)) < ((unsigned long) (Wrd89.Lng))))
    goto label_109;
  (Wrd79.uLng) = (OBJECT_DATUM (Wrd83.Obj));
  (Wrd81.pObj) = (& ((Wrd87.pObj) [(Wrd79.Lng)]));
  (Wrd82.Obj) = ((Wrd81.pObj) [1]);
  (* (--Rsp)) = (Wrd82.Obj);

DEFLABEL (label_108)
  (Wrd96.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd96.Obj);
  (Wrd97.Obj) = (Rsp [4]);
  (Wrd98.pObj) = (OBJECT_ADDRESS (Wrd97.Obj));
  (Wrd99.Obj) = ((Wrd98.pObj) [4]);
  (Wrd100.pObj) = (OBJECT_ADDRESS (Wrd99.Obj));
  (Wrd101.Obj) = ((Wrd100.pObj) [0]);
  (* (--Rsp)) = (Wrd101.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 4);
  }

DEFLABEL (continuation_7)
  INTERRUPT_CHECK (27, LABEL_38_26);
  (Rsp [1]) = Rvl;
  (Wrd7.Obj) = (Rsp [0]);
  (Wrd8.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd9.Obj) = ((Wrd8.pObj) [6]);
  (Wrd10.pObj) = (OBJECT_ADDRESS (Wrd9.Obj));
  (Wrd6.Obj) = ((Wrd10.pObj) [0]);
  (Rsp [0]) = (Wrd6.Obj);
  (Wrd12.Obj) = (Rsp [2]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  (Wrd14.Lng) = ((Wrd13.Lng) + 1L);
  (Wrd11.Obj) = (LONG_TO_FIXNUM (Wrd14.Lng));
  (Rsp [2]) = (Wrd11.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (label_109)
  (Wrd92.Obj) = (Rsp [4]);
  (Wrd95.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_30]))));
  (* (--Rsp)) = (Wrd95.Obj);
  (* (--Rsp)) = (Wrd92.Obj);
  (* (--Rsp)) = (Wrd54.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_10]), 2);

DEFLABEL (label_65)
  (* (--Rsp)) = Rvl;
  goto label_108;

DEFLABEL (label_111)
  (Wrd72.Obj) = (Rsp [2]);
  (Wrd73.pObj) = (OBJECT_ADDRESS (Wrd72.Obj));
  (Wrd71.Obj) = ((Wrd73.pObj) [2]);
  (Wrd74.Obj) = (current_block [OBJECT_38_0]);
  (Wrd77.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_29]))));
  (* (--Rsp)) = (Wrd77.Obj);
  (* (--Rsp)) = (Wrd74.Obj);
  (* (--Rsp)) = (Wrd71.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_64)
  (Wrd54.Obj) = Rvl;
  goto label_110;

DEFLABEL (label_113)
  (Wrd50.Obj) = (Rsp [3]);
  (Wrd53.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_28]))));
  (* (--Rsp)) = (Wrd53.Obj);
  (* (--Rsp)) = (Wrd50.Obj);
  (* (--Rsp)) = (Wrd12.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_10]), 2);

DEFLABEL (label_63)
  (* (--Rsp)) = Rvl;
  goto label_112;

DEFLABEL (label_115)
  (Wrd30.Obj) = (Rsp [1]);
  (Wrd31.pObj) = (OBJECT_ADDRESS (Wrd30.Obj));
  (Wrd29.Obj) = ((Wrd31.pObj) [2]);
  (Wrd32.Obj) = (current_block [OBJECT_38_9]);
  (Wrd35.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_27]))));
  (* (--Rsp)) = (Wrd35.Obj);
  (* (--Rsp)) = (Wrd32.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_62)
  (Wrd12.Obj) = Rvl;
  goto label_114;

DEFLABEL (label_116)
  (Wrd117.Obj) = ((Wrd7.pObj) [2]);
  (Wrd118.uLng) = (OBJECT_TYPE (Wrd117.Obj));
  if (! ((Wrd118.uLng) == 62))
    goto label_118;
  (Wrd112.pObj) = (OBJECT_ADDRESS (Wrd117.Obj));
  (Wrd113.Obj) = ((Wrd112.pObj) [0]);
  (Wrd114.Lng) = (FIXNUM_TO_LONG (Wrd113.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd114.Lng))))
    goto label_118;
  (Wrd102.Obj) = ((Wrd112.pObj) [8]);

DEFLABEL (label_117)
  (Rsp [2]) = (Wrd102.Obj);
  (Wrd127.Obj) = (Rsp [0]);
  (Wrd128.pObj) = (OBJECT_ADDRESS (Wrd127.Obj));
  (Wrd129.Obj) = ((Wrd128.pObj) [5]);
  (Wrd130.pObj) = (OBJECT_ADDRESS (Wrd129.Obj));
  (Wrd126.Obj) = ((Wrd130.pObj) [0]);
  (Rsp [0]) = (Wrd126.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 3);
  }

DEFLABEL (label_118)
  (Wrd120.Obj) = (Rsp [0]);
  (Wrd121.pObj) = (OBJECT_ADDRESS (Wrd120.Obj));
  (Wrd119.Obj) = ((Wrd121.pObj) [2]);
  (Wrd122.Obj) = (current_block [OBJECT_38_8]);
  (Wrd125.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_25]))));
  (* (--Rsp)) = (Wrd125.Obj);
  (* (--Rsp)) = (Wrd122.Obj);
  (* (--Rsp)) = (Wrd119.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_66)
  (Wrd102.Obj) = Rvl;
  goto label_117;

DEFLABEL (lambda_87)
DEFLABEL (lambda_43)
  INTERRUPT_CHECK (26, LABEL_38_13);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_31]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd8.Obj);
  (Wrd9.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd9.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_38_32]));

DEFLABEL (continuation_21)
  INTERRUPT_CHECK (27, LABEL_38_31);
  (* (--Rsp)) = Rvl;
  if (! (Rvl == ((SCHEME_OBJECT) 0)))
    goto label_119;
  Rvl = (Rsp [1]);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_119)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_34]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd10.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd10.Obj);
  (* (--Rsp)) = Rvl;
  (Wrd12.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd12.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_38_35]));

DEFLABEL (continuation_22)
  INTERRUPT_CHECK (27, LABEL_38_34);
  (* (--Rsp)) = Rvl;
  if (! (Rvl == ((SCHEME_OBJECT) 0)))
    goto label_142;
  (Wrd81.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_36]))));
  (* (--Rsp)) = (Wrd81.Obj);
  (Wrd82.Obj) = (Rsp [5]);
  (* (--Rsp)) = (Wrd82.Obj);
  (Wrd83.Obj) = (Rsp [5]);
  (* (--Rsp)) = (Wrd83.Obj);
  (Wrd84.Obj) = (Rsp [5]);
  (* (--Rsp)) = (Wrd84.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_38_37]));

DEFLABEL (continuation_23)
  INTERRUPT_CHECK (27, LABEL_38_36);
  (Rsp [0]) = Rvl;
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_121;
  Rvl = Rvl;

DEFLABEL (label_120)
  Rsp = (& (Rsp [5]));
  goto pop_return;

DEFLABEL (label_121)
  (Wrd19.Obj) = (Rsp [2]);
  (Wrd20.uLng) = (OBJECT_TYPE (Wrd19.Obj));
  if (! ((Wrd20.uLng) == 62))
    goto label_141;
  (Wrd16.pObj) = (OBJECT_ADDRESS (Wrd19.Obj));
  (Wrd17.Obj) = ((Wrd16.pObj) [0]);
  (Wrd18.Lng) = (FIXNUM_TO_LONG (Wrd17.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd18.Lng))))
    goto label_141;
  (Wrd12.Obj) = ((Wrd16.pObj) [8]);
  (* (--Rsp)) = (Wrd12.Obj);

DEFLABEL (label_140)
  (Wrd35.Obj) = (Rsp [3]);
  (Wrd36.uLng) = (OBJECT_TYPE (Wrd35.Obj));
  if (! ((Wrd36.uLng) == 62))
    goto label_139;
  (Wrd32.pObj) = (OBJECT_ADDRESS (Wrd35.Obj));
  (Wrd33.Obj) = ((Wrd32.pObj) [0]);
  (Wrd34.Lng) = (FIXNUM_TO_LONG (Wrd33.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd34.Lng))))
    goto label_139;
  (Wrd26.Obj) = ((Wrd32.pObj) [7]);

DEFLABEL (label_138)
  (Wrd54.uLng) = (OBJECT_TYPE (Wrd26.Obj));
  if (! ((Wrd54.uLng) == 10))
    goto label_137;
  (Wrd47.Obj) = (Rsp [2]);
  (Wrd48.uLng) = (OBJECT_TYPE (Wrd47.Obj));
  if (! ((Wrd48.uLng) == 26))
    goto label_137;
  (Wrd50.Lng) = (FIXNUM_TO_LONG (Wrd47.Obj));
  (Wrd51.pObj) = (OBJECT_ADDRESS (Wrd26.Obj));
  (Wrd52.Obj) = ((Wrd51.pObj) [0]);
  (Wrd53.Lng) = (FIXNUM_TO_LONG (Wrd52.Obj));
  if (! (((unsigned long) (Wrd50.Lng)) < ((unsigned long) (Wrd53.Lng))))
    goto label_137;
  (Wrd43.uLng) = (OBJECT_DATUM (Wrd47.Obj));
  (Wrd45.pObj) = (& ((Wrd51.pObj) [(Wrd43.Lng)]));
  (Wrd46.Obj) = ((Wrd45.pObj) [1]);
  (* (--Rsp)) = (Wrd46.Obj);

DEFLABEL (label_136)
  (Wrd69.Obj) = (Rsp [4]);
  (Wrd70.uLng) = (OBJECT_TYPE (Wrd69.Obj));
  if (! ((Wrd70.uLng) == 62))
    goto label_135;
  (Wrd66.pObj) = (OBJECT_ADDRESS (Wrd69.Obj));
  (Wrd67.Obj) = ((Wrd66.pObj) [0]);
  (Wrd68.Lng) = (FIXNUM_TO_LONG (Wrd67.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd68.Lng))))
    goto label_135;
  (Wrd60.Obj) = ((Wrd66.pObj) [6]);

DEFLABEL (label_134)
  (Wrd88.uLng) = (OBJECT_TYPE (Wrd60.Obj));
  if (! ((Wrd88.uLng) == 10))
    goto label_133;
  (Wrd81.Obj) = (Rsp [3]);
  (Wrd82.uLng) = (OBJECT_TYPE (Wrd81.Obj));
  if (! ((Wrd82.uLng) == 26))
    goto label_133;
  (Wrd84.Lng) = (FIXNUM_TO_LONG (Wrd81.Obj));
  (Wrd85.pObj) = (OBJECT_ADDRESS (Wrd60.Obj));
  (Wrd86.Obj) = ((Wrd85.pObj) [0]);
  (Wrd87.Lng) = (FIXNUM_TO_LONG (Wrd86.Obj));
  if (! (((unsigned long) (Wrd84.Lng)) < ((unsigned long) (Wrd87.Lng))))
    goto label_133;
  (Wrd78.uLng) = (OBJECT_DATUM (Wrd81.Obj));
  (Wrd80.pObj) = (& ((Wrd85.pObj) [(Wrd78.Lng)]));
  (Wrd76.Obj) = ((Wrd80.pObj) [1]);

DEFLABEL (label_132)
  (Wrd94.Obj) = (* (Rsp++));
  (* (Rhp++)) = (Wrd76.Obj);
  (* (Rhp++)) = (Wrd94.Obj);
  (Wrd97.pObj) = (& (Rhp [-2]));
  (Wrd95.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd97.pObj)));
  (Wrd98.Obj) = (* (Rsp++));
  (* (Rhp++)) = (Wrd95.Obj);
  (* (Rhp++)) = (Wrd98.Obj);
  (Wrd101.pObj) = (& (Rhp [-2]));
  (Wrd99.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd101.pObj)));
  (Wrd182.Obj) = (Rsp [2]);
  (Wrd183.uLng) = (OBJECT_TYPE (Wrd182.Obj));
  if (! ((Wrd183.uLng) == 62))
    goto label_131;
  (Wrd179.pObj) = (OBJECT_ADDRESS (Wrd182.Obj));
  (Wrd180.Obj) = ((Wrd179.pObj) [0]);
  (Wrd181.Lng) = (FIXNUM_TO_LONG (Wrd180.Obj));
  if (! (((unsigned long) 7L) < ((unsigned long) (Wrd181.Lng))))
    goto label_131;
  ((Wrd179.pObj) [8]) = (Wrd99.Obj);

DEFLABEL (label_130)
  (Wrd111.Obj) = (Rsp [2]);
  (Wrd112.uLng) = (OBJECT_TYPE (Wrd111.Obj));
  if (! ((Wrd112.uLng) == 62))
    goto label_129;
  (Wrd108.pObj) = (OBJECT_ADDRESS (Wrd111.Obj));
  (Wrd109.Obj) = ((Wrd108.pObj) [0]);
  (Wrd110.Lng) = (FIXNUM_TO_LONG (Wrd109.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd110.Lng))))
    goto label_129;
  (Wrd102.Obj) = ((Wrd108.pObj) [6]);

DEFLABEL (label_128)
  (Wrd167.uLng) = (OBJECT_TYPE (Wrd102.Obj));
  if (! ((Wrd167.uLng) == 10))
    goto label_127;
  (Wrd160.Obj) = (Rsp [1]);
  (Wrd161.uLng) = (OBJECT_TYPE (Wrd160.Obj));
  if (! ((Wrd161.uLng) == 26))
    goto label_127;
  (Wrd163.Lng) = (FIXNUM_TO_LONG (Wrd160.Obj));
  (Wrd164.pObj) = (OBJECT_ADDRESS (Wrd102.Obj));
  (Wrd165.Obj) = ((Wrd164.pObj) [0]);
  (Wrd166.Lng) = (FIXNUM_TO_LONG (Wrd165.Obj));
  if (! (((unsigned long) (Wrd163.Lng)) < ((unsigned long) (Wrd166.Lng))))
    goto label_127;
  (Wrd156.uLng) = (OBJECT_DATUM (Wrd160.Obj));
  (Wrd158.pObj) = (& ((Wrd164.pObj) [(Wrd156.Lng)]));
  (Wrd159.Obj) = (Rsp [3]);
  ((Wrd158.pObj) [1]) = (Wrd159.Obj);

DEFLABEL (label_126)
  (Wrd127.Obj) = (Rsp [2]);
  (Wrd128.uLng) = (OBJECT_TYPE (Wrd127.Obj));
  if (! ((Wrd128.uLng) == 62))
    goto label_125;
  (Wrd124.pObj) = (OBJECT_ADDRESS (Wrd127.Obj));
  (Wrd125.Obj) = ((Wrd124.pObj) [0]);
  (Wrd126.Lng) = (FIXNUM_TO_LONG (Wrd125.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd126.Lng))))
    goto label_125;
  (Wrd118.Obj) = ((Wrd124.pObj) [7]);

DEFLABEL (label_124)
  (Wrd148.uLng) = (OBJECT_TYPE (Wrd118.Obj));
  if (! ((Wrd148.uLng) == 10))
    goto label_123;
  (Wrd141.Obj) = (Rsp [1]);
  (Wrd142.uLng) = (OBJECT_TYPE (Wrd141.Obj));
  if (! ((Wrd142.uLng) == 26))
    goto label_123;
  (Wrd144.Lng) = (FIXNUM_TO_LONG (Wrd141.Obj));
  (Wrd145.pObj) = (OBJECT_ADDRESS (Wrd118.Obj));
  (Wrd146.Obj) = ((Wrd145.pObj) [0]);
  (Wrd147.Lng) = (FIXNUM_TO_LONG (Wrd146.Obj));
  if (! (((unsigned long) (Wrd144.Lng)) < ((unsigned long) (Wrd147.Lng))))
    goto label_123;
  (Wrd137.uLng) = (OBJECT_DATUM (Wrd141.Obj));
  (Wrd139.pObj) = (& ((Wrd145.pObj) [(Wrd137.Lng)]));
  (Wrd140.Obj) = (Rsp [4]);
  ((Wrd139.pObj) [1]) = (Wrd140.Obj);

DEFLABEL (label_122)
  Rvl = (Rsp [2]);
  goto label_120;

DEFLABEL (label_123)
  (Wrd150.Obj) = (Rsp [1]);
  (Wrd151.Obj) = (Rsp [4]);
  (Wrd154.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_51]))));
  (* (--Rsp)) = (Wrd154.Obj);
  (* (--Rsp)) = (Wrd151.Obj);
  (* (--Rsp)) = (Wrd150.Obj);
  (* (--Rsp)) = (Wrd118.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_12]), 3);

DEFLABEL (label_79)
  goto label_122;

DEFLABEL (label_125)
  (Wrd129.Obj) = (Rsp [2]);
  (Wrd130.Obj) = (current_block [OBJECT_38_9]);
  (Wrd133.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_50]))));
  (* (--Rsp)) = (Wrd133.Obj);
  (* (--Rsp)) = (Wrd130.Obj);
  (* (--Rsp)) = (Wrd129.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_78)
  (Wrd118.Obj) = Rvl;
  goto label_124;

DEFLABEL (label_127)
  (Wrd169.Obj) = (Rsp [1]);
  (Wrd170.Obj) = (Rsp [3]);
  (Wrd173.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_49]))));
  (* (--Rsp)) = (Wrd173.Obj);
  (* (--Rsp)) = (Wrd170.Obj);
  (* (--Rsp)) = (Wrd169.Obj);
  (* (--Rsp)) = (Wrd102.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_12]), 3);

DEFLABEL (label_80)
  goto label_126;

DEFLABEL (label_129)
  (Wrd113.Obj) = (Rsp [2]);
  (Wrd114.Obj) = (current_block [OBJECT_38_0]);
  (Wrd117.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_48]))));
  (* (--Rsp)) = (Wrd117.Obj);
  (* (--Rsp)) = (Wrd114.Obj);
  (* (--Rsp)) = (Wrd113.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_77)
  (Wrd102.Obj) = Rvl;
  goto label_128;

DEFLABEL (label_131)
  (Wrd184.Obj) = (Rsp [2]);
  (Wrd185.Obj) = (current_block [OBJECT_38_8]);
  (Wrd189.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_47]))));
  (* (--Rsp)) = (Wrd189.Obj);
  (* (--Rsp)) = (Wrd99.Obj);
  (* (--Rsp)) = (Wrd185.Obj);
  (* (--Rsp)) = (Wrd184.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_13]), 3);

DEFLABEL (label_81)
  goto label_130;

DEFLABEL (label_133)
  (Wrd90.Obj) = (Rsp [3]);
  (Wrd93.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_46]))));
  (* (--Rsp)) = (Wrd93.Obj);
  (* (--Rsp)) = (Wrd90.Obj);
  (* (--Rsp)) = (Wrd60.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_10]), 2);

DEFLABEL (label_76)
  (Wrd76.Obj) = Rvl;
  goto label_132;

DEFLABEL (label_135)
  (Wrd71.Obj) = (Rsp [4]);
  (Wrd72.Obj) = (current_block [OBJECT_38_0]);
  (Wrd75.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_45]))));
  (* (--Rsp)) = (Wrd75.Obj);
  (* (--Rsp)) = (Wrd72.Obj);
  (* (--Rsp)) = (Wrd71.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_75)
  (Wrd60.Obj) = Rvl;
  goto label_134;

DEFLABEL (label_137)
  (Wrd56.Obj) = (Rsp [2]);
  (Wrd59.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_44]))));
  (* (--Rsp)) = (Wrd59.Obj);
  (* (--Rsp)) = (Wrd56.Obj);
  (* (--Rsp)) = (Wrd26.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_10]), 2);

DEFLABEL (label_74)
  (* (--Rsp)) = Rvl;
  goto label_136;

DEFLABEL (label_139)
  (Wrd37.Obj) = (Rsp [3]);
  (Wrd38.Obj) = (current_block [OBJECT_38_9]);
  (Wrd41.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_43]))));
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd38.Obj);
  (* (--Rsp)) = (Wrd37.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_73)
  (Wrd26.Obj) = Rvl;
  goto label_138;

DEFLABEL (label_141)
  (Wrd21.Obj) = (Rsp [2]);
  (Wrd22.Obj) = (current_block [OBJECT_38_8]);
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_42]))));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_72)
  (* (--Rsp)) = Rvl;
  goto label_140;

DEFLABEL (label_142)
  (Wrd16.Obj) = (Rsp [2]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_150;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_150;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_149)
  (Wrd72.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd72.uLng) == 10))
    goto label_148;
  (Wrd65.Obj) = (Rsp [0]);
  (Wrd66.uLng) = (OBJECT_TYPE (Wrd65.Obj));
  if (! ((Wrd66.uLng) == 26))
    goto label_148;
  (Wrd68.Lng) = (FIXNUM_TO_LONG (Wrd65.Obj));
  (Wrd69.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd70.Obj) = ((Wrd69.pObj) [0]);
  (Wrd71.Lng) = (FIXNUM_TO_LONG (Wrd70.Obj));
  if (! (((unsigned long) (Wrd68.Lng)) < ((unsigned long) (Wrd71.Lng))))
    goto label_148;
  (Wrd61.uLng) = (OBJECT_DATUM (Wrd65.Obj));
  (Wrd63.pObj) = (& ((Wrd69.pObj) [(Wrd61.Lng)]));
  (Wrd64.Obj) = (Rsp [3]);
  ((Wrd63.pObj) [1]) = (Wrd64.Obj);

DEFLABEL (label_147)
  (Wrd32.Obj) = (Rsp [2]);
  (Wrd33.uLng) = (OBJECT_TYPE (Wrd32.Obj));
  if (! ((Wrd33.uLng) == 62))
    goto label_146;
  (Wrd29.pObj) = (OBJECT_ADDRESS (Wrd32.Obj));
  (Wrd30.Obj) = ((Wrd29.pObj) [0]);
  (Wrd31.Lng) = (FIXNUM_TO_LONG (Wrd30.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd31.Lng))))
    goto label_146;
  (Wrd23.Obj) = ((Wrd29.pObj) [7]);

DEFLABEL (label_145)
  (Wrd53.uLng) = (OBJECT_TYPE (Wrd23.Obj));
  if (! ((Wrd53.uLng) == 10))
    goto label_144;
  (Wrd46.Obj) = (Rsp [0]);
  (Wrd47.uLng) = (OBJECT_TYPE (Wrd46.Obj));
  if (! ((Wrd47.uLng) == 26))
    goto label_144;
  (Wrd49.Lng) = (FIXNUM_TO_LONG (Wrd46.Obj));
  (Wrd50.pObj) = (OBJECT_ADDRESS (Wrd23.Obj));
  (Wrd51.Obj) = ((Wrd50.pObj) [0]);
  (Wrd52.Lng) = (FIXNUM_TO_LONG (Wrd51.Obj));
  if (! (((unsigned long) (Wrd49.Lng)) < ((unsigned long) (Wrd52.Lng))))
    goto label_144;
  (Wrd42.uLng) = (OBJECT_DATUM (Wrd46.Obj));
  (Wrd44.pObj) = (& ((Wrd50.pObj) [(Wrd42.Lng)]));
  (Wrd45.Obj) = (Rsp [4]);
  ((Wrd44.pObj) [1]) = (Wrd45.Obj);

DEFLABEL (label_143)
  Rvl = (Rsp [2]);
  Rsp = (& (Rsp [5]));
  goto pop_return;

DEFLABEL (label_144)
  (Wrd55.Obj) = (Rsp [0]);
  (Wrd56.Obj) = (Rsp [4]);
  (Wrd59.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_41]))));
  (* (--Rsp)) = (Wrd59.Obj);
  (* (--Rsp)) = (Wrd56.Obj);
  (* (--Rsp)) = (Wrd55.Obj);
  (* (--Rsp)) = (Wrd23.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_12]), 3);

DEFLABEL (label_70)
  goto label_143;

DEFLABEL (label_146)
  (Wrd34.Obj) = (Rsp [2]);
  (Wrd35.Obj) = (current_block [OBJECT_38_9]);
  (Wrd38.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_40]))));
  (* (--Rsp)) = (Wrd38.Obj);
  (* (--Rsp)) = (Wrd35.Obj);
  (* (--Rsp)) = (Wrd34.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_69)
  (Wrd23.Obj) = Rvl;
  goto label_145;

DEFLABEL (label_148)
  (Wrd74.Obj) = (Rsp [0]);
  (Wrd75.Obj) = (Rsp [3]);
  (Wrd78.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_39]))));
  (* (--Rsp)) = (Wrd78.Obj);
  (* (--Rsp)) = (Wrd75.Obj);
  (* (--Rsp)) = (Wrd74.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_12]), 3);

DEFLABEL (label_71)
  goto label_147;

DEFLABEL (label_150)
  (Wrd18.Obj) = (Rsp [2]);
  (Wrd19.Obj) = (current_block [OBJECT_38_0]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_38_38]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_38_1]), 2);

DEFLABEL (label_68)
  (Wrd7.Obj) = Rvl;
  goto label_149;

INVOKE_INTERFACE_TARGET_0
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_39_4 3
#define LABEL_39_6 5
#define LABEL_39_7 7
#define LABEL_39_5 9
#define LABEL_39_9 11
#define LABEL_39_10 13
#define LABEL_39_11 15
#define LABEL_39_12 17
#define LABEL_39_13 19
#define LABEL_39_14 21
#define LABEL_39_15 23
#define LABEL_39_17 25
#define LABEL_39_18 27
#define LABEL_39_20 29
#define LABEL_39_21 31
#define LABEL_39_19 33
#define LABEL_39_16 35
#define LABEL_39_26 37
#define LABEL_39_27 39
#define LABEL_39_28 41
#define LABEL_39_29 43
#define LABEL_39_30 45
#define LABEL_39_31 47
#define LABEL_39_33 49
#define LABEL_39_34 51
#define LABEL_39_23 53
#define TAG_39_24 25
#define LABEL_39_35 55
#define LABEL_39_36 57
#define LABEL_39_37 59
#define LABEL_39_38 61
#define LABEL_39_39 63
#define LABEL_39_40 65
#define LABEL_39_41 67
#define LABEL_39_42 69
#define LABEL_39_43 71
#define LABEL_39_44 73
#define LABEL_39_45 75
#define LABEL_39_46 77
#define LABEL_39_47 79
#define LABEL_39_48 81
#define LABEL_39_49 83
#define ENVIRONMENT_LABEL_39_3 106
#define DEBUGGING_LABEL_39_2 105
#define OBJECT_39_11 104
#define OBJECT_39_10 103
#define OBJECT_39_9 102
#define OBJECT_39_8 101
#define OBJECT_39_7 100
#define OBJECT_39_6 99
#define OBJECT_39_5 98
#define OBJECT_39_4 97
#define OBJECT_39_3 96
#define OBJECT_39_2 95
#define OBJECT_39_1 94
#define OBJECT_39_0 93
#define EXECUTE_CACHE_39_32 85
#define EXECUTE_CACHE_39_25 87
#define EXECUTE_CACHE_39_22 89
#define EXECUTE_CACHE_39_8 91
#define FREE_REFERENCES_LABEL_39_0 84
#define NUMBER_OF_LINKER_SECTIONS_39_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_39 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd159;
  machine_word Wrd150;
  machine_word Wrd162;
  machine_word Wrd170;
  machine_word Wrd168;
  machine_word Wrd166;
  machine_word Wrd149;
  machine_word Wrd148;
  machine_word Wrd144;
  machine_word Wrd137;
  machine_word Wrd136;
  machine_word Wrd140;
  machine_word Wrd124;
  machine_word Wrd110;
  machine_word Wrd108;
  machine_word Wrd118;
  machine_word Wrd119;
  machine_word Wrd106;
  machine_word Wrd103;
  machine_word Wrd102;
  machine_word Wrd101;
  machine_word Wrd94;
  machine_word Wrd93;
  machine_word Wrd189;
  machine_word Wrd188;
  machine_word Wrd187;
  machine_word Wrd186;
  machine_word Wrd75;
  machine_word Wrd76;
  machine_word Wrd68;
  machine_word Wrd74;
  machine_word Wrd73;
  machine_word Wrd72;
  machine_word Wrd51;
  machine_word Wrd50;
  machine_word Wrd265;
  machine_word Wrd261;
  machine_word Wrd250;
  machine_word Wrd248;
  machine_word Wrd258;
  machine_word Wrd257;
  machine_word Wrd256;
  machine_word Wrd255;
  machine_word Wrd253;
  machine_word Wrd252;
  machine_word Wrd259;
  machine_word Wrd244;
  machine_word Wrd241;
  machine_word Wrd238;
  machine_word Wrd240;
  machine_word Wrd239;
  machine_word Wrd221;
  machine_word Wrd233;
  machine_word Wrd232;
  machine_word Wrd231;
  machine_word Wrd237;
  machine_word Wrd236;
  machine_word Wrd235;
  machine_word Wrd234;
  machine_word Wrd284;
  machine_word Wrd280;
  machine_word Wrd269;
  machine_word Wrd267;
  machine_word Wrd277;
  machine_word Wrd276;
  machine_word Wrd275;
  machine_word Wrd274;
  machine_word Wrd272;
  machine_word Wrd271;
  machine_word Wrd278;
  machine_word Wrd220;
  machine_word Wrd217;
  machine_word Wrd214;
  machine_word Wrd216;
  machine_word Wrd215;
  machine_word Wrd197;
  machine_word Wrd209;
  machine_word Wrd208;
  machine_word Wrd207;
  machine_word Wrd213;
  machine_word Wrd212;
  machine_word Wrd211;
  machine_word Wrd210;
  machine_word Wrd62;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd63;
  machine_word Wrd58;
  machine_word Wrd57;
  machine_word Wrd49;
  machine_word Wrd41;
  machine_word Wrd70;
  machine_word Wrd69;
  machine_word Wrd139;
  machine_word Wrd141;
  machine_word Wrd143;
  machine_word Wrd142;
  machine_word Wrd138;
  machine_word Wrd135;
  machine_word Wrd121;
  machine_word Wrd125;
  machine_word Wrd123;
  machine_word Wrd132;
  machine_word Wrd131;
  machine_word Wrd130;
  machine_word Wrd129;
  machine_word Wrd127;
  machine_word Wrd126;
  machine_word Wrd133;
  machine_word Wrd120;
  machine_word Wrd117;
  machine_word Wrd116;
  machine_word Wrd105;
  machine_word Wrd113;
  machine_word Wrd112;
  machine_word Wrd111;
  machine_word Wrd115;
  machine_word Wrd114;
  machine_word Wrd104;
  machine_word Wrd100;
  machine_word Wrd96;
  machine_word Wrd99;
  machine_word Wrd98;
  machine_word Wrd97;
  machine_word Wrd95;
  machine_word Wrd87;
  machine_word Wrd90;
  machine_word Wrd89;
  machine_word Wrd91;
  machine_word Wrd86;
  machine_word Wrd83;
  machine_word Wrd82;
  machine_word Wrd71;
  machine_word Wrd79;
  machine_word Wrd78;
  machine_word Wrd77;
  machine_word Wrd81;
  machine_word Wrd80;
  machine_word Wrd171;
  machine_word Wrd175;
  machine_word Wrd174;
  machine_word Wrd173;
  machine_word Wrd172;
  machine_word Wrd169;
  machine_word Wrd161;
  machine_word Wrd164;
  machine_word Wrd163;
  machine_word Wrd165;
  machine_word Wrd160;
  machine_word Wrd157;
  machine_word Wrd156;
  machine_word Wrd145;
  machine_word Wrd153;
  machine_word Wrd152;
  machine_word Wrd151;
  machine_word Wrd155;
  machine_word Wrd154;
  machine_word Wrd12;
  machine_word Wrd180;
  machine_word Wrd182;
  machine_word Wrd184;
  machine_word Wrd183;
  machine_word Wrd177;
  machine_word Wrd178;
  machine_word Wrd190;
  machine_word Wrd196;
  machine_word Wrd198;
  machine_word Wrd192;
  machine_word Wrd45;
  machine_word Wrd32;
  machine_word Wrd23;
  machine_word Wrd22;
  machine_word Wrd10;
  machine_word Wrd6;
  machine_word Wrd5;
  machine_word Wrd61;
  machine_word Wrd53;
  machine_word Wrd56;
  machine_word Wrd55;
  machine_word Wrd54;
  machine_word Wrd52;
  machine_word Wrd44;
  machine_word Wrd47;
  machine_word Wrd46;
  machine_word Wrd48;
  machine_word Wrd43;
  machine_word Wrd40;
  machine_word Wrd38;
  machine_word Wrd27;
  machine_word Wrd25;
  machine_word Wrd11;
  machine_word Wrd42;
  machine_word Wrd39;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd26;
  machine_word Wrd36;
  machine_word Wrd35;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd37;
  machine_word Wrd24;
  machine_word Wrd21;
  machine_word Wrd20;
  machine_word Wrd9;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd8;
  machine_word Wrd7;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_39_4);
      goto find_free_cache_line_76;

    case 1:
      current_block = (Rpc - LABEL_39_6);
      goto label_78;

    case 2:
      current_block = (Rpc - LABEL_39_7);
      goto label_79;

    case 3:
      current_block = (Rpc - LABEL_39_5);
      goto continuation_2;

    case 4:
      current_block = (Rpc - LABEL_39_9);
      goto label_80;

    case 5:
      current_block = (Rpc - LABEL_39_10);
      goto label_81;

    case 6:
      current_block = (Rpc - LABEL_39_11);
      goto label_82;

    case 7:
      current_block = (Rpc - LABEL_39_12);
      goto pri_loop_73;

    case 8:
      current_block = (Rpc - LABEL_39_13);
      goto label_83;

    case 9:
      current_block = (Rpc - LABEL_39_14);
      goto label_84;

    case 10:
      current_block = (Rpc - LABEL_39_15);
      goto sec_loop_71;

    case 11:
      current_block = (Rpc - LABEL_39_17);
      goto label_85;

    case 12:
      current_block = (Rpc - LABEL_39_18);
      goto label_86;

    case 13:
      current_block = (Rpc - LABEL_39_20);
      goto continuation_52;

    case 14:
      current_block = (Rpc - LABEL_39_21);
      goto label_95;

    case 15:
      current_block = (Rpc - LABEL_39_19);
      goto continuation_21;

    case 16:
      current_block = (Rpc - LABEL_39_16);
      goto continuation_20;

    case 17:
      current_block = (Rpc - LABEL_39_26);
      goto label_93;

    case 18:
      current_block = (Rpc - LABEL_39_27);
      goto label_94;

    case 19:
      current_block = (Rpc - LABEL_39_28);
      goto label_89;

    case 20:
      current_block = (Rpc - LABEL_39_29);
      goto label_90;

    case 21:
      current_block = (Rpc - LABEL_39_30);
      goto label_91;

    case 22:
      current_block = (Rpc - LABEL_39_31);
      goto label_92;

    case 23:
      current_block = (Rpc - LABEL_39_33);
      goto label_87;

    case 24:
      current_block = (Rpc - LABEL_39_34);
      goto label_88;

    case 25:
      current_block = (Rpc - LABEL_39_23);
      goto lambda_114;

    case 26:
      current_block = (Rpc - LABEL_39_35);
      goto loop_40;

    case 27:
      current_block = (Rpc - LABEL_39_36);
      goto label_106;

    case 28:
      current_block = (Rpc - LABEL_39_37);
      goto label_109;

    case 29:
      current_block = (Rpc - LABEL_39_38);
      goto label_107;

    case 30:
      current_block = (Rpc - LABEL_39_39);
      goto label_108;

    case 31:
      current_block = (Rpc - LABEL_39_40);
      goto label_96;

    case 32:
      current_block = (Rpc - LABEL_39_41);
      goto label_97;

    case 33:
      current_block = (Rpc - LABEL_39_42);
      goto label_98;

    case 34:
      current_block = (Rpc - LABEL_39_43);
      goto label_99;

    case 35:
      current_block = (Rpc - LABEL_39_44);
      goto label_105;

    case 36:
      current_block = (Rpc - LABEL_39_45);
      goto label_100;

    case 37:
      current_block = (Rpc - LABEL_39_46);
      goto label_101;

    case 38:
      current_block = (Rpc - LABEL_39_47);
      goto label_102;

    case 39:
      current_block = (Rpc - LABEL_39_48);
      goto label_104;

    case 40:
      current_block = (Rpc - LABEL_39_49);
      goto label_103;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (find_free_cache_line_111)
DEFLABEL (find_free_cache_line_76)
  INTERRUPT_CHECK (26, LABEL_39_4);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_5]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd8.Obj);
  (Wrd18.Obj) = (Rsp [2]);
  (Wrd19.uLng) = (OBJECT_TYPE (Wrd18.Obj));
  if (! ((Wrd19.uLng) == 62))
    goto label_129;
  (Wrd15.pObj) = (OBJECT_ADDRESS (Wrd18.Obj));
  (Wrd16.Obj) = ((Wrd15.pObj) [0]);
  (Wrd17.Lng) = (FIXNUM_TO_LONG (Wrd16.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd17.Lng))))
    goto label_129;
  (Wrd9.Obj) = ((Wrd15.pObj) [6]);

DEFLABEL (label_128)
  (Wrd37.uLng) = (OBJECT_TYPE (Wrd9.Obj));
  if (! ((Wrd37.uLng) == 10))
    goto label_127;
  (Wrd30.Obj) = (Rsp [3]);
  (Wrd31.uLng) = (OBJECT_TYPE (Wrd30.Obj));
  if (! ((Wrd31.uLng) == 26))
    goto label_127;
  (Wrd33.Lng) = (FIXNUM_TO_LONG (Wrd30.Obj));
  (Wrd34.pObj) = (OBJECT_ADDRESS (Wrd9.Obj));
  (Wrd35.Obj) = ((Wrd34.pObj) [0]);
  (Wrd36.Lng) = (FIXNUM_TO_LONG (Wrd35.Obj));
  if (! (((unsigned long) (Wrd33.Lng)) < ((unsigned long) (Wrd36.Lng))))
    goto label_127;
  (Wrd26.uLng) = (OBJECT_DATUM (Wrd30.Obj));
  (Wrd28.pObj) = (& ((Wrd34.pObj) [(Wrd26.Lng)]));
  (Wrd29.Obj) = ((Wrd28.pObj) [1]);
  (* (--Rsp)) = (Wrd29.Obj);

DEFLABEL (label_126)
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_39_8]));

DEFLABEL (continuation_2)
  INTERRUPT_CHECK (27, LABEL_39_5);
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_116;
  Rvl = (Rsp [1]);
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_116)
  (Wrd18.Obj) = (Rsp [0]);
  (Wrd19.uLng) = (OBJECT_TYPE (Wrd18.Obj));
  if (! ((Wrd19.uLng) == 62))
    goto label_125;
  (Wrd15.pObj) = (OBJECT_ADDRESS (Wrd18.Obj));
  (Wrd16.Obj) = ((Wrd15.pObj) [0]);
  (Wrd17.Lng) = (FIXNUM_TO_LONG (Wrd16.Obj));
  if (! (((unsigned long) 3L) < ((unsigned long) (Wrd17.Lng))))
    goto label_125;
  (Wrd11.Obj) = ((Wrd15.pObj) [4]);
  (* (--Rsp)) = (Wrd11.Obj);

DEFLABEL (label_124)
  (Wrd25.Obj) = (current_block [OBJECT_39_4]);
  (* (--Rsp)) = (Wrd25.Obj);
  (Wrd26.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd26.Obj);
  (Wrd27.Obj) = (Rsp [4]);
  (* (--Rsp)) = (Wrd27.Obj);
  (Wrd37.Obj) = (Rsp [4]);
  (Wrd38.uLng) = (OBJECT_TYPE (Wrd37.Obj));
  if (! ((Wrd38.uLng) == 62))
    goto label_123;
  (Wrd34.pObj) = (OBJECT_ADDRESS (Wrd37.Obj));
  (Wrd35.Obj) = ((Wrd34.pObj) [0]);
  (Wrd36.Lng) = (FIXNUM_TO_LONG (Wrd35.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd36.Lng))))
    goto label_123;
  (Wrd28.Obj) = ((Wrd34.pObj) [6]);

DEFLABEL (label_122)
  (Wrd48.uLng) = (OBJECT_TYPE (Wrd28.Obj));
  if (! ((Wrd48.uLng) == 10))
    goto label_121;
  (Wrd46.pObj) = (OBJECT_ADDRESS (Wrd28.Obj));
  (Wrd47.Obj) = ((Wrd46.pObj) [0]);
  (Wrd44.Obj) = (MAKE_OBJECT (26, (Wrd47.uLng)));

DEFLABEL (label_120)
  (Wrd54.Obj) = (Rsp [5]);
  (Wrd55.Lng) = (FIXNUM_TO_LONG (Wrd54.Obj));
  (Wrd56.Lng) = ((Wrd55.Lng) + 1L);
  (Wrd53.Obj) = (LONG_TO_FIXNUM (Wrd56.Lng));
  if ((Wrd53.Obj) == (Wrd44.Obj))
    goto label_118;
  (* (--Rsp)) = (Wrd53.Obj);
  goto label_117;

DEFLABEL (label_118)
  (Wrd61.Obj) = (current_block [OBJECT_39_6]);
  (* (--Rsp)) = (Wrd61.Obj);

DEFLABEL (label_117)
DEFLABEL (label_119)
  goto pri_loop_73;

DEFLABEL (label_121)
  (Wrd52.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_11]))));
  (* (--Rsp)) = (Wrd52.Obj);
  (* (--Rsp)) = (Wrd28.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_5]), 1);

DEFLABEL (label_82)
  (Wrd44.Obj) = Rvl;
  goto label_120;

DEFLABEL (label_123)
  (Wrd39.Obj) = (Rsp [4]);
  (Wrd40.Obj) = (current_block [OBJECT_39_0]);
  (Wrd43.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_10]))));
  (* (--Rsp)) = (Wrd43.Obj);
  (* (--Rsp)) = (Wrd40.Obj);
  (* (--Rsp)) = (Wrd39.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_81)
  (Wrd28.Obj) = Rvl;
  goto label_122;

DEFLABEL (label_125)
  (Wrd20.Obj) = (Rsp [0]);
  (Wrd21.Obj) = (current_block [OBJECT_39_3]);
  (Wrd24.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_9]))));
  (* (--Rsp)) = (Wrd24.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = (Wrd20.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_80)
  (* (--Rsp)) = Rvl;
  goto label_124;

DEFLABEL (label_127)
  (Wrd39.Obj) = (Rsp [3]);
  (Wrd42.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_7]))));
  (* (--Rsp)) = (Wrd42.Obj);
  (* (--Rsp)) = (Wrd39.Obj);
  (* (--Rsp)) = (Wrd9.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_2]), 2);

DEFLABEL (label_79)
  (* (--Rsp)) = Rvl;
  goto label_126;

DEFLABEL (label_129)
  (Wrd20.Obj) = (Rsp [2]);
  (Wrd21.Obj) = (current_block [OBJECT_39_0]);
  (Wrd24.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_6]))));
  (* (--Rsp)) = (Wrd24.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = (Wrd20.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_78)
  (Wrd9.Obj) = Rvl;
  goto label_128;

DEFLABEL (pri_loop_112)
DEFLABEL (pri_loop_73)
  INTERRUPT_CHECK (26, LABEL_39_12);
  (Wrd5.Obj) = (Rsp [0]);
  (Wrd6.Lng) = (FIXNUM_TO_LONG (Wrd5.Obj));
  (Wrd7.Obj) = (Rsp [1]);
  (Wrd8.Lng) = (FIXNUM_TO_LONG (Wrd7.Obj));
  (Wrd9.Lng) = ((Wrd6.Lng) - (Wrd8.Lng));
  (Wrd10.Obj) = (LONG_TO_FIXNUM (Wrd9.Lng));
  (* (--Rsp)) = (Wrd10.Obj);
  if ((Wrd9.Lng) < 0)
    goto label_131;
  Rsp = (& (Rsp [1]));
  (* (--Rsp)) = (Wrd10.Obj);

DEFLABEL (label_130)
  (Wrd15.Obj) = (Rsp [1]);
  (* (--Rsp)) = (Wrd15.Obj);
  goto sec_loop_71;

DEFLABEL (label_131)
  (Wrd25.Obj) = (Rsp [6]);
  (Wrd26.uLng) = (OBJECT_TYPE (Wrd25.Obj));
  if (! ((Wrd26.uLng) == 62))
    goto label_135;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd25.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Lng) = (FIXNUM_TO_LONG (Wrd23.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd24.Lng))))
    goto label_135;
  (Wrd16.Obj) = ((Wrd22.pObj) [6]);

DEFLABEL (label_134)
  (Wrd36.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd36.uLng) == 10))
    goto label_133;
  (Wrd34.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd35.Obj) = ((Wrd34.pObj) [0]);
  (Wrd32.Obj) = (MAKE_OBJECT (26, (Wrd35.uLng)));

DEFLABEL (label_132)
  (Wrd43.Obj) = (Rsp [0]);
  (Wrd44.Lng) = (FIXNUM_TO_LONG (Wrd43.Obj));
  (Wrd45.Lng) = (FIXNUM_TO_LONG (Wrd32.Obj));
  (Wrd46.Lng) = ((Wrd44.Lng) + (Wrd45.Lng));
  (Wrd42.Obj) = (LONG_TO_FIXNUM (Wrd46.Lng));
  Rsp = (& (Rsp [1]));
  (* (--Rsp)) = (Wrd42.Obj);
  goto label_130;

DEFLABEL (label_133)
  (Wrd40.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_14]))));
  (* (--Rsp)) = (Wrd40.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_5]), 1);

DEFLABEL (label_84)
  (Wrd32.Obj) = Rvl;
  goto label_132;

DEFLABEL (label_135)
  (Wrd27.Obj) = (Rsp [6]);
  (Wrd28.Obj) = (current_block [OBJECT_39_0]);
  (Wrd31.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_13]))));
  (* (--Rsp)) = (Wrd31.Obj);
  (* (--Rsp)) = (Wrd28.Obj);
  (* (--Rsp)) = (Wrd27.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_83)
  (Wrd16.Obj) = Rvl;
  goto label_134;

DEFLABEL (sec_loop_113)
DEFLABEL (sec_loop_71)
  INTERRUPT_CHECK (26, LABEL_39_15);
  (Wrd5.Obj) = (Rsp [0]);
  (Wrd6.Obj) = (Rsp [8]);
  if (! ((Wrd5.Obj) == (Wrd6.Obj)))
    goto label_136;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [10]));
  goto pop_return;

DEFLABEL (label_136)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_16]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd19.Obj) = (Rsp [8]);
  (Wrd20.uLng) = (OBJECT_TYPE (Wrd19.Obj));
  if (! ((Wrd20.uLng) == 62))
    goto label_171;
  (Wrd16.pObj) = (OBJECT_ADDRESS (Wrd19.Obj));
  (Wrd17.Obj) = ((Wrd16.pObj) [0]);
  (Wrd18.Lng) = (FIXNUM_TO_LONG (Wrd17.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd18.Lng))))
    goto label_171;
  (Wrd10.Obj) = ((Wrd16.pObj) [6]);

DEFLABEL (label_170)
  (Wrd38.uLng) = (OBJECT_TYPE (Wrd10.Obj));
  if (! ((Wrd38.uLng) == 10))
    goto label_169;
  (Wrd31.Obj) = (Rsp [1]);
  (Wrd32.uLng) = (OBJECT_TYPE (Wrd31.Obj));
  if (! ((Wrd32.uLng) == 26))
    goto label_169;
  (Wrd34.Lng) = (FIXNUM_TO_LONG (Wrd31.Obj));
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd10.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (Wrd37.Lng) = (FIXNUM_TO_LONG (Wrd36.Obj));
  if (! (((unsigned long) (Wrd34.Lng)) < ((unsigned long) (Wrd37.Lng))))
    goto label_169;
  (Wrd27.uLng) = (OBJECT_DATUM (Wrd31.Obj));
  (Wrd29.pObj) = (& ((Wrd35.pObj) [(Wrd27.Lng)]));
  (Wrd30.Obj) = ((Wrd29.pObj) [1]);
  (* (--Rsp)) = (Wrd30.Obj);

DEFLABEL (label_168)
  (Wrd46.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_19]))));
  (* (--Rsp)) = (Wrd46.Obj);
  (Wrd47.Obj) = (Rsp [7]);
  (* (--Rsp)) = (Wrd47.Obj);
  (Wrd48.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd48.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_39_8]));

DEFLABEL (continuation_21)
  INTERRUPT_CHECK (27, LABEL_39_19);
  if (! (Rvl == ((SCHEME_OBJECT) 0)))
    goto label_137;
  (Wrd190.Obj) = (Rsp [9]);
  (* (--Rsp)) = (Wrd190.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_39_22]));

DEFLABEL (label_137)
  Rsp = (& (Rsp [2]));
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);

DEFLABEL (label_167)
  (Wrd5.Obj) = (Rsp [0]);
  if (! ((Wrd5.Obj) == ((SCHEME_OBJECT) 0)))
    goto label_138;
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 6));
  (Wrd178.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x101, 2);
  (* (Rhp++)) = (dispatch_base + TAG_39_24);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_39_23])));
  Rhp += 3;
  (Wrd177.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd178.pObj)));
  Wrd183 = Wrd178;
  (Wrd184.Obj) = (Rsp [8]);
  ((Wrd183.pObj) [2]) = (Wrd184.Obj);
  (Wrd182.Obj) = (Rsp [6]);
  ((Wrd183.pObj) [3]) = (Wrd182.Obj);
  (Wrd180.Obj) = (Rsp [1]);
  ((Wrd183.pObj) [4]) = (Wrd180.Obj);
  (Rsp [10]) = (Wrd177.Obj);
  Rsp = (& (Rsp [10]));
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_39_25]));

DEFLABEL (label_138)
  (Wrd7.Obj) = (Rsp [1]);
  (Wrd8.Lng) = (FIXNUM_TO_LONG (Wrd7.Obj));
  (Wrd10.Lng) = (FIXNUM_TO_LONG (Wrd5.Obj));
  (Wrd11.Lng) = ((Wrd8.Lng) - (Wrd10.Lng));
  (Wrd12.Obj) = (LONG_TO_FIXNUM (Wrd11.Lng));
  (* (--Rsp)) = (Wrd12.Obj);
  if ((Wrd11.Lng) < 0)
    goto label_162;
  Rsp = (& (Rsp [1]));
  (* (--Rsp)) = (Wrd12.Obj);

DEFLABEL (label_161)
  (Wrd17.Obj) = (Rsp [0]);
  (Wrd18.Lng) = (FIXNUM_TO_LONG (Wrd17.Obj));
  (Wrd19.Obj) = (Rsp [8]);
  (Wrd20.Lng) = (FIXNUM_TO_LONG (Wrd19.Obj));
  if ((Wrd18.Lng) < (Wrd20.Lng))
    goto label_139;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [12]));
  goto pop_return;

DEFLABEL (label_139)
  (Wrd23.Obj) = (Rsp [3]);
  (Wrd24.Lng) = (FIXNUM_TO_LONG (Wrd23.Obj));
  if ((Wrd24.Lng) > (Wrd18.Lng))
    goto label_148;
  if (! ((Wrd23.Obj) == (Wrd17.Obj)))
    goto label_147;
  (Wrd69.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_20]))));
  (* (--Rsp)) = (Wrd69.Obj);
  (Wrd70.Obj) = (current_block [OBJECT_39_7]);
  (* (--Rsp)) = (Wrd70.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_39_32]));

DEFLABEL (continuation_52)
  INTERRUPT_CHECK (27, LABEL_39_20);
  (Wrd192.uLng) = (OBJECT_TYPE (Rvl));
  if (! ((Wrd192.uLng) == 26))
    goto label_160;
  (Wrd198.Lng) = (FIXNUM_TO_LONG (Rvl));
  if ((Wrd198.Lng) == 0)
    goto label_148;

DEFLABEL (label_147)
  (Wrd38.Obj) = (Rsp [9]);
  (Wrd39.uLng) = (OBJECT_TYPE (Wrd38.Obj));
  if (! ((Wrd39.uLng) == 62))
    goto label_146;
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd38.Obj));
  (Wrd36.Obj) = ((Wrd35.pObj) [0]);
  (Wrd37.Lng) = (FIXNUM_TO_LONG (Wrd36.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd37.Lng))))
    goto label_146;
  (Wrd29.Obj) = ((Wrd35.pObj) [6]);

DEFLABEL (label_145)
  (Wrd49.uLng) = (OBJECT_TYPE (Wrd29.Obj));
  if (! ((Wrd49.uLng) == 10))
    goto label_144;
  (Wrd47.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd48.Obj) = ((Wrd47.pObj) [0]);
  (Wrd45.Obj) = (MAKE_OBJECT (26, (Wrd48.uLng)));

DEFLABEL (label_143)
  (Wrd55.Obj) = (Rsp [2]);
  (Wrd56.Lng) = (FIXNUM_TO_LONG (Wrd55.Obj));
  (Wrd57.Lng) = ((Wrd56.Lng) + 1L);
  (Wrd54.Obj) = (LONG_TO_FIXNUM (Wrd57.Lng));
  if ((Wrd54.Obj) == (Wrd45.Obj))
    goto label_141;
  Wrd58 = Wrd54;
  goto label_140;

DEFLABEL (label_141)
  (Wrd58.Obj) = (current_block [OBJECT_39_6]);

DEFLABEL (label_140)
DEFLABEL (label_142)
  (Rsp [2]) = (Wrd58.Obj);
  (Wrd63.Obj) = (Rsp [3]);
  (Wrd64.Lng) = (FIXNUM_TO_LONG (Wrd63.Obj));
  (Wrd65.Lng) = ((Wrd64.Lng) + 1L);
  (Wrd62.Obj) = (LONG_TO_FIXNUM (Wrd65.Lng));
  (Rsp [3]) = (Wrd62.Obj);
  Rsp = (& (Rsp [2]));
  goto sec_loop_71;

DEFLABEL (label_144)
  (Wrd53.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_34]))));
  (* (--Rsp)) = (Wrd53.Obj);
  (* (--Rsp)) = (Wrd29.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_5]), 1);

DEFLABEL (label_88)
  (Wrd45.Obj) = Rvl;
  goto label_143;

DEFLABEL (label_146)
  (Wrd40.Obj) = (Rsp [9]);
  (Wrd41.Obj) = (current_block [OBJECT_39_0]);
  (Wrd44.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_33]))));
  (* (--Rsp)) = (Wrd44.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  (* (--Rsp)) = (Wrd40.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_87)
  (Wrd29.Obj) = Rvl;
  goto label_145;

DEFLABEL (label_148)
  (Wrd80.Obj) = (Rsp [9]);
  (Wrd81.uLng) = (OBJECT_TYPE (Wrd80.Obj));
  if (! ((Wrd81.uLng) == 62))
    goto label_159;
  (Wrd77.pObj) = (OBJECT_ADDRESS (Wrd80.Obj));
  (Wrd78.Obj) = ((Wrd77.pObj) [0]);
  (Wrd79.Lng) = (FIXNUM_TO_LONG (Wrd78.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd79.Lng))))
    goto label_159;
  (Wrd71.Obj) = ((Wrd77.pObj) [6]);

DEFLABEL (label_158)
  (Wrd91.uLng) = (OBJECT_TYPE (Wrd71.Obj));
  if (! ((Wrd91.uLng) == 10))
    goto label_157;
  (Wrd89.pObj) = (OBJECT_ADDRESS (Wrd71.Obj));
  (Wrd90.Obj) = ((Wrd89.pObj) [0]);
  (Wrd87.Obj) = (MAKE_OBJECT (26, (Wrd90.uLng)));

DEFLABEL (label_156)
  (Wrd97.Obj) = (Rsp [2]);
  (Wrd98.Lng) = (FIXNUM_TO_LONG (Wrd97.Obj));
  (Wrd99.Lng) = ((Wrd98.Lng) + 1L);
  (Wrd96.Obj) = (LONG_TO_FIXNUM (Wrd99.Lng));
  if ((Wrd96.Obj) == (Wrd87.Obj))
    goto label_150;
  Wrd100 = Wrd96;
  goto label_149;

DEFLABEL (label_150)
  (Wrd100.Obj) = (current_block [OBJECT_39_6]);

DEFLABEL (label_149)
DEFLABEL (label_155)
  (Rsp [4]) = (Wrd100.Obj);
  (Wrd104.Obj) = (Rsp [1]);
  (Rsp [5]) = (Wrd104.Obj);
  (Wrd114.Obj) = (Rsp [9]);
  (Wrd115.uLng) = (OBJECT_TYPE (Wrd114.Obj));
  if (! ((Wrd115.uLng) == 62))
    goto label_154;
  (Wrd111.pObj) = (OBJECT_ADDRESS (Wrd114.Obj));
  (Wrd112.Obj) = ((Wrd111.pObj) [0]);
  (Wrd113.Lng) = (FIXNUM_TO_LONG (Wrd112.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd113.Lng))))
    goto label_154;
  (Wrd105.Obj) = ((Wrd111.pObj) [6]);

DEFLABEL (label_153)
  (Wrd133.uLng) = (OBJECT_TYPE (Wrd105.Obj));
  if (! ((Wrd133.uLng) == 10))
    goto label_152;
  (Wrd126.Obj) = (Rsp [2]);
  (Wrd127.uLng) = (OBJECT_TYPE (Wrd126.Obj));
  if (! ((Wrd127.uLng) == 26))
    goto label_152;
  (Wrd129.Lng) = (FIXNUM_TO_LONG (Wrd126.Obj));
  (Wrd130.pObj) = (OBJECT_ADDRESS (Wrd105.Obj));
  (Wrd131.Obj) = ((Wrd130.pObj) [0]);
  (Wrd132.Lng) = (FIXNUM_TO_LONG (Wrd131.Obj));
  if (! (((unsigned long) (Wrd129.Lng)) < ((unsigned long) (Wrd132.Lng))))
    goto label_152;
  (Wrd123.uLng) = (OBJECT_DATUM (Wrd126.Obj));
  (Wrd125.pObj) = (& ((Wrd130.pObj) [(Wrd123.Lng)]));
  (Wrd121.Obj) = ((Wrd125.pObj) [1]);

DEFLABEL (label_151)
  (Rsp [6]) = (Wrd121.Obj);
  (Wrd142.Obj) = (Rsp [2]);
  (Wrd143.Obj) = (Rsp [7]);
  (* (Rhp++)) = (Wrd142.Obj);
  (* (Rhp++)) = (Wrd143.Obj);
  (Wrd141.pObj) = (& (Rhp [-2]));
  (Wrd139.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd141.pObj)));
  (Rsp [7]) = (Wrd139.Obj);
  Rsp = (& (Rsp [4]));
  goto pri_loop_73;

DEFLABEL (label_152)
  (Wrd135.Obj) = (Rsp [2]);
  (Wrd138.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_31]))));
  (* (--Rsp)) = (Wrd138.Obj);
  (* (--Rsp)) = (Wrd135.Obj);
  (* (--Rsp)) = (Wrd105.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_2]), 2);

DEFLABEL (label_92)
  (Wrd121.Obj) = Rvl;
  goto label_151;

DEFLABEL (label_154)
  (Wrd116.Obj) = (Rsp [9]);
  (Wrd117.Obj) = (current_block [OBJECT_39_0]);
  (Wrd120.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_30]))));
  (* (--Rsp)) = (Wrd120.Obj);
  (* (--Rsp)) = (Wrd117.Obj);
  (* (--Rsp)) = (Wrd116.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_91)
  (Wrd105.Obj) = Rvl;
  goto label_153;

DEFLABEL (label_157)
  (Wrd95.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_29]))));
  (* (--Rsp)) = (Wrd95.Obj);
  (* (--Rsp)) = (Wrd71.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_5]), 1);

DEFLABEL (label_90)
  (Wrd87.Obj) = Rvl;
  goto label_156;

DEFLABEL (label_159)
  (Wrd82.Obj) = (Rsp [9]);
  (Wrd83.Obj) = (current_block [OBJECT_39_0]);
  (Wrd86.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_28]))));
  (* (--Rsp)) = (Wrd86.Obj);
  (* (--Rsp)) = (Wrd83.Obj);
  (* (--Rsp)) = (Wrd82.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_89)
  (Wrd71.Obj) = Rvl;
  goto label_158;

DEFLABEL (label_160)
  (Wrd196.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_21]))));
  (* (--Rsp)) = (Wrd196.Obj);
  (* (--Rsp)) = Rvl;
  INVOKE_INTERFACE_0 (45);

DEFLABEL (label_95)
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_147;
  goto label_148;

DEFLABEL (label_162)
  (Wrd154.Obj) = (Rsp [9]);
  (Wrd155.uLng) = (OBJECT_TYPE (Wrd154.Obj));
  if (! ((Wrd155.uLng) == 62))
    goto label_166;
  (Wrd151.pObj) = (OBJECT_ADDRESS (Wrd154.Obj));
  (Wrd152.Obj) = ((Wrd151.pObj) [0]);
  (Wrd153.Lng) = (FIXNUM_TO_LONG (Wrd152.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd153.Lng))))
    goto label_166;
  (Wrd145.Obj) = ((Wrd151.pObj) [6]);

DEFLABEL (label_165)
  (Wrd165.uLng) = (OBJECT_TYPE (Wrd145.Obj));
  if (! ((Wrd165.uLng) == 10))
    goto label_164;
  (Wrd163.pObj) = (OBJECT_ADDRESS (Wrd145.Obj));
  (Wrd164.Obj) = ((Wrd163.pObj) [0]);
  (Wrd161.Obj) = (MAKE_OBJECT (26, (Wrd164.uLng)));

DEFLABEL (label_163)
  (Wrd172.Obj) = (Rsp [0]);
  (Wrd173.Lng) = (FIXNUM_TO_LONG (Wrd172.Obj));
  (Wrd174.Lng) = (FIXNUM_TO_LONG (Wrd161.Obj));
  (Wrd175.Lng) = ((Wrd173.Lng) + (Wrd174.Lng));
  (Wrd171.Obj) = (LONG_TO_FIXNUM (Wrd175.Lng));
  Rsp = (& (Rsp [1]));
  (* (--Rsp)) = (Wrd171.Obj);
  goto label_161;

DEFLABEL (label_164)
  (Wrd169.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_27]))));
  (* (--Rsp)) = (Wrd169.Obj);
  (* (--Rsp)) = (Wrd145.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_5]), 1);

DEFLABEL (label_94)
  (Wrd161.Obj) = Rvl;
  goto label_163;

DEFLABEL (label_166)
  (Wrd156.Obj) = (Rsp [9]);
  (Wrd157.Obj) = (current_block [OBJECT_39_0]);
  (Wrd160.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_26]))));
  (* (--Rsp)) = (Wrd160.Obj);
  (* (--Rsp)) = (Wrd157.Obj);
  (* (--Rsp)) = (Wrd156.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_93)
  (Wrd145.Obj) = Rvl;
  goto label_165;

DEFLABEL (label_169)
  (Wrd40.Obj) = (Rsp [1]);
  (Wrd43.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_18]))));
  (* (--Rsp)) = (Wrd43.Obj);
  (* (--Rsp)) = (Wrd40.Obj);
  (* (--Rsp)) = (Wrd10.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_2]), 2);

DEFLABEL (label_86)
  (* (--Rsp)) = Rvl;
  goto label_168;

DEFLABEL (label_171)
  (Wrd21.Obj) = (Rsp [8]);
  (Wrd22.Obj) = (current_block [OBJECT_39_0]);
  (Wrd25.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_17]))));
  (* (--Rsp)) = (Wrd25.Obj);
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_85)
  (Wrd10.Obj) = Rvl;
  goto label_170;

DEFLABEL (continuation_20)
  INTERRUPT_CHECK (27, LABEL_39_16);
  (* (--Rsp)) = Rvl;
  goto label_167;

DEFLABEL (lambda_114)
  CLOSURE_HEADER (LABEL_39_23);

DEFLABEL (lambda_42)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd5.Obj) = (Rsp [0]);
  (Wrd6.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd7.Obj) = ((Wrd6.pObj) [3]);
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd10.Obj) = ((Wrd6.pObj) [4]);
  (* (--Rsp)) = (Wrd10.Obj);
  goto loop_40;

DEFLABEL (loop_115)
DEFLABEL (loop_40)
  INTERRUPT_CHECK (26, LABEL_39_35);
  (Wrd5.Obj) = (Rsp [1]);
  if ((Wrd5.Obj) == (current_block [OBJECT_39_4]))
    goto label_192;
  (Wrd11.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd11.uLng) == 1))
    goto label_191;
  (Wrd8.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd9.Obj) = ((Wrd8.pObj) [0]);
  (* (--Rsp)) = (Wrd9.Obj);

DEFLABEL (label_190)
  (Wrd29.Obj) = (Rsp [3]);
  (Wrd30.pObj) = (OBJECT_ADDRESS (Wrd29.Obj));
  (Wrd31.Obj) = ((Wrd30.pObj) [2]);
  (Wrd32.uLng) = (OBJECT_TYPE (Wrd31.Obj));
  if (! ((Wrd32.uLng) == 62))
    goto label_189;
  (Wrd26.pObj) = (OBJECT_ADDRESS (Wrd31.Obj));
  (Wrd27.Obj) = ((Wrd26.pObj) [0]);
  (Wrd28.Lng) = (FIXNUM_TO_LONG (Wrd27.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd28.Lng))))
    goto label_189;
  (Wrd16.Obj) = ((Wrd26.pObj) [6]);

DEFLABEL (label_188)
  (Wrd52.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd52.uLng) == 10))
    goto label_187;
  (Wrd45.Obj) = (Rsp [0]);
  (Wrd46.uLng) = (OBJECT_TYPE (Wrd45.Obj));
  if (! ((Wrd46.uLng) == 26))
    goto label_187;
  (Wrd48.Lng) = (FIXNUM_TO_LONG (Wrd45.Obj));
  (Wrd49.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd50.Obj) = ((Wrd49.pObj) [0]);
  (Wrd51.Lng) = (FIXNUM_TO_LONG (Wrd50.Obj));
  if (! (((unsigned long) (Wrd48.Lng)) < ((unsigned long) (Wrd51.Lng))))
    goto label_187;
  (Wrd41.uLng) = (OBJECT_DATUM (Wrd45.Obj));
  (Wrd43.pObj) = (& ((Wrd49.pObj) [(Wrd41.Lng)]));
  (Wrd44.Obj) = ((Wrd43.pObj) [1]);
  (* (--Rsp)) = (Wrd44.Obj);

DEFLABEL (label_186)
  (Wrd71.Obj) = (Rsp [4]);
  (Wrd72.pObj) = (OBJECT_ADDRESS (Wrd71.Obj));
  (Wrd73.Obj) = ((Wrd72.pObj) [2]);
  (Wrd74.uLng) = (OBJECT_TYPE (Wrd73.Obj));
  if (! ((Wrd74.uLng) == 62))
    goto label_185;
  (Wrd68.pObj) = (OBJECT_ADDRESS (Wrd73.Obj));
  (Wrd69.Obj) = ((Wrd68.pObj) [0]);
  (Wrd70.Lng) = (FIXNUM_TO_LONG (Wrd69.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd70.Lng))))
    goto label_185;
  (Wrd58.Obj) = ((Wrd68.pObj) [6]);

DEFLABEL (label_184)
  (Wrd82.Obj) = (* (Rsp++));
  (Wrd190.uLng) = (OBJECT_TYPE (Wrd58.Obj));
  if (! ((Wrd190.uLng) == 10))
    goto label_183;
  (Wrd183.Obj) = (Rsp [1]);
  (Wrd184.uLng) = (OBJECT_TYPE (Wrd183.Obj));
  if (! ((Wrd184.uLng) == 26))
    goto label_183;
  (Wrd186.Lng) = (FIXNUM_TO_LONG (Wrd183.Obj));
  (Wrd187.pObj) = (OBJECT_ADDRESS (Wrd58.Obj));
  (Wrd188.Obj) = ((Wrd187.pObj) [0]);
  (Wrd189.Lng) = (FIXNUM_TO_LONG (Wrd188.Obj));
  if (! (((unsigned long) (Wrd186.Lng)) < ((unsigned long) (Wrd189.Lng))))
    goto label_183;
  (Wrd180.uLng) = (OBJECT_DATUM (Wrd183.Obj));
  (Wrd182.pObj) = (& ((Wrd187.pObj) [(Wrd180.Lng)]));
  ((Wrd182.pObj) [1]) = (Wrd82.Obj);

DEFLABEL (label_182)
  (Wrd96.Obj) = (Rsp [3]);
  (Wrd97.pObj) = (OBJECT_ADDRESS (Wrd96.Obj));
  (Wrd98.Obj) = ((Wrd97.pObj) [2]);
  (Wrd99.uLng) = (OBJECT_TYPE (Wrd98.Obj));
  if (! ((Wrd99.uLng) == 62))
    goto label_181;
  (Wrd93.pObj) = (OBJECT_ADDRESS (Wrd98.Obj));
  (Wrd94.Obj) = ((Wrd93.pObj) [0]);
  (Wrd95.Lng) = (FIXNUM_TO_LONG (Wrd94.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd95.Lng))))
    goto label_181;
  (Wrd83.Obj) = ((Wrd93.pObj) [7]);

DEFLABEL (label_180)
  (Wrd119.uLng) = (OBJECT_TYPE (Wrd83.Obj));
  if (! ((Wrd119.uLng) == 10))
    goto label_179;
  (Wrd112.Obj) = (Rsp [0]);
  (Wrd113.uLng) = (OBJECT_TYPE (Wrd112.Obj));
  if (! ((Wrd113.uLng) == 26))
    goto label_179;
  (Wrd115.Lng) = (FIXNUM_TO_LONG (Wrd112.Obj));
  (Wrd116.pObj) = (OBJECT_ADDRESS (Wrd83.Obj));
  (Wrd117.Obj) = ((Wrd116.pObj) [0]);
  (Wrd118.Lng) = (FIXNUM_TO_LONG (Wrd117.Obj));
  if (! (((unsigned long) (Wrd115.Lng)) < ((unsigned long) (Wrd118.Lng))))
    goto label_179;
  (Wrd108.uLng) = (OBJECT_DATUM (Wrd112.Obj));
  (Wrd110.pObj) = (& ((Wrd116.pObj) [(Wrd108.Lng)]));
  (Wrd111.Obj) = ((Wrd110.pObj) [1]);
  (* (--Rsp)) = (Wrd111.Obj);

DEFLABEL (label_178)
  (Wrd138.Obj) = (Rsp [4]);
  (Wrd139.pObj) = (OBJECT_ADDRESS (Wrd138.Obj));
  (Wrd140.Obj) = ((Wrd139.pObj) [2]);
  (Wrd141.uLng) = (OBJECT_TYPE (Wrd140.Obj));
  if (! ((Wrd141.uLng) == 62))
    goto label_177;
  (Wrd135.pObj) = (OBJECT_ADDRESS (Wrd140.Obj));
  (Wrd136.Obj) = ((Wrd135.pObj) [0]);
  (Wrd137.Lng) = (FIXNUM_TO_LONG (Wrd136.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd137.Lng))))
    goto label_177;
  (Wrd125.Obj) = ((Wrd135.pObj) [7]);

DEFLABEL (label_176)
  (Wrd149.Obj) = (* (Rsp++));
  (Wrd172.uLng) = (OBJECT_TYPE (Wrd125.Obj));
  if (! ((Wrd172.uLng) == 10))
    goto label_175;
  (Wrd165.Obj) = (Rsp [1]);
  (Wrd166.uLng) = (OBJECT_TYPE (Wrd165.Obj));
  if (! ((Wrd166.uLng) == 26))
    goto label_175;
  (Wrd168.Lng) = (FIXNUM_TO_LONG (Wrd165.Obj));
  (Wrd169.pObj) = (OBJECT_ADDRESS (Wrd125.Obj));
  (Wrd170.Obj) = ((Wrd169.pObj) [0]);
  (Wrd171.Lng) = (FIXNUM_TO_LONG (Wrd170.Obj));
  if (! (((unsigned long) (Wrd168.Lng)) < ((unsigned long) (Wrd171.Lng))))
    goto label_175;
  (Wrd162.uLng) = (OBJECT_DATUM (Wrd165.Obj));
  (Wrd164.pObj) = (& ((Wrd169.pObj) [(Wrd162.Lng)]));
  ((Wrd164.pObj) [1]) = (Wrd149.Obj);

DEFLABEL (label_174)
  (Wrd150.Obj) = (Rsp [0]);
  (Rsp [1]) = (Wrd150.Obj);
  (Wrd154.Obj) = (Rsp [2]);
  (Wrd155.uLng) = (OBJECT_TYPE (Wrd154.Obj));
  if (! ((Wrd155.uLng) == 1))
    goto label_173;
  (Wrd153.pObj) = (OBJECT_ADDRESS (Wrd154.Obj));
  (Wrd151.Obj) = ((Wrd153.pObj) [1]);

DEFLABEL (label_172)
  (Rsp [2]) = (Wrd151.Obj);
  Rsp = (& (Rsp [1]));
  goto loop_40;

DEFLABEL (label_173)
  (Wrd159.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_49]))));
  (* (--Rsp)) = (Wrd159.Obj);
  (* (--Rsp)) = (Wrd154.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_11]), 1);

DEFLABEL (label_103)
  (Wrd151.Obj) = Rvl;
  goto label_172;

DEFLABEL (label_175)
  (Wrd174.Obj) = (Rsp [1]);
  (Wrd178.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_48]))));
  (* (--Rsp)) = (Wrd178.Obj);
  (* (--Rsp)) = (Wrd149.Obj);
  (* (--Rsp)) = (Wrd174.Obj);
  (* (--Rsp)) = (Wrd125.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_8]), 3);

DEFLABEL (label_104)
  goto label_174;

DEFLABEL (label_177)
  (Wrd143.Obj) = (Rsp [4]);
  (Wrd144.pObj) = (OBJECT_ADDRESS (Wrd143.Obj));
  (Wrd142.Obj) = ((Wrd144.pObj) [2]);
  (Wrd145.Obj) = (current_block [OBJECT_39_9]);
  (Wrd148.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_47]))));
  (* (--Rsp)) = (Wrd148.Obj);
  (* (--Rsp)) = (Wrd145.Obj);
  (* (--Rsp)) = (Wrd142.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_102)
  (Wrd125.Obj) = Rvl;
  goto label_176;

DEFLABEL (label_179)
  (Wrd121.Obj) = (Rsp [0]);
  (Wrd124.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_46]))));
  (* (--Rsp)) = (Wrd124.Obj);
  (* (--Rsp)) = (Wrd121.Obj);
  (* (--Rsp)) = (Wrd83.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_2]), 2);

DEFLABEL (label_101)
  (* (--Rsp)) = Rvl;
  goto label_178;

DEFLABEL (label_181)
  (Wrd101.Obj) = (Rsp [3]);
  (Wrd102.pObj) = (OBJECT_ADDRESS (Wrd101.Obj));
  (Wrd100.Obj) = ((Wrd102.pObj) [2]);
  (Wrd103.Obj) = (current_block [OBJECT_39_9]);
  (Wrd106.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_45]))));
  (* (--Rsp)) = (Wrd106.Obj);
  (* (--Rsp)) = (Wrd103.Obj);
  (* (--Rsp)) = (Wrd100.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_100)
  (Wrd83.Obj) = Rvl;
  goto label_180;

DEFLABEL (label_183)
  (Wrd192.Obj) = (Rsp [1]);
  (Wrd196.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_44]))));
  (* (--Rsp)) = (Wrd196.Obj);
  (* (--Rsp)) = (Wrd82.Obj);
  (* (--Rsp)) = (Wrd192.Obj);
  (* (--Rsp)) = (Wrd58.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_8]), 3);

DEFLABEL (label_105)
  goto label_182;

DEFLABEL (label_185)
  (Wrd76.Obj) = (Rsp [4]);
  (Wrd77.pObj) = (OBJECT_ADDRESS (Wrd76.Obj));
  (Wrd75.Obj) = ((Wrd77.pObj) [2]);
  (Wrd78.Obj) = (current_block [OBJECT_39_0]);
  (Wrd81.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_43]))));
  (* (--Rsp)) = (Wrd81.Obj);
  (* (--Rsp)) = (Wrd78.Obj);
  (* (--Rsp)) = (Wrd75.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_99)
  (Wrd58.Obj) = Rvl;
  goto label_184;

DEFLABEL (label_187)
  (Wrd54.Obj) = (Rsp [0]);
  (Wrd57.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_42]))));
  (* (--Rsp)) = (Wrd57.Obj);
  (* (--Rsp)) = (Wrd54.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_2]), 2);

DEFLABEL (label_98)
  (* (--Rsp)) = Rvl;
  goto label_186;

DEFLABEL (label_189)
  (Wrd34.Obj) = (Rsp [3]);
  (Wrd35.pObj) = (OBJECT_ADDRESS (Wrd34.Obj));
  (Wrd33.Obj) = ((Wrd35.pObj) [2]);
  (Wrd36.Obj) = (current_block [OBJECT_39_0]);
  (Wrd39.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_41]))));
  (* (--Rsp)) = (Wrd39.Obj);
  (* (--Rsp)) = (Wrd36.Obj);
  (* (--Rsp)) = (Wrd33.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_97)
  (Wrd16.Obj) = Rvl;
  goto label_188;

DEFLABEL (label_191)
  (Wrd15.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_40]))));
  (* (--Rsp)) = (Wrd15.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_10]), 1);

DEFLABEL (label_96)
  (* (--Rsp)) = Rvl;
  goto label_190;

DEFLABEL (label_192)
  (Wrd210.Obj) = (Rsp [2]);
  (Wrd211.pObj) = (OBJECT_ADDRESS (Wrd210.Obj));
  (Wrd212.Obj) = ((Wrd211.pObj) [2]);
  (Wrd213.uLng) = (OBJECT_TYPE (Wrd212.Obj));
  if (! ((Wrd213.uLng) == 62))
    goto label_200;
  (Wrd207.pObj) = (OBJECT_ADDRESS (Wrd212.Obj));
  (Wrd208.Obj) = ((Wrd207.pObj) [0]);
  (Wrd209.Lng) = (FIXNUM_TO_LONG (Wrd208.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd209.Lng))))
    goto label_200;
  (Wrd197.Obj) = ((Wrd207.pObj) [6]);

DEFLABEL (label_199)
  (Wrd278.uLng) = (OBJECT_TYPE (Wrd197.Obj));
  if (! ((Wrd278.uLng) == 10))
    goto label_198;
  (Wrd271.Obj) = (Rsp [0]);
  (Wrd272.uLng) = (OBJECT_TYPE (Wrd271.Obj));
  if (! ((Wrd272.uLng) == 26))
    goto label_198;
  (Wrd274.Lng) = (FIXNUM_TO_LONG (Wrd271.Obj));
  (Wrd275.pObj) = (OBJECT_ADDRESS (Wrd197.Obj));
  (Wrd276.Obj) = ((Wrd275.pObj) [0]);
  (Wrd277.Lng) = (FIXNUM_TO_LONG (Wrd276.Obj));
  if (! (((unsigned long) (Wrd274.Lng)) < ((unsigned long) (Wrd277.Lng))))
    goto label_198;
  (Wrd267.uLng) = (OBJECT_DATUM (Wrd271.Obj));
  (Wrd269.pObj) = (& ((Wrd275.pObj) [(Wrd267.Lng)]));
  ((Wrd269.pObj) [1]) = ((SCHEME_OBJECT) 0);

DEFLABEL (label_197)
  (Wrd234.Obj) = (Rsp [2]);
  (Wrd235.pObj) = (OBJECT_ADDRESS (Wrd234.Obj));
  (Wrd236.Obj) = ((Wrd235.pObj) [2]);
  (Wrd237.uLng) = (OBJECT_TYPE (Wrd236.Obj));
  if (! ((Wrd237.uLng) == 62))
    goto label_196;
  (Wrd231.pObj) = (OBJECT_ADDRESS (Wrd236.Obj));
  (Wrd232.Obj) = ((Wrd231.pObj) [0]);
  (Wrd233.Lng) = (FIXNUM_TO_LONG (Wrd232.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd233.Lng))))
    goto label_196;
  (Wrd221.Obj) = ((Wrd231.pObj) [7]);

DEFLABEL (label_195)
  (Wrd259.uLng) = (OBJECT_TYPE (Wrd221.Obj));
  if (! ((Wrd259.uLng) == 10))
    goto label_194;
  (Wrd252.Obj) = (Rsp [0]);
  (Wrd253.uLng) = (OBJECT_TYPE (Wrd252.Obj));
  if (! ((Wrd253.uLng) == 26))
    goto label_194;
  (Wrd255.Lng) = (FIXNUM_TO_LONG (Wrd252.Obj));
  (Wrd256.pObj) = (OBJECT_ADDRESS (Wrd221.Obj));
  (Wrd257.Obj) = ((Wrd256.pObj) [0]);
  (Wrd258.Lng) = (FIXNUM_TO_LONG (Wrd257.Obj));
  if (! (((unsigned long) (Wrd255.Lng)) < ((unsigned long) (Wrd258.Lng))))
    goto label_194;
  (Wrd248.uLng) = (OBJECT_DATUM (Wrd252.Obj));
  (Wrd250.pObj) = (& ((Wrd256.pObj) [(Wrd248.Lng)]));
  ((Wrd250.pObj) [1]) = ((SCHEME_OBJECT) 0);

DEFLABEL (label_193)
  Rvl = (Rsp [0]);
  Rsp = (& (Rsp [3]));
  goto pop_return;

DEFLABEL (label_194)
  (Wrd261.Obj) = (Rsp [0]);
  (Wrd265.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_39]))));
  (* (--Rsp)) = (Wrd265.Obj);
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  (* (--Rsp)) = (Wrd261.Obj);
  (* (--Rsp)) = (Wrd221.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_8]), 3);

DEFLABEL (label_108)
  goto label_193;

DEFLABEL (label_196)
  (Wrd239.Obj) = (Rsp [2]);
  (Wrd240.pObj) = (OBJECT_ADDRESS (Wrd239.Obj));
  (Wrd238.Obj) = ((Wrd240.pObj) [2]);
  (Wrd241.Obj) = (current_block [OBJECT_39_9]);
  (Wrd244.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_38]))));
  (* (--Rsp)) = (Wrd244.Obj);
  (* (--Rsp)) = (Wrd241.Obj);
  (* (--Rsp)) = (Wrd238.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_107)
  (Wrd221.Obj) = Rvl;
  goto label_195;

DEFLABEL (label_198)
  (Wrd280.Obj) = (Rsp [0]);
  (Wrd284.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_37]))));
  (* (--Rsp)) = (Wrd284.Obj);
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  (* (--Rsp)) = (Wrd280.Obj);
  (* (--Rsp)) = (Wrd197.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_8]), 3);

DEFLABEL (label_109)
  goto label_197;

DEFLABEL (label_200)
  (Wrd215.Obj) = (Rsp [2]);
  (Wrd216.pObj) = (OBJECT_ADDRESS (Wrd215.Obj));
  (Wrd214.Obj) = ((Wrd216.pObj) [2]);
  (Wrd217.Obj) = (current_block [OBJECT_39_0]);
  (Wrd220.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_39_36]))));
  (* (--Rsp)) = (Wrd220.Obj);
  (* (--Rsp)) = (Wrd217.Obj);
  (* (--Rsp)) = (Wrd214.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_39_1]), 2);

DEFLABEL (label_106)
  (Wrd197.Obj) = Rvl;
  goto label_199;

INVOKE_INTERFACE_TARGET_0
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_40_4 3
#define LABEL_40_5 5
#define LABEL_40_7 7
#define LABEL_40_10 9
#define LABEL_40_9 11
#define LABEL_40_12 13
#define LABEL_40_15 15
#define LABEL_40_16 17
#define LABEL_40_14 19
#define LABEL_40_17 21
#define LABEL_40_18 23
#define LABEL_40_19 25
#define LABEL_40_20 27
#define LABEL_40_13 29
#define LABEL_40_22 31
#define ENVIRONMENT_LABEL_40_3 47
#define DEBUGGING_LABEL_40_2 46
#define OBJECT_40_4 45
#define OBJECT_40_3 44
#define OBJECT_40_2 43
#define OBJECT_40_1 42
#define OBJECT_40_0 41
#define EXECUTE_CACHE_40_21 33
#define EXECUTE_CACHE_40_11 35
#define EXECUTE_CACHE_40_8 37
#define EXECUTE_CACHE_40_6 39
#define FREE_REFERENCES_LABEL_40_0 32
#define NUMBER_OF_LINKER_SECTIONS_40_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_40 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd6;
  machine_word Wrd50;
  machine_word Wrd49;
  machine_word Wrd44;
  machine_word Wrd43;
  machine_word Wrd45;
  machine_word Wrd42;
  machine_word Wrd34;
  machine_word Wrd36;
  machine_word Wrd38;
  machine_word Wrd37;
  machine_word Wrd33;
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd29;
  machine_word Wrd28;
  machine_word Wrd22;
  machine_word Wrd24;
  machine_word Wrd21;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd5;
  machine_word Wrd23;
  machine_word Wrd20;
  machine_word Wrd19;
  machine_word Wrd16;
  machine_word Wrd15;
  machine_word Wrd14;
  machine_word Wrd18;
  machine_word Wrd17;
  machine_word Wrd10;
  machine_word Wrd9;
  machine_word Wrd8;
  machine_word Wrd7;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_40_4);
      goto purge_cache_entries_17;

    case 1:
      current_block = (Rpc - LABEL_40_5);
      goto continuation_0;

    case 2:
      current_block = (Rpc - LABEL_40_7);
      goto continuation_3;

    case 3:
      current_block = (Rpc - LABEL_40_10);
      goto label_19;

    case 4:
      current_block = (Rpc - LABEL_40_9);
      goto continuation_2;

    case 5:
      current_block = (Rpc - LABEL_40_12);
      goto loop_15;

    case 6:
      current_block = (Rpc - LABEL_40_15);
      goto label_20;

    case 7:
      current_block = (Rpc - LABEL_40_16);
      goto label_21;

    case 8:
      current_block = (Rpc - LABEL_40_14);
      goto continuation_8;

    case 9:
      current_block = (Rpc - LABEL_40_17);
      goto label_23;

    case 10:
      current_block = (Rpc - LABEL_40_18);
      goto label_24;

    case 11:
      current_block = (Rpc - LABEL_40_19);
      goto label_25;

    case 12:
      current_block = (Rpc - LABEL_40_20);
      goto label_26;

    case 13:
      current_block = (Rpc - LABEL_40_13);
      goto continuation_9;

    case 14:
      current_block = (Rpc - LABEL_40_22);
      goto label_22;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (purge_cache_entries_28)
DEFLABEL (purge_cache_entries_17)
  INTERRUPT_CHECK (26, LABEL_40_4);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_5]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd8.Obj);
  (Wrd9.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd9.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_40_6]));

DEFLABEL (continuation_0)
  INTERRUPT_CHECK (27, LABEL_40_5);
  if (! (Rvl == ((SCHEME_OBJECT) 0)))
    goto label_30;
  Rvl = (Rsp [0]);
  Rsp = (& (Rsp [2]));
  goto pop_return;

DEFLABEL (label_30)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_7]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd10.Obj) = (Rsp [1]);
  (* (--Rsp)) = (Wrd10.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_40_8]));

DEFLABEL (continuation_3)
  INTERRUPT_CHECK (27, LABEL_40_7);
  (* (--Rsp)) = Rvl;
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_9]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd17.Obj) = (Rsp [2]);
  (Wrd18.uLng) = (OBJECT_TYPE (Wrd17.Obj));
  if (! ((Wrd18.uLng) == 62))
    goto label_32;
  (Wrd14.pObj) = (OBJECT_ADDRESS (Wrd17.Obj));
  (Wrd15.Obj) = ((Wrd14.pObj) [0]);
  (Wrd16.Lng) = (FIXNUM_TO_LONG (Wrd15.Obj));
  if (! (((unsigned long) 4L) < ((unsigned long) (Wrd16.Lng))))
    goto label_32;
  (Wrd10.Obj) = ((Wrd14.pObj) [5]);
  (* (--Rsp)) = (Wrd10.Obj);

DEFLABEL (label_31)
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_40_11]));

DEFLABEL (continuation_2)
  INTERRUPT_CHECK (27, LABEL_40_9);
  (* (--Rsp)) = Rvl;
  goto loop_15;

DEFLABEL (label_32)
  (Wrd19.Obj) = (Rsp [2]);
  (Wrd20.Obj) = (current_block [OBJECT_40_0]);
  (Wrd23.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_10]))));
  (* (--Rsp)) = (Wrd23.Obj);
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_1]), 2);

DEFLABEL (label_19)
  (* (--Rsp)) = Rvl;
  goto label_31;

DEFLABEL (loop_29)
DEFLABEL (loop_15)
  INTERRUPT_CHECK (26, LABEL_40_12);
  (Wrd5.Obj) = (Rsp [1]);
  if (! ((Wrd5.Obj) == (current_block [OBJECT_40_2])))
    goto label_33;
  Rvl = (Rsp [0]);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_33)
  (Wrd9.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_13]))));
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd12.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_14]))));
  (* (--Rsp)) = (Wrd12.Obj);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd17.uLng) == 1))
    goto label_49;
  (Wrd15.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd13.Obj) = ((Wrd15.pObj) [0]);

DEFLABEL (label_48)
  (Wrd24.uLng) = (OBJECT_TYPE (Wrd13.Obj));
  if (! ((Wrd24.uLng) == 1))
    goto label_47;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd13.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (* (--Rsp)) = (Wrd23.Obj);

DEFLABEL (label_46)
  (Wrd29.Obj) = (Rsp [6]);
  (* (--Rsp)) = (Wrd29.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (continuation_8)
  INTERRUPT_CHECK (27, LABEL_40_14);
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_37;
  (Wrd5.Obj) = (Rsp [1]);
  Rsp = (& (Rsp [1]));

DEFLABEL (label_36)
  (Rsp [0]) = (Wrd5.Obj);
  (Wrd9.Obj) = (Rsp [1]);
  (Wrd10.uLng) = (OBJECT_TYPE (Wrd9.Obj));
  if (! ((Wrd10.uLng) == 1))
    goto label_35;
  (Wrd8.pObj) = (OBJECT_ADDRESS (Wrd9.Obj));
  (Wrd6.Obj) = ((Wrd8.pObj) [1]);

DEFLABEL (label_34)
  (Rsp [1]) = (Wrd6.Obj);
  goto loop_15;

DEFLABEL (label_35)
  (Wrd14.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_22]))));
  (* (--Rsp)) = (Wrd14.Obj);
  (* (--Rsp)) = (Wrd9.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_4]), 1);

DEFLABEL (label_22)
  (Wrd6.Obj) = Rvl;
  goto label_34;

DEFLABEL (label_37)
  (Wrd21.Obj) = (Rsp [2]);
  (Wrd22.uLng) = (OBJECT_TYPE (Wrd21.Obj));
  if (! ((Wrd22.uLng) == 1))
    goto label_45;
  (Wrd20.pObj) = (OBJECT_ADDRESS (Wrd21.Obj));
  (Wrd18.Obj) = ((Wrd20.pObj) [0]);

DEFLABEL (label_44)
  (Wrd29.uLng) = (OBJECT_TYPE (Wrd18.Obj));
  if (! ((Wrd29.uLng) == 1))
    goto label_43;
  (Wrd27.pObj) = (OBJECT_ADDRESS (Wrd18.Obj));
  (Wrd28.Obj) = ((Wrd27.pObj) [1]);
  (* (--Rsp)) = (Wrd28.Obj);

DEFLABEL (label_42)
  (Wrd37.Obj) = (Rsp [3]);
  (Wrd38.uLng) = (OBJECT_TYPE (Wrd37.Obj));
  if (! ((Wrd38.uLng) == 1))
    goto label_41;
  (Wrd36.pObj) = (OBJECT_ADDRESS (Wrd37.Obj));
  (Wrd34.Obj) = ((Wrd36.pObj) [0]);

DEFLABEL (label_40)
  (Wrd45.uLng) = (OBJECT_TYPE (Wrd34.Obj));
  if (! ((Wrd45.uLng) == 1))
    goto label_39;
  (Wrd43.pObj) = (OBJECT_ADDRESS (Wrd34.Obj));
  (Wrd44.Obj) = ((Wrd43.pObj) [0]);
  (* (--Rsp)) = (Wrd44.Obj);

DEFLABEL (label_38)
  (Wrd50.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd50.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_40_21]));

DEFLABEL (continuation_9)
  INTERRUPT_CHECK (27, LABEL_40_13);
  (Wrd5.Obj) = Rvl;
  goto label_36;

DEFLABEL (label_39)
  (Wrd49.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_20]))));
  (* (--Rsp)) = (Wrd49.Obj);
  (* (--Rsp)) = (Wrd34.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_3]), 1);

DEFLABEL (label_26)
  (* (--Rsp)) = Rvl;
  goto label_38;

DEFLABEL (label_41)
  (Wrd42.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_19]))));
  (* (--Rsp)) = (Wrd42.Obj);
  (* (--Rsp)) = (Wrd37.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_3]), 1);

DEFLABEL (label_25)
  (Wrd34.Obj) = Rvl;
  goto label_40;

DEFLABEL (label_43)
  (Wrd33.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_18]))));
  (* (--Rsp)) = (Wrd33.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_4]), 1);

DEFLABEL (label_24)
  (* (--Rsp)) = Rvl;
  goto label_42;

DEFLABEL (label_45)
  (Wrd26.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_17]))));
  (* (--Rsp)) = (Wrd26.Obj);
  (* (--Rsp)) = (Wrd21.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_3]), 1);

DEFLABEL (label_23)
  (Wrd18.Obj) = Rvl;
  goto label_44;

DEFLABEL (label_47)
  (Wrd28.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_16]))));
  (* (--Rsp)) = (Wrd28.Obj);
  (* (--Rsp)) = (Wrd13.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_3]), 1);

DEFLABEL (label_21)
  (* (--Rsp)) = Rvl;
  goto label_46;

DEFLABEL (label_49)
  (Wrd21.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_40_15]))));
  (* (--Rsp)) = (Wrd21.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_40_3]), 1);

DEFLABEL (label_20)
  (Wrd13.Obj) = Rvl;
  goto label_48;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_41_4 3
#define LABEL_41_5 5
#define LABEL_41_6 7
#define LABEL_41_7 9
#define LABEL_41_8 11
#define LABEL_41_9 13
#define LABEL_41_10 15
#define LABEL_41_11 17
#define ENVIRONMENT_LABEL_41_3 27
#define DEBUGGING_LABEL_41_2 26
#define OBJECT_41_4 25
#define OBJECT_41_3 24
#define OBJECT_41_2 23
#define OBJECT_41_1 22
#define OBJECT_41_0 21
#define EXECUTE_CACHE_41_12 19
#define FREE_REFERENCES_LABEL_41_0 18
#define NUMBER_OF_LINKER_SECTIONS_41_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_41 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd10;
  machine_word Wrd57;
  machine_word Wrd54;
  machine_word Wrd47;
  machine_word Wrd50;
  machine_word Wrd49;
  machine_word Wrd48;
  machine_word Wrd45;
  machine_word Wrd44;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd37;
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd31;
  machine_word Wrd28;
  machine_word Wrd35;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd7;
  machine_word Wrd6;
  machine_word Wrd30;
  machine_word Wrd29;
  machine_word Wrd24;
  machine_word Wrd23;
  machine_word Wrd22;
  machine_word Wrd25;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_41_4);
      goto there_exists_a_cache_entryP_16;

    case 1:
      current_block = (Rpc - LABEL_41_5);
      goto label_18;

    case 2:
      current_block = (Rpc - LABEL_41_6);
      goto label_19;

    case 3:
      current_block = (Rpc - LABEL_41_7);
      goto loop_13;

    case 4:
      current_block = (Rpc - LABEL_41_8);
      goto label_20;

    case 5:
      current_block = (Rpc - LABEL_41_9);
      goto label_21;

    case 6:
      current_block = (Rpc - LABEL_41_10);
      goto continuation_8;

    case 7:
      current_block = (Rpc - LABEL_41_11);
      goto continuation_7;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (there_exists_a_cache_entryP_23)
DEFLABEL (there_exists_a_cache_entryP_16)
  INTERRUPT_CHECK (26, LABEL_41_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_28;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_28;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_27)
  (Wrd25.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd25.uLng) == 10))
    goto label_26;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Obj) = (MAKE_OBJECT (26, (Wrd23.uLng)));
  (* (--Rsp)) = (Wrd24.Obj);

DEFLABEL (label_25)
  (Wrd30.Obj) = (current_block [OBJECT_41_3]);
  (* (--Rsp)) = (Wrd30.Obj);
  goto loop_13;

DEFLABEL (label_26)
  (Wrd29.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_41_6]))));
  (* (--Rsp)) = (Wrd29.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_41_2]), 1);

DEFLABEL (label_19)
  (* (--Rsp)) = Rvl;
  goto label_25;

DEFLABEL (label_28)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_41_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_41_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_41_1]), 2);

DEFLABEL (label_18)
  (Wrd5.Obj) = Rvl;
  goto label_27;

DEFLABEL (loop_24)
DEFLABEL (loop_13)
  INTERRUPT_CHECK (26, LABEL_41_7);
  (Wrd5.Obj) = (Rsp [0]);
  (Wrd6.Obj) = (Rsp [1]);
  if (! ((Wrd5.Obj) == (Wrd6.Obj)))
    goto label_29;
  Rvl = ((SCHEME_OBJECT) 0);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_29)
  (Wrd16.Obj) = (Rsp [2]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_36;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_36;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_35)
  (Wrd35.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd35.uLng) == 10))
    goto label_34;
  (Wrd28.Obj) = (Rsp [0]);
  (Wrd29.uLng) = (OBJECT_TYPE (Wrd28.Obj));
  if (! ((Wrd29.uLng) == 26))
    goto label_34;
  (Wrd31.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  (Wrd32.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd33.Obj) = ((Wrd32.pObj) [0]);
  (Wrd34.Lng) = (FIXNUM_TO_LONG (Wrd33.Obj));
  if (! (((unsigned long) (Wrd31.Lng)) < ((unsigned long) (Wrd34.Lng))))
    goto label_34;
  (Wrd24.uLng) = (OBJECT_DATUM (Wrd28.Obj));
  (Wrd26.pObj) = (& ((Wrd32.pObj) [(Wrd24.Lng)]));
  (Wrd27.Obj) = ((Wrd26.pObj) [1]);
  (* (--Rsp)) = (Wrd27.Obj);

DEFLABEL (label_33)
  (Wrd41.Obj) = (Rsp [0]);
  if (! ((Wrd41.Obj) == ((SCHEME_OBJECT) 0)))
    goto label_31;

DEFLABEL (label_30)
  (Wrd48.Obj) = (Rsp [1]);
  (Wrd49.Lng) = (FIXNUM_TO_LONG (Wrd48.Obj));
  (Wrd50.Lng) = ((Wrd49.Lng) + 1L);
  (Wrd47.Obj) = (LONG_TO_FIXNUM (Wrd50.Lng));
  (Rsp [1]) = (Wrd47.Obj);
  Rsp = (& (Rsp [1]));
  goto loop_13;

DEFLABEL (label_31)
  (Wrd44.pObj) = (OBJECT_ADDRESS (Wrd41.Obj));
  (Wrd45.Obj) = ((Wrd44.pObj) [0]);
  if ((Wrd45.Obj) == ((SCHEME_OBJECT) 0))
    goto label_30;
  (Wrd54.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_41_10]))));
  (* (--Rsp)) = (Wrd54.Obj);
  (Wrd57.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_41_11]))));
  (* (--Rsp)) = (Wrd57.Obj);
  (* (--Rsp)) = (Wrd41.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_41_12]));

DEFLABEL (continuation_7)
  INTERRUPT_CHECK (27, LABEL_41_11);
  (* (--Rsp)) = Rvl;
  (Wrd5.Obj) = (Rsp [6]);
  (* (--Rsp)) = (Wrd5.Obj);
  {
    SCHEME_OBJECT procedure = (* (Rsp++));
    INVOKE_INTERFACE_2 (20, procedure, 2);
  }

DEFLABEL (continuation_8)
  INTERRUPT_CHECK (27, LABEL_41_10);
  (Rsp [0]) = Rvl;
  if (Rvl == ((SCHEME_OBJECT) 0))
    goto label_32;
  Rvl = Rvl;
  Rsp = (& (Rsp [5]));
  goto pop_return;

DEFLABEL (label_32)
  (Wrd11.Obj) = (Rsp [1]);
  (Wrd12.Lng) = (FIXNUM_TO_LONG (Wrd11.Obj));
  (Wrd13.Lng) = ((Wrd12.Lng) + 1L);
  (Wrd10.Obj) = (LONG_TO_FIXNUM (Wrd13.Lng));
  (Rsp [1]) = (Wrd10.Obj);
  Rsp = (& (Rsp [1]));
  goto loop_13;

DEFLABEL (label_34)
  (Wrd37.Obj) = (Rsp [0]);
  (Wrd40.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_41_9]))));
  (* (--Rsp)) = (Wrd40.Obj);
  (* (--Rsp)) = (Wrd37.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_41_4]), 2);

DEFLABEL (label_21)
  (* (--Rsp)) = Rvl;
  goto label_33;

DEFLABEL (label_36)
  (Wrd18.Obj) = (Rsp [2]);
  (Wrd19.Obj) = (current_block [OBJECT_41_0]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_41_8]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_41_1]), 2);

DEFLABEL (label_20)
  (Wrd7.Obj) = Rvl;
  goto label_35;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_42_4 3
#define LABEL_42_5 5
#define LABEL_42_6 7
#define LABEL_42_7 9
#define LABEL_42_8 11
#define LABEL_42_9 13
#define LABEL_42_10 15
#define LABEL_42_11 17
#define LABEL_42_12 19
#define ENVIRONMENT_LABEL_42_3 31
#define DEBUGGING_LABEL_42_2 30
#define OBJECT_42_6 29
#define OBJECT_42_5 28
#define OBJECT_42_4 27
#define OBJECT_42_3 26
#define OBJECT_42_2 25
#define OBJECT_42_1 24
#define OBJECT_42_0 23
#define EXECUTE_CACHE_42_13 21
#define FREE_REFERENCES_LABEL_42_0 20
#define NUMBER_OF_LINKER_SECTIONS_42_1 1

#ifndef WANT_ONLY_DATA

static SCHEME_OBJECT *
gencache_so_code_42 (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd90;
  machine_word Wrd89;
  machine_word Wrd86;
  machine_word Wrd83;
  machine_word Wrd73;
  machine_word Wrd72;
  machine_word Wrd70;
  machine_word Wrd80;
  machine_word Wrd79;
  machine_word Wrd78;
  machine_word Wrd77;
  machine_word Wrd75;
  machine_word Wrd74;
  machine_word Wrd81;
  machine_word Wrd68;
  machine_word Wrd65;
  machine_word Wrd64;
  machine_word Wrd53;
  machine_word Wrd61;
  machine_word Wrd60;
  machine_word Wrd59;
  machine_word Wrd63;
  machine_word Wrd62;
  machine_word Wrd49;
  machine_word Wrd52;
  machine_word Wrd51;
  machine_word Wrd50;
  machine_word Wrd45;
  machine_word Wrd44;
  machine_word Wrd41;
  machine_word Wrd40;
  machine_word Wrd37;
  machine_word Wrd27;
  machine_word Wrd26;
  machine_word Wrd34;
  machine_word Wrd33;
  machine_word Wrd32;
  machine_word Wrd28;
  machine_word Wrd35;
  machine_word Wrd19;
  machine_word Wrd18;
  machine_word Wrd7;
  machine_word Wrd6;
  machine_word Wrd48;
  machine_word Wrd100;
  machine_word Wrd101;
  machine_word Wrd95;
  machine_word Wrd97;
  machine_word Wrd93;
  machine_word Wrd31;
  machine_word Wrd30;
  machine_word Wrd29;
  machine_word Wrd24;
  machine_word Wrd23;
  machine_word Wrd22;
  machine_word Wrd25;
  machine_word Wrd20;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd5;
  machine_word Wrd13;
  machine_word Wrd12;
  machine_word Wrd11;
  machine_word Wrd15;
  machine_word Wrd14;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_42_4);
      goto cache__alist_17;

    case 1:
      current_block = (Rpc - LABEL_42_5);
      goto label_19;

    case 2:
      current_block = (Rpc - LABEL_42_6);
      goto label_20;

    case 3:
      current_block = (Rpc - LABEL_42_7);
      goto continuation_9;

    case 4:
      current_block = (Rpc - LABEL_42_8);
      goto do_loop_14;

    case 5:
      current_block = (Rpc - LABEL_42_9);
      goto label_21;

    case 6:
      current_block = (Rpc - LABEL_42_10);
      goto label_22;

    case 7:
      current_block = (Rpc - LABEL_42_11);
      goto label_23;

    case 8:
      current_block = (Rpc - LABEL_42_12);
      goto label_24;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (cache__alist_26)
DEFLABEL (cache__alist_17)
  INTERRUPT_CHECK (26, LABEL_42_4);
  (Wrd14.Obj) = (Rsp [0]);
  (Wrd15.uLng) = (OBJECT_TYPE (Wrd14.Obj));
  if (! ((Wrd15.uLng) == 62))
    goto label_31;
  (Wrd11.pObj) = (OBJECT_ADDRESS (Wrd14.Obj));
  (Wrd12.Obj) = ((Wrd11.pObj) [0]);
  (Wrd13.Lng) = (FIXNUM_TO_LONG (Wrd12.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd13.Lng))))
    goto label_31;
  (Wrd5.Obj) = ((Wrd11.pObj) [6]);

DEFLABEL (label_30)
  (Wrd25.uLng) = (OBJECT_TYPE (Wrd5.Obj));
  if (! ((Wrd25.uLng) == 10))
    goto label_29;
  (Wrd22.pObj) = (OBJECT_ADDRESS (Wrd5.Obj));
  (Wrd23.Obj) = ((Wrd22.pObj) [0]);
  (Wrd24.Obj) = (MAKE_OBJECT (26, (Wrd23.uLng)));
  (* (--Rsp)) = (Wrd24.Obj);

DEFLABEL (label_28)
  (Wrd30.Obj) = (current_block [OBJECT_42_3]);
  (* (--Rsp)) = (Wrd30.Obj);
  (Wrd31.Obj) = (current_block [OBJECT_42_4]);
  (* (--Rsp)) = (Wrd31.Obj);
  goto do_loop_14;

DEFLABEL (label_29)
  (Wrd29.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_42_6]))));
  (* (--Rsp)) = (Wrd29.Obj);
  (* (--Rsp)) = (Wrd5.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_42_2]), 1);

DEFLABEL (label_20)
  (* (--Rsp)) = Rvl;
  goto label_28;

DEFLABEL (label_31)
  (Wrd16.Obj) = (Rsp [0]);
  (Wrd17.Obj) = (current_block [OBJECT_42_0]);
  (Wrd20.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_42_5]))));
  (* (--Rsp)) = (Wrd20.Obj);
  (* (--Rsp)) = (Wrd17.Obj);
  (* (--Rsp)) = (Wrd16.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_42_1]), 2);

DEFLABEL (label_19)
  (Wrd5.Obj) = Rvl;
  goto label_30;

DEFLABEL (do_loop_27)
DEFLABEL (do_loop_14)
  INTERRUPT_CHECK (26, LABEL_42_8);
  (Wrd5.Obj) = (Rsp [0]);
  (Wrd6.Obj) = (Rsp [2]);
  if (! ((Wrd5.Obj) == (Wrd6.Obj)))
    goto label_32;
  Rvl = (Rsp [1]);
  Rsp = (& (Rsp [4]));
  goto pop_return;

DEFLABEL (label_32)
  (Wrd16.Obj) = (Rsp [3]);
  (Wrd17.uLng) = (OBJECT_TYPE (Wrd16.Obj));
  if (! ((Wrd17.uLng) == 62))
    goto label_42;
  (Wrd13.pObj) = (OBJECT_ADDRESS (Wrd16.Obj));
  (Wrd14.Obj) = ((Wrd13.pObj) [0]);
  (Wrd15.Lng) = (FIXNUM_TO_LONG (Wrd14.Obj));
  if (! (((unsigned long) 5L) < ((unsigned long) (Wrd15.Lng))))
    goto label_42;
  (Wrd7.Obj) = ((Wrd13.pObj) [6]);

DEFLABEL (label_41)
  (Wrd35.uLng) = (OBJECT_TYPE (Wrd7.Obj));
  if (! ((Wrd35.uLng) == 10))
    goto label_40;
  (Wrd28.Obj) = (Rsp [0]);
  (Wrd29.uLng) = (OBJECT_TYPE (Wrd28.Obj));
  if (! ((Wrd29.uLng) == 26))
    goto label_40;
  (Wrd31.Lng) = (FIXNUM_TO_LONG (Wrd28.Obj));
  (Wrd32.pObj) = (OBJECT_ADDRESS (Wrd7.Obj));
  (Wrd33.Obj) = ((Wrd32.pObj) [0]);
  (Wrd34.Lng) = (FIXNUM_TO_LONG (Wrd33.Obj));
  if (! (((unsigned long) (Wrd31.Lng)) < ((unsigned long) (Wrd34.Lng))))
    goto label_40;
  (Wrd24.uLng) = (OBJECT_DATUM (Wrd28.Obj));
  (Wrd26.pObj) = (& ((Wrd32.pObj) [(Wrd24.Lng)]));
  (Wrd27.Obj) = ((Wrd26.pObj) [1]);
  (* (--Rsp)) = (Wrd27.Obj);

DEFLABEL (label_39)
  (Wrd41.Obj) = (Rsp [0]);
  if ((Wrd41.Obj) == ((SCHEME_OBJECT) 0))
    goto label_38;
  (Wrd44.pObj) = (OBJECT_ADDRESS (Wrd41.Obj));
  (Wrd45.Obj) = ((Wrd44.pObj) [0]);
  if ((Wrd45.Obj) == ((SCHEME_OBJECT) 0))
    goto label_38;
  (Wrd62.Obj) = (Rsp [4]);
  (Wrd63.uLng) = (OBJECT_TYPE (Wrd62.Obj));
  if (! ((Wrd63.uLng) == 62))
    goto label_37;
  (Wrd59.pObj) = (OBJECT_ADDRESS (Wrd62.Obj));
  (Wrd60.Obj) = ((Wrd59.pObj) [0]);
  (Wrd61.Lng) = (FIXNUM_TO_LONG (Wrd60.Obj));
  if (! (((unsigned long) 6L) < ((unsigned long) (Wrd61.Lng))))
    goto label_37;
  (Wrd53.Obj) = ((Wrd59.pObj) [7]);

DEFLABEL (label_36)
  (Wrd81.uLng) = (OBJECT_TYPE (Wrd53.Obj));
  if (! ((Wrd81.uLng) == 10))
    goto label_35;
  (Wrd74.Obj) = (Rsp [1]);
  (Wrd75.uLng) = (OBJECT_TYPE (Wrd74.Obj));
  if (! ((Wrd75.uLng) == 26))
    goto label_35;
  (Wrd77.Lng) = (FIXNUM_TO_LONG (Wrd74.Obj));
  (Wrd78.pObj) = (OBJECT_ADDRESS (Wrd53.Obj));
  (Wrd79.Obj) = ((Wrd78.pObj) [0]);
  (Wrd80.Lng) = (FIXNUM_TO_LONG (Wrd79.Obj));
  if (! (((unsigned long) (Wrd77.Lng)) < ((unsigned long) (Wrd80.Lng))))
    goto label_35;
  (Wrd70.uLng) = (OBJECT_DATUM (Wrd74.Obj));
  (Wrd72.pObj) = (& ((Wrd78.pObj) [(Wrd70.Lng)]));
  (Wrd73.Obj) = ((Wrd72.pObj) [1]);
  (* (--Rsp)) = (Wrd73.Obj);

DEFLABEL (label_34)
  (Wrd89.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_42_7]))));
  (* (--Rsp)) = (Wrd89.Obj);
  (Wrd90.Obj) = (Rsp [2]);
  (* (--Rsp)) = (Wrd90.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [EXECUTE_CACHE_42_13]));

DEFLABEL (continuation_9)
  INTERRUPT_CHECK (27, LABEL_42_7);
  (Wrd93.Obj) = (* (Rsp++));
  (* (Rhp++)) = Rvl;
  (* (Rhp++)) = (Wrd93.Obj);
  (Wrd97.pObj) = (& (Rhp [-2]));
  (Wrd95.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd97.pObj)));
  (Wrd101.Obj) = (Rsp [2]);
  (* (Rhp++)) = (Wrd95.Obj);
  (* (Rhp++)) = (Wrd101.Obj);
  (Wrd100.pObj) = (& (Rhp [-2]));
  (Wrd48.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd100.pObj)));

DEFLABEL (label_33)
  Rsp = (& (Rsp [1]));
  (Rsp [1]) = (Wrd48.Obj);
  (Wrd50.Obj) = (Rsp [0]);
  (Wrd51.Lng) = (FIXNUM_TO_LONG (Wrd50.Obj));
  (Wrd52.Lng) = ((Wrd51.Lng) + 1L);
  (Wrd49.Obj) = (LONG_TO_FIXNUM (Wrd52.Lng));
  (Rsp [0]) = (Wrd49.Obj);
  goto do_loop_14;

DEFLABEL (label_35)
  (Wrd83.Obj) = (Rsp [1]);
  (Wrd86.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_42_12]))));
  (* (--Rsp)) = (Wrd86.Obj);
  (* (--Rsp)) = (Wrd83.Obj);
  (* (--Rsp)) = (Wrd53.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_42_5]), 2);

DEFLABEL (label_24)
  (* (--Rsp)) = Rvl;
  goto label_34;

DEFLABEL (label_37)
  (Wrd64.Obj) = (Rsp [4]);
  (Wrd65.Obj) = (current_block [OBJECT_42_6]);
  (Wrd68.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_42_11]))));
  (* (--Rsp)) = (Wrd68.Obj);
  (* (--Rsp)) = (Wrd65.Obj);
  (* (--Rsp)) = (Wrd64.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_42_1]), 2);

DEFLABEL (label_23)
  (Wrd53.Obj) = Rvl;
  goto label_36;

DEFLABEL (label_38)
  (Wrd48.Obj) = (Rsp [2]);
  goto label_33;

DEFLABEL (label_40)
  (Wrd37.Obj) = (Rsp [0]);
  (Wrd40.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_42_10]))));
  (* (--Rsp)) = (Wrd40.Obj);
  (* (--Rsp)) = (Wrd37.Obj);
  (* (--Rsp)) = (Wrd7.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_42_5]), 2);

DEFLABEL (label_22)
  (* (--Rsp)) = Rvl;
  goto label_39;

DEFLABEL (label_42)
  (Wrd18.Obj) = (Rsp [3]);
  (Wrd19.Obj) = (current_block [OBJECT_42_0]);
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_42_9]))));
  (* (--Rsp)) = (Wrd22.Obj);
  (* (--Rsp)) = (Wrd19.Obj);
  (* (--Rsp)) = (Wrd18.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_42_1]), 2);

DEFLABEL (label_21)
  (Wrd7.Obj) = Rvl;
  goto label_41;

INVOKE_INTERFACE_TARGET_1
INVOKE_PRIMITIVE_TARGET
}

#endif /* !WANT_ONLY_DATA */

#define LABEL_4 3
#define LABEL_9 5
#define LABEL_5 7
#define LABEL_7 9
#define LABEL_8 11
#define LABEL_11 13
#define LABEL_17 15
#define LABEL_13 17
#define TAG_14 7
#define LABEL_15 19
#define LABEL_16 21
#define LABEL_18 23
#define LABEL_19 25
#define LABEL_20 27
#define ENVIRONMENT_LABEL_3 58
#define DEBUGGING_LABEL_2 57
#define PURIFICATION_ROOT 56
#define OBJECT_18 55
#define OBJECT_17 54
#define OBJECT_16 53
#define OBJECT_15 52
#define OBJECT_14 51
#define OBJECT_13 50
#define OBJECT_12 49
#define OBJECT_11 48
#define OBJECT_10 47
#define OBJECT_9 46
#define OBJECT_8 45
#define OBJECT_7 44
#define OBJECT_6 43
#define OBJECT_5 42
#define OBJECT_4 41
#define OBJECT_3 40
#define OBJECT_2 39
#define OBJECT_1 38
#define OBJECT_0 37
#define FREE_REFERENCE_0 29
#define GLOBAL_EXECUTE_CACHE_12 31
#define GLOBAL_EXECUTE_CACHE_10 33
#define GLOBAL_EXECUTE_CACHE_6 35
#define FREE_REFERENCES_LABEL_0 28
#define NUMBER_OF_LINKER_SECTIONS_1 2

#ifndef WANT_ONLY_DATA

SCHEME_OBJECT *
gencache_so_813832bb378a83bd (SCHEME_OBJECT * Rpc, entry_count_t dispatch_base)
{
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES ();
  SCHEME_OBJECT * Rdl ATTRIBUTE((unused));
  machine_word Wrd19;
  machine_word Wrd9;
  machine_word Wrd6;
  machine_word Wrd12;
  machine_word Wrd10;
  machine_word Wrd7;
  machine_word Wrd43;
  machine_word Wrd42;
  machine_word Wrd40;
  machine_word Wrd39;
  machine_word Wrd41;
  machine_word Wrd34;
  machine_word Wrd36;
  machine_word Wrd37;
  machine_word Wrd30;
  machine_word Wrd32;
  machine_word Wrd33;
  machine_word Wrd26;
  machine_word Wrd28;
  machine_word Wrd29;
  machine_word Wrd22;
  machine_word Wrd24;
  machine_word Wrd25;
  machine_word Wrd18;
  machine_word Wrd20;
  machine_word Wrd21;
  machine_word Wrd13;
  machine_word Wrd15;
  machine_word Wrd17;
  machine_word Wrd16;
  machine_word Wrd11;
  machine_word Wrd8;
  machine_word Wrd5;
  INVOKE_INTERFACE_DECLS
  INVOKE_PRIMITIVE_DECLS

  Rdl = (OBJECT_ADDRESS (Rvl));
  goto perform_dispatch;

DEFLABEL (pop_return)
  Rpc = (OBJECT_ADDRESS (* (Rsp++)));

DEFLABEL (perform_dispatch)
  switch ((* ((unsigned long *) Rpc)) - dispatch_base)
    {
    case 0:
      current_block = (Rpc - LABEL_4);
      goto continuation_8;

    case 1:
      current_block = (Rpc - LABEL_9);
      goto label_19;

    case 2:
      current_block = (Rpc - LABEL_5);
      goto continuation_7;

    case 3:
      current_block = (Rpc - LABEL_7);
      goto continuation_13;

    case 4:
      current_block = (Rpc - LABEL_8);
      goto continuation_9;

    case 5:
      current_block = (Rpc - LABEL_11);
      goto continuation_14;

    case 6:
      current_block = (Rpc - LABEL_17);
      goto label_20;

    case 7:
      current_block = (Rpc - LABEL_13);
      goto Z__make_cache_22;

    case 8:
      current_block = (Rpc - LABEL_15);
      goto continuation_16;

    case 9:
      current_block = (Rpc - LABEL_16);
      goto continuation_15;

    case 10:
      current_block = (Rpc - LABEL_18);
      goto label_24;

    case 11:
      current_block = (Rpc - LABEL_19);
      goto label_25;

    case 12:
      current_block = (Rpc - LABEL_20);
      goto expression_18;

    default:
      UNCACHE_VARIABLES ();
      return (Rpc);
    }

DEFLABEL (expression_18)
  (current_block [ENVIRONMENT_LABEL_3]) = (Rrb [REGBLOCK_ENV]);
  INVOKE_INTERFACE_4 (23, (& (current_block [LABEL_19])), current_block, (& (current_block [FREE_REFERENCES_LABEL_0])), NUMBER_OF_LINKER_SECTIONS_1);

DEFLABEL (label_25)
  (* (--Rsp)) = (ULONG_TO_FIXNUM (1UL));

DEFLABEL (label_24)
  {
    static const short sections [] =
      {
	0,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
      };
    unsigned long counter = (OBJECT_DATUM (* Rsp));
    SCHEME_OBJECT blocks;
    SCHEME_OBJECT * sub_block;
    short section;
    if (counter > 42)
      goto label_23;
    blocks = (current_block [OBJECT_18]);
    sub_block = (OBJECT_ADDRESS (MEMORY_REF (blocks, counter)));
    (sub_block [(OBJECT_DATUM (sub_block [0]))]) = (Rrb [REGBLOCK_ENV]);
    section = (sections [counter]);
    (* Rsp) = (ULONG_TO_FIXNUM (counter + 1));
    INVOKE_INTERFACE_4 (23, (& (current_block [LABEL_18])), sub_block, (sub_block + (2 + (OBJECT_DATUM (sub_block [1])))), section);
  }

DEFLABEL (label_23)
  Rsp += 1;
  (Wrd5.Obj) = (Rrb [3]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd8.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_4]))));
  (* (--Rsp)) = (Wrd8.Obj);
  (Wrd11.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_5]))));
  (* (--Rsp)) = (Wrd11.Obj);
  (* (--Rsp)) = ((SCHEME_OBJECT) 0);
  (Wrd16.Obj) = (current_block [OBJECT_0]);
  (Wrd17.Obj) = (current_block [OBJECT_1]);
  (* (Rhp++)) = (Wrd16.Obj);
  (* (Rhp++)) = (Wrd17.Obj);
  (Wrd15.pObj) = (& (Rhp [-2]));
  (Wrd13.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd15.pObj)));
  (Wrd21.Obj) = (current_block [OBJECT_2]);
  (* (Rhp++)) = (Wrd21.Obj);
  (* (Rhp++)) = (Wrd13.Obj);
  (Wrd20.pObj) = (& (Rhp [-2]));
  (Wrd18.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd20.pObj)));
  (Wrd25.Obj) = (current_block [OBJECT_3]);
  (* (Rhp++)) = (Wrd25.Obj);
  (* (Rhp++)) = (Wrd18.Obj);
  (Wrd24.pObj) = (& (Rhp [-2]));
  (Wrd22.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd24.pObj)));
  (Wrd29.Obj) = (current_block [OBJECT_4]);
  (* (Rhp++)) = (Wrd29.Obj);
  (* (Rhp++)) = (Wrd22.Obj);
  (Wrd28.pObj) = (& (Rhp [-2]));
  (Wrd26.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd28.pObj)));
  (Wrd33.Obj) = (current_block [OBJECT_5]);
  (* (Rhp++)) = (Wrd33.Obj);
  (* (Rhp++)) = (Wrd26.Obj);
  (Wrd32.pObj) = (& (Rhp [-2]));
  (Wrd30.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd32.pObj)));
  (Wrd37.Obj) = (current_block [OBJECT_6]);
  (* (Rhp++)) = (Wrd37.Obj);
  (* (Rhp++)) = (Wrd30.Obj);
  (Wrd36.pObj) = (& (Rhp [-2]));
  (Wrd34.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd36.pObj)));
  (Wrd41.Obj) = (current_block [OBJECT_7]);
  (* (Rhp++)) = (Wrd41.Obj);
  (* (Rhp++)) = (Wrd34.Obj);
  (Wrd39.pObj) = (& (Rhp [-2]));
  (Wrd40.Obj) = (MAKE_POINTER_OBJECT (1, (Wrd39.pObj)));
  (* (--Rsp)) = (Wrd40.Obj);
  (Wrd42.Obj) = (current_block [OBJECT_8]);
  (* (--Rsp)) = (Wrd42.Obj);
  (Wrd43.Obj) = (current_block [OBJECT_9]);
  (* (--Rsp)) = (Wrd43.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [GLOBAL_EXECUTE_CACHE_6]));

DEFLABEL (continuation_7)
  INTERRUPT_CHECK (27, LABEL_5);
  (* (--Rsp)) = Rvl;
  (Wrd5.Obj) = (current_block [OBJECT_10]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd6.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_11]), 3);

DEFLABEL (continuation_8)
  INTERRUPT_CHECK (27, LABEL_4);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_7]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd10.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_8]))));
  (* (--Rsp)) = (Wrd10.Obj);
  (Wrd12.pObj) = ((SCHEME_OBJECT *) (current_block [FREE_REFERENCE_0]));
  (Wrd15.Obj) = ((Wrd12.pObj) [0]);
  (Wrd16.uLng) = (OBJECT_TYPE (Wrd15.Obj));
  if ((Wrd16.uLng) == 50)
    goto label_29;
  Wrd11 = Wrd15;

DEFLABEL (label_28)
  (* (--Rsp)) = (Wrd11.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [GLOBAL_EXECUTE_CACHE_10]));

DEFLABEL (continuation_9)
  INTERRUPT_CHECK (27, LABEL_8);
  (* (--Rsp)) = Rvl;
  (* (Rhp++)) = (MAKE_OBJECT (TC_MANIFEST_CLOSURE, 4));
  (Wrd8.pObj) = (Rhp + 1);
  Rhp += 1;
  WRITE_LABEL_DESCRIPTOR (Rhp, 0x808, 2);
  (* (Rhp++)) = (dispatch_base + TAG_14);
  (* (Rhp++)) = ((SCHEME_OBJECT) (& (current_block [LABEL_13])));
  Rhp += 1;
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (Wrd8.pObj)));
  ((Wrd8.pObj) [2]) = Rvl;
  Rsp = (& (Rsp [1]));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd11.Obj) = (current_block [OBJECT_14]);
  (* (--Rsp)) = (Wrd11.Obj);
  (Wrd12.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd12.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_11]), 3);

DEFLABEL (continuation_13)
  INTERRUPT_CHECK (27, LABEL_7);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_11]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd8.Obj) = (current_block [OBJECT_12]);
  (* (--Rsp)) = (Wrd8.Obj);
  (Wrd9.Obj) = (current_block [OBJECT_13]);
  (* (--Rsp)) = (Wrd9.Obj);
  (Wrd10.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd10.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [GLOBAL_EXECUTE_CACHE_12]));

DEFLABEL (continuation_14)
  INTERRUPT_CHECK (27, LABEL_11);
  (Wrd7.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_15]))));
  (* (--Rsp)) = (Wrd7.Obj);
  (Wrd10.Obj) = (MAKE_POINTER_OBJECT (40, (& (current_block [LABEL_16]))));
  (* (--Rsp)) = (Wrd10.Obj);
  (Wrd12.pObj) = ((SCHEME_OBJECT *) (current_block [FREE_REFERENCE_0]));
  (Wrd15.Obj) = ((Wrd12.pObj) [0]);
  (Wrd16.uLng) = (OBJECT_TYPE (Wrd15.Obj));
  if ((Wrd16.uLng) == 50)
    goto label_27;
  Wrd11 = Wrd15;

DEFLABEL (label_26)
  (* (--Rsp)) = (Wrd11.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [GLOBAL_EXECUTE_CACHE_10]));

DEFLABEL (continuation_15)
  INTERRUPT_CHECK (27, LABEL_16);
  (* (--Rsp)) = Rvl;
  (Wrd5.Obj) = (current_block [OBJECT_17]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (Rsp [3]);
  (* (--Rsp)) = (Wrd6.Obj);
  INVOKE_PRIMITIVE ((current_block [OBJECT_11]), 3);

DEFLABEL (continuation_16)
  INTERRUPT_CHECK (27, LABEL_15);
  (Wrd5.Obj) = (current_block [OBJECT_15]);
  (* (--Rsp)) = (Wrd5.Obj);
  (Wrd6.Obj) = (Rsp [1]);
  (* (--Rsp)) = (Wrd6.Obj);
  (Wrd7.Obj) = (current_block [OBJECT_16]);
  (Rsp [2]) = (Wrd7.Obj);
  JUMP ((SCHEME_OBJECT *) (current_block [GLOBAL_EXECUTE_CACHE_12]));

DEFLABEL (label_27)
  INVOKE_INTERFACE_2 (31, (& (current_block [LABEL_17])), (Wrd12.pObj));

DEFLABEL (label_20)
  (Wrd11.Obj) = Rvl;
  goto label_26;

DEFLABEL (label_29)
  INVOKE_INTERFACE_2 (31, (& (current_block [LABEL_9])), (Wrd12.pObj));

DEFLABEL (label_19)
  (Wrd11.Obj) = Rvl;
  goto label_28;

DEFLABEL (Z__make_cache_22)
  CLOSURE_HEADER (LABEL_13);

DEFLABEL (Z__make_cache_11)
  CLOSURE_INTERRUPT_CHECK (24);
  (Wrd16.Obj) = (MAKE_OBJECT (0, 8));
  (Wrd17.Obj) = (Rsp [0]);
  (Wrd18.pObj) = (OBJECT_ADDRESS (Wrd17.Obj));
  (Wrd19.Obj) = ((Wrd18.pObj) [2]);
  (Wrd20.Obj) = (Rsp [1]);
  (Wrd21.Obj) = (Rsp [2]);
  (* (Rhp++)) = (Wrd16.Obj);
  (* (Rhp++)) = (Wrd19.Obj);
  (* (Rhp++)) = (Wrd20.Obj);
  (* (Rhp++)) = (Wrd21.Obj);
  (Wrd10.Obj) = (Rsp [3]);
  (Wrd11.Obj) = (Rsp [4]);
  (Wrd12.Obj) = (Rsp [5]);
  (Wrd13.Obj) = (Rsp [6]);
  (* (Rhp++)) = (Wrd10.Obj);
  (* (Rhp++)) = (Wrd11.Obj);
  (* (Rhp++)) = (Wrd12.Obj);
  (* (Rhp++)) = (Wrd13.Obj);
  (Wrd9.Obj) = (Rsp [7]);
  (* (Rhp++)) = (Wrd9.Obj);
  (Wrd7.pObj) = (& (Rhp [-9]));
  Rvl = (MAKE_POINTER_OBJECT (62, (Wrd7.pObj)));
  Rsp = (& (Rsp [8]));
  goto pop_return;

INVOKE_INTERFACE_TARGET_0
INVOKE_PRIMITIVE_TARGET
}

static const struct liarc_code_S arr_decl_gencache_so_813832bb378a83bd [42] =
  {
    { "gencache_so_code_1", 1, gencache_so_code_1 },
    { "gencache_so_code_2", 1, gencache_so_code_2 },
    { "gencache_so_code_3", 1, gencache_so_code_3 },
    { "gencache_so_code_4", 1, gencache_so_code_4 },
    { "gencache_so_code_5", 1, gencache_so_code_5 },
    { "gencache_so_code_6", 1, gencache_so_code_6 },
    { "gencache_so_code_7", 1, gencache_so_code_7 },
    { "gencache_so_code_8", 1, gencache_so_code_8 },
    { "gencache_so_code_9", 1, gencache_so_code_9 },
    { "gencache_so_code_10", 1, gencache_so_code_10 },
    { "gencache_so_code_11", 1, gencache_so_code_11 },
    { "gencache_so_code_12", 1, gencache_so_code_12 },
    { "gencache_so_code_13", 1, gencache_so_code_13 },
    { "gencache_so_code_14", 1, gencache_so_code_14 },
    { "gencache_so_code_15", 1, gencache_so_code_15 },
    { "gencache_so_code_16", 1, gencache_so_code_16 },
    { "gencache_so_code_17", 4, gencache_so_code_17 },
    { "gencache_so_code_18", 1, gencache_so_code_18 },
    { "gencache_so_code_19", 4, gencache_so_code_19 },
    { "gencache_so_code_20", 2, gencache_so_code_20 },
    { "gencache_so_code_21", 2, gencache_so_code_21 },
    { "gencache_so_code_22", 2, gencache_so_code_22 },
    { "gencache_so_code_23", 2, gencache_so_code_23 },
    { "gencache_so_code_24", 2, gencache_so_code_24 },
    { "gencache_so_code_25", 3, gencache_so_code_25 },
    { "gencache_so_code_26", 3, gencache_so_code_26 },
    { "gencache_so_code_27", 19, gencache_so_code_27 },
    { "gencache_so_code_28", 5, gencache_so_code_28 },
    { "gencache_so_code_29", 2, gencache_so_code_29 },
    { "gencache_so_code_30", 7, gencache_so_code_30 },
    { "gencache_so_code_31", 33, gencache_so_code_31 },
    { "gencache_so_code_32", 59, gencache_so_code_32 },
    { "gencache_so_code_33", 75, gencache_so_code_33 },
    { "gencache_so_code_34", 102, gencache_so_code_34 },
    { "gencache_so_code_35", 9, gencache_so_code_35 },
    { "gencache_so_code_36", 7, gencache_so_code_36 },
    { "gencache_so_code_37", 26, gencache_so_code_37 },
    { "gencache_so_code_38", 40, gencache_so_code_38 },
    { "gencache_so_code_39", 41, gencache_so_code_39 },
    { "gencache_so_code_40", 15, gencache_so_code_40 },
    { "gencache_so_code_41", 8, gencache_so_code_41 },
    { "gencache_so_code_42", 9, gencache_so_code_42 }
  };

int
decl_gencache_so_813832bb378a83bd (void)
{
  DECLARE_SUBCODE_MULTIPLE (arr_decl_gencache_so_813832bb378a83bd);
  return (0);
}

DECLARE_COMPILED_CODE ("gencache.so", 13, decl_gencache_so_813832bb378a83bd, gencache_so_813832bb378a83bd)

#endif /* !WANT_ONLY_DATA */

#ifndef WANT_ONLY_CODE

static const unsigned char prog_gencache_so_data_813832bb378a83bd [6223] =
  "\x81\x02\x3d\x97\x0e\x1d\x0c\xb8\x0d\x1d\xb0\x81\x88\x80\x22\x29"
  "\x21\x9d\x2b\xb9\x1d\xb0\x82\x88\x80\x22\x29\x21\x9d\x2b\xba\x1d"
  "\xb0\x83\x88\x80\x22\x29\x21\x9d\x2b\xbb\x1d\xb0\x84\x88\x80\x22"
  "\x29\x21\x9d\x2b\xbc\x1d\xb0\x85\x88\x17\x22\x29\x21\x9d\x2b\xbd"
  "\x1d\xb0\x86\x88\x17\x22\x29\x21\x9d\x2b\xbe\x1d\xb0\x02\x88\x08"
  "\x22\x29\x21\x9d\x2b\xbf\x1d\xb0\x02\x88\xc2\x1c\x81\x22\x29\x21"
  "\x9e\x2b\x1c\x1d\xb0\x02\x88\x1b\x82\x22\x29\x21\x9e\x2b\x1c\x1d"
  "\xb0\x02\x88\x1b\x83\x22\x29\x21\x9e\x2b\x1c\x1d\xb0\x02\x88\x1b"
  "\x84\x22\x29\x21\x9e\x2b\x1c\x1d\xb0\x02\x88\x1b\x85\x22\x29\x21"
  "\x9e\x2b\x1c\x1d\xb0\x02\x88\x1b\x86\x22\x29\x21\x9e\x2b\x1c\x1d"
  "\xb0\x02\x88\x1b\x02\x22\x29\x21\x9e\x2b\x1c\x1d\xb0\x02\x88\xc3"
  "\x1c\x1d\x81\x22\x29\x21\x9f\x2b\x1c\x1d\xb0\x02\x88\x1b\x1d\x02"
  "\x22\x29\x21\x9f\x2b\x1c\x1d\xb0\x02\x88\x07\x1b\x80\xc1\x0e\x1c"
  "\x24\x22\x29\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02"
  "\x88\x84\x82\x28\x0d\x1c\x23\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02"
  "\x88\x08\x81\x86\x84\x28\x0d\x28\x0d\x28\x0d\x1c\x23\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\xc1\x1c\x1b"
  "\x85\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\xc2\x1c\x1b"
  "\x85\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\xc3\x1c\x1d"
  "\x1b\x85\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b\x1b"
  "\x86\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b\x1d\x1b"
  "\x86\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x80\x1b\x1b"
  "\x85\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b"
  "\x1b\x85\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88"
  "\x86\x1b\x02\xc1\x1c\x07\x1b\x85\xc1\x1c\x08\x80\x1b\x83\x28\x0d"
  "\x1c\x23\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88"
  "\x08\x80\x81\x1b\x82\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x21"
  "\x17\x2b\x1c\x1d\xb0\x02\x88\x08\x07\x22\x29\x22\x29\x21\x17\x2b"
  "\x1c\x1d\xb0\x02\x88\x1b\x08\x80\x1b\x1b\x85\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02"
  "\x88\x1b\x1b\x08\x02\x1b\x80\x83\x86\x1b\x85\x81\x1b\x82\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b\x1b\x08\x02\x1b\x80\x83\x86"
  "\x1b\x85\x81\x1b\x82\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d"
  "\xb0\x02\x88\x1b\x1b\x08\x02\x1b\x80\x83\x86\x1b\x85\x81\x1b\x82"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b\x1b"
  "\x08\x02\x1b\x80\x83\x86\x1b\x85\x81\x1b\x82\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x06"
  "\x09\x1b\x1b\x85\x28\x0d\x28\x0d\x1c\x28\x0d\x1c\x28\x0d\x1c\x28"
  "\x0d\x1c\x23\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x86\x1b\x1b"
  "\x85\x28\x1b\x28\x0d\x1c\x23\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b\x86\x02"
  "\x1b\x1b\x08\x1b\x80\x81\x84\x1b\x1b\x85\x28\x1b\x28\x0d\x1c\x28"
  "\x1b\x23\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b\x1b"
  "\x80\x1b\x86\x02\x1b\x1b\x08\x81\x84\x1b\x1b\x85\x28\x1b\x28\x1b"
  "\x28\x1b\x28\x1b\x28\x1b\x23\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b"
  "\x1b\x86\x1b\x82\x80\x1b\x08\x83\x1b\x1b\x85\x28\x1b\x28\x1b\x28"
  "\x0d\x28\x0d\x23\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x21\x17\x2b\x1c\x1d\xb0\x02\x88\x1b\x1b"
  "\x08\x1b\x84\x28\x0d\x1c\x28\x0d\x1c\x28\x0d\x1c\x28\x0d\x1c\x23"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29"
  "\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x21\x17"
  "\x2b\x1c\x1d\xb0\x02\x88\x1b\x80\x1b\x1b\x85\x28\x0d\x1c\x23\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x21"
  "\x17\x2b\x1c\x1d\xb0\x02\x88\x86\x1b\x80\x08\x1b\x1b\x85\x28\x1b"
  "\x23\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x21\x17\x2b\x1c\x17\x1c\x88\x1b\x1b\x1b\x2a\x1b\x2a"
  "\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a"
  "\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a"
  "\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a"
  "\x17\x1b\x1b\x0d\x1b\x1b\x1b\x1b\x1b\x0d\x0d\x0d\x0d\x1b\x1b\x1b"
  "\x0d\x0d\x0d\x0d\x0d\x0d\x0d\x0d\x1b\x1b\x0d\x17\x1b\x0d\x0d\x0d"
  "\x0d\x0d\x0d\x0d\x0d\x0d\x17\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b"
  "\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x1b\x2a\x17\xc3\x0d\x1c\x0c\x0d\x0d"
  "\x0d\x0d\x0d\x0d\x0d\x08\x8e\xb1\x2a\xb2\x2a\xb3\x2a\xb4\x2a\xb5"
  "\x2a\xb6\x2a\x08\xb7\x2a\x28\x0d\x28\x0d\x28\x0d\x26\x1b\x24\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22\x29\x22"
  "\x29\x22\x29\x22\x29\x22\x29\x22\x29\x21\x17\x02\x57\x2f\x55\x73"
  "\x65\x72\x73\x2f\x63\x70\x68\x2f\x53\x6f\x66\x74\x77\x61\x72\x65"
  "\x2f\x6d\x69\x74\x2d\x73\x63\x68\x65\x6d\x65\x2f\x72\x65\x6c\x65"
  "\x61\x73\x65\x2d\x39\x2e\x32\x2f\x6d\x69\x74\x2d\x73\x63\x68\x65"
  "\x6d\x65\x2d\x63\x2d\x39\x2e\x32\x2f\x73\x72\x63\x2f\x72\x75\x6e"
  "\x74\x69\x6d\x65\x2f\x2e\x2f\x67\x65\x6e\x63\x61\x63\x68\x65\x2e"
  "\x69\x6e\x66\x15\x23\x5b\x70\x75\x72\x69\x66\x69\x63\x61\x74\x69"
  "\x6f\x6e\x2d\x72\x6f\x6f\x74\x5d\x02\x0e\x04\x82\x02\x03\x02\x0f"
  "\x04\x82\x02\x03\x02\x10\x04\x82\x02\x03\x02\x11\x04\x82\x02\x03"
  "\x02\x01\x12\x04\x82\x02\x03\x02\x01\x13\x04\x82\x02\x03\x02\x08"
  "\x14\x04\x82\x02\x03\x02\x09\x0c\x25\x72\x65\x63\x6f\x72\x64\x2d"
  "\x72\x65\x66\x09\x15\x04\x83\x04\x03\x0a\x02\x0a\x09\x16\x04\x83"
  "\x04\x03\x0b\x02\x0b\x09\x17\x04\x83\x04\x03\x0c\x02\x0c\x09\x18"
  "\x04\x83\x04\x03\x0d\x02\x0d\x09\x19\x04\x83\x04\x03\x0e\x02\x0e"
  "\x09\x1a\x04\x83\x04\x03\x0f\x02\x0f\x09\x08\x1b\x04\x83\x04\x03"
  "\x10\x02\x10\x0d\x25\x72\x65\x63\x6f\x72\x64\x2d\x73\x65\x74\x21"
  "\x11\x02\x1c\x04\x84\x06\x03\x12\x02\x11\x11\x02\x08\x1d\x04\x84"
  "\x06\x03\x13\x02\x12\x09\x0f\x25\x72\x65\x63\x6f\x72\x64\x2d\x6c"
  "\x65\x6e\x67\x74\x68\x07\x2e\x74\x61\x67\x2e\x31\x14\x02\x21\x0a"
  "\x81\x85\x02\x20\x08\x81\x83\x02\x1f\x06\x81\x83\x02\x1e\x04\x83"
  "\x04\x09\x12\x15\x02\x13\x05\x0b\x6d\x61\x6b\x65\x2d\x63\x61\x63"
  "\x68\x65\x16\x02\x22\x04\x83\x04\x03\x0b\x17\x02\x14\x04\x0a\x6d"
  "\x61\x6b\x65\x2d\x6c\x69\x73\x74\x04\x0c\x6d\x61\x6b\x65\x2d\x76"
  "\x65\x63\x74\x6f\x72\x09\x0c\x25\x6d\x61\x6b\x65\x2d\x63\x61\x63"
  "\x68\x65\x18\x04\x26\x0a\x81\x8f\x02\x25\x08\x81\x91\x02\x24\x06"
  "\x81\x8f\x02\x23\x04\x85\x08\x09\x17\x19\x02\x15\x0e\x76\x65\x63"
  "\x74\x6f\x72\x2d\x6c\x65\x6e\x67\x74\x68\x1a\x09\x28\x06\x81\x83"
  "\x02\x27\x04\x83\x04\x05\x0b\x1b\x02\x16\x0b\x76\x65\x63\x74\x6f"
  "\x72\x2d\x72\x65\x66\x1c\x09\x2a\x06\x81\x85\x02\x29\x04\x84\x06"
  "\x05\x0b\x1d\x02\x17\x0c\x76\x65\x63\x74\x6f\x72\x2d\x73\x65\x74"
  "\x21\x1e\x02\x09\x2c\x06\x81\x87\x02\x2b\x04\x85\x08\x05\x0c\x1f"
  "\x02\x18\x1c\x09\x2e\x06\x81\x85\x02\x2d\x04\x84\x06\x05\x0b\x20"
  "\x02\x19\x1e\x02\x09\x30\x06\x81\x87\x02\x2f\x04\x85\x08\x05\x0c"
  "\x21\x02\x1a\x1a\x09\x33\x08\x81\x85\x02\x32\x06\x81\x85\x02\x31"
  "\x04\x84\x06\x07\x0e\x22\x02\x1b\x1a\x09\x36\x08\x81\x89\x02\x35"
  "\x06\x81\x89\x02\x34\x04\x85\x08\x07\x0d\x23\x02\x1c\x1a\x08\x04"
  "\x63\x64\x72\x24\x1c\x04\x63\x61\x72\x25\x09\x04\x1b\x63\x6f\x6d"
  "\x70\x75\x74\x65\x2d\x70\x72\x69\x6d\x61\x72\x79\x2d\x63\x61\x63"
  "\x68\x65\x2d\x6c\x69\x6e\x65\x26\x02\x49\x28\x81\x87\x02\x48\x26"
  "\x81\x87\x02\x47\x24\x81\x87\x02\x46\x22\x81\x87\x02\x45\x20\x81"
  "\x87\x02\x44\x1e\x81\x85\x02\x43\x1c\x81\x85\x02\x42\x1a\x81\x85"
  "\x02\x41\x18\x81\x85\x02\x40\x16\x81\x89\x02\x3f\x14\x81\x89\x02"
  "\x3e\x12\x81\x87\x02\x3d\x10\x81\x87\x02\x3c\x0e\x81\x87\x02\x3b"
  "\x0c\x81\x85\x02\x3a\x0a\x81\x85\x02\x39\x08\x81\x87\x02\x38\x06"
  "\x81\x85\x02\x37\x04\x84\x06\x27\x39\x27\x02\x1d\x09\x4e\x0c\x81"
  "\x8d\x02\x4d\x0a\x81\x8d\x02\x4c\x08\x81\x87\x02\x4b\x06\x81\x85"
  "\x02\x4a\x04\x84\x06\x0b\x13\x28\x02\x1e\x50\x06\x81\x85\x02\x4f"
  "\x04\x84\x06\x05\x0a\x29\x02\x1f\x1c\x1a\x09\x57\x10\x81\x89\x02"
  "\x56\x0e\x81\x89\x02\x55\x0c\x81\x89\x02\x54\x0a\x81\x8b\x02\x53"
  "\x08\x81\x83\x02\x52\x06\x81\x83\x02\x51\x04\x83\x04\x0f\x18\x2a"
  "\x02\x20\x24\x25\x08\x1a\x1c\x09\x78\x44\x81\x87\x02\x77\x42\x81"
  "\x87\x02\x76\x40\x81\x87\x02\x75\x3e\x81\x87\x02\x74\x3c\x81\x87"
  "\x02\x73\x3a\x81\x8b\x02\x72\x38\x81\x8b\x02\x71\x36\x81\x8b\x02"
  "\x70\x34\x81\x8b\x02\x6f\x32\x81\x8b\x02\x6e\x30\x81\x8b\x02\x6d"
  "\x2e\x81\x8b\x02\x6c\x2c\x81\x8b\x02\x6b\x2a\x81\x8b\x02\x6a\x28"
  "\x81\x8b\x02\x69\x26\x81\x8b\x02\x68\x24\x81\x89\x02\x67\x22\x81"
  "\x8d\x02\x66\x20\x81\x8d\x02\x65\x1e\x81\x8b\x02\x64\x1c\x81\x89"
  "\x02\x63\x1a\x81\x89\x02\x62\x18\x81\x85\x02\x61\x16\x81\x85\x02"
  "\x60\x14\x81\x87\x02\x5f\x12\x81\x87\x02\x5e\x10\x81\x85\x02\x5d"
  "\x0e\x81\x85\x02\x5c\x0c\x81\x87\x02\x5b\x0a\x81\x87\x02\x5a\x08"
  "\x81\x87\x02\x59\x06\x81\x85\x02\x58\x04\x84\x06\x43\x53\x2b\x02"
  "\x21\x24\x25\x08\x1a\x1c\x09\xb3\x01\x78\x81\x89\x02\xb2\x01\x76"
  "\x81\x89\x02\xb1\x01\x74\x81\x89\x02\xb0\x01\x72\x81\x89\x02\xaf"
  "\x01\x70\x81\x89\x02\xae\x01\x6e\x81\x89\x02\xad\x01\x6c\x81\x89"
  "\x02\xac\x01\x6a\x81\x8d\x02\xab\x01\x68\x81\x8d\x02\xaa\x01\x66"
  "\x81\x8d\x02\xa9\x01\x64\x81\x8d\x02\xa8\x01\x62\x81\x8d\x02\xa7"
  "\x01\x60\x81\x8d\x02\xa6\x01\x5e\x81\x8d\x02\xa5\x01\x5c\x81\x8d"
  "\x02\xa4\x01\x5a\x81\x8d\x02\xa3\x01\x58\x81\x8d\x02\xa2\x01\x56"
  "\x81\x8d\x02\xa1\x01\x54\x81\x8f\x02\xa0\x01\x52\x81\x8f\x02\x9f"
  "\x01\x50\x81\x8d\x02\x9e\x01\x4e\x81\x8d\x02\x9d\x01\x4c\x81\x8b"
  "\x02\x9c\x01\x4a\x81\x91\x02\x9b\x01\x48\x81\x91\x02\x9a\x01\x46"
  "\x81\x8f\x02\x99\x01\x44\x81\x8f\x02\x98\x01\x42\x81\x8d\x02\x97"
  "\x01\x40\x81\x8b\x02\x96\x01\x3e\x81\x8b\x02\x95\x01\x3c\x81\x87"
  "\x02\x94\x01\x3a\x81\x87\x02\x93\x01\x38\x81\x8b\x02\x92\x01\x36"
  "\x81\x8b\x02\x91\x01\x34\x81\x89\x02\x90\x01\x32\x81\x89\x02\x8f"
  "\x01\x30\x81\x87\x02\x8e\x01\x2e\x81\x87\x02\x8d\x01\x2c\x81\x89"
  "\x02\x8c\x01\x2a\x81\x8b\x02\x8b\x01\x28\x81\x8b\x02\x8a\x01\x26"
  "\x81\x89\x02\x89\x01\x24\x81\x89\x02\x88\x01\x22\x81\x87\x02\x87"
  "\x01\x20\x81\x87\x02\x86\x01\x1e\x81\x89\x02\x85\x01\x1c\x81\x8b"
  "\x02\x84\x01\x1a\x81\x8b\x02\x83\x01\x18\x81\x89\x02\x82\x01\x16"
  "\x81\x89\x02\x81\x01\x14\x81\x87\x02\x80\x01\x12\x81\x87\x02\x7f"
  "\x10\x81\x89\x02\x7e\x0e\x81\x8b\x02\x7d\x0c\x81\x8b\x02\x7c\x0a"
  "\x81\x89\x02\x7b\x08\x81\x89\x02\x7a\x06\x81\x87\x02\x79\x04\x85"
  "\x08\x77\x87\x01\x2c\x02\x22\x24\x25\x08\x1a\x1c\x09\xfe\x01\x98"
  "\x01\x81\x8b\x02\xfd\x01\x96\x01\x81\x8b\x02\xfc\x01\x94\x01\x81"
  "\x8b\x02\xfb\x01\x92\x01\x81\x8b\x02\xfa\x01\x90\x01\x81\x8b\x02"
  "\xf9\x01\x8e\x01\x81\x8b\x02\xf8\x01\x8c\x01\x81\x8b\x02\xf7\x01"
  "\x8a\x01\x81\x8b\x02\xf6\x01\x88\x01\x81\x8b\x02\xf5\x01\x86\x01"
  "\x81\x8f\x02\xf4\x01\x84\x01\x81\x8f\x02\xf3\x01\x82\x01\x81\x8f"
  "\x02\xf2\x01\x80\x01\x81\x8f\x02\xf1\x01\x7e\x81\x8f\x02\xf0\x01"
  "\x7c\x81\x8f\x02\xef\x01\x7a\x81\x8f\x02\xee\x01\x78\x81\x8f\x02"
  "\xed\x01\x76\x81\x8f\x02\xec\x01\x74\x81\x8f\x02\xeb\x01\x72\x81"
  "\x8f\x02\xea\x01\x70\x81\x8f\x02\xe9\x01\x6e\x81\x8f\x02\xe8\x01"
  "\x6c\x81\x91\x02\xe7\x01\x6a\x81\x91\x02\xe6\x01\x68\x81\x91\x02"
  "\xe5\x01\x66\x81\x91\x02\xe4\x01\x64\x81\x8f\x02\xe3\x01\x62\x81"
  "\x8f\x02\xe2\x01\x60\x81\x8d\x02\xe1\x01\x5e\x81\x93\x02\xe0\x01"
  "\x5c\x81\x93\x02\xdf\x01\x5a\x81\x93\x02\xde\x01\x58\x81\x93\x02"
  "\xdd\x01\x56\x81\x91\x02\xdc\x01\x54\x81\x91\x02\xdb\x01\x52\x81"
  "\x8f\x02\xda\x01\x50\x81\x8d\x02\xd9\x01\x4e\x81\x8d\x02\xd8\x01"
  "\x4c\x81\x89\x02\xd7\x01\x4a\x81\x89\x02\xd6\x01\x48\x81\x8d\x02"
  "\xd5\x01\x46\x81\x8d\x02\xd4\x01\x44\x81\x8d\x02\xd3\x01\x42\x81"
  "\x8d\x02\xd2\x01\x40\x81\x8b\x02\xd1\x01\x3e\x81\x8b\x02\xd0\x01"
  "\x3c\x81\x89\x02\xcf\x01\x3a\x81\x89\x02\xce\x01\x38\x81\x8b\x02"
  "\xcd\x01\x36\x81\x8d\x02\xcc\x01\x34\x81\x8d\x02\xcb\x01\x32\x81"
  "\x8d\x02\xca\x01\x30\x81\x8d\x02\xc9\x01\x2e\x81\x8b\x02\xc8\x01"
  "\x2c\x81\x8b\x02\xc7\x01\x2a\x81\x89\x02\xc6\x01\x28\x81\x89\x02"
  "\xc5\x01\x26\x81\x8b\x02\xc4\x01\x24\x81\x8d\x02\xc3\x01\x22\x81"
  "\x8d\x02\xc2\x01\x20\x81\x8d\x02\xc1\x01\x1e\x81\x8d\x02\xc0\x01"
  "\x1c\x81\x8b\x02\xbf\x01\x1a\x81\x8b\x02\xbe\x01\x18\x81\x89\x02"
  "\xbd\x01\x16\x81\x89\x02\xbc\x01\x14\x81\x8b\x02\xbb\x01\x12\x81"
  "\x8d\x02\xba\x01\x10\x81\x8d\x02\xb9\x01\x0e\x81\x8d\x02\xb8\x01"
  "\x0c\x81\x8d\x02\xb7\x01\x0a\x81\x8b\x02\xb6\x01\x08\x81\x8b\x02"
  "\xb5\x01\x06\x81\x89\x02\xb4\x01\x04\x86\x0a\x97\x01\xa7\x01\x2d"
  "\x02\x23\x24\x25\x08\x1a\x1c\x09\xe4\x02\xce\x01\x81\x8d\x02\xe3"
  "\x02\xcc\x01\x81\x8d\x02\xe2\x02\xca\x01\x81\x8d\x02\xe1\x02\xc8"
  "\x01\x81\x8d\x02\xe0\x02\xc6\x01\x81\x8d\x02\xdf\x02\xc4\x01\x81"
  "\x8d\x02\xde\x02\xc2\x01\x81\x8d\x02\xdd\x02\xc0\x01\x81\x8d\x02"
  "\xdc\x02\xbe\x01\x81\x8d\x02\xdb\x02\xbc\x01\x81\x8d\x02\xda\x02"
  "\xba\x01\x81\x8d\x02\xd9\x02\xb8\x01\x81\x91\x02\xd8\x02\xb6\x01"
  "\x81\x91\x02\xd7\x02\xb4\x01\x81\x91\x02\xd6\x02\xb2\x01\x81\x91"
  "\x02\xd5\x02\xb0\x01\x81\x91\x02\xd4\x02\xae\x01\x81\x91\x02\xd3"
  "\x02\xac\x01\x81\x91\x02\xd2\x02\xaa\x01\x81\x91\x02\xd1\x02\xa8"
  "\x01\x81\x91\x02\xd0\x02\xa6\x01\x81\x91\x02\xcf\x02\xa4\x01\x81"
  "\x91\x02\xce\x02\xa2\x01\x81\x91\x02\xcd\x02\xa0\x01\x81\x91\x02"
  "\xcc\x02\x9e\x01\x81\x91\x02\xcb\x02\x9c\x01\x81\x91\x02\xca\x02"
  "\x9a\x01\x81\x95\x02\xc9\x02\x98\x01\x81\x95\x02\xc8\x02\x96\x01"
  "\x81\x93\x02\xc7\x02\x94\x01\x81\x93\x02\xc6\x02\x92\x01\x81\x93"
  "\x02\xc5\x02\x90\x01\x81\x93\x02\xc4\x02\x8e\x01\x81\x91\x02\xc3"
  "\x02\x8c\x01\x81\x91\x02\xc2\x02\x8a\x01\x81\x8f\x02\xc1\x02\x88"
  "\x01\x81\x97\x02\xc0\x02\x86\x01\x81\x97\x02\xbf\x02\x84\x01\x81"
  "\x95\x02\xbe\x02\x82\x01\x81\x95\x02\xbd\x02\x80\x01\x81\x95\x02"
  "\xbc\x02\x7e\x81\x95\x02\xbb\x02\x7c\x81\x93\x02\xba\x02\x7a\x81"
  "\x93\x02\xb9\x02\x78\x81\x91\x02\xb8\x02\x76\x81\x8f\x02\xb7\x02"
  "\x74\x81\x8f\x02\xb6\x02\x72\x81\x8b\x02\xb5\x02\x70\x81\x8b\x02"
  "\xb4\x02\x6e\x81\x91\x02\xb3\x02\x6c\x81\x91\x02\xb2\x02\x6a\x81"
  "\x8f\x02\xb1\x02\x68\x81\x8f\x02\xb0\x02\x66\x81\x8f\x02\xaf\x02"
  "\x64\x81\x8f\x02\xae\x02\x62\x81\x8d\x02\xad\x02\x60\x81\x8d\x02"
  "\xac\x02\x5e\x81\x8b\x02\xab\x02\x5c\x81\x8b\x02\xaa\x02\x5a\x81"
  "\x8d\x02\xa9\x02\x58\x81\x91\x02\xa8\x02\x56\x81\x91\x02\xa7\x02"
  "\x54\x81\x8f\x02\xa6\x02\x52\x81\x8f\x02\xa5\x02\x50\x81\x8f\x02"
  "\xa4\x02\x4e\x81\x8f\x02\xa3\x02\x4c\x81\x8d\x02\xa2\x02\x4a\x81"
  "\x8d\x02\xa1\x02\x48\x81\x8b\x02\xa0\x02\x46\x81\x8b\x02\x9f\x02"
  "\x44\x81\x8d\x02\x9e\x02\x42\x81\x91\x02\x9d\x02\x40\x81\x91\x02"
  "\x9c\x02\x3e\x81\x8f\x02\x9b\x02\x3c\x81\x8f\x02\x9a\x02\x3a\x81"
  "\x8f\x02\x99\x02\x38\x81\x8f\x02\x98\x02\x36\x81\x8d\x02\x97\x02"
  "\x34\x81\x8d\x02\x96\x02\x32\x81\x8b\x02\x95\x02\x30\x81\x8b\x02"
  "\x94\x02\x2e\x81\x8d\x02\x93\x02\x2c\x81\x91\x02\x92\x02\x2a\x81"
  "\x91\x02\x91\x02\x28\x81\x8f\x02\x90\x02\x26\x81\x8f\x02\x8f\x02"
  "\x24\x81\x8f\x02\x8e\x02\x22\x81\x8f\x02\x8d\x02\x20\x81\x8d\x02"
  "\x8c\x02\x1e\x81\x8d\x02\x8b\x02\x1c\x81\x8b\x02\x8a\x02\x1a\x81"
  "\x8b\x02\x89\x02\x18\x81\x8d\x02\x88\x02\x16\x81\x91\x02\x87\x02"
  "\x14\x81\x91\x02\x86\x02\x12\x81\x8f\x02\x85\x02\x10\x81\x8f\x02"
  "\x84\x02\x0e\x81\x8f\x02\x83\x02\x0c\x81\x8f\x02\x82\x02\x0a\x81"
  "\x8d\x02\x81\x02\x08\x81\x8d\x02\x80\x02\x06\x81\x8b\x02\xff\x01"
  "\x04\x87\x0c\xcd\x01\xdd\x01\x2e\x02\x24\x03\x2e\x38\x1a\x09\x03"
  "\x10\x6c\x69\x73\x74\x2d\x3e\x77\x65\x61\x6b\x2d\x6c\x69\x73\x74"
  "\x05\x17\x66\x69\x6c\x6c\x2d\x63\x61\x63\x68\x65\x2d\x69\x66\x2d"
  "\x70\x6f\x73\x73\x69\x62\x6c\x65\x2f\x03\x0c\x63\x61\x63\x68\x65"
  "\x2d\x63\x6f\x75\x6e\x74\x30\x05\x0d\x61\x64\x6a\x75\x73\x74\x2d"
  "\x63\x61\x63\x68\x65\x31\x05\x0d\x65\x78\x70\x61\x6e\x64\x2d\x63"
  "\x61\x63\x68\x65\x32\x06\xed\x02\x14\x81\x8b\x02\xec\x02\x12\x81"
  "\x8d\x02\xeb\x02\x10\x81\x8f\x02\xea\x02\x0e\x81\x8d\x02\xe9\x02"
  "\x0c\x81\x8d\x02\xe8\x02\x0a\x81\x8d\x02\xe7\x02\x08\x81\x89\x02"
  "\xe6\x02\x06\x81\x87\x02\xe5\x02\x04\x85\x08\x13\x26\x33\x02\x25"
  "\x1e\x09\x04\x26\x05\x15\x66\x69\x6e\x64\x2d\x66\x72\x65\x65\x2d"
  "\x63\x61\x63\x68\x65\x2d\x6c\x69\x6e\x65\x34\x03\xf4\x02\x10\x81"
  "\x89\x02\xf3\x02\x0e\x81\x89\x02\xf2\x02\x0c\x81\x89\x02\xf1\x02"
  "\x0a\x81\x89\x02\xf0\x02\x08\x81\x89\x02\xef\x02\x06\x81\x87\x02"
  "\xee\x02\x04\x85\x08\x0f\x1b\x35\x02\x26\x1c\x08\x24\x25\x11\x1a"
  "\x09\x05\x16\x04\x16\x63\x61\x63\x68\x65\x2d\x65\x6e\x74\x72\x79"
  "\x2d\x72\x65\x75\x73\x61\x62\x6c\x65\x3f\x36\x05\x2f\x04\x8e\x03"
  "\x36\x81\x85\x02\x8d\x03\x34\x81\x85\x02\x8c\x03\x32\x81\x85\x02"
  "\x8b\x03\x30\x81\x85\x02\x8a\x03\x2e\x81\x87\x02\x89\x03\x2c\x81"
  "\x89\x02\x88\x03\x2a\x81\x89\x02\x87\x03\x28\x81\x87\x02\x86\x03"
  "\x26\x81\x87\x02\x85\x03\x24\x81\x85\x02\x84\x03\x22\x81\x85\x02"
  "\x83\x03\x20\x81\x89\x02\x82\x03\x1e\x81\x89\x02\x81\x03\x1c\x81"
  "\x87\x02\x80\x03\x1a\x81\x87\x02\xff\x02\x18\x81\x85\x02\xfe\x02"
  "\x16\x81\x87\x02\xfd\x02\x14\x81\x85\x02\xfc\x02\x12\x81\x83\x02"
  "\xfb\x02\x10\x81\x83\x02\xfa\x02\x0e\x81\x89\x02\xf9\x02\x0c\x81"
  "\x8f\x02\xf8\x02\x0a\x81\x8d\x02\xf7\x02\x08\x81\x87\x02\xf6\x02"
  "\x06\x81\x87\x02\xf5\x02\x04\x85\x08\x35\x4c\x37\x02\x27\x11\x1e"
  "\x1c\x08\x24\x25\x1a\x09\x05\x16\x04\x36\x04\x26\x05\x34\x05\x31"
  "\x06\xb6\x03\x52\x81\x8b\x02\xb5\x03\x50\x81\x8b\x02\xb4\x03\x4e"
  "\x81\x8b\x02\xb3\x03\x4c\x81\x8b\x02\xb2\x03\x4a\x81\x8b\x02\xb1"
  "\x03\x48\x81\x8f\x02\xb0\x03\x46\x81\x8f\x02\xaf\x03\x44\x81\x8d"
  "\x02\xae\x03\x42\x81\x8d\x02\xad\x03\x40\x81\x8b\x02\xac\x03\x3e"
  "\x81\x8b\x02\xab\x03\x3c\x81\x8b\x02\xaa\x03\x3a\x81\x8b\x02\xa9"
  "\x03\x38\x81\x8b\x02\xa8\x03\x36\x81\x8b\x02\xa7\x03\x34\x81\x89"
  "\x02\xa6\x03\x32\x81\x87\x02\xa5\x03\x30\x81\x87\x02\xa4\x03\x2e"
  "\x81\x87\x02\xa3\x03\x2c\x81\x87\x02\xa2\x03\x2a\x81\x89\x02\xa1"
  "\x03\x28\x81\x91\x02\xa0\x03\x26\x85\x08\x9f\x03\x24\x81\x8b\x02"
  "\x9e\x03\x22\x81\x8b\x02\x9d\x03\x20\x81\x89\x02\x9c\x03\x1e\x81"
  "\x89\x02\x9b\x03\x1c\x81\x87\x02\x9a\x03\x1a\x81\x87\x02\x99\x03"
  "\x18\x81\x8b\x02\x98\x03\x16\x81\x8b\x02\x97\x03\x14\x81\x89\x02"
  "\x96\x03\x12\x81\x89\x02\x95\x03\x10\x81\x87\x02\x94\x03\x0e\x81"
  "\x89\x02\x93\x03\x0c\x81\x97\x02\x92\x03\x0a\x81\x95\x02\x91\x03"
  "\x08\x81\x87\x02\x90\x03\x06\x81\x87\x02\x8f\x03\x04\x85\x08\x51"
  "\x6d\x11\x02\x28\x24\x25\x1e\x1a\x1c\x09\x04\x36\x04\x26\x03\x13"
  "\x77\x69\x74\x68\x6f\x75\x74\x2d\x69\x6e\x74\x65\x72\x72\x75\x70"
  "\x74\x73\x03\x07\x72\x61\x6e\x64\x6f\x6d\x05\xdf\x03\x54\x81\x89"
  "\x02\xde\x03\x52\x81\x89\x02\xdd\x03\x50\x81\x8b\x02\xdc\x03\x4e"
  "\x81\x89\x02\xdb\x03\x4c\x81\x89\x02\xda\x03\x4a\x81\x89\x02\xd9"
  "\x03\x48\x81\x8b\x02\xd8\x03\x46\x81\x89\x02\xd7\x03\x44\x81\x89"
  "\x02\xd6\x03\x42\x81\x87\x02\xd5\x03\x40\x81\x87\x02\xd4\x03\x3e"
  "\x81\x87\x02\xd3\x03\x3c\x81\x87\x02\xd2\x03\x3a\x81\x87\x02\xd1"
  "\x03\x38\x81\x87\x02\xd0\x03\x36\x81\x83\x02\xcf\x03\x34\x81\x99"
  "\x02\xce\x03\x32\x81\x99\x02\xcd\x03\x30\x81\x99\x02\xcc\x03\x2e"
  "\x81\x99\x02\xcb\x03\x2c\x81\x99\x02\xca\x03\x2a\x81\x99\x02\xc9"
  "\x03\x28\x81\x99\x02\xc8\x03\x26\x81\x99\x02\xc7\x03\x24\x81\x95"
  "\x02\xc6\x03\x22\x81\x83\x02\xc5\x03\x20\x81\x99\x02\xc4\x03\x1e"
  "\x81\x99\x02\xc3\x03\x1c\x81\x97\x02\xc2\x03\x1a\x81\x97\x02\xc1"
  "\x03\x18\x81\x95\x02\xc0\x03\x16\x81\x93\x02\xbf\x03\x14\x81\x93"
  "\x02\xbe\x03\x12\x81\x91\x02\xbd\x03\x10\x81\x8f\x02\xbc\x03\x0e"
  "\x81\x8f\x02\xbb\x03\x0c\x81\x87\x02\xba\x03\x0a\x81\x87\x02\xb9"
  "\x03\x08\x81\x8b\x02\xb8\x03\x06\x81\x8b\x02\xb7\x03\x04\x85\x08"
  "\x53\x6b\x1e\x02\x29\x24\x25\x09\x04\x1c\x74\x68\x65\x72\x65\x2d"
  "\x65\x78\x69\x73\x74\x73\x2d\x61\x2d\x63\x61\x63\x68\x65\x2d\x65"
  "\x6e\x74\x72\x79\x3f\x25\x03\x0d\x63\x61\x63\x68\x65\x2d\x3e\x61"
  "\x6c\x69\x73\x74\x24\x03\x0a\x6e\x65\x77\x2d\x63\x61\x63\x68\x65"
  "\x38\x05\x0b\x66\x69\x6c\x6c\x2d\x63\x61\x63\x68\x65\x39\x05\xee"
  "\x03\x20\x81\x89\x02\xed\x03\x1e\x81\x89\x02\xec\x03\x1c\x81\x8d"
  "\x02\xeb\x03\x1a\x81\x8d\x02\xea\x03\x18\x81\x8b\x02\xe9\x03\x16"
  "\x81\x8b\x02\xe8\x03\x14\x81\x8b\x02\xe7\x03\x12\x81\x8d\x02\xe6"
  "\x03\x10\x81\x8d\x02\xe5\x03\x0e\x81\x89\x02\xe4\x03\x0c\x81\x87"
  "\x02\xe3\x03\x0a\x81\x89\x02\xe2\x03\x08\x81\x85\x02\xe1\x03\x06"
  "\x81\x85\x02\xe0\x03\x04\x84\x06\x1f\x30\x3a\x02\x2a\x1c\x1a\x09"
  "\x03\x10\x77\x65\x61\x6b\x2d\x6c\x69\x73\x74\x2d\x3e\x6c\x69\x73"
  "\x74\x3b\x02\xf6\x03\x12\x81\x8d\x02\xf5\x03\x10\x81\x8b\x02\xf4"
  "\x03\x0e\x81\x89\x02\xf3\x03\x0c\x81\x89\x02\xf2\x03\x0a\x81\x89"
  "\x02\xf1\x03\x08\x81\x85\x02\xf0\x03\x06\x81\x85\x02\xef\x03\x04"
  "\x84\x06\x11\x1c\x3c\x02\x2b\x1c\x1a\x09\x03\x3b\x02\xff\x03\x14"
  "\x81\x8b\x02\xfe\x03\x12\x81\x8b\x02\xfd\x03\x10\x81\x89\x02\xfc"
  "\x03\x0e\x81\x89\x02\xfb\x03\x0c\x81\x89\x02\xfa\x03\x0a\x81\x8d"
  "\x02\xf9\x03\x08\x81\x83\x02\xf8\x03\x06\x81\x83\x02\xf7\x03\x04"
  "\x83\x04\x13\x20\x3b\x2b\x1c\x1c\x14\x3b\x04\x3c\x04\x3a\x04\x1e"
  "\x04\x11\x04\x37\x04\x35\x04\x33\x04\x2e\x04\x2d\x04\x2c\x04\x2b"
  "\x04\x2a\x04\x29\x04\x28\x04\x27\x04\x23\x04\x22\x04\x21\x04\x20"
  "\x04\x1f\x04\x1d\x04\x1b\x04\x19\x04\x17\x04\x15\x04\x1b\x24\x25"
  "\x14\x70\x75\x72\x67\x65\x2d\x63\x61\x63\x68\x65\x2d\x65\x6e\x74"
  "\x72\x69\x65\x73\x34\x32\x31\x2f\x39\x0e\x70\x72\x6f\x62\x65\x2d"
  "\x63\x61\x63\x68\x65\x2d\x34\x0e\x70\x72\x6f\x62\x65\x2d\x63\x61"
  "\x63\x68\x65\x2d\x33\x0e\x70\x72\x6f\x62\x65\x2d\x63\x61\x63\x68"
  "\x65\x2d\x32\x0e\x70\x72\x6f\x62\x65\x2d\x63\x61\x63\x68\x65\x2d"
  "\x31\x30\x36\x26\x0c\x70\x72\x6f\x62\x65\x2d\x63\x61\x63\x68\x65"
  "\x16\x63\x61\x63\x68\x65\x2d\x6c\x69\x6e\x65\x2d\x73\x65\x70\x61"
  "\x72\x61\x74\x69\x6f\x6e\x10\x63\x61\x63\x68\x65\x2d\x6e\x65\x78"
  "\x74\x2d\x6c\x69\x6e\x65\x16\x73\x65\x74\x2d\x63\x61\x63\x68\x65"
  "\x2d\x6c\x69\x6e\x65\x2d\x76\x61\x6c\x75\x65\x21\x11\x63\x61\x63"
  "\x68\x65\x2d\x6c\x69\x6e\x65\x2d\x76\x61\x6c\x75\x65\x15\x73\x65"
  "\x74\x2d\x63\x61\x63\x68\x65\x2d\x6c\x69\x6e\x65\x2d\x74\x61\x67"
  "\x73\x21\x10\x63\x61\x63\x68\x65\x2d\x6c\x69\x6e\x65\x2d\x74\x61"
  "\x67\x73\x0d\x63\x61\x63\x68\x65\x2d\x6c\x65\x6e\x67\x74\x68\x16"
  "\x38\x07\x63\x61\x63\x68\x65\x3f\x1b\x18\x14\x73\x65\x74\x2d\x63"
  "\x61\x63\x68\x65\x2d\x6f\x76\x65\x72\x66\x6c\x6f\x77\x21\x15\x73"
  "\x65\x74\x2d\x63\x61\x63\x68\x65\x2d\x74\x61\x67\x2d\x69\x6e\x64"
  "\x65\x78\x21\x0f\x63\x61\x63\x68\x65\x2d\x6f\x76\x65\x72\x66\x6c"
  "\x6f\x77\x0d\x63\x61\x63\x68\x65\x2d\x76\x61\x6c\x75\x65\x73\x0b"
  "\x63\x61\x63\x68\x65\x2d\x74\x61\x67\x73\x0d\x63\x61\x63\x68\x65"
  "\x2d\x6e\x2d\x74\x61\x67\x73\x0c\x63\x61\x63\x68\x65\x2d\x6c\x69"
  "\x6d\x69\x74\x0b\x63\x61\x63\x68\x65\x2d\x6d\x61\x73\x6b\x10\x63"
  "\x61\x63\x68\x65\x2d\x74\x61\x67\x2d\x69\x6e\x64\x65\x78\x0a\x13"
  "\x04\x12\x04\x10\x04\x0f\x04\x0e\x04\x0d\x04\x0c\x04\x0b\x04\x0a"
  "\x04\x0a\x11\x6c\x6f\x63\x61\x6c\x2d\x61\x73\x73\x69\x67\x6e\x6d"
  "\x65\x6e\x74\x0a\x72\x74\x64\x3a\x63\x61\x63\x68\x65\x3c\x06\x63"
  "\x61\x63\x68\x65\x0a\x74\x61\x67\x2d\x69\x6e\x64\x65\x78\x05\x6d"
  "\x61\x73\x6b\x06\x6c\x69\x6d\x69\x74\x07\x6e\x2d\x74\x61\x67\x73"
  "\x05\x74\x61\x67\x73\x07\x76\x61\x6c\x75\x65\x73\x09\x6f\x76\x65"
  "\x72\x66\x6c\x6f\x77\x04\x04\x04\x04\x04\x04\x04\x06\x11\x6d\x61"
  "\x6b\x65\x2d\x72\x65\x63\x6f\x72\x64\x2d\x74\x79\x70\x65\x03\x19"
  "\x72\x65\x63\x6f\x72\x64\x2d\x74\x79\x70\x65\x2d\x64\x69\x73\x70"
  "\x61\x74\x63\x68\x2d\x74\x61\x67\x05\x10\x64\x65\x66\x69\x6e\x65"
  "\x2d\x6d\x75\x6c\x74\x69\x70\x6c\x65\x04\x3c\x02\x0d\x1c\x80\x80"
  "\x04\x0c\x1a\x81\x81\x02\x0b\x18\x81\x81\x02\x0a\x16\x81\x85\x02"
  "\x09\x14\x81\x83\x02\x08\x12\x81\x91\x02\x07\x10\x81\x87\x02\x06"
  "\x0e\x81\x83\x02\x05\x0c\x81\x85\x02\x04\x0a\x81\x83\x02\x03\x08"
  "\x81\x85\x02\x02\x06\x81\x87\x02\x01\x04\x81\x83\x02\x1b\x3b";

SCHEME_OBJECT *
gencache_so_data_813832bb378a83bd (entry_count_t dispatch_base)
{
  SCHEME_OBJECT ccb;
  SCHEME_OBJECT * current_block;
  DECLARE_VARIABLES_FOR_DATA ();

  ccb = (unstackify (((unsigned char *) (& (prog_gencache_so_data_813832bb378a83bd [0]))), (sizeof (prog_gencache_so_data_813832bb378a83bd)), dispatch_base));
  current_block = (OBJECT_ADDRESS (ccb));
  return (& (current_block [LABEL_20]));
}

DECLARE_COMPILED_DATA_NS ("gencache.so", gencache_so_data_813832bb378a83bd)

#endif /* !WANT_ONLY_CODE */

DECLARE_DYNAMIC_INITIALIZATION ("gencache.so", "2514a9e65994d628")
